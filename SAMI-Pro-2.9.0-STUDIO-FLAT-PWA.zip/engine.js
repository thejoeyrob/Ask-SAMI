(() => {
  "use strict";
  const $ = (q) => document.querySelector(q),
    $$ = (q) => [...document.querySelectorAll(q)],
    G = window.SamiGeometry,
    LS_KEY = "sami.project.v1";
  const copy = G.copy,
    esc = (s) =>
      String(s ?? "").replace(
        /[&<>"']/g,
        (c) =>
          ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
          })[c],
      );
  const uid = () =>
    window.crypto?.randomUUID?.() ||
    "sami-" +
      Date.now().toString(36) +
      "-" +
      Math.random().toString(36).slice(2);
  const SERVICE_BUFFER_M = 160.9344,
    PLAN_BLEED_DEFAULT = 10;
  const SERVICES = {
    electric: { name: "Underground electricity", color: "#df4141" },
    gas: { name: "Gas", color: "#ce9b00" },
    water: { name: "Water", color: "#1481d4" },
    drainage: { name: "Waste / drainage", color: "#826648" },
    telecom: { name: "Telecoms", color: "#bd661d" },
    ohl: { name: "Overhead power lines", color: "#c3429e" },
    ecology: { name: "Ecology / habitat", color: "#32965d", area: true },
    sssi: { name: "SSSI / protected site", color: "#428a47", area: true },
    tpo: { name: "Tree protection order", color: "#227c6d", area: true },
    heritage: { name: "Listed / heritage asset", color: "#9659a3", area: true },
    archaeology: {
      name: "Archaeology / scheduled monument",
      color: "#b96c50",
      area: true,
    },
    flood: { name: "Flood constraint", color: "#3f7fbf", area: true },
    conservation: {
      name: "Conservation / protected landscape",
      color: "#5f8b73",
      area: true,
    },
    other: { name: "Other restriction / permit", color: "#697eb6", area: true },
  };
  const HGV_PROFILES = {
    van35: {
      name: "3.5 t commercial vehicle",
      weight: 3.5,
      height: 3.0,
      width: 2.2,
      length: 7.0,
      axles: 2,
    },
    rigid75: {
      name: "7.5 t rigid",
      weight: 7.5,
      height: 3.5,
      width: 2.55,
      length: 8.0,
      axles: 2,
    },
    rigid24: {
      name: "24 t rigid",
      weight: 24,
      height: 4.0,
      width: 2.55,
      length: 10.5,
      axles: 3,
    },
    artic40: {
      name: "40 t · 45 ft artic",
      weight: 40,
      height: 4.2,
      width: 2.55,
      length: 16.5,
      axles: 5,
    },
    custom: {
      name: "Custom HGV profile",
      weight: 18,
      height: 4.0,
      width: 2.55,
      length: 12,
      axles: 3,
    },
  };
  function hgvIssueName(profile, weight) {
    const w = Number(weight);
    if (profile === "artic40")
      return `${Number.isFinite(w) ? w : 40} t / 45 ft articulated vehicle`;
    if (profile === "rigid24")
      return `${Number.isFinite(w) ? w : 24} t rigid HGV`;
    if (profile === "rigid75") return `${Number.isFinite(w) ? w : 7.5} t rigid`;
    if (profile === "van35")
      return `${Number.isFinite(w) ? w : 3.5} t commercial vehicle`;
    return "Custom vehicle profile";
  }
  const DATA_CATALOG = [
    {
      id: "ohl-osm",
      name: "Overhead electricity · representative",
      type: "ohl",
      coverage: "UK / Ireland where mapped",
      source: "OpenStreetMap power=line/minor_line + tower/pole",
      status: "Built-in snapshot updater",
      note: "Representative planning layer only. Verify with network operator and site survey.",
    },
    {
      id: "osm-utilities",
      name: "Mapped public utilities · reference",
      type: "utilities",
      coverage: "Where contributors have mapped them",
      source:
        "OpenStreetMap power=cable / man_made=pipeline / utility features",
      status: "Built-in bounded snapshot",
      note: "Sparse contributor-mapped gas, water, sewer/drainage, electricity and telecom references only. No complete openly licensed UK-wide mains dataset is connected; this is never a safe-dig record.",
    },
    {
      id: "planning-data-constraints",
      name: "Planning constraints · England",
      type: "constraints",
      coverage: "England · dataset coverage varies",
      source: "Planning Data API (MHCLG and contributing authorities/bodies)",
      status: "Built-in bounded snapshot",
      note: "TPO, heritage, conservation, scheduled monuments, SSSI, ancient woodland and flood planning datasets where available.",
    },
    {
      id: "nuar",
      name: "Underground utilities · NUAR",
      type: "utilities",
      coverage: "England, Wales & Northern Ireland",
      source: "National Underground Asset Register",
      status: "Authorised connector required",
      note: "Secure data. SAMI keeps this separate from user observations.",
    },
    {
      id: "nged",
      name: "NGED electricity network assets",
      type: "electric",
      coverage: "NGED licence areas",
      source: "National Grid Electricity Distribution Open Data",
      status: "Data-pack capable",
      note: "Official DNO datasets include overhead/underground lines, poles and towers by voltage.",
    },
    {
      id: "ukpn",
      name: "UK Power Networks infrastructure",
      type: "electric",
      coverage: "London, South East & East of England",
      source: "UK Power Networks Open Data",
      status: "Data-pack capable",
      note: "Open geospatial network infrastructure, including overhead lines, towers and poles.",
    },
    {
      id: "planning-tpo",
      name: "Tree Preservation Orders",
      type: "tpo",
      coverage: "England · participating LPAs",
      source: "Planning Data / local planning authorities",
      status: "Data-pack capable",
      note: "Coverage is expanding; absence must not be taken as proof that no TPO exists.",
    },
    {
      id: "heritage",
      name: "Protected heritage",
      type: "heritage",
      coverage: "England / Scotland / Wales via national bodies",
      source: "Historic England · HES · Cadw",
      status: "Data-pack capable",
      note: "Listed buildings, scheduled monuments and other national designations.",
    },
    {
      id: "ea-flood",
      name: "Flood constraints",
      type: "flood",
      coverage: "England",
      source: "Environment Agency / Defra",
      status: "Data-pack capable",
      note: "Use the current published flood datasets appropriate to the project purpose.",
    },
    {
      id: "ecology",
      name: "Ecology & protected sites",
      type: "ecology",
      coverage: "UK via national environment bodies",
      source: "Natural England / NatureScot / NRW / DAERA",
      status: "Data-pack capable",
      note: "SSSI/ASSI and habitat datasets are jurisdiction-specific.",
    },
    {
      id: "os-rami",
      name: "HGV restrictions & routing",
      type: "routing",
      coverage: "Great Britain",
      source: "Ordnance Survey Routing & Asset Management Information",
      status: "Licensed production source",
      note: "Authoritative routing hazards and turn, height, weight and width restrictions; updated monthly.",
    },
  ];
  const PRODUCTS = {
    lion: {
      name: "Lion Panel",
      length: 2.41,
      width: 3,
      overlap: 0,
      lateralOverlap: 0,
      color: "#b19b39",
    },
    hybrid: {
      name: "Hybrid Panel",
      length: 2.44,
      width: 3,
      overlap: 0,
      lateralOverlap: 0,
      color: "#ac7d31",
    },
    tuff: {
      name: "TuffTrak",
      length: 2.5,
      width: 3,
      overlap: 0,
      lateralOverlap: 0,
      color: "#328ba3",
    },
    sabre: {
      name: "Sabre-X",
      length: 1.8,
      width: 3.8,
      physicalLength: 4,
      physicalWidth: 2,
      overlap: 0,
      lateralOverlap: 0,
      color: "#80938c",
      specialPlacement: true,
    },
    custom: {
      name: "Custom panel",
      length: 3,
      width: 2,
      overlap: 0,
      lateralOverlap: 0,
      color: "#848098",
    },
  };
  const ASSETS = {
    cabin10: {
      name: "10 ft welfare / office cabin",
      length: 3.05,
      width: 2.44,
      category: "Welfare",
      symbol: "CAB",
    },
    cabin20: {
      name: "20 ft welfare / office cabin",
      length: 6.1,
      width: 2.44,
      category: "Welfare",
      symbol: "CAB",
    },
    cabin32: {
      name: "32 ft welfare / office cabin",
      length: 9.75,
      width: 3.0,
      category: "Welfare",
      symbol: "CAB",
    },
    cabin40: {
      name: "40 ft cabin / container",
      length: 12.19,
      width: 2.44,
      category: "Welfare",
      symbol: "CAB",
    },
    toilet: {
      name: "Portable toilet",
      length: 1.2,
      width: 1.2,
      category: "Welfare",
      symbol: "WC",
    },
    storage: {
      name: "20 ft storage container",
      length: 6.1,
      width: 2.44,
      category: "Welfare",
      symbol: "STO",
    },
    rigid: {
      name: "Rigid HGV footprint",
      length: 10.5,
      width: 2.55,
      category: "Vehicles",
      symbol: "HGV",
    },
    artic: {
      name: "45 ft articulated HGV footprint",
      length: 16.5,
      width: 2.55,
      category: "Vehicles",
      symbol: "ART",
    },
    van: {
      name: "3.5 t van footprint",
      length: 7,
      width: 2.2,
      category: "Vehicles",
      symbol: "VAN",
    },
    pickup: {
      name: "Site pickup",
      length: 5.4,
      width: 2.0,
      category: "Vehicles",
      symbol: "4×4",
    },
    concreteMixer8: {
      name: "8 m³ concrete mixer / delivery truck",
      length: 9.76,
      width: 3.101,
      bodyWidth: 2.542,
      category: "Vehicles",
      symbol: "MIX",
      dimensionLocked: true,
      verifiedDimensions: true,
      source: "Holcim UK · Concrete Mixer Truck Dimensions",
      sourceUrl:
        "https://www.holcim.co.uk/products/ready-mix-concrete/small-load/mixer-truck-dimensions",
      sourceRetrievedAt: "2026-09-15",
      sourceNote:
        "Overall planning footprint uses 9.760 m length × 3.101 m width including mirrors. Published body width excluding mirrors: 2.542 m.",
    },
    forklift: {
      name: "Forklift",
      length: 3.8,
      width: 1.3,
      category: "Plant",
      symbol: "FLT",
    },
    telehandler: {
      name: "Telehandler",
      length: 5.2,
      width: 2.4,
      category: "Plant",
      symbol: "TH",
    },
    excavator8: {
      name: "Excavator · compact / 8 t class",
      length: 6.0,
      width: 2.3,
      category: "Plant",
      symbol: "EX",
    },
    excavator20: {
      name: "Excavator · 20 t class",
      length: 9.5,
      width: 3.0,
      category: "Plant",
      symbol: "EX",
    },
    roller: {
      name: "Road roller",
      length: 5.5,
      width: 2.2,
      category: "Plant",
      symbol: "ROL",
    },
    dumper: {
      name: "Site dumper",
      length: 4.5,
      width: 2.4,
      category: "Plant",
      symbol: "DMP",
    },
    mewp: {
      name: "MEWP / boom lift",
      length: 7,
      width: 2.5,
      category: "Plant",
      symbol: "MEWP",
    },
    heras: {
      name: "Heras fence panel",
      length: 3.5,
      width: 0.05,
      category: "Perimeter",
      symbol: "F",
    },
    storm: {
      name: "Storm / solid fence panel",
      length: 2.4,
      width: 0.08,
      category: "Perimeter",
      symbol: "F",
    },
    pedGate: {
      name: "Pedestrian gate",
      length: 1.2,
      width: 0.1,
      category: "Perimeter",
      symbol: "G",
    },
    vehicleGate: {
      name: "Vehicle gate",
      length: 6,
      width: 0.1,
      category: "Perimeter",
      symbol: "G",
    },
    barrier: {
      name: "Pedestrian barrier",
      length: 2.0,
      width: 0.05,
      category: "Perimeter",
      symbol: "B",
    },
    parking: {
      name: "Parking bay",
      length: 5,
      width: 2.5,
      category: "Logistics",
      symbol: "P",
    },
    generator: {
      name: "Generator",
      length: 2.5,
      width: 1.2,
      category: "Logistics",
      symbol: "GEN",
    },
    fuel: {
      name: "Fuel tank / bowser",
      length: 3.5,
      width: 1.6,
      category: "Logistics",
      symbol: "FUEL",
    },
    skip: {
      name: "Skip",
      length: 3.5,
      width: 1.8,
      category: "Logistics",
      symbol: "SKIP",
    },
    wheelwash: {
      name: "Wheel wash",
      length: 12,
      width: 4,
      category: "Logistics",
      symbol: "WW",
    },
    muster: {
      name: "Muster point",
      length: 2,
      width: 2,
      category: "Safety",
      symbol: "M",
    },
    firstaid: {
      name: "First aid point",
      length: 2,
      width: 2,
      category: "Safety",
      symbol: "+",
    },
    fire: {
      name: "Fire point",
      length: 1.5,
      width: 1.5,
      category: "Safety",
      symbol: "FIRE",
    },
    stage: {
      name: "Event stage",
      length: 8,
      width: 6,
      category: "Event",
      symbol: "STG",
    },
    custom: {
      name: "Custom footprint",
      length: 4,
      width: 3,
      category: "Other",
      symbol: "•",
    },
  };
  const TYPES = {
    access: "On-site access route",
    egress: "On-site egress route",
    route: "On-site route",
    area: "Site area",
    measure: "Measurement",
    service: "Services & constraints",
    hazard: "Concern area",
    note: "Site note",
    photo: "Site photo",
    panel: "Trakway panel",
    trakway: "Trakway barrier",
    asset: "Site asset",
    "hazard-marker": "Concern",
    shape: "Drawing shape",
    excavation: "Excavation",
    stoneRoad: "Stone road",
    textBox: "Text box",
  };
  const state = {
    map: null,
    bases: {},
    base: "satellite",
    mode: "map",
    mapView: null,
    mapLocked: false,
    planLocked: true,
    group: null,
    planBaseGroup: null,
    routeGroup: null,
    ohlSupportGroup: null,
    draftGroup: null,
    editGroup: null,
    areaLayer: null,
    layers: new Map(),
    drawer: null,
    selected: null,
    tool: null,
    points: [],
    options: {},
    history: [],
    future: [],
    recognition: null,
    listening: false,
    voiceStarting: false,
    voices: [],
    voiceResultHandled: false,
    voiceError: false,
    request: null,
    areaGeneration: 0,
    cache: new Map(),
    importKind: null,
    routePick: null,
    vertexEditId: null,
    groupPick: null,
    multiSelection: new Set(),
    serviceScreen: "home",
    project: null,
  };
  function fresh() {
    const now = new Date().toISOString();
    return {
      format: "SAMI-PROJECT-3",
      id: uid(),
      createdAt: now,
      savedAt: now,
      name: "Untitled site",
      meta: {},
      area: null,
      planFrame: null,
      planView: null,
      areaAspectLocked: false,
      areaPaperRatio: 420 / 297,
      planBleed: PLAN_BLEED_DEFAULT,
      planDetail: "low",
      planBase: [],
      planBaseMeta: null,
      features: [],
      routes: [],
      contributions: [],
      base: "satellite",
      map: { center: { lat: 52.5862, lng: -2.1288 }, zoom: 16, bearing: 0 },
      gridSnap: true,
      gridStep: 0.5,
      hiddenTypes: [],
      serviceVisibility: Object.fromEntries(
        Object.keys(SERVICES).map((k) => [k, k === "ohl"]),
      ),
      serviceVisibilityConfigured: true,
      serviceStyles: {},
      route: { product: "lion", ...PRODUCTS.lion, lanes: 1 },
      asset: { kind: "cabin20", ...ASSETS.cabin20, angle: 0 },
      serviceType: "electric",
      hgv: {
        profile: "artic40",
        ...HGV_PROFILES.artic40,
        start: null,
        end: null,
      },
    };
  }
  function feature(type, geometry, properties = {}) {
    return {
      type: "Feature",
      id: uid(),
      properties: {
        type,
        label: TYPES[type] || type,
        created: new Date().toISOString(),
        ...properties,
      },
      geometry,
    };
  }
  function cleanMeta(m) {
    const o = {};
    for (const [k, v] of Object.entries(m || {})) {
      if (["__proto__", "prototype", "constructor"].includes(k)) continue;
      if (["string", "number", "boolean"].includes(typeof v) || v === null)
        o[k] = v;
    }
    return o;
  }
  function normaliseProject(p) {
    const n = fresh();
    if (
      !p ||
      !["SAMI-PROJECT-1", "SAMI-PROJECT-2", "SAMI-PROJECT-3"].includes(p.format)
    )
      throw Error("Choose a SAMI project backup.");
    if (typeof p.id === "string" && p.id.trim())
      n.id = p.id.trim().slice(0, 200);
    for (const key of ["createdAt", "savedAt", "checkpointAt"])
      if (typeof p[key] === "string" && p[key]) n[key] = p[key].slice(0, 80);
    n.name = String(p.name || n.name).slice(0, 200);
    n.meta = cleanMeta(p.meta);
    n.area = G.validBounds(p.area) ? p.area : null;
    if (
      Array.isArray(p.planFrame) &&
      p.planFrame.length === 4 &&
      p.planFrame.every(G.validCoord)
    )
      n.planFrame = p.planFrame.map(copy);
    if (
      p.planView &&
      G.validCoord([p.planView.center?.lng, p.planView.center?.lat])
    )
      n.planView = {
        center: { lat: +p.planView.center.lat, lng: +p.planView.center.lng },
        zoom: Math.max(3, Math.min(23, +p.planView.zoom || 16)),
        bearing: (((+p.planView.bearing || 0) % 360) + 360) % 360,
      };
    n.areaAspectLocked = p.areaAspectLocked === true;
    n.areaPaperRatio =
      Number.isFinite(+p.areaPaperRatio) && +p.areaPaperRatio > 1
        ? +p.areaPaperRatio
        : 420 / 297;
    if (p.areaAspectLocked === undefined && n.area) {
      const c = [(n.area[0] + n.area[2]) / 2, (n.area[1] + n.area[3]) / 2],
        pr = G.projection(c),
        sw = pr.xy([n.area[0], n.area[1]]),
        ne = pr.xy([n.area[2], n.area[3]]);
      let w = Math.max(1, ne[0] - sw[0]),
        h = Math.max(1, ne[1] - sw[1]);
      if (w / h < n.areaPaperRatio) w = h * n.areaPaperRatio;
      else h = w / n.areaPaperRatio;
      const a = pr.ll([-w / 2, -h / 2]),
        z = pr.ll([w / 2, h / 2]);
      n.area = [a[0], a[1], z[0], z[1]];
    }
    const fs = p.features || p.geojson?.features || [];
    if (!Array.isArray(fs) || fs.length > 12000)
      throw Error("The project has too many items.");
    n.features = fs.filter(G.validateFeature).map((f) => {
      const x = {
        ...copy(f),
        id: typeof f.id === "string" ? f.id : uid(),
        properties: cleanMeta(f.properties),
      };
      const m = x.properties || {};
      if (m.routeId && !m.groupUngrouped && !m.groupId) m.groupId = m.routeId;
      if (m.routeId && m.generated && (m.type === "route" || m.type === "area"))
        m.guideHidden = true;
      return x;
    });
    if (["street", "satellite", "drawing"].includes(p.base)) n.base = p.base;
    n.storageRevision = p.storageRevision || 0;
    n.planBaseStyle = ["street", "satellite", "drawing"].includes(p.planBaseStyle) ? p.planBaseStyle : n.base;
    n.exploreBase = ["street", "satellite"].includes(p.exploreBase) ? p.exploreBase : n.base === "drawing" ? "satellite" : n.base;
    if (G.validCoord([p.map?.center?.lng, p.map?.center?.lat]))
      n.map = {
        center: { lat: p.map.center.lat, lng: p.map.center.lng },
        zoom: Math.max(3, Math.min(23, Number(p.map.zoom) || 16)),
        bearing: (((+p.map?.bearing || 0) % 360) + 360) % 360,
      };
    n.gridSnap = p.gridSnap !== false;
    n.gridStep = [0.1, 0.25, 0.5, 1, 2, 5].includes(+p.gridStep)
      ? +p.gridStep
      : 0.5;
    if (Array.isArray(p.hiddenTypes))
      n.hiddenTypes = p.hiddenTypes.filter((k) => TYPES[k]);
    if (p.serviceVisibilityConfigured === true && p.serviceVisibility) {
      for (const k of Object.keys(SERVICES))
        n.serviceVisibility[k] = p.serviceVisibility[k] === true;
    } else
      n.serviceVisibility = Object.fromEntries(
        Object.keys(SERVICES).map((k) => [k, k === "ohl"]),
      );
    n.serviceVisibilityConfigured = true;
    if (p.serviceStyles && typeof p.serviceStyles === "object") {
      for (const k of Object.keys(SERVICES)) {
        const q = p.serviceStyles[k];
        if (!q || typeof q !== "object") continue;
        const x = {};
        if (/^#[0-9a-f]{6}$/i.test(q.color || "")) x.color = q.color;
        if (/^#[0-9a-f]{6}$/i.test(q.fillColor || ""))
          x.fillColor = q.fillColor;
        if (Number.isFinite(+q.weight))
          x.weight = Math.max(0.5, Math.min(12, +q.weight));
        if (["solid", "dashed", "dotted"].includes(q.dash)) x.dash = q.dash;
        if (Number.isFinite(+q.opacity))
          x.opacity = Math.max(0.05, Math.min(1, +q.opacity));
        if (Number.isFinite(+q.fillOpacity))
          x.fillOpacity = Math.max(0, Math.min(1, +q.fillOpacity));
        n.serviceStyles[k] = x;
      }
    }
    if (p.route && PRODUCTS[p.route.product])
      n.route = { ...n.route, ...cleanMeta(p.route) };
    if (p.asset && ASSETS[p.asset.kind])
      n.asset = { ...n.asset, ...cleanMeta(p.asset) };
    if (SERVICES[p.serviceType]) n.serviceType = p.serviceType;
    if (Number.isFinite(+p.planBleed))
      n.planBleed = Math.max(0, Math.min(200, +p.planBleed));
    if (["low", "medium", "high"].includes(p.planDetail))
      n.planDetail = p.planDetail;
    if (Array.isArray(p.planBase))
      n.planBase = p.planBase
        .filter(G.validateFeature)
        .slice(0, 12000)
        .map(copy);
    if (p.planBaseMeta && typeof p.planBaseMeta === "object")
      n.planBaseMeta = cleanMeta(p.planBaseMeta);
    if (Array.isArray(p.routes))
      n.routes = p.routes
        .filter(
          (r) =>
            r && Array.isArray(r.geometry) && r.geometry.every(G.validCoord),
        )
        .slice(0, 50)
        .map(copy);
    if (Array.isArray(p.contributions))
      n.contributions = p.contributions
        .filter(
          (x) =>
            x &&
            x.geometry &&
            G.validateFeature({
              type: "Feature",
              geometry: x.geometry,
              properties: {},
            }),
        )
        .slice(0, 2000)
        .map(copy);
    if (p.hgv && HGV_PROFILES[p.hgv.profile])
      n.hgv = {
        ...n.hgv,
        ...cleanMeta(p.hgv),
        start: p.hgv.start && G.validCoord(p.hgv.start) ? p.hgv.start : null,
        end: p.hgv.end && G.validCoord(p.hgv.end) ? p.hgv.end : null,
      };
    n.format = "SAMI-PROJECT-3";
    return n;
  }
  function init() {
    if (!window.L || !G) {
      $("#splashStatus").textContent =
        "A required app file is missing. Re-upload the complete package.";
      return;
    }
    state.project = fresh();
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        state.project = normaliseProject(JSON.parse(raw));
        const legacy = JSON.parse(localStorage.getItem("sami.meta") || "{}");
        if (!Object.keys(state.project.meta).length)
          state.project.meta = cleanMeta(legacy);
      }
    } catch (e) {
      toast(
        "The saved project could not be read. Your stored copy has been kept.",
      );
    }
    state.map = L.map("map", {
      zoomControl: false,
      preferCanvas: true,
      maxZoom: 23,
      zoomSnap: 0.25,
      zoomDelta: 1,
      doubleClickZoom: false,
      attributionControl: true,
      fadeAnimation: false,
      markerZoomAnimation: false,
      zoomAnimation: true,
    }).setView(state.project.map.center, state.project.map.zoom);
    requestAnimationFrame(() => {
      state.map.invalidateSize();
      state.map.setView(state.project.map.center, state.project.map.zoom);
    });
    const tilePerf = {
      maxNativeZoom: 19,
      maxZoom: 23,
      updateWhenIdle: true,
      updateWhenZooming: false,
      keepBuffer: 2,
    };
    state.bases.street = L.tileLayer(
      "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      {
        ...tilePerf,
        attribution:
          '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      },
    );
    state.bases.satellite = L.tileLayer(
      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      { ...tilePerf, attribution: "Imagery © Esri" },
    );
    state.planBaseGroup = L.featureGroup().addTo(state.map);
    state.routeGroup = L.featureGroup().addTo(state.map);
    state.group = L.featureGroup().addTo(state.map);
    state.assetIconGroup = L.featureGroup().addTo(state.map);
    state.ohlSupportGroup = L.featureGroup().addTo(state.map);
    state.draftGroup = L.featureGroup().addTo(state.map);
    state.editGroup = L.featureGroup().addTo(state.map);
    L.control
      .scale({ position: "bottomright", imperial: false, maxWidth: 100 })
      .addTo(state.map);
    state.map.on("click", onMapClick);
    state.map.on("mousemove", (e) => {
      $("#coordReadout").textContent =
        e.latlng.lat.toFixed(5) + ", " + e.latlng.lng.toFixed(5);
    });
    state.map.on("moveend", () => {
      if (state.mode !== "plan") {
        state.project.map = {
          center: state.map.getCenter(),
          zoom: state.map.getZoom(),
          bearing: state.map.getBearing?.() || state.project.map?.bearing || 0,
        };
        saveSoon();
      }
    });
    state.map.on("zoomend", renderAssetIllustrations);
    state.map.on("zoomend bearingchange", () => {
      for (const f of state.project.features) if (f.properties.dimension) {
        const old = state.layers.get(f.id);
        if (old) state.group.removeLayer(old);
        state.layers.delete(f.id);
        if (visibleFeature(f)) renderDimensionView(f);
      }
    });
    for (const b of Object.values(state.bases)) {
      let warned = false;
      b.on("tileerror", () => {
        if (!warned) {
          warned = true;
          $("#sourceChip").textContent =
            "Map imagery unavailable · drawing still works";
        }
      });
    }
    bindUI();
    initFreehandInput();
    initAssetDropZone();
    switchBase(state.project.base, false);
    render();
    snapshot(true);
    initVoice();
    initToolRail();
    updateVoiceButton();
    $("#projectName").value = state.project.name;
    $("#welcomeCard").hidden = true;
    setupLaunchGate();
    new ResizeObserver(() => {
      state.map.invalidateSize({ pan: false, animate: false });
      clampRail();
    }).observe($("#workspace"));
    window.addEventListener("beforeprint", () => {
      if (state.project.area) {
        buildPrintTemplate(state.project.meta);
        applyPrintScale();
      }
    });
    window.addEventListener("afterprint", () => {
      state.map.options.zoomSnap = 0.25;
      state.map.invalidateSize({ pan: false, animate: false });
    });
    // Service-worker lifecycle is owned by pwa.js so updates only activate
    // after the current project has been saved and the user accepts reload.
    window.addEventListener("pagehide", () => {
      saveNow();
      abortLayerRequest();
    });
  }
  function bindUI() {
    $("#homeBtn").onclick = () => openDrawer("project", true);
    $("#projectBtn").onclick = () => openDrawer("project", true);
    $("#searchBtn").onclick = () => openDrawer("search", true);
    $("#exportBtn").onclick = openExport;
    $$("[data-mode]").forEach(
      (b) => (b.onclick = () => setMode(b.dataset.mode)),
    );
    $$("[data-base]").forEach(
      (b) => (b.onclick = () => switchBase(b.dataset.base)),
    );
    $$("[data-drawer]").forEach(
      (b) =>
        (b.onclick = () =>
          state.drawer === b.dataset.drawer
            ? closeDrawer(true)
            : openDrawer(b.dataset.drawer, true)),
    );
    $("#closeDrawer").onclick = () => closeDrawer(true);
    $("#areaChip").onclick = () => openDrawer("area", true);
    $("#locateBtn").onclick = locate;
    $("#fitBtn").onclick = fitProject;
    $("#lockBtn").onclick = () => setLock(!isLocked());
    $("#zoomInBtn").onclick = () => state.map.zoomIn();
    $("#zoomOutBtn").onclick = () => state.map.zoomOut();
    $("#undoBtn").onclick = undo;
    $("#redoBtn").onclick = redo;
    $("#finishDrawBtn").onclick = finishDraw;
    $("#cancelDrawBtn").onclick = cancelDraw;
    $("#backPointBtn").onclick = backPoint;
    $("#projectName").onchange = () => {
      state.project.name = $("#projectName").value.trim() || "Untitled site";
      commit();
    };
    $("#startFindBtn").onclick = () => {
      dismissWelcome();
      openDrawer("search", true);
    };
    $("#dismissWelcome").onclick = dismissWelcome;
    $("#sendBtn").onclick = handleAskButton;
    if ($("#headerAskBtn")) $("#headerAskBtn").onclick = handleAskButton;
    $("#askInput").onkeydown = (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        sendAsk();
      }
    };
    $("#askInput").oninput = updateAskLabel;
    window.addEventListener("sami:assistant-config", updateAskLabel);
    $("#closeSami").onclick = () => $("#samiPanel").classList.remove("open");
    $("#muteSami").onclick = () => {
      setPref(
        "sami.voice.output",
        readPref("sami.voice.output") === "off" ? "on" : "off",
      );
      if (readPref("sami.voice.output") === "off")
        window.speechSynthesis?.cancel();
      updateVoiceButton();
    };
    $("#modalClose").onclick = closeModal;
    $("#modal").onclick = (e) => {
      if (e.target === $("#modal")) closeModal();
    };
    $("#importInput").onchange = handleImport;
    $("#photoInput").onchange = handlePhoto;
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        cancelDraw();
        closeModal();
        closeDrawer();
        return;
      }
      if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        e.shiftKey ? redo() : undo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redo();
      } else if (e.key === "Enter" && state.tool) {
        e.preventDefault();
        finishDraw();
      } else if ((e.key === "Backspace" || e.key === "Delete") && state.tool) {
        e.preventDefault();
        backPoint();
      }
    });
  }
  function dismissWelcome() {
    $("#welcomeCard").hidden = true;
    setPref("sami.welcome", "seen");
  }
  function isLocked() {
    return state.mode === "plan" ? state.planLocked : state.mapLocked;
  }
  function setLock(value) {
    if (state.mode === "plan") state.planLocked = value;
    else state.mapLocked = value;
    updateLock();
    toast(
      value
        ? "View locked. Panning is disabled; zoom remains available."
        : "View unlocked. Drag to pan; pinch or scroll to zoom.",
    );
  }
  function updateLock() {
    const locked = isLocked();
    ["dragging", "boxZoom", "keyboard"].forEach((k) => {
      if (state.map[k]) state.map[k][locked ? "disable" : "enable"]();
    });
    ["touchZoom", "scrollWheelZoom"].forEach((k) => state.map[k]?.enable?.());
    state.map.doubleClickZoom.disable();
    $("#lockBtn").classList.toggle("active", locked);
    $("#lockBtn").setAttribute("aria-pressed", String(locked));
    $("#lockBtn").innerHTML =
      (locked
        ? '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>'
        : '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2.5"/></svg>') +
      " <span>" +
      (locked ? "Unlock" : "Lock") +
      "</span>";
    $("#lockBtn").title = locked ? "Unlock pan" : "Lock pan";
    $("#zoomInBtn").disabled = false;
    $("#zoomOutBtn").disabled = false;
  }
  function setMode(mode) {
    cancelDraw();
    closeDrawer();
    if (mode === "library") {
      state.modeBeforeLibrary = state.mode;
      setModeUI("library");
      openDrawer("library");
      return true;
    }
    const wasSite = state.mode === "plan";
    if (state.mode !== "plan" && mode === "plan") {
      state.mapView = {
        center: state.map.getCenter(),
        zoom: state.map.getZoom(),
        base: state.base,
      };
      state.planLocked = true;
    }
    state.mode = mode;
    setModeUI(mode);
    if (mode === "plan") {
      if (state.project.area) fitArea();
    } else if (wasSite && mode !== "plan" && state.mapView) {
    }
    updateLock();
    render();
    if (mode === "route") openDrawer("routeToSite");
    else if (mode === "plan") openDrawer("draw");
    return true;
  }
  function setModeUI(mode) {
    $$("[data-mode]").forEach((b) => {
      const on = b.dataset.mode === mode;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", String(on));
    });
    $("#modeCaption").textContent = {
      map: "Your site, in context",
      route: "HGV-aware route to site",
      plan: "Draw directly over Map, Satellite or CAD",
      library: "Trakway, assets and your project items",
    }[mode];
    const drawingBtn = $('[data-base="drawing"]');
    if (drawingBtn) {
      drawingBtn.hidden = mode !== "plan";
      drawingBtn.disabled = !state.project.area;
      drawingBtn.setAttribute("aria-disabled", String(!state.project.area));
      drawingBtn.title = state.project.area
        ? "CAD site drawing"
        : "Define a site area to enable CAD";
    }
  }
  function switchBase(base, save = true) {
    const exploreBase = ["street", "satellite"].includes(
      state.project.exploreBase,
    )
      ? state.project.exploreBase
      : "satellite";
    if (base === "drawing" && state.mode !== "plan") base = exploreBase;
    if (!["street", "satellite", "drawing"].includes(base)) return;
    if (base === "drawing" && !state.project.area) {
      if (save) {
        openDrawer("area");
        toast(
          "Define the site drawing area before creating the bounded CAD view.",
        );
        return;
      }
      base = exploreBase;
    }
    Object.values(state.bases).forEach((l) => {
      if (state.map.hasLayer(l)) state.map.removeLayer(l);
    });
    if (state.bases[base]) state.bases[base].addTo(state.map);
    state.base = base;
    $("#map").classList.toggle("drawing-base", base === "drawing");
    $("#workspace").classList.toggle("cad-view", base === "drawing");
    $$("[data-base]").forEach((b) => {
      const on = b.dataset.base === base;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", String(on));
      b.disabled = b.dataset.base === "drawing" && !state.project.area;
      b.setAttribute("aria-disabled", String(b.disabled));
    });
    $("#sourceChip").textContent =
      base === "drawing"
        ? state.project.planBaseMeta?.capturedAt
          ? "CAD site drawing · snapshot " +
            new Date(state.project.planBaseMeta.capturedAt).toLocaleDateString(
              "en-GB",
            )
          : "CAD site drawing · capture bounded detail"
        : { street: "OpenStreetMap", satellite: "Esri imagery" }[base];
    if (save) {
      state.project.base = base;
      state.project[state.mode === "plan" ? "planBaseStyle" : "exploreBase"] = base;
      saveSoon();
    }
    if (base === "drawing" && planBaseNeedsCapture() && !state.planCaptureError)
      queueMicrotask(() => capturePlanBase(true));
    render();
  }
  function fitArea() {
    if (!state.project.area) return;
    const b = state.mode === "plan" ? planBounds() : state.project.area;
    state.map.fitBounds(
      [
        [b[1], b[0]],
        [b[3], b[2]],
      ],
      {
        paddingTopLeft: [window.innerWidth < 760 ? 82 : 98, 112],
        paddingBottomRight: [window.innerWidth < 760 ? 65 : 83, 105],
        maxZoom: 23,
        animate: false,
      },
    );
  }
  function fitProject() {
    if (state.project.area) {
      fitArea();
      return;
    }
    if (state.group.getLayers().length)
      state.map.fitBounds(state.group.getBounds(), {
        padding: [100, 120],
        maxZoom: 22,
      });
    else toast("Define a site area or add an item first.");
  }
  function latlng(c) {
    return [c[1], c[0]];
  }
  function coord(ll) {
    return [ll.lng, ll.lat];
  }
  function areaText() {
    const b = state.project.area;
    if (!b) return "No site area";
    const a = G.area(b);
    return a >= 10000
      ? (a / 10000).toFixed(2) + " ha"
      : Math.round(a).toLocaleString() + " m²";
  }
  function planBounds() {
    return state.project.area
      ? G.expandBoundsMeters(
          state.project.area,
          Math.max(
            0,
            Math.min(200, Number(state.project.planBleed ?? PLAN_BLEED_DEFAULT)),
          ),
        )
      : null;
  }
  function serviceBounds() {
    return state.project.area
      ? G.expandBoundsMeters(state.project.area, SERVICE_BUFFER_M)
      : null;
  }
  function ohlSearchBounds() {
    return state.project.area
      ? G.expandBoundsMeters(state.project.area, 804.672)
      : null;
  }
  function boundsText(b) {
    if (!b) return "";
    return b.map((x) => Number(x).toFixed(6)).join(", ");
  }
  function selectedFeature() {
    return state.project.features.find((f) => f.id === state.selected) || null;
  }
  function selectedGroupId() {
    return selectedFeature()?.properties?.groupId || null;
  }
  function groupMembers(f = selectedFeature()) {
    if (!f) return [];
    const gid = f.properties?.groupId;
    return gid
      ? state.project.features.filter((x) => x.properties?.groupId === gid)
      : [f];
  }
  function groupBounds(members) {
    const bs = members.map((x) => G.boundsOf(x.geometry)).filter(Boolean);
    if (!bs.length) return null;
    return [
      Math.min(...bs.map((b) => b[0])),
      Math.min(...bs.map((b) => b[1])),
      Math.max(...bs.map((b) => b[2])),
      Math.max(...bs.map((b) => b[3])),
    ];
  }
  function featureCenter(f) {
    const b = G.boundsOf(f.geometry);
    return b ? [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2] : null;
  }
  function translateMembers(members, delta) {
    for (const x of members) {
      transformGeometry(x.geometry, (c) => [c[0] + delta[0], c[1] + delta[1]]);
      if (Number.isFinite(+x.properties.centerLng)) {
        x.properties.centerLng += delta[0];
        x.properties.centerLat += delta[1];
      }
    }
  }
  function rotateMembers(members, center, degrees) {
    const pr = G.projection(center),
      a = (degrees * Math.PI) / 180,
      cs = Math.cos(a),
      sn = Math.sin(a);
    for (const x of members) {
      transformGeometry(x.geometry, (c) => {
        const q = pr.xy(c),
          r = [q[0] * cs + q[1] * sn, -q[0] * sn + q[1] * cs];
        return pr.ll(r);
      });
      if (
        Number.isFinite(+x.properties.centerLng) &&
        Number.isFinite(+x.properties.centerLat)
      ) {
        const q = pr.xy([+x.properties.centerLng, +x.properties.centerLat]),
          r = [q[0] * cs + q[1] * sn, -q[0] * sn + q[1] * cs],
          c = pr.ll(r);
        x.properties.centerLng = c[0];
        x.properties.centerLat = c[1];
      }
      if (Number.isFinite(+x.properties.angle))
        x.properties.angle = (+x.properties.angle + degrees + 360) % 360;
    }
  }
  function groupPickSnapshot() {
    return Object.fromEntries(
      state.project.features.map((x) => [
        x.id,
        {
          groupId: x.properties?.groupId ?? null,
          groupUngrouped: x.properties?.groupUngrouped,
        },
      ]),
    );
  }
  function restoreGroupPick(pick = state.groupPick) {
    if (!pick?.before) return;
    for (const x of state.project.features) {
      const b = pick.before[x.id];
      if (!b) continue;
      if (b.groupId == null) delete x.properties.groupId;
      else x.properties.groupId = b.groupId;
      if (b.groupUngrouped === undefined) delete x.properties.groupUngrouped;
      else x.properties.groupUngrouped = b.groupUngrouped;
    }
  }
  function startGroupPick() {
    const f = selectedFeature();
    if (!f || f.properties.locked) return;
    const before = groupPickSnapshot();
    let gid = f.properties.groupId;
    if (!gid) {
      gid = uid();
      f.properties.groupId = gid;
      f.properties.groupUngrouped = false;
    }
    state.groupPick = { groupId: gid, originId: f.id, before };
    closeDrawer();
    const ob = G.boundsOf(f.geometry);
    if (ob)
      state.map.fitBounds(
        [
          [ob[1], ob[0]],
          [ob[3], ob[2]],
        ],
        { maxZoom: 21, padding: [140, 140] },
      );
    render();
    toast("Group selection: tap items to add or remove them, then press Done.");
  }
  function completeGroupPick(target) {
    const pick = state.groupPick;
    if (!pick || target.properties?.locked) return false;
    const originalGroup = pick.before?.[target.id]?.groupId,
      cluster = originalGroup
        ? state.project.features.filter(
            (x) => pick.before?.[x.id]?.groupId === originalGroup,
          )
        : [target],
      containsOrigin = cluster.some((x) => x.id === pick.originId),
      allSelected = cluster.every(
        (x) => x.properties?.groupId === pick.groupId,
      );
    if (allSelected) {
      if (containsOrigin) {
        toast(
          "The starting item stays selected. Add more items or press Done.",
        );
        return true;
      }
      for (const x of cluster) {
        const b = pick.before?.[x.id];
        if (b?.groupId == null) delete x.properties.groupId;
        else x.properties.groupId = b.groupId;
        if (b?.groupUngrouped === undefined) delete x.properties.groupUngrouped;
        else x.properties.groupUngrouped = b.groupUngrouped;
      }
      render();
      toast(
        (cluster.length > 1 ? "Group" : "Item") +
          " removed from the selection.",
      );
      return true;
    }
    for (const x of cluster) {
      x.properties.groupId = pick.groupId;
      x.properties.groupUngrouped = false;
    }
    render();
    toast(
      (cluster.length > 1 ? cluster.length + " grouped items" : "Item") +
        " selected. Tap more items or press Done.",
    );
    return true;
  }
  function finishGroupPick() {
    const pick = state.groupPick;
    if (!pick) return false;
    const count = state.project.features.filter(
      (x) => x.properties?.groupId === pick.groupId,
    ).length;
    if (count < 2) {
      restoreGroupPick(pick);
      state.groupPick = null;
      render();
      openDrawer("selection");
      toast("Choose at least two items to create a group.");
      return false;
    }
    state.groupPick = null;
    commit();
    state.selected = pick.originId;
    openDrawer("selection");
    toast(count + " items grouped.");
    return true;
  }
  function cancelGroupPick() {
    const pick = state.groupPick;
    if (!pick) return false;
    restoreGroupPick(pick);
    state.groupPick = null;
    render();
    state.selected = pick.originId;
    openDrawer("selection");
    toast("Grouping cancelled.");
    return true;
  }
  function ungroupSelected() {
    const f = selectedFeature();
    if (!f) return;
    const members = groupMembers(f);
    if (members.length < 2) {
      delete f.properties.groupId;
      f.properties.groupUngrouped = true;
      commit();
      toast("Item is not grouped.");
      return;
    }
    for (const x of members) {
      delete x.properties.groupId;
      x.properties.groupUngrouped = true;
    }
    state.groupPick = null;
    commit();
    state.selected = f.id;
    openDrawer("selection");
    toast("Group separated into individual items.");
  }
  function groupMultiSelection() {
    if (state.multiSelection.size < 2) {
      toast("Select at least two items to create a group.");
      return;
    }
    const groupId = uid();
    let count = 0,
      firstGroupedId = null;
    for (const id of state.multiSelection) {
      const f = state.project.features.find((x) => x.id === id);
      if (f && !f.properties.locked) {
        f.properties.groupId = groupId;
        f.properties.groupUngrouped = false;
        firstGroupedId ??= id;
        count++;
      }
    }
    if (count < 2) {
      toast("At least two items must not be locked to create a group.");
      return;
    }
    state.multiSelection.clear();
    state.selected = firstGroupedId;
    commit();
    openDrawer("selection");
    toast(count + " items grouped.");
  }
  function duplicateSelected() {
    const f = selectedFeature();
    if (!f) return;
    const members = groupMembers(f),
      b = groupBounds(members),
      c = b ? [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2] : featureCenter(f),
      pr = G.projection(c),
      next = pr.ll([2, -2]),
      delta = [next[0] - c[0], next[1] - c[1]],
      newGroup = members.length > 1 ? uid() : null,
      newRoute = members.some((x) => x.properties.routeId)
        ? newGroup || uid()
        : null,
      dupes = [];
    for (const x of members) {
      const d = copy(x);
      d.id = uid();
      d.properties = { ...d.properties, created: new Date().toISOString() };
      transformGeometry(d.geometry, (p) => [p[0] + delta[0], p[1] + delta[1]]);
      if (newGroup) d.properties.groupId = newGroup;
      else delete d.properties.groupId;
      if (newRoute && d.properties.routeId) d.properties.routeId = newRoute;
      if (Number.isFinite(+d.properties.centerLng)) {
        d.properties.centerLng += delta[0];
        d.properties.centerLat += delta[1];
      }
      dupes.push(d);
    }
    state.project.features.push(...dupes);
    state.selected = (
      dupes.find((x) => !x.properties.guideHidden) || dupes[0]
    ).id;
    commit();
    openDrawer("selection");
    toast((members.length > 1 ? "Group" : "Item") + " duplicated.");
  }
  function paperRatioBoundsFromPoints(ps) {
    const raw = boundsFromPoints(ps);
    if (!state.project.areaAspectLocked) return raw;
    const ratio = +state.project.areaPaperRatio || 420 / 297,
      centre = [(raw[0] + raw[2]) / 2, (raw[1] + raw[3]) / 2],
      pr = G.projection(centre),
      xy = ps.map(pr.xy),
      xs = xy.map((v) => v[0]),
      ys = xy.map((v) => v[1]);
    let minX = Math.min(...xs),
      maxX = Math.max(...xs),
      minY = Math.min(...ys),
      maxY = Math.max(...ys),
      w = Math.max(1, maxX - minX),
      h = Math.max(1, maxY - minY),
      pad = Math.max(1, Math.min(w, h) * 0.025);
    minX -= pad;
    maxX += pad;
    minY -= pad;
    maxY += pad;
    w = maxX - minX;
    h = maxY - minY;
    const cx = (minX + maxX) / 2,
      cy = (minY + maxY) / 2;
    if (w / h < ratio) w = h * ratio;
    else h = w / ratio;
    const corners = [
      [cx - w / 2, cy - h / 2],
      [cx + w / 2, cy - h / 2],
      [cx + w / 2, cy + h / 2],
      [cx - w / 2, cy + h / 2],
    ].map(pr.ll);
    return boundsFromPoints(corners);
  }
  function clearSiteArea() {
    if (!state.project.area) return;
    abortLayerRequest();
    state.areaGeneration++;
    state.planCaptureError = null;
    state.cache.clear();
    state.project.area = null;
    state.project.planBase = [];
    state.project.planBaseMeta = null;
    state.selected = null;
    cancelDraw();
    if (state.base === "drawing") {
      const fallback = ["street", "satellite"].includes(
        state.project.exploreBase,
      )
        ? state.project.exploreBase
        : "satellite";
      state.project.planBaseStyle = fallback;
      state.project.base = fallback;
      switchBase(fallback, false);
    }
    if (state.mode === "plan") setMode("map");
    commit();
    openDrawer("area");
    toast(
      "Site drawing frame cleared. Existing assets, services and routes were retained. Undo is available.",
    );
  }
  const FREEHAND_BASE = {
    serviceFreehand: "service",
    accessFreehand: "access",
    egressFreehand: "egress",
    routeFreehand: "route",
    areaFreehand: "area",
    hazardFreehand: "hazard",
    excavationFreehand: "excavation",
    arrowFreehand: "arrow",
    stoneRoadFreehand: "stoneRoad",
    stoneAreaFreehand: "stoneArea",
  };
  function baseToolName(t) {
    return FREEHAND_BASE[t] || t;
  }
  function lineMidpointAndBearing(coords) {
    if (!coords || coords.length < 2) return null;
    let lens = [],
      total = 0;
    for (let i = 1; i < coords.length; i++) {
      const d = G.distance(coords[i - 1], coords[i]);
      lens.push(d);
      total += d;
    }
    let at = total / 2,
      idx = 1;
    for (; idx < coords.length; idx++) {
      if (at <= lens[idx - 1]) break;
      at -= lens[idx - 1];
    }
    idx = Math.min(idx, coords.length - 1);
    const a = coords[idx - 1],
      b = coords[idx],
      d = Math.max(0.001, lens[idx - 1]),
      t = Math.max(0, Math.min(1, at / d)),
      mid = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t],
      pr = G.projection(mid),
      aa = pr.xy(a),
      bb = pr.xy(b),
      bearing = (Math.atan2(bb[0] - aa[0], bb[1] - aa[1]) * 180) / Math.PI;
    return { mid, bearing };
  }
  function renderDirectionMarker(f, shown) {
    const m = f.properties || {};
    if (
      !["access", "egress", "route"].includes(m.type) ||
      m.showArrow === false ||
      shown.geometry?.type !== "LineString"
    )
      return;
    const q = lineMidpointAndBearing(shown.geometry.coordinates);
    if (!q) return;
    const col =
        m.styleColor ||
        (m.type === "access"
          ? "#087f61"
          : m.type === "egress"
            ? "#cb4d32"
            : "#356bd6"),
      html =
        '<div class="route-direction-arrow" style="--arrow:' +
        col +
        ";--bearing:" +
        q.bearing +
        'deg">➜</div>';
    L.marker(latlng(q.mid), {
      interactive: false,
      zIndexOffset: 180,
      icon: L.divIcon({
        className: "",
        html,
        iconSize: [34, 34],
        iconAnchor: [17, 17],
      }),
    }).addTo(state.group);
  }
  function renderStoneTexture(f, shown) {
    if (
      f.properties?.type !== "stoneRoad" ||
      shown.geometry?.type !== "Polygon" ||
      ["solid", "dots", "none"].includes(f.properties?.stylePattern)
    )
      return;
    const ring = shown.geometry.coordinates?.[0];
    if (!ring || ring.length < 4) return;
    const b = G.boundsOf(shown.geometry),
      c = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2],
      pr = G.projection(c),
      rxy = ring.slice(0, -1).map(pr.xy),
      xs = rxy.map((p) => p[0]),
      ys = rxy.map((p) => p[1]),
      minX = Math.min(...xs),
      maxX = Math.max(...xs),
      minY = Math.min(...ys),
      maxY = Math.max(...ys),
      w = Math.max(0.5, maxX - minX),
      h = Math.max(0.5, maxY - minY),
      target = 340,
      spacing = Math.max(0.75, Math.sqrt((w * h) / target)),
      len = Math.max(0.3, spacing * 0.3);
    let count = 0;
    for (let x = minX; x <= maxX; x += spacing) {
      for (let y = minY; y <= maxY; y += spacing) {
        if (!pointInRingXY([x, y], rxy)) continue;
        const a = pr.ll([x - len, y - len * 0.55]),
          b2 = pr.ll([x + len, y + len * 0.55]);
        L.polyline([latlng(a), latlng(b2)], {
          interactive: false,
          color:
            f.properties.textureColor || f.properties.styleColor || "#88867c",
          weight: 1,
          opacity: 0.52,
        }).addTo(state.group);
        if (++count > 520) return;
      }
    }
  }
  function editPointData(f) {
    const g = f.geometry;
    if (g.type === "Point") return { g, pts: [g.coordinates], kind: "Point" };
    if (g.type === "LineString")
      return { g, pts: g.coordinates, kind: "LineString" };
    if (g.type === "Polygon" && g.coordinates.length === 1)
      return { g, pts: g.coordinates[0].slice(0, -1), kind: "Polygon" };
    return null;
  }
  function activateVertexEdit(id = state.selected) {
    const f = state.project.features.find((x) => x.id === id),
      data = f && editPointData(f);
    if (!data || data.pts.length > 150) {
      toast("This geometry cannot be point-edited here.");
      return;
    }
    state.vertexEditId = id;
    state.tool = null;
    state.points = [];
    closeDrawer();
    $("#drawStatus").hidden = false;
    $("#toolName").textContent = "Edit points";
    $("#drawHint").textContent =
      "Move as many points as required. Point editing stays active until Done.";
    $("#backPointBtn").hidden = true;
    $("#cancelDrawBtn").hidden = false;
    $("#finishDrawBtn").hidden = false;
    $("#finishDrawBtn").disabled = false;
    $("#finishDrawBtn").textContent = "Done";
    render();
    toast("Edit points is locked on. Drag points, then press Done.");
  }
  function renderVertexHandles() {
    const f = state.project.features.find((x) => x.id === state.vertexEditId),
      data = f && editPointData(f);
    if (!data) return;
    data.pts.forEach((p, i) => {
      const marker = editMarker(p);
      marker.bindTooltip(String(i + 1), { direction: "top" });
      marker.on("dragend", () => {
        const old = copy(f.geometry),
          next = coord(marker.getLatLng());
        if (
          f.properties.type === "service" &&
          state.project.area &&
          !G.inside(next, serviceBounds())
        ) {
          f.geometry = old;
          toast("Keep service points inside the site area + 0.1 mile buffer.");
          render();
          return;
        }
        if (data.kind === "Point") data.g.coordinates = next;
        else if (data.kind === "LineString") data.g.coordinates[i] = next;
        else {
          data.g.coordinates[0][i] = next;
          if (i === 0)
            data.g.coordinates[0][data.g.coordinates[0].length - 1] =
              next.slice();
        }
        if (f.properties.type === "measure")
          f.properties.distance = geometryLength(data.g);
        commit();
        $("#drawStatus").hidden = false;
        $("#finishDrawBtn").textContent = "Done";
        $("#drawHint").textContent =
          "Point moved. Continue editing any point, then press Done.";
      });
    });
  }
  function exitVertexEdit(open = true) {
    const id = state.vertexEditId;
    state.vertexEditId = null;
    state.editGroup?.clearLayers();
    $("#drawStatus").hidden = true;
    $("#finishDrawBtn").textContent = "Finish";
    render();
    if (open && id) {
      state.selected = id;
      openDrawer("selection");
    }
    toast("Points locked back into the drawing.");
  }
  function visibleFeature(f) {
    const m = f.properties;
    if (m.guideHidden || (m.autoAnnotation && !state.project.showAutoMeasurements)) return null;
    if (state.project.hiddenTypes.includes(m.type)) return null;
    if (
      m.type === "service" &&
      state.project.serviceVisibility[m.serviceType] === false
    )
      return null;
    if (
      state.base === "drawing" &&
      ["note", "photo"].includes(m.type) &&
      m.includeOnDrawing === false
    )
      return null;
    let geometry = f.geometry;
    if (state.project.area && m.type === "service")
      geometry = G.clipGeometry(
        geometry,
        state.base === "drawing" ? planBounds() : serviceBounds(),
      );
    else if (state.project.area && state.mode === "plan")
      geometry = G.clipGeometry(geometry, planBounds());
    return geometry ? { ...f, geometry } : null;
  }
  function featureStyle(f) {
    const m = f.properties,
      t = m.type,
      c = SERVICES[m.serviceType]?.color;
    let style = {
      color: "#174d43",
      weight: 3,
      fillColor: "#72bc9c",
      fillOpacity: 0.12,
    };
    if (t === "panel")
      style = {
        color: "#476b58",
        weight: 1,
        fillColor: PRODUCTS[m.product]?.color || "#9fbfa9",
        fillOpacity: 0.6,
      };
    if (t === "trakway")
      style = {
        color: m.trakwayKind === "area" ? "#3a8b77" : "#2a7864",
        weight: m.trakwayKind === "area" ? 2.5 : 4,
        fillColor: "#5fb393",
        fillOpacity: m.trakwayKind === "area" ? 0.35 : 0,
        dashArray: m.trakwayKind === "area" ? null : "8 6",
        opacity: 0.95,
      };
    if (t === "asset")
      style = {
        color: "#324c69",
        weight: 0.5,
        fillColor: "#d6e2e4",
        fillOpacity: 0.22,
      };
    if (t === "service")
      style = {
        color: c || "#9c6530",
        weight: 1,
        dashArray: m.serviceType === "ohl" ? "9 7" : "8 5",
        fillColor: c,
        fillOpacity: 0.15,
      };
    if (t === "access") style = { color: "#087f61", weight: 5 };
    if (t === "egress")
      style = { color: "#cb4d32", weight: 5, dashArray: "10 6" };
    if (t === "route")
      style = {
        color: state.base === "drawing" ? "#223934" : "#356bd6",
        weight: 4,
      };
    if (t === "measure")
      style = { color: "#42444a", weight: 2, dashArray: "5 5" };
    if (t === "hazard")
      style = {
        color: "#c44545",
        weight: 2,
        fillColor: "#e47166",
        fillOpacity: 0.2,
      };
    if (t === "stoneRoad")
      style = {
        color: "#7b786e",
        weight: 2,
        fillColor: "#c8c4b6",
        fillOpacity: 0.78,
      };
    if (t === "excavation")
      style = {
        color: "#8b5f39",
        weight: 2,
        fillColor: "#cda879",
        fillOpacity: 0.36,
        dashArray: "7 4",
      };
    if (t === "shape")
      style = {
        color: m.stroke || "#384d52",
        weight: +m.weight || 2,
        fillColor: m.fill || "#c7d4d2",
        fillOpacity: m.fillOpacity == null ? 0.12 : +m.fillOpacity,
      };
    if (m.styleColor) style.color = m.styleColor;
    if (Number.isFinite(+m.styleWeight))
      style.weight = Math.max(0.5, Math.min(12, +m.styleWeight));
    if (m.styleDash === "solid") delete style.dashArray;
    else if (m.styleDash === "dashed") style.dashArray = "10 6";
    else if (m.styleDash === "dotted") style.dashArray = "2 5";
    if (m.styleFill) style.fillColor = m.styleFill;
    if (Number.isFinite(+m.styleFillOpacity))
      style.fillOpacity = Math.max(0, Math.min(1, +m.styleFillOpacity));
    const gid = selectedGroupId();
    if (f.id === state.selected || (gid && m.groupId === gid) || state.multiSelection.has(f.id))
      style = {
        ...style,
        color: "#00a885",
        weight: Math.max(3, +style.weight || 3) + 1,
      };
    return style;
  }
  function baseStyle(f) {
    const k = f.properties.baseClass,
      g = f.geometry?.type,
      common = { interactive: false };
    if (k === "building")
      return {
        ...common,
        color: "#596467",
        weight: 1,
        fillColor: "#d7dbda",
        fillOpacity: 0.82,
      };
    if (k === "road")
      return {
        ...common,
        color: "#616967",
        weight: g?.includes("Polygon")
          ? 1
          : Math.max(2, Math.min(7, +f.properties.roadWeight || 3)),
        fillColor: "#e7e5df",
        fillOpacity: g?.includes("Polygon") ? 0.9 : 0,
        opacity: 0.95,
      };
    if (k === "path")
      return {
        ...common,
        color: "#828c87",
        weight: 1,
        fillColor: "#eeeeea",
        fillOpacity: g?.includes("Polygon") ? 0.72 : 0,
        dashArray: g?.includes("Polygon") ? null : "5 4",
      };
    if (k === "rail")
      return { ...common, color: "#34383a", weight: 2, dashArray: "9 4" };
    if (k === "water")
      return {
        ...common,
        color: "#5795b7",
        weight: 1.2,
        fillColor: "#c7e3ed",
        fillOpacity: 0.65,
      };
    if (k === "barrier")
      return { ...common, color: "#39433e", weight: 1.3, dashArray: "3 2" };
    if (k === "land")
      return {
        ...common,
        color: "#98a899",
        weight: 0.7,
        fillColor: "#e7ece7",
        fillOpacity: 0.3,
      };
    if (k === "power")
      return { ...common, color: "#9b4b8e", weight: 1.4, dashArray: "8 5" };
    return { ...common, color: "#a0aaa5", weight: 1, fillOpacity: 0 };
  }
  function readSupportTypes(f) {
    try {
      return JSON.parse(f.properties.supportTypesJSON || "{}");
    } catch {
      return {};
    }
  }
  function supportKey(c) {
    return Number(c[0]).toFixed(7) + "," + Number(c[1]).toFixed(7);
  }
  function ohlCoords(g, f = null) {
    try {
      const pts = JSON.parse(f?.properties?.supportPointsJSON || "[]");
      if (Array.isArray(pts) && pts.length) return pts.filter(G.validCoord);
    } catch {}
    if (g.type === "LineString") return g.coordinates;
    if (g.type === "MultiLineString") return g.coordinates.flat();
    return [];
  }
  function supportIcon(kind) {
    const cls =
        kind === "pole" ? "pole" : kind === "pylon" ? "pylon" : "unknown",
      txt = kind === "pole" ? "│" : kind === "pylon" ? "△" : "+";
    return L.divIcon({
      className: "",
      html: '<div class="ohl-support ' + cls + '">' + txt + "</div>",
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    });
  }
  function chooseOhlSupport(id, key) {
    const f = state.project.features.find((x) => x.id === id);
    if (!f) return;
    showModal(
      "Overhead-line support",
      '<p class="subtle">Choose the observed support at this point. This changes the drawing symbol only; verify the line and support on site.</p><div class="modal-grid">' +
        button("Wooden / utility pole", "ohlSupport:pole", true) +
        button("Pylon / lattice tower", "ohlSupport:pylon") +
        button("Unknown / not checked", "ohlSupport:unknown") +
        "</div>",
    );
    $("#modalBody").onclick = (e) => {
      const a = e.target.closest("[data-action]")?.dataset.action;
      if (!a?.startsWith("ohlSupport:")) return;
      const map = readSupportTypes(f),
        kind = a.split(":")[1];
      if (kind === "unknown") delete map[key];
      else map[key] = kind;
      f.properties.supportTypesJSON = JSON.stringify(map);
      closeModal();
      commit();
    };
  }
  function renderPlanBase() {
    state.planBaseGroup.clearLayers();
    if (state.base !== "drawing" || !state.project.planBase?.length) return;
    const placed = [];
    for (const f of state.project.planBase) {
      let g;
      try {
        g = G.clipGeometry(f.geometry, planBounds());
      } catch {
        continue;
      }
      if (!g) continue;
      const m = f.properties;
      if (m.baseClass === "tree" && g.type === "Point") {
        const center = g.coordinates,
          pr = G.projection(center),
          r = +m.radius || 3,
          ring = Array.from({ length: 49 }, (_, i) => {
            const a = (i * Math.PI) / 24,
              rr = r * (1 + 0.1 * Math.sin(a * 12));
            return latlng(pr.ll([Math.cos(a) * rr, Math.sin(a) * rr]));
          });
        L.polygon(ring, {
          color: "#7e9583",
          weight: 0.6,
          fillColor: "#f5f8f3",
          fillOpacity: 0.6,
          interactive: false,
        }).addTo(state.planBaseGroup);
        for (const pair of [
          [
            [0, -r * 0.25],
            [0, r * 0.25],
          ],
          [
            [-r * 0.25, 0],
            [r * 0.25, 0],
          ],
        ])
          L.polyline(pair.map(pr.ll).map(latlng), {
            color: "#6b8070",
            weight: 0.7,
            interactive: false,
          }).addTo(state.planBaseGroup);
        continue;
      }
      L.geoJSON(
        { ...f, geometry: g },
        {
          style: () => baseStyle({ ...f, geometry: g }),
          pointToLayer: (ff, ll) =>
            L.circleMarker(ll, { ...baseStyle(f), radius: 2 }),
        },
      ).addTo(state.planBaseGroup);
      if (m.name) {
        const b = G.boundsOf(g);
        let c = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
        try {
          const p = JSON.parse(m.labelPointJSON);
          if (G.inside(p, planBounds())) c = p;
        } catch {}
        const pos = state.map.latLngToContainerPoint(latlng(c));
        if (
          placed.some(
            (p) => Math.abs(p.x - pos.x) < 65 && Math.abs(p.y - pos.y) < 17,
          )
        )
          continue;
        placed.push(pos);
        L.marker(latlng(c), {
          interactive: false,
          icon: L.divIcon({
            className: "base-text-label",
            html: "<span>" + esc(m.name) + "</span>",
            iconSize: [130, 18],
            iconAnchor: [65, 9],
          }),
        }).addTo(state.planBaseGroup);
      }
    }
  }
  function renderRoutes() {
    state.routeGroup.clearLayers();
    if (state.mode === "plan") return;
    for (const r of state.project.routes || []) {
      if (!Array.isArray(r.geometry) || r.geometry.length < 2) continue;
      const l = L.polyline(r.geometry.map(latlng), {
        color: "#00a885",
        weight: 5,
        opacity: 0.85,
        dashArray: r.status === "preview" ? "12 5" : null,
      }).addTo(state.routeGroup);
      const p = HGV_PROFILES[r.profile]?.name || r.vehicleName || "HGV";
      l.bindTooltip(
        esc((r.accessPoint?.label || r.label || "Route to site") + " · " + p),
        { sticky: true, className: "map-label" },
      );
      const mid = r.geometry[Math.floor(r.geometry.length / 2)],
        html =
          '<div class="route-vehicle-marker" title="' +
          esc(p) +
          '"><svg viewBox="0 0 54 30" aria-hidden="true"><path d="M3 7h30v16H3zM33 11h10l8 7v5H33z"/><circle cx="12" cy="24" r="4"/><circle cx="39" cy="24" r="4"/></svg></div>';
      L.marker(latlng(mid), {
        interactive: false,
        zIndexOffset: 180,
        icon: L.divIcon({
          className: "",
          html,
          iconSize: [26, 18],
          iconAnchor: [13, 9],
        }),
      }).addTo(state.routeGroup);
    }
  }
  function renderDimensionView(f) {
    const P=window.SAMIPlanning, d=P.dimensionGeometry(f,state.project.features);
    if(!d) return;
    const selected=state.selected===f.id, color=selected ? "#18a976" : state.base === "drawing" ? "#384951" : "#edf5f0";
    const group=L.featureGroup().addTo(state.group);
    const line=points=>L.polyline(points.map(latlng),{color,weight:selected?1.8:1.15,interactive:true}).addTo(group);
    d.extensions.forEach(line); line(d.line);
    const a=state.map.latLngToContainerPoint(latlng(d.line[0])),b=state.map.latLngToContainerPoint(latlng(d.line[1]));
    const dx=b.x-a.x,dy=b.y-a.y,n=Math.hypot(dx,dy)||1,ux=dx/n,uy=dy/n;
    for(const pt of [a,b]) {
      const corners=[L.point(pt.x-4*(ux-uy),pt.y-4*(uy+ux)),L.point(pt.x+4*(ux-uy),pt.y+4*(uy+ux))];
      line(corners.map(p=>coord(state.map.containerPointToLatLng(p))));
    }
    let angle=Math.atan2(dy,dx)*180/Math.PI+(state.map.getBearing?.()||0);
    angle=((angle+180)%360+360)%360-180;if(angle>90)angle-=180;if(angle< -90)angle+=180;
    const marker=L.marker(latlng(d.midpoint),{keyboard:true,icon:L.divIcon({className:"dimension-note",html:`<button type="button" aria-label="Edit dimension ${esc(P.dimensionLabel(d.length,f.properties))}" style="transform:translate(-50%,-50%) rotate(calc(${angle}deg + var(--counter-bearing,0deg)))">${esc(P.dimensionLabel(d.length,f.properties))}</button>`,iconSize:[0,0]})}).addTo(group);
    group.on("click",e=>{
      if(e.originalEvent)L.DomEvent.stopPropagation(e.originalEvent);
      if(state.tool || state.routePick){if(e.latlng)onMapClick(e);return;}
      selectFeature(f.id); openDrawer("selection",true);
    });
    state.layers.set(f.id,group);
  }
  function render() {
    if (!state.map) return;
    state.group.clearLayers();
    state.layers.clear();
    state.editGroup.clearLayers();
    state.ohlSupportGroup.clearLayers();
    for (const f of state.project.features) if(f.properties.dimension) {
      f.geometry.coordinates = window.SAMIPlanning.resolveDimension(f,state.project.features);
      f.properties.distance = G.length(f.geometry.coordinates);
    }
    renderPlanBase();
    renderRoutes();
    let ohlMarkerCount = 0;
    for (const f of state.project.features) {
      let shown;
      try {
        shown = visibleFeature(f);
      } catch {
        continue;
      }
      if (!shown) continue;
      if (f.properties.dimension) { renderDimensionView(f); continue; }
      const layer = L.geoJSON(shown, {
        style: () => featureStyle(f),
        pointToLayer: (ff, ll) => {
          const m = f.properties;
          if (m.type === "service")
            return L.circleMarker(ll, {
              ...featureStyle(f),
              radius: 6,
              fillOpacity: 0.8,
            });
          const label = m.type === "textBox" ? m.text || m.label : null;
          if (label)
            return L.marker(ll, {
              icon: L.divIcon({
                className: "",
                html: '<div class="text-box-marker">' + esc(label) + "</div>",
                iconSize: [150, 40],
                iconAnchor: [12, 20],
              }),
            });
          if (m.type === "accessPoint")
            return L.marker(ll, {
              icon: L.divIcon({
                className: "",
                html: '<div class="access-pin">↳</div>',
                iconSize: [32, 32],
                iconAnchor: [16, 28],
              }),
            });
          const html =
            m.type === "photo" &&
            typeof m.data === "string" &&
            m.data.startsWith("data:image/")
              ? '<img class="photo-marker" src="' +
                esc(m.data) +
                '" alt="Site photo">'
              : '<div class="marker-note">' +
                (m.type === "hazard-marker"
                  ? "!"
                  : m.type === "photo"
                    ? "▣"
                    : "N") +
                "</div>";
          return L.marker(ll, {
            icon: L.divIcon({
              className: "",
              html,
              iconSize: [28, 28],
              iconAnchor: [14, 14],
            }),
          });
        },
      });
      layer.on("click", (e) => {
        if (state.suppressMapClick > performance.now() && !state.routePick) return;
        if (e.originalEvent) L.DomEvent.stopPropagation(e.originalEvent);
        if (state.groupPick) {
          if (f.properties.locked) return;
          completeGroupPick(f);
          return;
        }
        if (state.tool || state.routePick) {
          if (e.latlng) onMapClick({ latlng: e.latlng, originalEvent: e.originalEvent });
          return;
        }
        selectFeature(f.id);
      });
      if (f.properties.type === "measure") {
        const total = geometryLength(f.geometry);
        layer.bindTooltip("Σ " + formatDistance(total), {
          permanent: true,
          className: "map-label dimension-label total-dimension",
          direction: "center",
        });
        const lines =
          f.geometry.type === "LineString"
            ? [f.geometry.coordinates]
            : f.geometry.type === "MultiLineString"
              ? f.geometry.coordinates
              : [];
        let count = 0;
        for (const line of lines)
          for (let i = 1; i < line.length && count < 24; i++) {
            const a = line[i - 1],
              b = line[i],
              d = G.distance(a, b);
            if (d < 0.15) continue;
            const mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
            L.marker(latlng(mid), {
              interactive: false,
              icon: L.divIcon({
                className: "measure-segment-label",
                html: "<span>" + esc(formatDistance(d)) + "</span>",
                iconSize: [72, 18],
                iconAnchor: [36, 9],
              }),
            }).addTo(state.group);
            count++;
          }
      } else if (["asset", "note"].includes(f.properties.type)) {
        const dim =
            f.properties.type === "asset" &&
            f.properties.length &&
            f.properties.width
              ? " · " +
                Number(f.properties.length).toFixed(1) +
                "×" +
                Number(f.properties.width).toFixed(1) +
                "m"
              : "",
          txt =
            f.properties.type === "asset"
              ? (f.properties.symbol ? f.properties.symbol + " · " : "") +
                (f.properties.label || "") +
                dim
              : f.properties.text || f.properties.label;
        layer.bindTooltip(esc(txt), {
          permanent: false,
          className: "map-label",
          direction: "center",
        });
      }
      layer.addTo(state.group);
      state.layers.set(f.id, layer);
      renderDirectionMarker(f, shown);
      renderStoneTexture(f, shown);
      if (
        f.properties.type === "service" &&
        f.properties.serviceType === "ohl" &&
        ["LineString", "MultiLineString"].includes(shown.geometry.type) &&
        ohlMarkerCount < 800
      ) {
        const types = readSupportTypes(f);
        const seen = new Set();
        for (const c of ohlCoords(shown.geometry, f)) {
          if (
            state.project.area &&
            !G.inside(
              c,
              state.base === "drawing" ? planBounds() : serviceBounds(),
            )
          )
            continue;
          const key = supportKey(c);
          if (seen.has(key) || ohlMarkerCount++ > 800) continue;
          seen.add(key);
          const marker = L.marker(latlng(c), {
            icon: supportIcon(types[key]),
            zIndexOffset: 400,
          }).addTo(state.ohlSupportGroup);
          marker.on("click", (e) => {
            L.DomEvent.stopPropagation(e.originalEvent);
            chooseOhlSupport(f.id, key);
          });
        }
      }
    }
    if (state.areaLayer) state.map.removeLayer(state.areaLayer);
    if (state.project.area) {
      const b = state.project.area,
        frame = state.project.planFrame;
      state.areaLayer =
        frame?.length === 4
          ? L.polygon([...frame, frame[0]].map(latlng), {
              color: "#098b69",
              weight: 2,
              dashArray: "8 5",
              fillOpacity: 0,
              interactive: false,
            }).addTo(state.map)
          : L.rectangle(
              [
                [b[1], b[0]],
                [b[3], b[2]],
              ],
              {
                color: "#098b69",
                weight: 2,
                dashArray: "8 5",
                fillOpacity: 0,
                interactive: false,
              },
            ).addTo(state.map);
    }
    $("#areaChip").textContent = state.project.area
      ? "Site area · " + areaText()
      : "＋ Define site area";
    renderAssetIllustrations();
    if (state.vertexEditId) renderVertexHandles();
    else renderTransformHandles();
    updateCadOverlay();
    updateLock();
    updateHistory();
  }
  function snapshot(initial = false) {
    const s = JSON.stringify(state.project);
    if (initial) {
      state.history = [s];
      state.future = [];
    } else if (s !== state.history.at(-1)) {
      state.history.push(s);
      while (
        state.history.length > 2 &&
        (state.history.length > 40 ||
          state.history.reduce((n, x) => n + x.length, 0) > 20000000)
      )
        state.history.shift();
      state.future = [];
    }
    updateHistory();
  }
  function commit() {
    snapshot();
    render();
    saveSoon();
  }
  function updateHistory() {
    if (!$("#undoBtn")) return;
    $("#undoBtn").disabled = state.tool
      ? state.points.length === 0
      : state.history.length < 2;
    $("#redoBtn").disabled = !!state.tool || !state.future.length;
  }
  function undo() {
    if (state.tool) {
      backPoint();
      return;
    }
    if (state.history.length < 2) return;
    abortLayerRequest();
    state.future.push(state.history.pop());
    restoreHistory(state.history.at(-1));
    toast("Undone.");
  }
  function redo() {
    if (state.tool || !state.future.length) return;
    abortLayerRequest();
    const s = state.future.pop();
    state.history.push(s);
    restoreHistory(s);
    toast("Redone.");
  }
  function restoreHistory(s) {
    state.project = JSON.parse(s);
    state.areaGeneration++;
    state.planCaptureError = null;
    state.cache.clear();
    state.selected = null;
    $("#projectName").value = state.project.name;
    render();
    if (state.mode === "plan" && state.project.area) fitArea();
    if (state.drawer) renderDrawer(state.drawer);
    saveSoon();
  }
  let saveTimer;
  function saveSoon() {
    clearTimeout(saveTimer);
    $("#saveState").textContent = "Saving…";
    saveTimer = setTimeout(saveNow, 450);
  }
  function saveNow() {
    clearTimeout(saveTimer);
    if (window.SAMIWorkspace) return window.SAMIWorkspace.save();
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(state.project));
      $("#saveState").textContent = "Saved on this device";
      return true;
    } catch {
      $("#saveState").textContent = "Export a backup";
      toast("Device storage is full. Export your project backup now.");
      return false;
    }
  }
  function readPref(k) {
    try {
      return localStorage.getItem(k);
    } catch {
      return null;
    }
  }
  function setPref(k, v) {
    try {
      localStorage.setItem(k, v);
    } catch {}
  }
  function startTool(tool, options = {}) {
    dismissWelcome();
    cancelDraw();
    $("#samiPanel").classList.remove("open");
    state.selected = null;
    if (
      (tool === "service" || tool === "serviceFreehand") &&
      !state.project.area
    ) {
      openDrawer("area");
      toast("Define the site area for service records first.");
      return;
    }
    state.tool = tool;
    state.options = copy(options);
    state.points = [];
    $("#map").classList.add("drawing-active");
    $("#drawStatus").hidden = false;
    const names = {
      planArea: "Site frame · two corners",
      planAreaFreehand: "Site frame · freehand envelope",
      planAreaPoints: "Site frame · point boundary",
      panelRoute: "Trakway · touch line",
      panelFreehand: "Trakway · freehand run",
      panelAreaFreehand: "Trakway · fill area",
      trakwayLine: "Trakway line · no grid",
      trakwayArea: "Trakway area · no grid",
      singlePanel: "Place a panel",
      asset: "Place " + (options.label || "asset"),
      serviceFreehand: "Draw service",
      accessFreehand: "Access · freehand",
      egressFreehand: "Egress · freehand",
      routeFreehand: "Route · freehand",
      areaFreehand: "Area · freehand",
      hazardFreehand: "Concern area · freehand",
      excavationFreehand: "Excavation · freehand",
      stoneRoadFreehand: "Stone road · freehand",
      stoneAreaFreehand: "Stone area · freehand",
    };
    $("#toolName").textContent =
      names[tool] || TYPES[baseToolName(tool)] || tool;
    renderDraft();
    if (isFreehandTool(tool))
      toast(
        tool === "planAreaFreehand"
          ? "Sketch around the space you need. SAMI retains the current viewed orientation for Site Plan."
          : "Draw with one finger or pointer. Lift to finish.",
      );
  }
  function cancelDraw() {
    if (state.groupPick) restoreGroupPick(state.groupPick);
    state.tool = null;
    state.points = [];
    state.options = {};
    $("#map").classList.remove("drawing-active");
    state.freehandActive = false;
    state.vertexEditId = null;
    state.groupPick = null;
    state.draftGroup?.clearLayers();
    state.editGroup?.clearLayers();
    if ($("#drawStatus")) $("#drawStatus").hidden = true;
    if ($("#finishDrawBtn")) $("#finishDrawBtn").textContent = "Finish";
    updateLock();
    updateHistory();
  }
  function backPoint() {
    if (state.points.length) {
      state.points.pop();
      renderDraft();
    }
  }
  function snapped(c) {
    return window.SAMIWorkspace?.snap(c) || c;
  }
  function insidePlanFrame(c) {
    const frame = state.project.planFrame;
    if (!frame?.length) return !state.project.area || G.inside(c, planBounds());
    const pr = G.projection(c),
      ring = frame.map(pr.xy);
    return pointInRingXY([0, 0], ring);
  }
  function segmentDistanceM(c, a, b) {
    const pr = G.projection(c),
      x = pr.xy(a),
      y = pr.xy(b),
      dx = y[0] - x[0],
      dy = y[1] - x[1],
      t = Math.max(
        0,
        Math.min(1, (-x[0] * dx - x[1] * dy) / (dx * dx + dy * dy || 1)),
      );
    return Math.hypot(x[0] + dx * t, x[1] + dy * t);
  }
  function hitFeatureAt(c) {
    const threshold = Math.max(
      0.35,
      14 *
        ((40075016.686 * Math.cos((c[1] * Math.PI) / 180)) /
          (256 * Math.pow(2, state.map.getZoom()))),
    );
    for (const f of [...state.project.features].reverse()) {
      if (f.properties.hidden || f.properties.guideHidden) continue;
      let shown;
      try {
        shown = visibleFeature(f);
      } catch {
        continue;
      }
      if (!shown) continue;
      const g = shown.geometry;
      if (g.type === "Point") {
        if (G.distance(c, g.coordinates) <= threshold) return f;
        continue;
      }
      const lines =
        g.type === "LineString"
          ? [g.coordinates]
          : g.type === "MultiLineString"
            ? g.coordinates
            : g.type === "Polygon"
              ? g.coordinates
              : g.type === "MultiPolygon"
                ? g.coordinates.flat()
                : [];
      if (g.type === "Polygon" || g.type === "MultiPolygon") {
        const polys = g.type === "Polygon" ? [g.coordinates] : g.coordinates,
          pr = G.projection(c);
        for (const poly of polys) {
          if (
            pointInRingXY([0, 0], poly[0].map(pr.xy)) &&
            !poly.slice(1).some((r) => pointInRingXY([0, 0], r.map(pr.xy)))
          )
            return f;
        }
      }
      for (const line of lines)
        for (let i = 1; i < line.length; i++)
          if (segmentDistanceM(c, line[i - 1], line[i]) <= threshold) return f;
    }
    return null;
  }
  function snapToCorner(c, prevPoint) {
    const corners = [];
    for (const f of state.project.features) {
      if (f.properties.hidden || f.properties.guideHidden) continue;
      const g = f.geometry;
      if (g.type === "Point") {
        corners.push(g.coordinates);
      } else if (g.type === "LineString") {
        g.coordinates.forEach((coord) => corners.push(coord));
      } else if (g.type === "MultiLineString") {
        g.coordinates.forEach((line) =>
          line.forEach((coord) => corners.push(coord))
        );
      } else if (g.type === "Polygon") {
        g.coordinates[0].forEach((coord) => corners.push(coord));
      } else if (g.type === "MultiPolygon") {
        g.coordinates.forEach((poly) =>
          poly[0].forEach((coord) => corners.push(coord))
        );
      }
    }
    if (!corners.length || !prevPoint) return c;
    const snapDistances = [10, 8, 6, 4, 2];
    const pr = G.projection(c);
    let bestSnap = null;
    let bestDist = Infinity;
    for (const snapDist of snapDistances) {
      const snapThresholdDeg = (snapDist / 111000) * 1.5;
      for (const corner of corners) {
        const dist = G.distance(c, corner);
        if (dist > snapThresholdDeg) continue;
        const prevXY = pr.xy(prevPoint);
        const cornerXY = pr.xy(corner);
        const currentXY = pr.xy(c);
        const incomingDx = cornerXY[0] - prevXY[0];
        const incomingDy = cornerXY[1] - prevXY[1];
        const outgoingDx = currentXY[0] - cornerXY[0];
        const outgoingDy = currentXY[1] - cornerXY[1];
        const dotProduct =
          incomingDx * outgoingDx + incomingDy * outgoingDy;
        const mag1 = Math.hypot(incomingDx, incomingDy);
        const mag2 = Math.hypot(outgoingDx, outgoingDy);
        if (mag1 > 0 && mag2 > 0) {
          const cosAngle = dotProduct / (mag1 * mag2);
          if (cosAngle < -0.3 && dist < bestDist) {
            bestSnap = corner;
            bestDist = dist;
          }
        }
      }
      if (bestSnap) return bestSnap;
    }
    return c;
  }
  function onMapClick(e) {
    const raw = coord(e.latlng);
    if (state.routePick) {
      const which = state.routePick, project = state.project;
      state.routePick = null;
      state.project.hgv = {
        ...state.project.hgv,
        [which]: raw,
        [which + "Text"]: coordLabel(raw),
        [which + "Address"]: "",
        [which + "W3w"]: "",
      };
      commit();
      openDrawer("routeToSite");
      toast(
        "Route " +
          (which === "start" ? "start" : "destination") +
          " selected · looking up address / what3words…",
      );
      routePointDetails(raw).then((details) => {
        if (state.project !== project) return;
        const current = state.project.hgv?.[which];
        if (!current || G.distance(current, raw) > 0.2) return;
        const text = details.what3words || details.address || coordLabel(raw);
        state.project.hgv = {
          ...state.project.hgv,
          [which + "Text"]: text,
          [which + "Address"]: details.address,
          [which + "W3w"]: details.what3words,
        };
        commit();
        if (state.drawer === "routeToSite") renderDrawer("routeToSite");
        if (details.what3words)
          toast("what3words added to the route point automatically.");
      });
      return;
    }
    if (!state.tool) {
      const hit = hitFeatureAt(raw);
      if (hit) {
        const isCtrlClick = e.originalEvent?.ctrlKey || e.originalEvent?.metaKey;
        if (isCtrlClick) {
          if (state.multiSelection.has(hit.id)) {
            state.multiSelection.delete(hit.id);
          } else {
            state.multiSelection.add(hit.id);
          }
          state.selected = null;
          render();
          return;
        }
        if (state.multiSelection.size > 0) {
          state.multiSelection.clear();
        }
        selectFeature(hit.id, false);
        return;
      }
      state.selected = null;
      state.multiSelection.clear();
      render();
      return;
    }
    if (isFreehandTool(state.tool)) return;
    const c = snapped(raw);
    if (
      state.mode === "plan" &&
      state.project.area &&
      !["service", "contribution"].includes(baseToolName(state.tool)) &&
      !["planArea", "planAreaPoints"].includes(state.tool) &&
      !insidePlanFrame(c)
    ) {
      toast("Tap inside the site drawing area.");
      return;
    }
    if (
      ["service", "contribution"].includes(baseToolName(state.tool)) &&
      state.project.area &&
      !G.inside(c, serviceBounds())
    ) {
      toast("Service information is limited to the site area plus 0.1 mile.");
      return;
    }
    if (
      [
        "asset",
        "singlePanel",
        "note",
        "photo",
        "hazard-marker",
        "textBox",
      ].includes(state.tool)
    ) {
      placeItem(c);
      return;
    }
    if (state.points.length && G.distance(state.points.at(-1), c) < 0.02)
      return;
    state.points.push(c);
    renderDraft();
    if (
      ["planArea", "rectangle"].includes(state.tool) &&
      state.points.length === 2
    )
      finishDraw();
  }
  function renderDraft() {
    state.draftGroup.clearLayers();
    if (!state.tool) return;
    const ps = state.points,
      polygon =
        [
          "area",
          "hazard",
          "planArea",
          "planAreaFreehand",
          "planAreaPoints",
          "panelAreaFreehand",
          "areaFreehand",
          "hazardFreehand",
          "rectangle",
          "excavation",
          "excavationFreehand",
          "circle",
          "stoneArea",
          "stoneAreaFreehand",
        ].includes(state.tool) ||
        (["service", "serviceFreehand", "contribution"].includes(state.tool) &&
          state.options.area);
    let coords = ps;
    if (state.tool === "planArea" && ps.length === 2) {
      const b = paperRatioBoundsFromPoints(ps);
      coords = G.boundsGeometry(b).coordinates[0];
    }
    if (state.tool === "rectangle" && ps.length === 2)
      coords = G.boundsGeometry(boundsFromPoints(ps)).coordinates[0];
    if (state.tool === "circle" && ps.length === 2)
      coords = G.circlePolygon(ps[0], G.distance(ps[0], ps[1]), 48)
        .coordinates[0];
    if (coords.length > 1)
      (polygon && coords.length > 2
        ? L.polygon(coords.map(latlng), {
            color: "#00a481",
            weight: 3,
            fillOpacity: 0.14,
            interactive: false,
          })
        : L.polyline(coords.map(latlng), {
            color: "#00a481",
            weight: 3,
            dashArray: isFreehandTool(state.tool) ? null : "6 5",
            interactive: false,
          })
      ).addTo(state.draftGroup);
    if (!isFreehandTool(state.tool))
      ps.forEach((p) =>
        L.marker(latlng(p), {
          interactive: false,
          icon: L.divIcon({
            className: "",
            html: '<div class="draft-vertex"></div>',
            iconSize: [10, 10],
            iconAnchor: [5, 5],
          }),
        }).addTo(state.draftGroup),
      );
    if (state.snapPoint)
      L.marker(latlng(state.snapPoint), {
        interactive: false,
        icon: L.divIcon({
          className: "",
          html: '<div class="draft-snap-point"></div>',
          iconSize: [14, 14],
          iconAnchor: [7, 7],
        }),
      }).addTo(state.draftGroup);
    const repeatPlace = ["asset", "singlePanel"].includes(state.tool),
      single = ["note", "photo", "hazard-marker", "textBox"].includes(
        state.tool,
      ),
      free = isFreehandTool(state.tool);
    $("#finishDrawBtn").hidden =
      single || free || state.tool === "planArea" || state.tool === "rectangle";
    $("#backPointBtn").hidden = single || repeatPlace || free;
    $("#backPointBtn").disabled = !ps.length;
    const min = state.tool === "circle" ? 2 : polygon ? 3 : 2;
    $("#finishDrawBtn").disabled = repeatPlace
      ? !state.options.placedIds?.length
      : ps.length < min;
    $("#finishDrawBtn").textContent =
      polygon && !free && state.tool !== "circle" && state.tool !== "rectangle"
        ? "Close shape"
        : "Finish";
    $("#drawHint").textContent = free
      ? ps.length
        ? "Keep drawing · lift to finish."
        : "Draw directly on Map, Satellite or CAD view."
      : repeatPlace
        ? (state.options.placedIds?.length || 0) +
          " placed · tap another position or Finish."
        : single
          ? "Tap the exact position on your site drawing."
          : state.tool === "circle"
            ? ps.length
              ? "Tap the circle edge, then Finish."
              : "Tap the circle centre."
            : state.tool === "planArea"
              ? "Tap two opposite corners. The current view and bearing are retained for Site Plan."
              : state.tool === "planAreaPoints"
                ? ps.length
                  ? `${ps.length} points · add more, then Close shape.`
                  : "Drop points around the space, then Close shape."
                : state.tool === "rectangle"
                  ? "Tap two opposite corners."
                  : ps.length
                    ? `${ps.length} points · ${formatDistance(G.length(ps))} · add more, then ${polygon ? "Close shape" : "Finish"}.`
                    : "Tap points deliberately, then finish.";
    updateHistory();
  }
  function boundsFromPoints(ps) {
    const pts = (ps || []).filter(G.validCoord);
    if (!pts.length) return null;
    return [
      Math.min(...pts.map((p) => p[0])),
      Math.min(...pts.map((p) => p[1])),
      Math.max(...pts.map((p) => p[0])),
      Math.max(...pts.map((p) => p[1])),
    ];
  }
  function finishDraw() {
    if (state.vertexEditId) {
      exitVertexEdit(true);
      return;
    }
    const tool = state.tool,
      ps = copy(state.points),
      opt = copy(state.options);
    if (!tool) return;
    const base = baseToolName(tool);
    try {
      if (["asset", "singlePanel"].includes(tool)) {
        const ids = state.options.placedIds || [];
        if (!ids.length) return;
        cancelDraw();
        state.selected = null;
        commit();
        toast(
          ids.length +
            " item" +
            (ids.length === 1 ? "" : "s") +
            " placed · Select mode.",
        );
        return;
      }
      if (["planArea", "planAreaFreehand", "planAreaPoints"].includes(tool)) {
        if (ps.length < (tool === "planArea" ? 2 : 3)) return;
        setArea(boundsFromPoints(ps));
        return;
      }
      if (tool === "panelRoute" || tool === "panelFreehand") {
        if (ps.length < 2) return;
        addPanelRun(ps, opt);
        return;
      }
      if (tool === "panelAreaFreehand") {
        if (ps.length < 3) return;
        addPanelFill(ps, opt);
        return;
      }
      if (tool === "trakwayLine") {
        if (ps.length < 2) return;
        const clean = simplifyLine(ps, 0.3),
          geom = { type: "LineString", coordinates: clean },
          added = feature("trakway", geom, {
            ...opt,
            label: opt.label || "Trakway line",
            trakwayKind: "line",
            includeLegend: true,
          });
        state.project.features.push(added);
        cancelDraw();
        state.selected = null;
        commit();
        toast("Trakway line created · Select mode.");
        return;
      }
      if (tool === "trakwayArea") {
        if (ps.length < 3) return;
        const clean = simplifyLine(ps, 0.45);
        if (clean.length < 3) throw Error("Sketch a larger trakway area.");
        const geom = {
            type: "Polygon",
            coordinates: [[...clean, clean[0].slice()]],
          },
          added = feature("trakway", geom, {
            ...opt,
            label: opt.label || "Trakway area",
            trakwayKind: "area",
            includeLegend: true,
          });
        state.project.features.push(added);
        cancelDraw();
        state.selected = null;
        commit();
        toast("Trakway area created · Select mode.");
        return;
      }
      if (tool === "contribution") {
        if (finishContribution(ps, opt)) return;
      }
      if (base === "stoneRoad") {
        if (ps.length < 2) return;
        const clean = simplifyLine(ps, 0.35),
          geom = G.lineBuffer(clean, +opt.width || 4);
        if (!geom) throw Error("Could not create the stone-road corridor.");
        const added = feature("stoneRoad", geom, {
          ...opt,
          stoneKind: "road",
          length: G.length(clean),
          includeLegend: true,
        });
        state.project.features.push(added);
        cancelDraw();
        state.selected = null;
        commit();
        toast("Stone road created and neatened · Select mode.");
        return;
      }
      if (base === "stoneArea") {
        if (ps.length < 3) return;
        const clean = simplifyLine(ps, 0.45);
        if (clean.length < 3) throw Error("Sketch a larger stone area.");
        const geom = {
            type: "Polygon",
            coordinates: [[...clean, clean[0].slice()]],
          },
          added = feature("stoneRoad", geom, {
            ...opt,
            label: opt.label || "Stone area",
            stoneKind: "area",
            includeLegend: true,
          });
        state.project.features.push(added);
        cancelDraw();
        state.selected = null;
        commit();
        toast("Stone area created · Select mode.");
        return;
      }
      let polygon =
        ["area", "hazard", "excavation"].includes(base) ||
        ["rectangle", "circle"].includes(tool) ||
        (base === "service" && opt.area);
      if (tool === "circle" && ps.length < 2) return;
      if (
        ps.length <
        (tool === "rectangle" ? 2 : tool === "circle" ? 2 : polygon ? 3 : 2)
      )
        return;
      const clean = isFreehandTool(tool)
        ? simplifyLine(ps, polygon ? 0.45 : 0.3)
        : ps;
      let geom =
        tool === "rectangle"
          ? G.boundsGeometry(boundsFromPoints(ps))
          : tool === "circle"
            ? G.circlePolygon(ps[0], G.distance(ps[0], ps[1]), 48)
            : polygon
              ? { type: "Polygon", coordinates: [[...clean, clean[0].slice()]] }
              : { type: "LineString", coordinates: clean };
      if (
        polygon &&
        geom.type === "Polygon" &&
        Math.abs(signedArea(geom.coordinates[0])) < 1e-16
      )
        throw Error("The area needs a non-zero width and height.");
      if (base === "service") {
        geom = G.clipGeometry(geom, serviceBounds());
        if (!geom)
          throw Error(
            "No service geometry falls inside the site area + 0.1 mile service buffer.",
          );
      }
      const type =
          ["rectangle", "circle"].includes(tool) || base === "arrow"
            ? "shape"
            : base === "service"
              ? "service"
              : base,
        properties = {
          ...opt,
          shapeKind:
            tool === "circle"
              ? "circle"
              : base === "arrow"
                ? "arrow"
                : tool === "rectangle"
                  ? "rectangle"
                  : opt.shapeKind,
          includeLegend: opt.includeLegend !== false,
        };
      if (base === "measure") properties.distance = G.length(clean);
      if (base === "arrow")
        Object.assign(properties, {
          shapeKind: "arrow",
          label: opt.label || "Direction arrow",
        });
      if (base === "excavation") properties.label = opt.label || "Excavation";
      if (["access", "egress", "route"].includes(base))
        properties.showArrow = opt.showArrow !== false;
      const added = feature(type, geom, properties);
      state.project.features.push(added);
      cancelDraw();
      state.selected = null;
      commit();
      toast((TYPES[type] || "Item") + " added · Select mode.");
    } catch (e) {
      toast(e.message);
    }
  }
  function signedArea(r) {
    let s = 0;
    for (let i = 1; i < r.length; i++)
      s += r[i - 1][0] * r[i][1] - r[i][0] * r[i - 1][1];
    return s / 2;
  }
  function placePanelLayout(c, o, trackPlacement = true) {
    const product = PRODUCTS[o.panelProduct] || PRODUCTS.lion,
      groupId = uid(),
      runId = "layout_" + groupId,
      pr = G.projection(c),
      a = ((+o.angle || 0) * Math.PI) / 180,
      u = [Math.sin(a), Math.cos(a)],
      v = [Math.cos(a), -Math.sin(a)],
      ids = [];
    for (const q of (o.panelLayout || []).slice(0, 500)) {
      if (
        !Array.isArray(q) ||
        !Number.isFinite(+q[0]) ||
        !Number.isFinite(+q[1])
      )
        continue;
      const x = +q[0],
        y = +q[1],
        cc = pr.ll([u[0] * y + v[0] * x, u[1] * y + v[1] * x]),
        pa = (+o.angle || 0) + (+q[2] || 0),
        pf = feature(
          "panel",
          G.rectangle(cc, +product.length, +product.width, pa),
          {
            ...product,
            product: o.panelProduct || "lion",
            type: "panel",
            label: product.name,
            groupId,
            runId,
            layoutAsset: o.kind || "",
            layoutName: o.name || o.label || "Trakway layout",
            corner: false,
            junctionRow: 0,
            cornerRule: "premade scaled layout",
            centerLng: cc[0],
            centerLat: cc[1],
            angle: pa,
            includeLegend: true,
          },
        );
      state.project.features.push(pf);
      ids.push(pf.id);
    }
    if (!ids.length) return [];
    if (trackPlacement)
      state.options.placedIds = [...(state.options.placedIds || []), ...ids];
    return ids;
  }
  function placeItem(c) {
    const tool = state.tool,
      o = state.options;
    let f;
    if (tool === "asset" || tool === "singlePanel") {
      if (
        tool === "asset" &&
        Array.isArray(o.panelLayout) &&
        o.panelLayout.length
      ) {
        const ids = placePanelLayout(c, o, true);
        if (!ids.length) {
          toast("This Trakway layout contains no panels.");
          return;
        }
        cancelDraw();
        state.selected = ids[0];
        commit();
        toast("Layout placed · Select mode.");
        return;
      }
      f = feature(
        tool === "asset" ? "asset" : "panel",
        G.rectangle(c, +o.length, +o.width, +o.angle || 0),
        {
          ...o,
          centerLng: c[0],
          centerLat: c[1],
          includeLegend: o.includeLegend !== false,
        },
      );
      state.project.features.push(f);
      cancelDraw();
      state.selected = f.id;
      commit();
      toast("Item placed · Select mode.");
      return;
    }
    f = feature(
      tool,
      { type: "Point", coordinates: c },
      { ...o, includeLegend: o.includeLegend !== false },
    );
    state.project.features.push(f);
    cancelDraw();
    state.selected = null;
    commit();
    toast("Item placed · Select mode.");
  }
  function setArea(b, frame = null, planView = null) {
    if (!G.validBounds(b) || G.area(b) < 1) {
      toast("Choose a site area larger than 1 m².");
      return;
    }
    if (G.area(b) > 25000000) {
      toast("Zoom in: keep each site area below 25 km².");
      return;
    }
    abortLayerRequest();
    state.areaGeneration++;
    state.planCaptureError = null;
    state.cache.clear();
    state.project.area = b;
    if (Array.isArray(frame) && frame.length === 4 && frame.every(G.validCoord))
      state.project.planFrame = frame.map(copy);
    else {
      state.project.planFrame = [
        [b[0], b[1]],
        [b[2], b[1]],
        [b[2], b[3]],
        [b[0], b[3]],
      ];
    }
    state.project.planView = planView ? copy(planView) : null;
    state.areaViewPending = true;
    state.project.planBaseMeta = {
      ...(state.project.planBaseMeta || {}),
      stale: true,
      reason: "Site area changed",
    };
    state.project.meta = state.project.meta || {};
    state.project.meta.ohlStale = true;
    cancelDraw();
    commit();
    setMode("plan");
    toast("Site area saved. Draw and place assets in Site Plan.");
    clearTimeout(state._ohlAutoRefresh);
    if (state.project.serviceVisibility?.ohl !== false)
      state._ohlAutoRefresh = setTimeout(() => {
        Promise.resolve(refreshOhlSnapshot?.({ auto: true })).catch(() => {});
      }, 900);
  }
  function useVisibleArea() {
    const sz = state.map.getSize(),
      x1 = Math.min(100, sz.x * 0.2),
      y1 = Math.min(125, sz.y * 0.25),
      x2 = sz.x - Math.min(80, sz.x * 0.18),
      y2 = sz.y - Math.min(115, sz.y * 0.25),
      ps = [
        coord(state.map.containerPointToLatLng([x1, y1])),
        coord(state.map.containerPointToLatLng([x2, y2])),
      ];
    setArea(paperRatioBoundsFromPoints(ps));
  }
  function geometryLength(g) {
    return g.type === "LineString"
      ? G.length(g.coordinates)
      : g.type === "MultiLineString"
        ? g.coordinates.reduce((s, l) => s + G.length(l), 0)
        : 0;
  }
  function openDrawer(kind, reveal = false) {
    dismissWelcome();
    if (state.tool) cancelDraw();
    $("#samiPanel").classList.remove("open");
    state.drawer = kind;
    const el = $("#drawer");
    if (reveal) document.body.classList.remove("inspector-collapsed");
    const visible = !document.body.classList.contains("inspector-collapsed");
    const restore = $("#restoreInspector");
    if (restore) restore.hidden = visible;
    el.classList.add("open");
    el.inert = !visible;
    el.setAttribute("aria-hidden", String(!visible));
    $$("[data-drawer]").forEach((b) =>
      b.classList.toggle("active", b.dataset.drawer === kind),
    );
    renderDrawer(kind);
  }
  function closeDrawer(userCommand = false) {
    if (!userCommand) return;
    document.body.classList.add("inspector-collapsed");
    const el = $("#drawer"),
      restore = $("#restoreInspector");
    if (restore) restore.hidden = false;
    el.inert = true;
    el.setAttribute("aria-hidden", "true");
    if ($('[data-mode="library"]').classList.contains("active"))
      setModeUI(state.mode);
  }
  function section(s) {
    return '<div class="section-title">' + s + "</div>";
  }
  function button(label, action, primary = false) {
    return (
      '<button class="wide-btn ' +
      (primary ? "primary" : "") +
      '" data-action="' +
      action +
      '">' +
      label +
      "</button>"
    );
  }
  function field(id, label, value = "", type = "text", attrs = "") {
    return (
      '<label class="field-label" for="' +
      id +
      '">' +
      label +
      '</label><input class="field" id="' +
      id +
      '" type="' +
      type +
      '" value="' +
      esc(value) +
      '" ' +
      attrs +
      ">"
    );
  }
  function choice(id, label, items, value) {
    return (
      '<label class="field-label" for="' +
      id +
      '">' +
      label +
      '</label><select class="field" id="' +
      id +
      '">' +
      Object.entries(items)
        .map(
          ([k, o]) =>
            '<option value="' +
            k +
            '" ' +
            (k === value ? "selected" : "") +
            ">" +
            esc(o.name || o) +
            "</option>",
        )
        .join("") +
      "</select>"
    );
  }
  function checkedRow(label, attrs, yes) {
    return (
      '<label class="switch-row"><span>' +
      label +
      '</span><input type="checkbox" ' +
      attrs +
      " " +
      (yes ? "checked" : "") +
      "></label>"
    );
  }
  function renderDrawer(kind) {
    const title = {
      routeToSite: "Route to site",
      draw: "Draw on your site",
      panels: "Trakway · top category",
      assets: "Site planning asset library",
      services: "Services & constraints",
      area: "Your site area",
      layers: "Visible layers",
      library: "Your library",
      project: "Your project",
      search: "Find your site",
      help: "Find your tools",
      selection: "Edit item",
      appearance: "Appearance & brand",
    };
    $("#drawerTitle").textContent = title[kind] || "SAMI";
    const box = $("#drawerContent");
    box.innerHTML = (
      {
        routeToSite: routeToSiteHTML,
        draw: drawHTML,
        panels: panelsHTML,
        assets: assetsHTML,
        services: servicesHTML,
        area: areaHTML,
        layers: layersHTML,
        library: libraryHTML,
        project: projectHTML,
        search: searchHTML,
        help: helpHTML,
        selection: selectionHTML,
        appearance: appearanceHTML,
      }[kind] || helpHTML
    )();
    box.onclick = (e) => {
      const b = e.target.closest("[data-action]");
      if (b) runAction(b.dataset.action, b);
    };
    bindDrawer(kind);
  }
  function appearanceHTML() {
    const themes = {
      graphite: "Graphite (dark, default)",
      obsidian: "Obsidian (darker)",
      carbon: "Carbon (high contrast)",
      midnight: "Midnight (cool dark)",
      titanium: "Titanium (neutral dark)",
      blackout: "Blackout (pure black)",
      navy: "Navy (blue dark)",
      slate: "Slate (gray dark)",
      sandstone: "Sandstone (warm dark)",
      arctic: "Arctic (cool light)",
      studioLight: "Studio light (bright)",
      paper: "Paper (clean light)",
      arcticLight: "Arctic light (soft light)",
    };
    const current =
      localStorage.getItem("sami.appearance") || "graphite";
    return (
      '<div class="card"><span class="tag">USER INTERFACE</span><h3>Choose your appearance</h3><p class="subtle">Select a color theme for the SAMI interface. Your choice is saved automatically.</p></div>' +
      '<div class="appearance-grid">' +
      Object.entries(themes)
        .map(
          ([key, label]) =>
            '<button class="appearance-btn' +
            (key === current ? " active" : "") +
            '" data-appearance="' +
            key +
            '" title="' +
            label +
            '">' +
            '<span class="appearance-preview" data-theme="' +
            key +
            '"></span>' +
            "<span>" +
            label +
            "</span>" +
            "</button>",
        )
        .join("") +
      "</div>" +
      '<div class="card"><span class="tag">BRAND CUSTOMIZATION</span><h3>Customize brand colors</h3><p class="subtle">Define custom brand colors for your organization. Colors apply to accents and highlights throughout the interface.</p></div>' +
      '<div class="brand-customization">' +
      field("brandPrimary", "Primary accent",
        localStorage.getItem("sami.brandPrimary") || "#00a885",
        "color") +
      field("brandSecondary", "Secondary accent",
        localStorage.getItem("sami.brandSecondary") || "#00a481",
        "color") +
      '</div>' +
      '<div class="compact-tools">' +
      button("Apply brand colors", "applyBrandColors") +
      button("Reset to defaults", "resetBrandColors") +
      "</div>"
    );
  }
  function drawHTML() {
    const card = (title, desc, methods) =>
      '<div class="draw-object-card"><div><strong>' +
      title +
      "</strong><small>" +
      desc +
      '</small></div><div class="draw-methods">' +
      methods
        .map(
          ([label, action]) =>
            '<button data-action="' + action + '">' + label + "</button>",
        )
        .join("") +
      "</div></div>";
    return (
      '<div class="card drawing-intro"><span class="tag">SITE DRAWING</span><h3>Choose what you want to draw</h3><p class="subtle">The drawing method appears with the item: point line, freehand line, point area or freehand area. Map, Satellite and CAD are only background views.</p><div class="view-shortcuts"><button data-base-jump="street">Map</button><button data-base-jump="satellite">Satellite</button><button data-base-jump="drawing">CAD</button></div></div>' +
      card("Access route", "Entry movement · green directional route", [
        ["Point line", "drawMethod:access:point"],
        ["Freehand", "drawMethod:access:free"],
      ]) +
      card("Egress route", "Exit movement · red directional route", [
        ["Point line", "drawMethod:egress:point"],
        ["Freehand", "drawMethod:egress:free"],
      ]) +
      card("On-site route", "General vehicle/pedestrian route", [
        ["Point line", "drawMethod:route:point"],
        ["Freehand", "drawMethod:route:free"],
      ]) +
      card("Stone road", "Neatened true-width textured road", [
        ["Point line", "drawMethod:stoneRoad:point"],
        ["Freehand", "drawMethod:stoneRoad:free"],
      ]) +
      card("Stone area", "Neatened textured hardstanding / stone surface", [
        ["Point area", "drawMethod:stoneArea:point"],
        ["Freehand area", "drawMethod:stoneArea:free"],
      ]) +
      card("Area / compound", "General boundary or compound", [
        ["Point area", "drawMethod:area:point"],
        ["Freehand area", "drawMethod:area:free"],
      ]) +
      card("Concern / exclusion area", "Restriction or safety zone", [
        ["Point area", "drawMethod:hazard:point"],
        ["Freehand area", "drawMethod:hazard:free"],
      ]) +
      card("Excavation", "Excavation footprint", [
        ["Point area", "drawMethod:excavation:point"],
        ["Freehand area", "drawMethod:excavation:free"],
      ]) +
      section("Precision / annotation") +
      '<div class="compact-tools">' +
      button("Dimension", "draw:measure") +
      button("Rectangle", "draw:rectangle") +
      button("Circle / radius", "draw:circle") +
      button("Direction arrow", "draw:arrow") +
      button("Text box", "draw:textBox") +
      button("Map note", "draw:note") +
      button("Site photo", "draw:photo") +
      "</div>" +
      section("Specialist") +
      button("Trakway · line, freehand or fill", "open:panels", true) +
      button("Pictorial site assets · drag & drop", "open:assets") +
      button("Services & constraints", "open:services") +
      button("Define / redraw site frame", "open:area") +
      '<p class="subtle">Tap any finished item to select it. Editing, grouping, point editing, style and duplication are all available from the selected-item controls.</p>'
    );
  }
  function panelsHTML() {
    const r = state.project.route,
      panels = state.project.features.filter(
        (f) => f.properties.type === "panel",
      );
    return (
      '<div class="card trakway-simple"><span class="tag">TRAKWAY</span><h3>Draw it the way you would mark it on a plan</h3><p class="subtle">Choose the panel once, then either tap a route, draw it freehand, or sketch an area and let SAMI fill it with panels.</p></div>' +
      choice("panelProduct", "Panel type", PRODUCTS, r.product) +
      '<div class="trakway-draw-modes"><button class="hero-tool" data-action="panelRoute"><strong>Touch line</strong><small>Tap route points · Finish</small></button><button class="hero-tool" data-action="panelFreehand"><strong>Freehand run</strong><small>Draw continuously with one finger</small></button><button class="hero-tool" data-action="panelAreaFill"><strong>Fill area</strong><small>Sketch the footprint to panelise</small></button></div>' +
      '<details class="compact-section"><summary>Trakway line & area tools</summary>' +
      '<div class="row equal"><button data-action="trakwayLine"><strong>Trakway line</strong><small>Linear barrier · no grid</small></button><button data-action="trakwayArea"><strong>Trakway area</strong><small>Bounded region · no grid</small></button></div>' +
      '</details>' +
      '<details class="advanced-settings"><summary>Panel setup / joints</summary><div class="row equal"><div>' +
      field(
        "panelLength",
        "Along run (m)",
        r.length,
        "number",
        'min="0.2" max="20" step="0.01"',
      ) +
      "</div><div>" +
      field(
        "panelWidth",
        "Across run (m)",
        r.width,
        "number",
        'min="0.2" max="20" step="0.01"',
      ) +
      "</div></div>" +
      choice(
        "panelLanes",
        "Run width",
        {
          1: { name: "1 panel wide" },
          2: { name: "2 panels wide" },
          3: { name: "3 panels wide" },
          4: { name: "4 panels wide" },
        },
        String(r.lanes),
      ) +
      '<div class="row equal"><div>' +
      field(
        "panelOverlap",
        "Along overlap (m)",
        r.overlap,
        "number",
        'min="0" step="0.01"',
      ) +
      "</div><div>" +
      field(
        "panelLateral",
        "Side overlap (m)",
        r.lateralOverlap,
        "number",
        'min="0" step="0.01"',
      ) +
      '</div></div><p class="subtle">Existing bend overlap rules and Sabre-X stagger warnings remain active.</p></details>' +
      button("Place one panel", "singlePanel") +
      '<div class="card row between"><span>Panels in this project</span><strong class="count">' +
      panels.length +
      "</strong></div>" +
      button("View materials schedule", "open:library") +
      '<p class="subtle">Planning dimensions are editable. Confirm deployed product, joints and quantities before construction.</p>'
    );
  }
  function assetsHTML() {
    const a = state.project.asset,
      cats = assetCategories();
    return (
      '<div class="card"><span class="tag">DRAG & DROP</span><h3>Site assets that look like site assets</h3><p class="subtle">Drag an asset onto the drawing on desktop or iPad. A tap selects it; drag the centre handle to move, the round handle to rotate and the corner handle to resize.</p></div>' +
      Object.entries(cats)
        .map(
          ([cat, items], idx) =>
            '<details class="asset-category" ' +
            (idx === 0 ? "open" : "") +
            "><summary>" +
            esc(cat) +
            '</summary><div class="asset-list visual-assets">' +
            items
              .map(
                ([k, v]) =>
                  '<button class="asset-palette ' +
                  (a.kind === k ? "active" : "") +
                  '" draggable="true" data-asset-drag="' +
                  k +
                  '" data-action="assetChoice:' +
                  k +
                  '"><span class="asset-preview">' +
                  assetIconSVG(k, v) +
                  '</span><span class="asset-copy">' +
                  esc(v.name) +
                  "<small>" +
                  v.length +
                  " × " +
                  v.width +
                  " m</small></span></button>",
              )
              .join("") +
            "</div></details>",
        )
        .join("") +
      section("Selected asset") +
      field("assetLabel", "Label", a.name) +
      '<div class="row equal"><div>' +
      field(
        "assetLength",
        "Length (m)",
        a.length,
        "number",
        'min="0.1" max="500" step="0.1"' +
          (a.dimensionLocked ? " disabled" : ""),
      ) +
      "</div><div>" +
      field(
        "assetWidth",
        "Width (m)",
        a.width,
        "number",
        'min="0.1" max="500" step="0.1"' +
          (a.dimensionLocked ? " disabled" : ""),
      ) +
      "</div></div>" +
      (a.dimensionLocked
        ? '<p class="subtle"><strong>Verified catalogue dimensions locked.</strong> Move and rotate normally; use a custom footprint if you intentionally need different dimensions.</p>'
        : "") +
      field(
        "assetAngle",
        "Rotation clockwise from north (°)",
        a.angle,
        "number",
        'step="5"',
      ) +
      checkedRow(
        "Include in exported legend / schedule",
        'id="assetLegend"',
        a.includeLegend !== false,
      ) +
      button("Tap location to place selected asset", "placeAsset", true) +
      '<p class="subtle">Vehicle and plant footprints retain true planning dimensions. The illustration is a visual identifier, not the clearance envelope.</p>'
    );
  }
  function areaHTML() {
    const b = state.project.area,
      bleed = Number(state.project.planBleed ?? PLAN_BLEED_DEFAULT),
      meta = state.project.planBaseMeta,
      detail = planDetailLevel();
    return (
      '<div class="card"><span class="tag">SITE DRAWING FRAME</span><h3>Define the current view</h3><p class="subtle">Use the visible map as the Site Plan frame. SAMI applies the A3/A4 landscape paper ratio automatically while retaining the current bearing.</p>' +
      button(
        b ? "Redefine area from current view" : "Define area from current view",
        "visibleArea",
        true,
      ) +
      "</div>" +
      (b
        ? '<div class="card"><span class="tag">FRAME DEFINED</span><h3 style="margin:12px 0 4px">' +
          areaText() +
          '</h3><div class="subtle">Landscape paper ratio · view orientation retained.</div></div>'
        : "") +
      '<details class="compact-section"><summary>Manual / irregular area tools</summary><div class="area-method-grid"><button data-action="defineAreaFreehand"><strong>Freehand extent</strong><small>Sketch an irregular extent</small></button><button data-action="defineAreaPoints"><strong>Point boundary</strong><small>Drop points, then Close shape</small></button><button data-action="defineArea"><strong>Two corners</strong><small>Define a rectangular extent manually</small></button></div></details>' +
      (b && state.mode === "plan"
        ? button("Clear defined site area", "clearArea") +
          '<details class="compact-section" open><summary>CAD drawing background</summary>' +
          '<p class="subtle">Site Plan only draws the defined area + bleed - not the wider map. Low detail keeps things fast while drawing; switch up for a detailed preview.</p>' +
          '<div class="radio-cards compact">' +
          [
            ["low", "Low", "Fastest · roads & buildings"],
            ["medium", "Medium", "+ rail, water, landuse, power lines"],
            ["high", "High", "Full detail · trees, barriers, amenities"],
          ]
            .map(
              ([v, label, small]) =>
                `<label><input type="radio" name="planDetail" value="${v}"${detail === v ? " checked" : ""}><span><strong>${label}</strong><small>${small}</small></span></label>`,
            )
            .join("") +
          "</div>" +
          field(
            "planBleed",
            "CAD bleed outside boundary (m)",
            bleed,
            "number",
            'min="0" max="200" step="10"',
          ) +
          '<div class="card"><strong>Stored bounded vector base</strong><p class="subtle">' +
          (meta?.capturedAt
            ? "Captured " +
              esc(new Date(meta.capturedAt).toLocaleString()) +
              " · " +
              (meta.featureCount || 0) +
              " features · " +
              (meta.detail || "low") +
              " detail" +
              (meta.stale ? " · <strong>refresh required</strong>" : "")
            : "Not captured yet.") +
          "</p></div>" +
          button(
            meta?.capturedAt
              ? "Refresh CAD site detail"
              : "Create CAD site drawing",
            "capturePlanBase",
            true,
          ) +
          button("Open CAD drawing background", "cadMode") +
          button("Fit site frame to screen", "fitArea") +
          button("Services · site + 0.1 mile", "open:services") +
          '</details>'
        : "") +
      '<p class="subtle">Issued A3/A4 drawings use the same √2 landscape ratio.</p>'
    );
  }
  function servicesHTML() {
    const s = state.project,
      has = !!s.area,
      counts = {};
    s.features
      .filter((f) => f.properties.type === "service")
      .forEach((f) => {
        counts[f.properties.serviceType] =
          (counts[f.properties.serviceType] || 0) + 1;
      });
    if (!has)
      return (
        '<div class="card"><span class="tag">SERVICES & CONSTRAINTS</span><h3>Define the site frame first</h3><p class="subtle">SAMI keeps service searches bounded to the site plus 0.1 mile.</p></div>' +
        button("Define site frame", "open:area", true)
      );
    if (state.serviceScreen === "mapping") return serviceMappingHTML(counts);
    if (state.serviceScreen === "manual") return manualServiceHTML();
    return '<div class="card"><span class="tag">SERVICES & CONSTRAINTS</span><h3>What do you want to do?</h3><p class="subtle">Keep it simple: show available external mapping, or manually add information from a drawing, survey or site record.</p></div><div class="services-choice-grid"><button data-action="servicesMapping"><span class="service-choice-icon">⌁</span><strong>Service mapping</strong><small>Choose public/reference layers and show them on the site</small></button><button data-action="servicesManual"><span class="service-choice-icon">＋</span><strong>Add service / constraint</strong><small>Draw or import a project record manually</small></button></div><div class="card subtle"><strong>Default mapping view</strong><p>Overhead lines are selected initially. Every other external layer stays off until you choose it.</p></div>';
  }
  function serviceMappingHTML(counts) {
    const s = state.project;
    return (
      '<button class="back-link" data-action="servicesHome">← Services</button><div class="card public-data-card"><span class="tag">SERVICE MAPPING</span><h3>Choose what SAMI should show</h3><p class="subtle">Only checked layers are displayed. Press <strong>Show selected mapping</strong> to refresh the relevant bounded public/reference sources and display what is actually returned.</p></div><div class="service-map-list">' +
      Object.entries(SERVICES)
        .map(([k, v]) =>
          checkedRow(
            '<i class="swatch" style="background:' +
              v.color +
              '"></i>' +
              v.name +
              ' <span class="tag muted">' +
              (counts[k] || 0) +
              "</span>",
            'data-service-toggle="' + k + '"',
            s.serviceVisibility[k] === true,
          ),
        )
        .join("") +
      "</div>" +
      button("Show", "showServiceMapping", true) +
      button("Reset to overhead lines only", "resetServiceMapping") +
      '<details class="advanced-settings"><summary>Source / snapshot tools</summary><p class="subtle">Public layers are planning references only—not safe-dig information. Missing public data does not prove a service is absent.</p>' +
      button("Refresh overhead-line snapshot", "refreshOhl") +
      button("Refresh public mapped utilities", "refreshPublicUtilities") +
      button(
        "Refresh planning constraints (England)",
        "refreshPlanningConstraints",
      ) +
      button("Archived source snapshots", "archives") +
      dataCatalogHTML() +
      "</details>"
    );
  }
  function manualServiceHTML() {
    const k = state.project.serviceType || "electric",
      v = SERVICES[k];
    return (
      '<button class="back-link" data-action="servicesHome">← Services</button><div class="card"><span class="tag">ADD SERVICE / CONSTRAINT</span><h3>Draw a project record</h3><p class="subtle">Choose the record type and use point or freehand drawing. Add a drawing/survey reference whenever possible.</p></div>' +
      choice("serviceType", "Record type", SERVICES, k) +
      field("serviceLabel", "Label", v?.name || "") +
      field(
        "serviceSource",
        "Source / drawing reference",
        "",
        "text",
        'placeholder="e.g. utility drawing U-04 Rev C / survey ref"',
      ) +
      '<div class="draw-methods service-methods"><button data-action="manualServicePoint">' +
      (v?.area ? "Point area" : "Point line") +
      '</button><button data-action="manualServiceFreehand">' +
      (v?.area ? "Freehand area" : "Freehand line") +
      "</button></div>" +
      button("Import GeoJSON / KML / KMZ service data", "importServices") +
      '<details class="advanced-settings"><summary>Contribution / data management</summary>' +
      button("Draw pending contribution", "contribute") +
      button("Export pending contributions", "exportContrib") +
      button("Refresh connected selected sources", "loadServices") +
      "</details>"
    );
  }
  function layersHTML() {
    return (
      '<p class="subtle">Choose which project items are visible. Hidden items remain saved.</p>' +
      Object.entries(TYPES)
        .map(([k, v]) =>
          checkedRow(
            v,
            'data-type-toggle="' + k + '"',
            !state.project.hiddenTypes.includes(k),
          ),
        )
        .join("") +
      button("Choose service types", "open:services") +
      button("Open materials library", "open:library")
    );
  }
  function libraryHTML() {
    const fs = state.project.features,
      p = fs.filter((f) => f.properties.type === "panel"),
      assets = fs.filter((f) => f.properties.type === "asset"),
      counts = {};
    p.forEach((f) => {
      const key =
        f.properties.label +
        "|" +
        f.properties.length +
        "|" +
        f.properties.width;
      counts[key] = (counts[key] || 0) + 1;
    });
    return (
      '<div class="row equal">' +
      button("Add panels", "open:panels", true) +
      button("Add assets", "open:assets") +
      "</div>" +
      section("Materials schedule") +
      '<div class="card row between"><div><strong class="count">' +
      p.length +
      '</strong> panels</div><div><strong class="count">' +
      assets.length +
      "</strong> assets</div></div>" +
      Object.entries(counts)
        .map(([k, n]) => {
          const [label, l, w] = k.split("|");
          return (
            '<div class="item-row"><div><strong>' +
            esc(label) +
            "</strong><small>" +
            esc(l) +
            " × " +
            esc(w) +
            " m</small></div><b>" +
            n +
            "</b></div>"
          );
        })
        .join("") +
      button("Download materials CSV", "csv") +
      section("Routes, areas and assets") +
      (fs
        .filter((f) => f.properties.type !== "panel")
        .slice(0, 200)
        .map(
          (f) =>
            '<div class="item-row"><div><strong>' +
            esc(f.properties.label) +
            "</strong><small>" +
            esc(TYPES[f.properties.type] || f.properties.type) +
            '</small></div><button class="mini-btn" data-action="select:' +
            esc(f.id) +
            '">Edit</button></div>',
        )
        .join("") ||
        '<p class="subtle">Items appear here as you build your plan.</p>') +
      (fs.filter((f) => f.properties.type !== "panel").length > 200
        ? '<p class="subtle">Showing the first 200 items. All items are included in exports.</p>'
        : "")
    );
  }
  function projectHTML() {
    const m = state.project.meta;
    return (
      field("projectNameEdit", "Project name", state.project.name) +
      field("siteAddress", "Site address", m.siteAddress || "") +
      field(
        "what3words",
        "Destination what3words",
        m.what3words || m.w3w || "",
        "text",
        'placeholder="///word.word.word"',
      ) +
      field("siteRef", "Site reference", m.siteRef || "") +
      field("clientName", "Client / contractor", m.clientName || "") +
      '<details class="compact-section"><summary>Drawing / issue metadata</summary>' +
      '<div class="row equal"><div>' +
      field("creator", "Created by", m.creator || "") +
      "</div><div>" +
      field("drawingNo", "Drawing no.", m.drawingNo || "") +
      "</div></div>" +
      field("revision", "Revision", m.revision || "") +
      '</details>' +
      '<details class="compact-section" open><summary>Driver / delivery information</summary>' +
      '<div class="row equal"><div>' +
      field("siteContact", "Site contact", m.siteContact || "") +
      "</div><div>" +
      field("sitePhone", "Contact telephone", m.sitePhone || "", "tel") +
      "</div></div>" +
      field("siteEntrance", "Site entrance / gate", m.siteEntrance || "") +
      '<label class="field-label" for="arrivalInstructions">Arrival instructions</label><textarea class="field" id="arrivalInstructions" rows="3">' +
      esc(m.arrivalInstructions || "") +
      '</textarea><label class="field-label" for="driverNotes">Driver notes</label><textarea class="field" id="driverNotes" rows="3" placeholder="e.g. DO NOT FOLLOW SAT NAV AFTER THIS POINT">' +
      esc(m.driverNotes || "") +
      '</textarea><label class="field-label" for="siteNotes">Site / drawing notes</label><textarea class="field" id="siteNotes" rows="3">' +
      esc(m.siteNotes || "") +
      "</textarea></details>" +
      '<details class="compact-section"><summary>Project files</summary>' +
      button("Save on this device", "save") +
      button("Export editable backup", "backup") +
      button("Restore a SAMI backup", "restore") +
      button("New project", "new") +
      '</details>' +
      '<details class="compact-section"><summary>Location integration & voice</summary>' +
      field(
        "w3wApiKey",
        "what3words API key",
        w3wKey(),
        "password",
        'placeholder="Needed for ///three.word.address lookup"',
      ) +
      '<p class="subtle">what3words requires its API. Coordinates and normal addresses work without this key.</p>' +
      checkedRow(
        "Talk-back using an available device voice",
        'id="voiceOutput"',
        readPref("sami.voice.output") !== "off",
      ) +
      '<label class="field-label" for="samiVoiceSelect">Spoken voice</label><select class="field" id="samiVoiceSelect"></select>' +
      button("Test SAMI voice", "testVoice") +
      '<p class="subtle">Tap the single Ask SAMI control to capture speech when the text box is empty; typed text uses the same button.</p>' +
      button("Reset toolbar position", "resetRail") +
      '</details>'
    );
  }
  function searchHTML() {
    return (
      '<p class="subtle">Search by address, postcode, ///what3words or coordinates. A map point can also be selected directly when setting HGV route endpoints.</p><label class="field-label" for="placeQuery">Address · postcode · ///what3words · lat,lng</label><div class="row"><input class="field" id="placeQuery" placeholder="e.g. WV1 1AA · ///filled.count.soap · 52.58,-2.12"><button class="mini-btn" data-action="search">Find</button></div><div id="placeResults"></div>' +
      button("Use my current location", "locate") +
      '<details class="compact-section"><summary>Coordinates</summary>' +
      field("latInput", "Latitude", "", "number", 'step="any"') +
      field("lngInput", "Longitude", "", "number", 'step="any"') +
      button("Go to coordinates", "coords") +
      '</details>'
    );
  }
  function helpHTML() {
    return [
      [
        "1 · Find the site",
        "Use Find site with an address, postcode, coordinates or ///what3words.",
      ],
      [
        "2 · Define the site frame",
        "Freehand, point-drop, two corners or current view. SAMI stores the current view and bearing as the Site Plan frame, separately from Explore.",
      ],
      [
        "3 · Draw what you need",
        "Choose the object first, then use its point/freehand line or point/freehand area method. Map, Satellite and CAD are background choices.",
      ],
      [
        "4 · Add Trakway",
        "Touch line, Freehand run or Fill area automatically creates a grouped panel result and hides the generating sketch.",
      ],
      [
        "5 · Edit like a mobile design app",
        "Tap an item to select it. Move directly, use Edit points until Done, change Style, then use More for Duplicate / Group / Ungroup / Delete.",
      ],
      [
        "6 · Add pictorial assets",
        "Drag and drop site assets. Safety signs, vehicles, plant, welfare and logistics assets use recognisable pictorial symbols.",
      ],
      [
        "7 · Services & constraints",
        "Open Service mapping to choose external/reference layers and press Show, or open Add service / constraint to draw a project record manually.",
      ],
      [
        "8 · Ask SAMI to build",
        "Try “create a 15 × 15 m pad in Lion panels” or “add a concrete mixer truck”. SAMI interprets the request, then deterministic geometry creates a grouped, scale-locked result.",
      ],
      [
        "9 · Route & Issue",
        "Route to Site stays separate. Export / Issue creates the two-page SAMI Site Logistics Pack from the same project geometry and route data.",
      ],
    ]
      .map(
        ([t, d]) =>
          '<div class="help-step"><strong>' +
          t +
          "</strong><p>" +
          d +
          "</p></div>",
      )
      .join("");
  }
  function selectionHTML() {
    const f = selectedFeature();
    if (!f) return '<p class="subtle">Tap an item to edit it.</p>';
    const m = f.properties,
      members = groupMembers(f),
      grouped = members.length > 1,
      dim =
        ["asset", "panel", "logo"].includes(m.type) && m.length && m.width
          ? '<div class="card subtle">Footprint: ' +
            esc(m.length) +
            " × " +
            esc(m.width) +
            " m" +
            (m.dimensionLocked ? " · <strong>dimensions locked</strong>" : "") +
            "</div>"
          : "",
      canPoints =
        !m.derived &&
        !m.sourceId &&
        !["asset", "panel", "logo"].includes(m.type) &&
        !!editPointData(f),
      defaultColor =
        featureStyle({
          ...f,
          id: "__style_preview__",
          properties: { ...m, groupId: null },
        }).color || "#174d43",
      defaultFill =
        featureStyle({
          ...f,
          id: "__style_preview__",
          properties: { ...m, groupId: null },
        }).fillColor || "#c8d4d0";
    return (
      '<div class="selection-head"><div><span class="tag">' +
      esc(TYPES[m.type] || m.type) +
      (grouped ? " · GROUP" : "") +
      "</span><strong>" +
      esc(m.text || m.label || TYPES[m.type] || "Item") +
      "</strong><small>" +
      (grouped
        ? members.filter((x) => !x.properties.guideHidden).length +
          " items selected together"
        : "Tap-and-drag handles are active on the drawing") +
      "</small></div></div>" +
      dim +
      '<div class="selection-actions"><button data-action="editMove">✥ <span>Move' +
      (grouped ? " group" : "") +
      "</span></button>" +
      (canPoints
        ? '<button data-action="editVertices">⌁ <span>Edit points</span></button>'
        : "") +
      '<button data-action="editStyle">◐ <span>Style</span></button><details class="selection-more"><summary>•••<span>More</span></summary><div>' +
      button("Duplicate", "editDuplicate") +
      button("Bring to front", "editBringFront") +
      button("Send to back", "editSendBack") +
      (grouped
        ? button("Add another item to group", "editGroup") +
          button("Ungroup", "editUngroup")
        : button("Group with another item", "editGroup")) +
      (m.routeId
        ? button("Delete complete Trakway run", "editDeleteRun")
        : "") +
      button("Delete", "editDelete") +
      "</div></details></div>" +
      field("editLabel", "Label", m.text || m.label) +
      checkedRow(
        "Include in exported legend / key",
        'id="editLegend"',
        m.includeLegend !== false,
      ) +
      (["note", "photo"].includes(m.type)
        ? checkedRow(
            "Show on issued drawing",
            'id="editOnDrawing"',
            m.includeOnDrawing !== false,
          )
        : "") +
      button("Save label", "editLabel", true) +
      '<details class="style-editor" id="styleEditor"><summary>Style options</summary><div class="style-grid"><label>Line colour<input id="editStyleColor" type="color" value="' +
      esc(m.styleColor || defaultColor) +
      '"></label><label>Line width<input id="editStyleWeight" type="number" min="0.5" max="12" step="0.5" value="' +
      esc(
        m.styleWeight ||
          featureStyle({
            ...f,
            id: "__style_preview__",
            properties: { ...m, groupId: null },
          }).weight ||
          2,
      ) +
      '"></label><label>Line style<select id="editStyleDash"><option value="solid" ' +
      ((m.styleDash || "solid") === "solid" ? "selected" : "") +
      '>Solid</option><option value="dashed" ' +
      (m.styleDash === "dashed" ? "selected" : "") +
      '>Dashed</option><option value="dotted" ' +
      (m.styleDash === "dotted" ? "selected" : "") +
      '>Dotted</option></select></label><label>Fill colour<input id="editStyleFill" type="color" value="' +
      esc(m.styleFill || defaultFill) +
      '"></label></div>' +
      (["access", "egress", "route"].includes(m.type)
        ? checkedRow(
            "Show direction arrow",
            'id="editShowArrow"',
            m.showArrow !== false,
          )
        : "") +
      button("Apply style", "editApplyStyle", true) +
      "</details>" +
      (m.source
        ? '<div class="card subtle">Source: ' +
          esc(m.source) +
          (m.sourceUrl
            ? '<br><a href="' +
              esc(m.sourceUrl) +
              '" target="_blank" rel="noopener">Open specification source</a>'
            : "") +
          (m.sourceRetrievedAt
            ? "<br>Source checked: " + esc(m.sourceRetrievedAt)
            : "") +
          (m.sourceNote ? "<br>" + esc(m.sourceNote) : "") +
          "<br>Status: " +
          esc(
            m.verification ||
              (m.verifiedDimensions
                ? "Sourced dimensions · confirm actual vehicle/item before issue"
                : "Unverified"),
          ) +
          "</div>"
        : "")
    );
  }
  function serviceInformation(f) {
    const m = f.properties || {},
      svc = SERVICES[m.serviceType] || {
        name: m.serviceType || "Service / constraint",
      },
      rows = [
        ["Type", svc.name],
        ["Name / reference", m.label],
        ["Source", m.source],
        ["Verification", m.verification],
        ["Operator", m.operator],
        ["Voltage", m.voltage],
        ["Line / asset ref", m.lineRef || m.ref],
        [
          "Captured",
          m.capturedAt ? new Date(m.capturedAt).toLocaleString() : null,
        ],
      ].filter(([, v]) => v !== undefined && v !== null && String(v).trim());
    const sourceRef = m.osmWayId
      ? "OpenStreetMap way " + m.osmWayId
      : m.osmNodeId
        ? "OpenStreetMap node " + m.osmNodeId
        : "";
    showModal(
      svc.name,
      `<div class="service-info-panel"><div class="service-info-badge"><i style="background:${esc(svc.color || "#73808b")}"></i><div><small>SERVICE / CONSTRAINT</small><strong>${esc(m.label || svc.name)}</strong></div></div><dl class="service-info-list">${rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(String(v))}</dd></div>`).join("")}${sourceRef ? `<div><dt>Source record</dt><dd>${esc(sourceRef)}</dd></div>` : ""}</dl><p class="service-guidance">Service information is planning/reference information and must be verified against appropriate records, surveys and safe-dig procedures before work.</p>${m.serviceType === "ohl" ? (m.planCommitted ? '<div class="inline-note">Added to CAD · saved with this project</div>' : button("Add OHL", "serviceInfoAddOhl", true)) : ""}<div class="button-pair">${button("Services", "serviceInfoServices")}${button("Edit " + esc(svc.name) + " style", "serviceInfoStyle", true)}</div></div>`,
    );
    $("#modalBody").onclick = (e) => {
      const a = e.target.closest("[data-action]")?.dataset.action;
      if (a === "serviceInfoAddOhl") {
        window.SAMIWorkspace?.runAction?.("addOhlToPlan:" + f.id);
        return;
      }
      if (a === "serviceInfoServices") {
        closeModal();
        window.SAMIWorkspace?.runAction?.("open:services");
      }
      if (a === "serviceInfoStyle") {
        closeModal();
        window.SAMIWorkspace?.runAction?.("serviceStyle:" + m.serviceType);
      }
    };
  }
  function selectFeature(id, fit = false) {
    const f = state.project.features.find((x) => x.id === id);
    if (!f) return;
    if (state.vertexEditId && state.vertexEditId !== id) exitVertexEdit(false);
    else cancelDraw();
    state.selected = id;
    render();
    if (f.properties?.type === "service") serviceInformation(f);
    else if (
      state.drawer === "selection" &&
      !document.body.classList.contains("inspector-collapsed")
    )
      renderDrawer("selection");
    if (fit) {
      const b = groupBounds(groupMembers(f));
      if (b)
        state.map.fitBounds(
          [
            [b[1], b[0]],
            [b[3], b[2]],
          ],
          { maxZoom: 21, padding: [50, 50] },
        );
    }
  }
  function startNote() {
    showModal(
      "Add a site note",
      '<label class="field-label" for="newNote">Text</label><textarea id="newNote" class="field" rows="4"></textarea>' +
        button("Choose its position", "placeNote", true),
    );
    $("#modalBody").onclick = (e) => {
      if (e.target.closest('[data-action="placeNote"]')) {
        const text = $("#newNote").value.trim();
        if (!text) return;
        closeModal();
        startTool("note", {
          text,
          label: text,
          includeOnDrawing: state.mode !== "map",
          includeLegend: state.mode !== "map",
        });
      }
    };
    $("#newNote").focus();
  }
  function bindDrawer(kind) {
    if (kind === "appearance") {
      $$("[data-appearance]").forEach((btn) => {
        btn.onclick = (e) => {
          const theme = btn.dataset.appearance;
          document.documentElement.dataset.theme = theme;
          localStorage.setItem("sami.appearance", theme);
          $$("[data-appearance]").forEach((b) =>
            b.classList.toggle("active", b.dataset.appearance === theme)
          );
          e.stopPropagation();
        };
      });
    }
    if (kind === "routeToSite") {
      $("#hgvProfile").onchange = () => {
        const k = $("#hgvProfile").value,
          v = HGV_PROFILES[k];
        state.project.hgv = {
          ...state.project.hgv,
          profile: k,
          weight: v.weight,
          height: v.height,
          width: v.width,
          length: v.length,
          axles: v.axles,
          stale: !!state.project.routes.length,
        };
        renderDrawer("routeToSite");
        saveSoon();
      };
      [
        "hgvWeight",
        "hgvHeight",
        "hgvWidth",
        "hgvLength",
        "routeStart",
        "routeEnd",
      ].forEach((id) => {
        const el = $("#" + id);
        if (el)
          el.oninput = () => {
            try {
              readHgvOptions();
              state.project.hgv.stale = !!state.project.routes.length;
              saveSoon();
            } catch {}
          };
      });
    }
    if (kind === "draw")
      $$("[data-base-jump]").forEach(
        (el) =>
          (el.onclick = (e) => {
            e.stopPropagation();
            switchBase(el.dataset.baseJump);
          }),
      );
    if (kind === "panels")
      $("#panelProduct").onchange = () => {
        const product = $("#panelProduct").value;
        state.project.route = {
          ...state.project.route,
          product,
          ...PRODUCTS[product],
          lanes: state.project.route.lanes,
        };
        renderDrawer("panels");
        saveSoon();
      };
    if (kind === "assets") {
      $("#assetLegend")?.addEventListener("change", () => {
        state.project.asset.includeLegend = $("#assetLegend").checked;
        saveSoon();
      });
      queueMicrotask(bindAssetPaletteDrag);
    }
    if (kind === "area") {
      $$('input[name="planDetail"]').forEach((r) =>
        r.addEventListener("change", () => {
          if (!r.checked) return;
          state.project.planDetail = r.value;
          commit();
          renderDrawer("area");
          if (planBaseNeedsCapture()) capturePlanBase(true);
        }),
      );
      $("#planBleed")?.addEventListener("change", () => {
        state.project.planBleed = Math.max(
          0,
          Math.min(200, +$("#planBleed").value || 0),
        );
        state.project.planBaseMeta = {
          ...(state.project.planBaseMeta || {}),
          stale: true,
          reason: "Drawing bleed changed",
        };
        commit();
        renderDrawer("area");
      });
      $("#areaAspectLocked")?.addEventListener("change", () => {
        state.project.areaAspectLocked = $("#areaAspectLocked").checked;
        if (state.project.areaAspectLocked && state.project.area) {
          const b = state.project.area,
            ps = [
              [b[0], b[1]],
              [b[2], b[1]],
              [b[2], b[3]],
              [b[0], b[3]],
            ];
          state.project.area = paperRatioBoundsFromPoints(ps);
          state.project.planBaseMeta = {
            ...(state.project.planBaseMeta || {}),
            stale: true,
            reason: "Site frame aspect ratio changed",
          };
        }
        commit();
        renderDrawer("area");
      });
    }
    if (kind === "services") {
      $$("[data-service-toggle]").forEach(
        (el) =>
          (el.onchange = () => {
            abortLayerRequest();
            state.project.serviceVisibilityConfigured = true;
            state.project.serviceVisibility[el.dataset.serviceToggle] =
              el.checked;
            commit();
          }),
      );
      $("#serviceType")?.addEventListener("change", () => {
        state.project.serviceType = $("#serviceType").value;
        saveSoon();
        if (state.serviceScreen === "manual") renderDrawer("services");
      });
    }
    if (kind === "layers")
      $$("[data-type-toggle]").forEach(
        (el) =>
          (el.onchange = () => {
            state.project.hiddenTypes = state.project.hiddenTypes.filter(
              (x) => x !== el.dataset.typeToggle,
            );
            if (!el.checked)
              state.project.hiddenTypes.push(el.dataset.typeToggle);
            commit();
          }),
      );
    if (kind === "project") {
      [
        "siteAddress",
        "what3words",
        "siteRef",
        "clientName",
        "creator",
        "drawingNo",
        "revision",
        "siteContact",
        "sitePhone",
        "siteEntrance",
        "arrivalInstructions",
        "driverNotes",
        "siteNotes",
      ].forEach(
        (id) =>
          ($("#" + id).onchange = () => {
            state.project.meta[id] = $("#" + id).value;
            commit();
          }),
      );
      $("#projectNameEdit").onchange = () => {
        state.project.name =
          $("#projectNameEdit").value.trim() || "Untitled site";
        $("#projectName").value = state.project.name;
        commit();
      };
      $("#w3wApiKey").onchange = () =>
        setPref("sami.w3w.key", $("#w3wApiKey").value.trim());
      $("#voiceOutput").onchange = () => {
        setPref("sami.voice.output", $("#voiceOutput").checked ? "on" : "off");
        updateVoiceButton();
        if (!$("#voiceOutput").checked) window.speechSynthesis?.cancel();
      };
      populateVoiceSelect();
      $("#samiVoiceSelect").onchange = () =>
        setPref("sami.voice.name", $("#samiVoiceSelect").value);
    }
    if (kind === "search")
      $("#placeQuery").onkeydown = (e) => {
        if (e.key === "Enter") findPlace();
      };
  }
  function readPanelOptions() {
    const product = $("#panelProduct")?.value || state.project.route.product,
      o = {
        product,
        name: PRODUCTS[product].name,
        length: Number($("#panelLength")?.value ?? state.project.route.length),
        width: Number($("#panelWidth")?.value ?? state.project.route.width),
        overlap: Number(
          $("#panelOverlap")?.value ?? state.project.route.overlap,
        ),
        lateralOverlap: Number(
          $("#panelLateral")?.value ?? state.project.route.lateralOverlap,
        ),
        lanes: Number($("#panelLanes")?.value ?? state.project.route.lanes),
      };
    G.panels(
      [
        [0, 52],
        [0.00001, 52],
      ],
      o,
    );
    state.project.route = copy(o);
    saveSoon();
    return o;
  }
  function runAction(action, b) {
    try {
      const [cmd, ...parts] = action.split(":"),
        arg = parts.join(":");
      if (cmd === "open") {
        if (arg === "services") state.serviceScreen = "home";
        openDrawer(arg);
        return;
      }
      if (cmd === "drawMethod") {
        const [kind, method] = parts;
        if (kind === "stoneRoad") {
          startStoneRoad(method === "free");
          return;
        }
        if (kind === "stoneArea") {
          startStoneArea(method === "free");
          return;
        }
        startTool(method === "free" ? kind + "Freehand" : kind, {
          label: TYPES[kind] || kind,
          includeLegend: true,
          showArrow: ["access", "egress", "route"].includes(kind),
        });
        return;
      }
      if (cmd === "draw") {
        if (arg === "note") startNote();
        else if (arg === "photo") $("#photoInput").click();
        else if (arg === "textBox") startTextBox();
        else if (arg === "stoneRoad") startStoneRoad(false);
        else if (arg === "excavation")
          startTool("excavation", { label: "Excavation", includeLegend: true });
        else if (arg === "circle")
          startTool("circle", {
            label: "Circle / radius",
            includeLegend: true,
          });
        else if (arg === "arrow")
          startTool("arrow", { label: "Direction arrow", includeLegend: true });
        else
          startTool(arg, {
            snap: arg === "measure",
            includeLegend: !["measure"].includes(arg),
          });
        return;
      }
      if (cmd === "assetChoice") {
        state.project.asset = {
          kind: arg,
          ...ASSETS[arg],
          angle: 0,
          includeLegend: true,
        };
        renderDrawer("assets");
        return;
      }
      if (cmd === "select") {
        selectFeature(arg, true);
        return;
      }
      if (cmd === "pickRoute") {
        pickRoutePoint(arg);
        return;
      }
      if (cmd === "quickService") {
        if (!state.project.area) {
          openDrawer("area");
          return;
        }
        const v = SERVICES[arg];
        if (!v) throw Error("Unknown service type.");
        state.project.serviceType = arg;
        state.project.serviceVisibility[arg] = true;
        state.project.serviceVisibilityConfigured = true;
        state.project.hiddenTypes = state.project.hiddenTypes.filter(
          (t) => t !== "service",
        );
        startTool("serviceFreehand", {
          serviceType: arg,
          area: false,
          label: v.name,
          source: "Manual project / planning record",
          verification: "Project record · verify before excavation",
          provenance: "Project / field record",
          includeLegend: true,
        });
        return;
      }
      if (action === "servicesHome") {
        state.serviceScreen = "home";
        renderDrawer("services");
        return;
      }
      if (action === "servicesMapping") {
        state.serviceScreen = "mapping";
        renderDrawer("services");
        return;
      }
      if (action === "servicesManual") {
        state.serviceScreen = "manual";
        renderDrawer("services");
        return;
      }
      if (action === "resetServiceMapping") {
        state.project.serviceVisibility = Object.fromEntries(
          Object.keys(SERVICES).map((k) => [k, k === "ohl"]),
        );
        state.project.serviceVisibilityConfigured = true;
        commit();
        renderDrawer("services");
        toast("Mapping reset to overhead lines only.");
        return;
      }
      if (action === "showServiceMapping") return showSelectedServiceMapping();
      if (
        action === "manualServicePoint" ||
        action === "manualServiceFreehand"
      ) {
        if (!state.project.area) {
          openDrawer("area");
          return;
        }
        const k = $("#serviceType").value,
          v = SERVICES[k];
        state.project.serviceType = k;
        state.project.serviceVisibility[k] = true;
        state.project.serviceVisibilityConfigured = true;
        state.project.hiddenTypes = state.project.hiddenTypes.filter(
          (t) => t !== "service",
        );
        startTool(
          action === "manualServiceFreehand" ? "serviceFreehand" : "service",
          {
            serviceType: k,
            area: !!v.area,
            label: $("#serviceLabel").value.trim() || v.name,
            source: $("#serviceSource").value.trim() || "Manual project record",
            verification: "Project record · verify before excavation",
            provenance: "Project / field record",
            includeLegend: true,
          },
        );
        return;
      }
      if (action === "planHgv") return planHgvRoute();
      if (action === "routeHandoff") {
        openRouteHandoff();
        return;
      }
      if (action === "routeHistory") {
        openRouteHistory();
        return;
      }
      if (action === "deleteLatestRoute") {
        deleteLatestRoute();
        return;
      }
      if (action === "panelRoute") {
        startTool("panelRoute", readPanelOptions());
        return;
      }
      if (action === "panelFreehand") {
        startTool("panelFreehand", readPanelOptions());
        return;
      }
      if (action === "panelAreaFill") {
        startTool("panelAreaFreehand", readPanelOptions());
        return;
      }
      if (action === "trakwayLine") {
        startTool("trakwayLine", {
          label: "Trakway line",
          includeLegend: true,
          showArrow: false,
        });
        return;
      }
      if (action === "trakwayArea") {
        startTool("trakwayArea", {
          label: "Trakway area",
          includeLegend: true,
          showArrow: false,
        });
        return;
      }
      if (action === "singlePanel") {
        const o = readPanelOptions();
        startTool("singlePanel", {
          ...o,
          label: o.name,
          angle: 0,
          includeLegend: true,
        });
        return;
      }
      if (action === "placeAsset") {
        const base = ASSETS[state.project.asset.kind] || ASSETS.custom,
          locked = base.dimensionLocked === true,
          a = {
            ...base,
            kind: state.project.asset.kind,
            name: $("#assetLabel").value.trim() || base.name || "Site asset",
            length: locked ? +base.length : +$("#assetLength").value,
            width: locked ? +base.width : +$("#assetWidth").value,
            angle: +$("#assetAngle").value || 0,
            symbol: base.symbol || "•",
            category: base.category || "Other",
            includeLegend: $("#assetLegend")?.checked !== false,
          };
        if (!(
          a.length > 0.1 &&
          a.length <= 500 &&
          a.width > 0.01 &&
          a.width <= 500
        ))
          throw Error("Enter valid footprint dimensions.");
        state.project.asset = copy(a);
        startTool("asset", { ...a, label: a.name });
        return;
      }
      if (action === "drawService") {
        if (!state.project.area) {
          openDrawer("area");
          return;
        }
        const k = $("#serviceType").value,
          v = SERVICES[k];
        state.project.serviceVisibility[k] = true;
        state.project.serviceVisibilityConfigured = true;
        state.project.hiddenTypes = state.project.hiddenTypes.filter(
          (t) => t !== "service",
        );
        startTool("service", {
          serviceType: k,
          area: !!v.area,
          label: $("#serviceLabel").value.trim() || v.name,
          source: $("#serviceSource").value.trim() || "Manual project record",
          verification: "Project record · verify before excavation",
          provenance: "Project / field record",
          includeLegend: true,
        });
        return;
      }
      if (action === "contribute") {
        startContribution();
        return;
      }
      if (action === "exportContrib") {
        exportContributions();
        return;
      }
      if (action === "refreshOhl") {
        refreshOhlSnapshot();
        return;
      }
      if (action === "refreshPublicUtilities") {
        refreshPublicUtilities();
        return;
      }
      if (action === "refreshPlanningConstraints") {
        refreshPlanningConstraints();
        return;
      }
      if (action === "archives") {
        openArchiveManager();
        return;
      }
      if (action === "applyBrandColors") {
        const primary = $("#brandPrimary")?.value;
        const secondary = $("#brandSecondary")?.value;
        if (primary) localStorage.setItem("sami.brandPrimary", primary);
        if (secondary) localStorage.setItem("sami.brandSecondary", secondary);
        document.documentElement.style.setProperty("--accent", primary);
        document.documentElement.style.setProperty("--secondary-accent", secondary);
        toast("Brand colors applied successfully.");
        return;
      }
      if (action === "resetBrandColors") {
        localStorage.removeItem("sami.brandPrimary");
        localStorage.removeItem("sami.brandSecondary");
        document.documentElement.style.removeProperty("--accent");
        document.documentElement.style.removeProperty("--secondary-accent");
        renderDrawer("appearance");
        toast("Brand colors reset to defaults.");
        return;
      }
      if (action === "defineArea") {
        startTool("planArea");
        return;
      }
      if (action === "defineAreaFreehand") {
        startTool("planAreaFreehand");
        return;
      }
      if (action === "defineAreaPoints") {
        startTool("planAreaPoints");
        return;
      }
      if (action === "clearArea") {
        clearSiteArea();
        return;
      }
      if (action === "visibleArea") {
        useVisibleArea();
        return;
      }
      if (action === "capturePlanBase") {
        capturePlanBase(false);
        return;
      }
      if (action === "cadMode") {
        closeDrawer();
        switchBase("drawing");
        return;
      }
      if (action === "planMode") {
        setMode("plan");
        return;
      }
      if (action === "fitArea") {
        closeDrawer();
        fitArea();
        return;
      }
      if (action === "importServices") {
        if (!state.project.area) {
          openDrawer("area");
          return;
        }
        state.importKind = "services";
        state.importServiceType =
          $("#serviceType")?.value || state.project.serviceType;
        $("#importInput").click();
        return;
      }
      if (action === "loadServices") {
        loadServices();
        return;
      }
      if (action === "restore") {
        state.importKind = "project";
        $("#importInput").click();
        return;
      }
      if (action === "search") {
        findPlace();
        return;
      }
      if (action === "coords") {
        goCoords();
        return;
      }
      if (action === "locate") {
        locate();
        return;
      }
      if (action === "save") {
        if (saveNow()) toast("Project saved on this device.");
        return;
      }
      if (action === "backup") {
        exportProjectJSON();
        return;
      }
      if (action === "csv") {
        exportCSV();
        return;
      }
      if (action === "testVoice") {
        primeSpeech();
        speakOptional(
          "SAMI is ready. Ask me about your site, or use me to open planning tools and site information.",
          true,
        );
        return;
      }
      if (action === "finishGroupPick") {
        finishGroupPick();
        return;
      }
      if (action === "cancelGroupPick") {
        cancelGroupPick();
        return;
      }
      if (action === "resetRail") {
        setPref("sami.toolrail", "{}");
        const r = $("#toolRail");
        r.style.left = "";
        r.style.top = "";
        r.dataset.dock = "";
        r.classList.remove(
          "collapsed",
          "dock-horizontal",
          "dock-top",
          "dock-bottom",
        );
        updateRailButton();
        clampRail();
        toast("Toolbar position reset.");
        return;
      }
      if (action === "new") {
        showModal(
          "Start a new project?",
          "<p>Your current project will be cleared from the workspace. Export a backup to keep a separate copy.</p>" +
            button("Export current backup", "backup") +
            button("Start new project", "confirmNew", true),
        );
        $("#modalBody").onclick = (e) => {
          const a = e.target.closest("[data-action]")?.dataset.action;
          if (a === "backup") exportProjectJSON();
          if (a === "confirmNew") {
            state.project = fresh();
            abortLayerRequest();
            state.cache.clear();
            state.areaGeneration++;
            state.selected = null;
            state.mode = "map";
            setModeUI("map");
            cancelDraw();
            closeModal();
            closeDrawer();
            $("#projectName").value = state.project.name;
            switchBase("street", false);
            commit();
            toast("New project. Undo restores the previous workspace.");
          }
        };
        return;
      }
      if (action.startsWith("edit")) editAction(action);
    } catch (e) {
      toast(e.message);
    }
  }
  function editAction(action) {
    const f = selectedFeature();
    if (!f) return;
    if (action === "editLabel") {
      f.properties.label =
        $("#editLabel").value.trim() || TYPES[f.properties.type];
      f.properties.includeLegend = $("#editLegend")?.checked !== false;
      if ($("#editOnDrawing"))
        f.properties.includeOnDrawing = $("#editOnDrawing").checked;
      if (f.properties.type === "note" || f.properties.type === "textBox")
        f.properties.text = f.properties.label;
      commit();
      toast("Label updated.");
    }
    if (action === "editDelete" || action === "editDeleteRun") {
      const ids = new Set(groupMembers(f).map((x) => x.id)),
        r = f.properties.routeId;
      state.project.features = state.project.features.filter((x) =>
        action === "editDeleteRun"
          ? x.properties.routeId !== r
          : !ids.has(x.id),
      );
      state.selected = null;
      commit();
      closeDrawer();
      toast((ids.size > 1 ? "Group" : "Item") + " deleted. Undo is available.");
    }
    if (action === "editDuplicate") {
      duplicateSelected();
      return;
    }
    if (action === "editGroup") {
      startGroupPick();
      return;
    }
    if (action === "finishGroupPick") {
      finishGroupPick();
      return;
    }
    if (action === "cancelGroupPick") {
      cancelGroupPick();
      return;
    }
    if (action === "groupMultiSelection") {
      groupMultiSelection();
      return;
    }
    if (action === "editUngroup") {
      ungroupSelected();
      return;
    }
    if (action === "editVertices") {
      activateVertexEdit(f.id);
      return;
    }
    if (action === "editStyle") {
      const d = $("#styleEditor");
      if (d) d.open = true;
      return;
    }
    if (action === "editApplyStyle") {
      const members = groupMembers(f),
        vals = {
          styleColor: $("#editStyleColor")?.value || f.properties.styleColor,
          styleWeight:
            +$("#editStyleWeight")?.value || f.properties.styleWeight || 2,
          styleDash: $("#editStyleDash")?.value || "solid",
          styleFill: $("#editStyleFill")?.value || f.properties.styleFill,
        };
      for (const x of members.filter((x) => !x.properties.guideHidden)) {
        Object.assign(x.properties, vals);
        if ($("#editShowArrow"))
          x.properties.showArrow = $("#editShowArrow").checked;
      }
      commit();
      renderDrawer("selection");
      toast(
        "Style updated" + (members.length > 1 ? " across the group" : "") + ".",
      );
      return;
    }
    if (action === "editRotate") {
      const a = ((+$("#editAngle").value || 0) * Math.PI) / 180,
        b = G.boundsOf(f.geometry),
        center = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2],
        p = G.projection(center);
      transformGeometry(f.geometry, (c) => {
        const [x, y] = p.xy(c);
        return p.ll([
          x * Math.cos(a) + y * Math.sin(a),
          -x * Math.sin(a) + y * Math.cos(a),
        ]);
      });
      commit();
      toast("Rotation applied.");
    }
    if (action === "editMove") {
      closeDrawer();
      state.editGroup.clearLayers();
      const members = groupMembers(f),
        b = groupBounds(members),
        p = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2],
        marker = editMarker(p);
      marker.bindTooltip(
        "Drag to move" + (members.length > 1 ? " group" : ""),
        { permanent: true, className: "map-label" },
      );
      marker.on("dragend", () => {
        const next = coord(marker.getLatLng()),
          delta = [next[0] - p[0], next[1] - p[1]];
        translateMembers(members, delta);
        commit();
        toast((members.length > 1 ? "Group" : "Item") + " moved.");
      });
      toast("Drag the white handle, then release.");
    }
    if (action === "editBringFront") {
      const members = groupMembers(f);
      for (const x of members.filter((x) => !x.properties.guideHidden)) {
        x.properties.zIndex = (x.properties.zIndex || 0) + 1000;
      }
      commit();
      renderDrawer("selection");
      toast(
        "Brought to front" + (members.length > 1 ? " (group)" : "") + ".",
      );
      return;
    }
    if (action === "editSendBack") {
      const members = groupMembers(f);
      for (const x of members.filter((x) => !x.properties.guideHidden)) {
        x.properties.zIndex = (x.properties.zIndex || 0) - 1000;
      }
      commit();
      renderDrawer("selection");
      toast(
        "Sent to back" + (members.length > 1 ? " (group)" : "") + ".",
      );
      return;
    }
  }
  function editMarker(p) {
    return L.marker(latlng(p), {
      draggable: true,
      icon: L.divIcon({
        className: "",
        html: '<div class="vertex-handle"></div>',
        iconSize: [17, 17],
        iconAnchor: [8, 8],
      }),
    }).addTo(state.editGroup);
  }
  function transformGeometry(g, fn) {
    function walk(a) {
      if (typeof a[0] === "number") return fn(a);
      return a.map(walk);
    }
    g.coordinates = walk(g.coordinates);
  }
  async function findPlace() {
    const q = $("#placeQuery")?.value.trim(),
      out = $("#placeResults");
    if (!q || !out) return;
    out.innerHTML = '<p class="subtle">Searching…</p>';
    try {
      const coordLike = /^-?\d+(?:\.\d+)?\s*,\s*-?\d+(?:\.\d+)?$/.test(q),
        w3w = W3W_RE.test(q);
      if (coordLike || w3w) {
        const x = await resolveLocationText(q);
        if (!out.isConnected) return;
        out.innerHTML =
          '<button class="wide-btn primary" data-resolved="1">' +
          esc(x.label) +
          "</button>";
        out.querySelector("[data-resolved]").onclick = () => goTo(x.coord);
        return;
      }
      const r = await fetch(
        "https://nominatim.openstreetmap.org/search?format=json&limit=6&q=" +
          encodeURIComponent(q),
        {
          signal: AbortSignal.timeout(10000),
          headers: { Accept: "application/json" },
        },
      );
      if (!r.ok) throw Error("Search source unavailable");
      const data = await r.json();
      if (!out.isConnected) return;
      out.innerHTML = data.length
        ? data
            .map(
              (x, i) =>
                '<button class="wide-btn" data-place="' +
                i +
                '">' +
                esc(x.display_name) +
                "</button>",
            )
            .join("")
        : '<p class="subtle">No matches found.</p>';
      out.querySelectorAll("[data-place]").forEach(
        (b) =>
          (b.onclick = () => {
            const x = data[+b.dataset.place];
            goTo([+x.lon, +x.lat]);
          }),
      );
    } catch (e) {
      if (out.isConnected)
        out.innerHTML =
          '<p class="subtle">' +
          esc(
            e.message ||
              "Search is unavailable. Use coordinates or current location.",
          ) +
          "</p>";
    }
  }
  function goCoords() {
    const p = [Number($("#lngInput").value), Number($("#latInput").value)];
    if (!$("#latInput").value || !$("#lngInput").value || !G.validCoord(p)) {
      toast("Enter valid latitude and longitude.");
      return;
    }
    goTo(p);
  }
  function goTo(c) {
    closeDrawer();
    dismissWelcome();
    state.map.setView(latlng(c), 18);
  }
  function locate() {
    if (!navigator.geolocation) {
      toast("Location is unavailable.");
      return;
    }
    toast("Finding your location…");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        const c = [p.coords.longitude, p.coords.latitude];
        goTo(c);
        const m = L.circleMarker(latlng(c), {
          color: "#fff",
          weight: 3,
          radius: 7,
          fillColor: "#0875f5",
          fillOpacity: 1,
        }).addTo(state.map);
        setTimeout(() => state.map.removeLayer(m), 12000);
      },
      () =>
        toast(
          "Location could not be read. Allow permission or enter coordinates.",
        ),
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }
  async function handlePhoto(ev) {
    const f = ev.target.files?.[0];
    ev.target.value = "";
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast("Choose an image file.");
      return;
    }
    try {
      const data = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(f);
      });
      const im = await new Promise((resolve, reject) => {
        const i = new Image();
        i.onload = () => resolve(i);
        i.onerror = reject;
        i.src = data;
      });
      const scale = Math.min(1, 1200 / Math.max(im.width, im.height)),
        c = document.createElement("canvas");
      c.width = im.width * scale;
      c.height = im.height * scale;
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      startTool("photo", {
        label: f.name,
        name: f.name,
        data: c.toDataURL("image/jpeg", 0.76),
        includeOnDrawing: state.mode !== "map",
        includeLegend: state.mode !== "map",
      });
    } catch {
      toast("This image could not be opened. Try a JPEG or PNG.");
    }
  }
  function sourceFeatures(data) {
    if (data?.crs && !/4326|CRS84/i.test(JSON.stringify(data.crs)))
      throw Error("Export the source as WGS84 GeoJSON (EPSG:4326 / CRS84).");
    const fs =
      data?.type === "FeatureCollection"
        ? data.features
        : data?.type === "Feature"
          ? [data]
          : null;
    if (!Array.isArray(fs))
      throw Error("Choose a GeoJSON FeatureCollection or Feature.");
    if (fs.length > 10000)
      throw Error(
        "The file exceeds 10,000 records. Export a smaller site area.",
      );
    return fs;
  }
  function kmlNodes(root, name) {
    return Array.from(root.getElementsByTagName("*")).filter(
      (node) => node.localName === name,
    );
  }
  function kmlText(root, name) {
    return kmlNodes(root, name)[0]?.textContent?.trim() || "";
  }
  function kmlCoordinates(text) {
    return String(text || "")
      .trim()
      .split(/\s+/)
      .map((tuple) => tuple.split(",").slice(0, 3).map(Number))
      .filter(
        (coordinate) =>
          coordinate.length >= 2 &&
          Number.isFinite(coordinate[0]) &&
          Number.isFinite(coordinate[1]) &&
          Math.abs(coordinate[0]) <= 180 &&
          Math.abs(coordinate[1]) <= 90,
      );
  }
  function kmlToGeoJSON(text) {
    const xml = new DOMParser().parseFromString(text, "application/xml");
    if (xml.querySelector("parsererror")) throw Error("The KML is malformed.");
    const features = [];
    for (const placemark of kmlNodes(xml, "Placemark")) {
      const properties = {
        name: kmlText(placemark, "name"),
        description: kmlText(placemark, "description"),
      };
      for (const data of [
        ...kmlNodes(placemark, "Data"),
        ...kmlNodes(placemark, "SimpleData"),
      ]) {
        const key = data.getAttribute("name");
        const value = kmlText(data, "value") || data.textContent?.trim() || "";
        if (key && value) properties[key] = value;
      }
      const add = (geometry) => {
        if (geometry)
          features.push({
            type: "Feature",
            properties: cleanMeta(properties),
            geometry,
          });
      };
      for (const point of kmlNodes(placemark, "Point")) {
        const coordinates = kmlCoordinates(kmlText(point, "coordinates"))[0];
        if (coordinates) add({ type: "Point", coordinates });
      }
      for (const line of kmlNodes(placemark, "LineString")) {
        const coordinates = kmlCoordinates(kmlText(line, "coordinates"));
        if (coordinates.length >= 2) add({ type: "LineString", coordinates });
      }
      for (const polygon of kmlNodes(placemark, "Polygon")) {
        const outer = kmlNodes(polygon, "outerBoundaryIs")[0],
          rings = [];
        if (outer) {
          const coordinates = kmlCoordinates(kmlText(outer, "coordinates"));
          if (coordinates.length >= 3) rings.push(coordinates);
        }
        for (const inner of kmlNodes(polygon, "innerBoundaryIs")) {
          const coordinates = kmlCoordinates(kmlText(inner, "coordinates"));
          if (coordinates.length >= 3) rings.push(coordinates);
        }
        if (rings.length) add({ type: "Polygon", coordinates: rings });
      }
      if (features.length > 10000)
        throw Error("The KML exceeds 10,000 records. Export a smaller area.");
    }
    if (!features.length)
      throw Error("No supported points, lines or polygons were found in the KML.");
    return { type: "FeatureCollection", features };
  }
  async function importDataFile(file) {
    const extension = file.name.split(".").pop()?.toLowerCase();
    if (extension === "kml") return kmlToGeoJSON(await file.text());
    if (extension === "kmz") {
      const unzip = window.SAMIShapeImport?.unzip;
      if (!unzip)
        throw Error("KMZ support is unavailable. Reopen SAMI and try again.");
      const files = await unzip(await file.arrayBuffer(), {
        label: "KMZ",
        maxEntries: 500,
        maxExpandedBytes: 60 * 1024 * 1024,
      });
      const entry =
        files.get("doc.kml") ||
        [...files.entries()].find(([name]) => /(?:^|\/)doc\.kml$/i.test(name))?.[1] ||
        [...files.entries()].find(([name]) => /\.kml$/i.test(name))?.[1];
      if (!entry) throw Error("This KMZ does not contain a KML document.");
      return kmlToGeoJSON(new TextDecoder().decode(entry));
    }
    try {
      return JSON.parse(await file.text());
    } catch {
      throw Error("The JSON file is malformed or is not a supported SAMI file.");
    }
  }
  function prepareServices(data, source, fallback, selectedOnly = true) {
    const results = [],
      skipped = { outside: 0, invalid: 0, hidden: 0 },
      clip = serviceBounds();
    for (const f of sourceFeatures(data)) {
      if (!G.validateFeature(f)) {
        skipped.invalid++;
        continue;
      }
      const m = cleanMeta(f.properties),
        type = SERVICES[m.serviceType]
          ? m.serviceType
          : SERVICES[m.service_type]
            ? m.service_type
            : fallback;
      if (selectedOnly && state.project.serviceVisibility[type] === false) {
        skipped.hidden++;
        continue;
      }
      let geometry;
      try {
        geometry = G.clipGeometry(f.geometry, clip);
      } catch {
        skipped.invalid++;
        continue;
      }
      if (!geometry) {
        skipped.outside++;
        continue;
      }
      results.push(
        feature("service", geometry, {
          ...m,
          type: "service",
          serviceType: type,
          label:
            m.label || m.name || SERVICES[type]?.name || "Service / constraint",
          source: m.source || source,
          sourceId: source,
          verification: m.verification || "Source record · verify on site",
          provenance: m.provenance || "Imported project / data-pack record",
          imported: new Date().toISOString(),
          includeLegend: true,
        }),
      );
    }
    return { results, skipped };
  }
  async function handleImport(ev) {
    const file = ev.target.files?.[0];
    ev.target.value = "";
    if (!file) return;
    try {
      if (file.size > 50 * 1024 * 1024)
        throw Error("Choose a file smaller than 50 MB.");
      const data = await importDataFile(file);
      if (state.importKind === "project") {
        const p = normaliseProject(data);
        showModal(
          "Restore this project?",
          "<p>Restore <strong>" +
            esc(p.name) +
            "</strong> with " +
            p.features.length +
            " items. This replaces the workspace; Undo can restore the current one.</p>" +
            button("Restore project", "confirmRestore", true),
        );
        $("#modalBody").onclick = (e) => {
          if (e.target.closest('[data-action="confirmRestore"]')) {
            cancelDraw();
            abortLayerRequest();
            state.project = p;
            state.areaGeneration++;
            state.cache.clear();
            state.selected = null;
            state.mode = "map";
            setModeUI("map");
            $("#projectName").value = p.name;
            closeModal();
            closeDrawer();
            switchBase(p.base, false);
            state.map.setView(p.map.center, p.map.zoom);
            commit();
            if (p.area) fitArea();
            toast("Project restored.");
          }
        };
        return;
      }
      if (!state.project.area)
        throw Error("Define a site area before importing services.");
      const k = state.importServiceType || state.project.serviceType;
      state.project.serviceVisibility[k] = true;
      state.project.hiddenTypes = state.project.hiddenTypes.filter(
        (t) => t !== "service",
      );
      const { results, skipped } = prepareServices(data, file.name, k, false);
      if (state.project.features.length + results.length > 12000)
        throw Error("This project exceeds 12,000 items. Split the project.");
      const sourceId = "file:" + file.name;
      results.forEach((f) => {
        f.properties.sourceId = sourceId;
      });
      await replaceSourceFeatures(sourceId, results, "Previous import · " + file.name);
      state.lastLoad =
        results.length +
        " records imported into site + 0.1 mile service buffer. " +
        skipped.outside +
        " outside, " +
        skipped.hidden +
        " hidden types, " +
        skipped.invalid +
        " unsupported / invalid.";
      openDrawer("services");
      toast(state.lastLoad);
    } catch (e) {
      toast("Import: " + e.message);
    }
  }
  function abortLayerRequest() {
    state.request?.abort();
    state.request = null;
  }
  async function boundedJSON(response, max = 4 * 1024 * 1024) {
    if (!response.ok) throw Error("Source returned HTTP " + response.status);
    if (+response.headers.get("content-length") > max)
      throw Error("Source response is too large. Query a smaller site area.");
    if (!response.body) {
      const t = await response.text();
      if (t.length > max) throw Error("Source response is too large.");
      return JSON.parse(t);
    }
    const reader = response.body.getReader(),
      parts = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > max) {
          await reader.cancel();
          throw Error("Source response is too large.");
        }
        parts.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    parts.forEach((p) => {
      bytes.set(p, offset);
      offset += p.length;
    });
    return JSON.parse(new TextDecoder().decode(bytes));
  }
  async function loadServices() {
    const project = state.project;
    const area = state.project.area,
      selected = Object.keys(SERVICES).filter(
        (k) => state.project.serviceVisibility[k],
      );
    if (!area) {
      openDrawer("area");
      return;
    }
    if (!selected.length) {
      toast("Select at least one service or constraint type.");
      return;
    }
    const sources = (window.SAMI_CONFIG?.serviceSources || []).filter(
      (s) => s.enabled !== false && s.url && selected.includes(s.type),
    );
    if (!sources.length) {
      state.lastLoad =
        "No authorised connector is configured for these selected types. Use the overhead-line snapshot, an approved data pack, or project survey records.";
      renderDrawer("services");
      toast(state.lastLoad);
      return;
    }
    abortLayerRequest();
    const controller = new AbortController();
    state.request = controller;
    const generation = state.areaGeneration,
      b = serviceBounds(),
      bbox = b.join(","),
      captured = JSON.stringify(selected);
    state.lastLoad = "Loading records only inside the site + 0.1 mile buffer…";
    renderDrawer("services");
    const pending = [],
      errors = [];
    const timer = setTimeout(() => controller.abort(), 25000);
    try {
      for (const src of sources) {
        if (controller.signal.aborted) break;
        try {
          const sourceId = "source:" + src.url + ":" + src.type,
            key = sourceId + "|" + bbox,
            hit = state.cache.get(key);
          let data;
          if (hit && Date.now() - hit.time < 300000) data = hit.data;
          else {
            const url = new URL(src.url, location.href);
            if (url.protocol !== "https:" && url.origin !== location.origin)
              throw Error("Use an HTTPS data source.");
            url.searchParams.set("bbox", bbox);
            url.searchParams.set("crs", "EPSG:4326");
            url.searchParams.set("limit", "10000");
            data = await boundedJSON(
              await fetch(url.href, {
                signal: controller.signal,
                headers: { Accept: "application/geo+json,application/json" },
              }),
            );
            state.cache.set(key, { data, time: Date.now() });
            if (state.cache.size > 10)
              state.cache.delete(state.cache.keys().next().value);
          }
          if (controller.signal.aborted) break;
          const res = prepareServices(data, src.name || src.url, src.type);
          res.results.forEach((f) => {
            f.properties.sourceId = sourceId;
            f.properties.source = src.name || src.url;
          });
          pending.push({
            sourceId,
            label: src.name || src.type,
            features: res.results,
          });
        } catch (e) {
          if (e.name !== "AbortError")
            errors.push((src.name || src.type) + ": " + e.message);
        }
      }
      if (
        controller.signal.aborted ||
        project !== state.project ||
        generation !== state.areaGeneration ||
        bbox !== serviceBounds()?.join(",") ||
        captured !==
          JSON.stringify(
            Object.keys(SERVICES).filter(
              (k) => state.project.serviceVisibility[k],
            ),
          )
      ) {
        state.lastLoad = "Load stopped. Run refresh for the current site area.";
        return;
      }
      for (const batch of pending) {
        await replaceSourceFeatures(batch.sourceId, batch.features,
          "Previous snapshot · " + batch.label, project, generation);
      }
      if (project !== state.project || generation !== state.areaGeneration) return;
      state.project.hiddenTypes = state.project.hiddenTypes.filter(
        (t) => t !== "service",
      );
      commit();
      state.lastLoad =
        pending.reduce((n, b) => n + b.features.length, 0) +
        " records refreshed in site + 0.1 mile buffer; previous source snapshots archived." +
        (errors.length ? " " + errors.join(" ") : "");
    } catch (e) {
      state.lastLoad = e.message;
    } finally {
      clearTimeout(timer);
      if (state.request === controller) state.request = null;
      if (state.drawer === "services") renderDrawer("services");
      toast(state.lastLoad);
    }
  }
  function formatDistance(n) {
    return n >= 1000
      ? (n / 1000).toFixed(2) + " km"
      : n.toFixed(n < 100 ? 1 : 0) + " m";
  }
  function safeName() {
    return state.project.name.replace(/[^a-z0-9_-]+/gi, "_") || "SAMI_Project";
  }
  function download(name, text, type) {
    const a = document.createElement("a");
    const url = URL.createObjectURL(new Blob([text], { type }));
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
  }
  function projectGeoJSON() {
    const features = copy(state.project.features);
    if (state.project.area)
      features.unshift(
        feature("plan-area", G.boundsGeometry(state.project.area), {
          label: "Defined site area",
          includeLegend: false,
        }),
      );
    features.forEach((f) => {
      delete f.properties.data;
    });
    return { type: "FeatureCollection", name: state.project.name, features };
  }
  function exportProjectJSON() {
    state.project.meta ||= {};
    state.project.meta.lastBackedUpAt = new Date().toISOString();
    try {
      localStorage.setItem("sami.backup.last", state.project.meta.lastBackedUpAt);
    } catch {}
    saveNow();
    download(
      safeName() + ".sami",
      JSON.stringify(state.project, null, 2),
      "application/json",
    );
  }
  function exportGeoJSON() {
    download(
      safeName() + "_SAMI.geojson",
      JSON.stringify(projectGeoJSON(), null, 2),
      "application/geo+json",
    );
  }
  function exportCSV() {
    const rows = [
        [
          "Item",
          "Type",
          "Length (m)",
          "Width (m)",
          "Quantity",
          "Source / reference",
        ],
      ],
      groups = new Map();
    for (const f of state.project.features) {
      const m = f.properties;
      if (["panel", "asset"].includes(m.type)) {
        const k = [m.label, m.type, m.length, m.width].join("|");
        if (!groups.has(k))
          groups.set(k, [
            m.label,
            m.type,
            m.length || "",
            m.width || "",
            0,
            "",
          ]);
        groups.get(k)[4]++;
      } else
        rows.push([
          m.label,
          TYPES[m.type] || m.type,
          m.type === "measure" ? geometryLength(f.geometry).toFixed(2) : "",
          "",
          1,
          m.source || "",
        ]);
    }
    rows.push(...groups.values());
    const cell = (v) =>
      '"' +
      String(v ?? "")
        .replace(/^[=+@-]/, "'")
        .replace(/"/g, '""') +
      '"';
    download(
      safeName() + "_materials.csv",
      "\ufeff" + rows.map((r) => r.map(cell).join(",")).join("\r\n"),
      "text/csv;charset=utf-8",
    );
  }
  function exportKML() {
    function geom(g) {
      const coords = (ps) => ps.map((c) => c[0] + "," + c[1] + ",0").join(" ");
      if (g.type === "Point")
        return (
          "<Point><coordinates>" +
          coords([g.coordinates]) +
          "</coordinates></Point>"
        );
      if (g.type === "LineString")
        return (
          "<LineString><coordinates>" +
          coords(g.coordinates) +
          "</coordinates></LineString>"
        );
      if (g.type === "Polygon")
        return (
          "<Polygon>" +
          g.coordinates
            .map(
              (r, i) =>
                "<" +
                (i ? "inner" : "outer") +
                "BoundaryIs><LinearRing><coordinates>" +
                coords(r) +
                "</coordinates></LinearRing></" +
                (i ? "inner" : "outer") +
                "BoundaryIs>",
            )
            .join("") +
          "</Polygon>"
        );
      const map = {
        MultiPoint: "Point",
        MultiLineString: "LineString",
        MultiPolygon: "Polygon",
      };
      return (
        "<MultiGeometry>" +
        g.coordinates
          .map((c) => geom({ type: map[g.type], coordinates: c }))
          .join("") +
        "</MultiGeometry>"
      );
    }
    const out =
      '<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>' +
      esc(state.project.name) +
      "</name>" +
      projectGeoJSON()
        .features.map(
          (f) =>
            "<Placemark><name>" +
            esc(f.properties.label) +
            "</name>" +
            geom(f.geometry) +
            "</Placemark>",
        )
        .join("") +
      "</Document></kml>";
    download(
      safeName() + "_SAMI.kml",
      out,
      "application/vnd.google-earth.kml+xml",
    );
  }
  async function exportDXF() {
    await ensureExportCadDetail();
    const features = projectGeoJSON().features.concat(
        copy(state.project.planBase || []).map((f) => ({
          ...f,
          properties: { ...f.properties, type: "planBase" },
        })),
      ),
      origin =
        planBounds()?.slice(0, 2) ||
        state.project.area?.slice(0, 2) ||
        coord(state.map.getCenter()),
      pr = G.projection(origin);
    let out =
      "999\nSAMI true-scale local metre export; origin longitude " +
      origin[0] +
      " latitude " +
      origin[1] +
      "\n0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1015\n9\n$MEASUREMENT\n70\n1\n9\n$INSUNITS\n70\n6\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n";
    function geom(g, layer) {
      if (g.type === "Point") {
        const [x, y] = pr.xy(g.coordinates);
        out +=
          "0\nPOINT\n100\nAcDbEntity\n8\n" +
          layer +
          "\n100\nAcDbPoint\n10\n" +
          x.toFixed(3) +
          "\n20\n" +
          y.toFixed(3) +
          "\n30\n0\n";
      } else if (g.type === "LineString") {
        out +=
          "0\nLWPOLYLINE\n100\nAcDbEntity\n8\n" +
          layer +
          "\n100\nAcDbPolyline\n90\n" +
          g.coordinates.length +
          "\n70\n0\n";
        g.coordinates.forEach((c) => {
          const [x, y] = pr.xy(c);
          out += "10\n" + x.toFixed(3) + "\n20\n" + y.toFixed(3) + "\n";
        });
      } else if (g.type === "Polygon")
        g.coordinates.forEach((r, i) => {
          out +=
            "0\nLWPOLYLINE\n100\nAcDbEntity\n8\n" + layer + "\n100\nAcDbPolyline\n90\n" + r.length + "\n70\n1\n";
          r.forEach((c) => {
            const [x, y] = pr.xy(c);
            out += "10\n" + x.toFixed(3) + "\n20\n" + y.toFixed(3) + "\n";
          });
        });
      else {
        const map = {
          MultiPoint: "Point",
          MultiLineString: "LineString",
          MultiPolygon: "Polygon",
        };
        g.coordinates.forEach((c) =>
          geom({ type: map[g.type], coordinates: c }, layer),
        );
      }
    }
    for (const f of features) {
      if (f.properties.guideHidden || (f.properties.autoAnnotation && !state.project.showAutoMeasurements)) continue;
      if (f.properties.dimension) {
        const d = window.SAMIPlanning.dimensionGeometry(f,state.project.features);
        if (!d) continue;
        [...d.extensions,d.line].forEach(coordinates=>geom({type:"LineString",coordinates},"DIMENSIONS"));
        const [a,b]=d.line.map(pr.xy),mid=pr.xy(d.midpoint);
        let angle=Math.atan2(b[1]-a[1],b[0]-a[0])*180/Math.PI;
        if (angle>90 || angle< -90) angle+=180;
        const label=window.SAMIPlanning.dimensionLabel(d.length,f.properties);
        out += "0\nTEXT\n100\nAcDbEntity\n8\nDIMENSIONS\n100\nAcDbText\n10\n"+mid[0].toFixed(3)+"\n20\n"+mid[1].toFixed(3)+"\n30\n0\n40\n0.35\n1\n"+label+"\n50\n"+angle.toFixed(2)+"\n72\n1\n11\n"+mid[0].toFixed(3)+"\n21\n"+mid[1].toFixed(3)+"\n31\n0\n";
        continue;
      }
      let g = f.geometry;
      if (state.project.area) {
        try {
          g = G.clipGeometry(g, planBounds());
        } catch {}
      }
      if (!g) continue;
      const layer = (
        f.properties.baseClass
          ? "BASE_" + f.properties.baseClass
          : f.properties.serviceType || f.properties.type || "SAMI"
      )
        .replace(/[^a-z0-9_-]/gi, "_")
        .toUpperCase();
      geom(g, layer);
      if (f.properties.type === "measure" && g.type === "LineString") {
        for (let i=1;i<g.coordinates.length;i++) {
          const a=g.coordinates[i-1],b=g.coordinates[i],pa=pr.xy(a),pb=pr.xy(b);
          let angle=Math.atan2(pb[1]-pa[1],pb[0]-pa[0])*180/Math.PI;
          if (angle>90 || angle < -90) angle+=180;
          out += "0\nTEXT\n100\nAcDbEntity\n8\nDIMENSIONS\n100\nAcDbText\n10\n" + ((pa[0]+pb[0])/2).toFixed(3) + "\n20\n" + ((pa[1]+pb[1])/2+0.3).toFixed(3) + "\n30\n0\n40\n0.35\n1\n" + G.distance(a,b).toFixed(2) + " m\n50\n" + angle.toFixed(2) + "\n";
        }
      }
    }
    out += "0\nENDSEC\n0\nEOF\n";
    download(safeName() + "_SAMI_true_scale.dxf", out, "application/dxf");
  }
  function openExport() {
    if (window.SAMIWorkspace && !window.SAMIWorkspace.exportApproved) {
      window.SAMIWorkspace.requestExport();
      return;
    }
    cancelDraw();
    const m = state.project.meta || {},
      route = (state.project.routes || []).at(-1);
    const body =
      '<div class="export-issue">' +
      '<div class="card"><span class="tag">SAMI DOCUMENT ENGINE</span><h3>Site Logistics Pack</h3><p class="subtle">Purpose-designed from the project data model. This does not capture the SAMI interface.</p></div>' +
      section("Pages") +
      checkedRow(
        "Site Drawing / Site Logistics Plan",
        'id="docPageSite"',
        true,
      ) +
      checkedRow(
        "Route to Site / Driver Information" +
          (route ? "" : " · no route currently saved"),
        'id="docPageRoute"',
        !!route,
      ) +
      section("Drawing style") +
      '<div class="radio-cards"><label><input type="radio" name="docStyle" value="cad" checked><span><strong>CAD</strong><small>Simplified bounded vector plan</small></span></label><label><input type="radio" name="docStyle" value="map"><span><strong>Map</strong><small>Map context + SAMI vectors</small></span></label><label><input type="radio" name="docStyle" value="satellite"><span><strong>Satellite</strong><small>Imagery context + SAMI vectors</small></span></label></div>' +
      section("Sheet annotations") +
      '<div class="radio-cards compact"><label><input type="radio" name="docDetail" value="high" checked><span><strong>High detail</strong><small>Full annotations, coordinates, key + notes</small></span></label><label><input type="radio" name="docDetail" value="simple"><span><strong>Simple</strong><small>Condensed - fewer annotations, faster to read</small></span></label></div>' +
      section("Paper") +
      '<div class="radio-cards compact"><label><input type="radio" name="docPaper" value="a3" checked><span><strong>A3 Landscape</strong><small>Default issue sheet</small></span></label><label><input type="radio" name="docPaper" value="a4"><span><strong>A4 Landscape</strong><small>Scaled alternative</small></span></label></div>' +
      section("Layers to include") +
      '<div class="layer-check-grid">' +
      [
        ["Trakway", "trakway"],
        ["Assets", "assets"],
        ["Utilities", "utilities"],
        ["Environmental constraints", "environment"],
        ["Dimensions", "dimensions"],
        ["Labels", "labels"],
        ["Safety information", "safety"],
        ["Other active project layers", "other"],
      ]
        .map(([label, k]) =>
          checkedRow(label, 'data-doc-layer="' + k + '"', true),
        )
        .join("") +
      "</div>" +
      section("Drawing detail") +
      checkedRow(
        "Essential road labels only",
        'id="docEssentialLabels"',
        true,
      ) +
      checkedRow(
        "OHL pole / tower reference schedule",
        'id="docOhlSupportDetails"',
        false,
      ) +
      section("Issue information") +
      '<div class="row equal"><div>' +
      field("docRevision", "Revision", m.revision || "") +
      '</div><div><label class="field-label" for="docStatus">Drawing status</label><select class="field" id="docStatus">' +
      [
        "",
        "Draft",
        "Preliminary",
        "For Information",
        "For Construction",
        "As Built",
      ]
        .map(
          (v) =>
            "<option " +
            ((m.drawingStatus || "") === v ? "selected" : "") +
            ">" +
            v +
            "</option>",
        )
        .join("") +
      "</select></div></div>" +
      field("docPrepared", "Prepared by", m.creator || "") +
      '<label class="field-label" for="docNotes">Issue / drawing notes</label><textarea class="field" id="docNotes" rows="3">' +
      esc(m.lastExportNotes || m.siteNotes || "") +
      "</textarea>" +
      '<details class="advanced-settings"><summary>Other technical exports</summary><div class="modal-grid">' +
      button("DXF · CAD true-scale", "dxf") +
      button("GeoJSON · GIS", "geojson") +
      button("KML · mapping", "kml") +
      button("Materials / assets CSV", "csv") +
      button("Editable SAMI backup", "backup") +
      "</div></details>" +
      "</div>";
    showModal("EXPORT / ISSUE · Site Logistics Pack", body);
    const footer = $("#modalFooter");
    footer.hidden = false;
    footer.innerHTML =
      '<button class="wide-btn" data-doc-action="preview">PREVIEW PDF</button><button class="wide-btn primary" data-doc-action="export">EXPORT PDF</button><button class="wide-btn" data-doc-action="share">SHARE</button>';
    const handle = async (e) => {
      const da = e.target.closest("[data-doc-action]")?.dataset.docAction;
      if (da) {
        e.preventDefault();
        await issueSiteLogisticsPack(da);
        return;
      }
      const k = e.target.closest("[data-action]")?.dataset.action;
      if (!k) return;
      await ({
        backup: exportProjectJSON,
        geojson: exportGeoJSON,
        dxf: exportDXF,
        kml: exportKML,
        csv: exportCSV,
      })[k]?.();
    };
    $("#modalBody").onclick = handle;
    footer.onclick = handle;
  }
  function readDocumentOptions() {
    const layers = {};
    $$("[data-doc-layer]").forEach(
      (el) => (layers[el.dataset.docLayer] = el.checked),
    );
    const opt = {
      pages: {
        site: $("#docPageSite")?.checked !== false,
        route: $("#docPageRoute")?.checked !== false,
      },
      style: $('input[name="docStyle"]:checked')?.value || "cad",
      detailLevel: $('input[name="docDetail"]:checked')?.value || "high",
      paper: $('input[name="docPaper"]:checked')?.value || "a3",
      layers,
      essentialLabels: $("#docEssentialLabels")?.checked !== false,
      ohlSupportDetails: $("#docOhlSupportDetails")?.checked === true,
      revision: $("#docRevision")?.value.trim() || "",
      status: $("#docStatus")?.value || "",
      preparedBy: $("#docPrepared")?.value.trim() || "",
      notes: $("#docNotes")?.value.trim() || "",
    };
    if (!opt.pages.site && !opt.pages.route)
      throw Error("Select at least one page.");
    return opt;
  }
  function saveDocumentIssueMeta(opt) {
    state.project.meta.revision = opt.revision;
    state.project.meta.creator = opt.preparedBy;
    state.project.meta.drawingStatus = opt.status;
    state.project.meta.lastExportNotes = opt.notes;
    commit();
  }
  function downloadBlob(name, blob) {
    const a = document.createElement("a"),
      url = URL.createObjectURL(blob);
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  async function buildSiteLogisticsPDF(opt) {
    if (!window.SAMIDocumentEngine)
      throw Error(
        "SAMI Document Engine is unavailable. Refresh the installed app.",
      );
    if (opt.pages.site && !state.project.area)
      throw Error(
        "Define the Site Drawing area before issuing the Site Drawing sheet.",
      );
    if (opt.pages.site && opt.style === "cad") await ensureExportCadDetail(planDetailLevel());
    saveDocumentIssueMeta(opt);
    return await window.SAMIDocumentEngine.generate(copy(state.project), { ...opt, onProgress: updateExportStep });
  }
  function showExportLoading(step = "Initializing…") {
    const loadingHTML =
      '<div class="export-loading">' +
      '<div class="export-loading-content">' +
      '<div class="export-logo-container">' +
      '<img alt="" class="export-logo-pulse" src="sami-badge.png" />' +
      "</div>" +
      '<div class="export-status">' +
      '<h3>Site Logistics Pack</h3>' +
      '<p class="export-step" id="exportStep">' +
      step +
      "</p>" +
      '<div class="export-progress">' +
      '<div class="export-progress-bar"></div>' +
      "</div>" +
      "</div>" +
      "</div>" +
      "</div>";
    showModal("EXPORTING", loadingHTML);
    document.body.classList.add("export-loading-active");
  }
  function updateExportStep(step) {
    const el = $("#exportStep");
    if (el) el.textContent = step;
  }
  function closeExportLoading() {
    document.body.classList.remove("export-loading-active");
    closeModal();
  }
  async function issueSiteLogisticsPack(action) {
    if (state.exportBusy) return;
    let opt;
    try {
      opt = readDocumentOptions();
    } catch (e) {
      toast(e.message);
      return;
    }
    closeModal();
    state.exportBusy = true;
    showExportLoading("Preparing document…");
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    try {
      updateExportStep("Processing site drawing…");
      const blob = await buildSiteLogisticsPDF(opt),
        name =
          safeName() +
          "_Site_Logistics_Pack_" +
          (opt.revision || "Rev0") +
          ".pdf";
      if (action === "preview") {
        closeExportLoading();
        updateExportStep("Building PDF preview…");
        const url = URL.createObjectURL(blob),
          w = window.open(url, "_blank", "noopener");
        if (!w) {
          showModal(
            "PDF preview",
            '<iframe class="pdf-preview" title="SAMI PDF preview" src="' +
              url +
              '"></iframe><p class="subtle">Use Export PDF or Share to issue this document.</p>',
          );
        }
        setTimeout(() => URL.revokeObjectURL(url), 5 * 60 * 1000);
      } else if (action === "share") {
        updateExportStep("Preparing to share…");
        const ok = await window.SAMIDocumentEngine.share(blob, name).catch(
          () => false,
        );
        closeExportLoading();
        if (!ok) {
          downloadBlob(name, blob);
          toast(
            "Native file sharing is not available here. The PDF has been saved instead.",
          );
        }
      } else {
        updateExportStep("Finalizing…");
        downloadBlob(name, blob);
        closeExportLoading();
        toast("SAMI Site Logistics Pack exported as PDF.");
      }
    } catch (e) {
      console.error(e);
      closeExportLoading();
      toast("PDF: " + (e.message || "Document generation failed."));
    } finally {
      state.exportBusy = false;
      document.body.classList.remove("export-loading-active");
    }
  }
  let toastTimer;
  function toast(t) {
    const el = $("#toast");
    if (!el) return;
    el.textContent = t;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.hidden = true), 5000);
  }
  let modalFocus;
  function modalTrap(e) {
    if (e.key !== "Tab") return;
    const card = $("#modal .modal-card");
    if (!card) return;
    const items = [
      ...card.querySelectorAll(
        'button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])',
      ),
    ].filter((el) => !el.disabled && el.offsetParent !== null);
    if (!items.length) return;
    const first = items[0],
      last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }
  function showModal(title, html) {
    modalFocus = document.activeElement;
    $("#modalTitle").textContent = title;
    $("#modalBody").innerHTML = html;
    $("#modalBody").onclick = null;
    const modal = $("#modal"),
      footer = $("#modalFooter");
    if (footer) {
      footer.hidden = true;
      footer.innerHTML = "";
      footer.onclick = null;
    }
    modal.classList.toggle("about-modal", title === "SAMI");
    modal.classList.toggle("export-modal", title.startsWith("EXPORT / ISSUE"));
    modal.classList.remove("hidden");
    document.body.classList.add("modal-open");
    $("#modalBody").scrollTop = 0;
    $("#modalClose").focus();
    document.addEventListener("keydown", modalTrap);
  }
  function closeModal() {
    const modal = $("#modal"),
      footer = $("#modalFooter");
    modal.classList.add("hidden");
    modal.classList.remove("export-modal");
    document.body.classList.remove("modal-open");
    if (footer) {
      footer.hidden = true;
      footer.innerHTML = "";
      footer.onclick = null;
    }
    document.removeEventListener("keydown", modalTrap);
    modalFocus?.focus?.();
  }
  function updateRailButton() {
    const c = $("#toolRail").classList.contains("collapsed");
    $("#railCollapse").textContent = c ? "☰" : "‹";
    $("#railCollapse").setAttribute("aria-expanded", String(!c));
    $("#railCollapse").setAttribute(
      "aria-label",
      c ? "Expand planning tools" : "Collapse planning tools",
    );
  }
  function saveRail() {
    const r = $("#toolRail");
    setPref(
      "sami.toolrail",
      JSON.stringify({
        left: parseFloat(r.style.left),
        top: parseFloat(r.style.top),
        collapsed: r.classList.contains("collapsed"),
        dock: r.dataset.dock || "",
      }),
    );
  }
  function clampRail() {
    const r = $("#toolRail"),
      w = $("#workspace");
    if (r.dataset.dock) {
      r.style.left = "";
      r.style.top = "";
      return;
    }
    if (!r.style.top) return;
    const rightReserve = 68;
    const maxX = Math.max(7, w.clientWidth - r.offsetWidth - rightReserve),
      maxY = Math.max(55, w.clientHeight - r.offsetHeight - 85);
    r.style.left =
      Math.max(7, Math.min(maxX, parseFloat(r.style.left) || 7)) + "px";
    r.style.top =
      Math.max(55, Math.min(maxY, parseFloat(r.style.top) || 55)) + "px";
  }
  function initToolRail() {
    const r = $("#toolRail"),
      h = $("#railMove");
    let p = {};
    try {
      p = JSON.parse(readPref("sami.toolrail") || "{}");
    } catch {}
    if (p.collapsed) r.classList.add("collapsed");
    if (p.dock) {
      r.dataset.dock = p.dock;
      r.classList.add("dock-horizontal", "dock-" + p.dock);
    } else if (Number.isFinite(p.left) && Number.isFinite(p.top)) {
      r.style.left = p.left + "px";
      r.style.top = p.top + "px";
      clampRail();
    }
    updateRailButton();
    $("#railCollapse").onclick = () => {
      r.classList.toggle("collapsed");
      updateRailButton();
      clampRail();
      saveRail();
    };
    let drag = null;
    h.onpointerdown = (e) => {
      const b = r.getBoundingClientRect(),
        w = $("#workspace").getBoundingClientRect();
      if (r.dataset.dock) {
        r.dataset.dock = "";
        r.classList.remove("dock-horizontal", "dock-top", "dock-bottom");
        r.style.left = b.left - w.left + "px";
        r.style.top = b.top - w.top + "px";
      }
      drag = { dx: e.clientX - b.left, dy: e.clientY - b.top };
      h.setPointerCapture(e.pointerId);
      e.preventDefault();
    };
    h.onpointermove = (e) => {
      if (!drag) return;
      const b = $("#workspace").getBoundingClientRect();
      r.style.left = e.clientX - b.left - drag.dx + "px";
      r.style.top = e.clientY - b.top - drag.dy + "px";
      clampRail();
    };
    const stop = (e) => {
      if (!drag) return;
      drag = null;
      h.releasePointerCapture?.(e.pointerId);
      const rb = r.getBoundingClientRect(),
        wb = $("#workspace").getBoundingClientRect(),
        snap = 72;
      if (rb.top - wb.top < snap) {
        r.dataset.dock = "top";
        r.classList.add("dock-horizontal", "dock-top");
        r.style.left = "";
        r.style.top = "";
        toast("Toolbar docked horizontally at the top.");
      } else if (wb.bottom - rb.bottom < snap + 70) {
        r.dataset.dock = "bottom";
        r.classList.add("dock-horizontal", "dock-bottom");
        r.style.left = "";
        r.style.top = "";
        toast("Toolbar docked horizontally at the bottom.");
      }
      saveRail();
    };
    h.onpointerup = stop;
    h.onpointercancel = stop;
  }
  const W3W_RE =
    /^(?:\/\/\/)?([\p{L}\p{M}-]+)\.([\p{L}\p{M}-]+)\.([\p{L}\p{M}-]+)$/u;
  function w3wKey() {
    return String(
      readPref("sami.w3w.key") || window.SAMI_CONFIG?.what3wordsApiKey || "",
    ).trim();
  }
  function coordLabel(c) {
    return c
      ? Number(c[1]).toFixed(6) + ", " + Number(c[0]).toFixed(6)
      : "Not set";
  }
  async function routePointDetails(c) {
    const out = { address: "", what3words: "" };
    try {
      const r = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${encodeURIComponent(c[1])}&lon=${encodeURIComponent(c[0])}&zoom=18`,
          {
            signal: AbortSignal.timeout(10000),
            headers: { Accept: "application/json" },
          },
        ),
        d = await boundedJSON(r, 250000);
      if (r.ok) out.address = String(d?.display_name || "");
    } catch {}
    const key = w3wKey();
    if (key)
      try {
        const r = await fetch(
            `https://api.what3words.com/v3/convert-to-3wa?coordinates=${encodeURIComponent(c[1] + "," + c[0])}&key=${encodeURIComponent(key)}`,
            { signal: AbortSignal.timeout(10000) },
          ),
          d = await boundedJSON(r, 250000);
        if (r.ok && d?.words) out.what3words = "///" + d.words;
      } catch {}
    return out;
  }
  function routeToSiteHTML() {
    const h = state.project.hgv || fresh().hgv,
      p = HGV_PROFILES[h.profile] || HGV_PROFILES.custom,
      last = (state.project.routes || []).at(-1);
    return (
      '<p class="subtle">Plan the journey <strong>to the site</strong>, not a Trakway run. Vehicle dimensions are used by the HGV routing engine. Always confirm the actual vehicle / trailer dimensions before use.</p>' +
      '<details class="compact-section" open><summary>Route endpoints</summary>' +
      '<div class="route-endpoint"><div>' +
      field(
        "routeStart",
        "Start · address, postcode or coordinates",
        h.startText || "",
      ) +
      '<div class="subtle">' +
      [
        h.start ? "Map point: " + coordLabel(h.start) : "",
        h.startW3w || "",
        h.startAddress || "",
      ]
        .filter(Boolean)
        .map(esc)
        .join(" · ") +
      '</div></div><button class="mini-btn" data-action="pickRoute:start" title="Pick start on map">◎</button></div>' +
      '<div class="route-endpoint"><div>' +
      field(
        "routeEnd",
        "Destination · site entrance",
        h.endText || "",
      ) +
      '<div class="subtle">' +
      [
        h.end ? "Map point: " + coordLabel(h.end) : "",
        h.endW3w || "",
        h.endAddress || "",
      ]
        .filter(Boolean)
        .map(esc)
        .join(" · ") +
      '</div></div><button class="mini-btn" data-action="pickRoute:end" title="Pick destination on map">◎</button></div></details>' +
      '<details class="compact-section"><summary>Vehicle profile & dimensions</summary>' +
      choice("hgvProfile", "Vehicle profile", HGV_PROFILES, h.profile) +
      '<div class="row equal"><div>' +
      field(
        "hgvWeight",
        "Gross weight (t)",
        h.weight ?? p.weight,
        "number",
        'min="1" max="100" step="0.1"',
      ) +
      "</div><div>" +
      field(
        "hgvHeight",
        "Height (m)",
        h.height ?? p.height,
        "number",
        'min="1" max="6.5" step="0.01"',
      ) +
      '</div></div><div class="row equal"><div>' +
      field(
        "hgvWidth",
        "Width (m)",
        h.width ?? p.width,
        "number",
        'min="1" max="5" step="0.01"',
      ) +
      "</div><div>" +
      field(
        "hgvLength",
        "Overall length (m)",
        h.length ?? p.length,
        "number",
        'min="2" max="40" step="0.1"',
      ) +
      "</div></div></details>" +
      button(
        state.routeBusy ? "Planning route…" : last ? "Plan another route" : "Plan route",
        "planHgv",
        true,
      ) +
      (state.lastRouteStatus
        ? '<div class="card route-warning">' +
          esc(state.lastRouteStatus) +
          "</div>"
        : "") +
      (last
        ? '<div class="route-card"><strong>' +
          esc(last.label || "Latest route") +
          "</strong><small>" +
          esc(new Date(last.createdAt).toLocaleString()) +
          " · " +
          esc(last.provider || "routing engine") +
          (last.datasetVersion ? " · " + esc(last.datasetVersion) : "") +
          '</small><div class="route-summary"><div><strong>' +
          Number(last.distanceKm || 0).toFixed(1) +
          "</strong><small>km</small></div><div><strong>" +
          Math.round((last.timeSec || 0) / 60) +
          "</strong><small>min</small></div><div><strong>" +
          esc(HGV_PROFILES[last.profile]?.name || "HGV") +
          '</strong><small>profile</small></div></div><div class="route-warning">' +
          esc(
            last.warning ||
              "Route is a planning aid. Confirm restrictions, notices and site access before travel.",
          ) +
          "</div>" +
          button("Open navigation hand-off", "routeHandoff") +
          button(
            "View saved route history (" +
              (state.project.routes?.length || 0) +
              ")",
            "routeHistory",
          ) +
          button("Delete latest route", "deleteLatestRoute") +
          "</div>"
        : "") +
      '<details class="compact-section"><summary>Routing data & sources</summary>' +
      '<div class="card warning-card"><strong>Production target: OS Routing & Asset Management Information</strong><p class="data-note">OS RAMI provides turn, time, height, weight and width restrictions and is updated monthly. This flat build uses the configured HGV endpoint when supplied; otherwise it uses an OpenStreetMap/Valhalla truck-route preview and labels it accordingly.</p></div></details>'
    );
  }
  function parseCoordText(text) {
    const m = String(text || "")
      .trim()
      .match(/^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$/);
    if (!m) return null;
    const a = +m[1],
      b = +m[2];
    const c =
      Math.abs(a) <= 90 && Math.abs(b) <= 180
        ? [b, a]
        : Math.abs(a) <= 180 && Math.abs(b) <= 90
          ? [a, b]
          : null;
    return c && G.validCoord(c) ? c : null;
  }
  async function resolveLocationText(text) {
    const raw = String(text || "").trim();
    if (!raw)
      throw Error("Enter a start and destination, or pick them on the map.");
    const c = parseCoordText(raw);
    if (c) return { coord: c, label: coordLabel(c), source: "coordinates" };
    const w = raw.replace(/^\/\/\//, "");
    if (W3W_RE.test(raw) || W3W_RE.test(w)) {
      const key = w3wKey();
      if (!key)
        throw Error(
          "what3words needs an API key. Add it under Project → Location integration.",
        );
      const r = await fetch(
        "https://api.what3words.com/v3/convert-to-coordinates?words=" +
          encodeURIComponent(w) +
          "&key=" +
          encodeURIComponent(key),
        { signal: AbortSignal.timeout(10000) },
      );
      const d = await boundedJSON(r, 200000);
      if (!d?.coordinates) throw Error("what3words address was not found.");
      return {
        coord: [+d.coordinates.lng, +d.coordinates.lat],
        label: "///" + d.words,
        source: "what3words",
      };
    }
    const r = await fetch(
      "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=gb,ie&q=" +
        encodeURIComponent(raw),
      {
        signal: AbortSignal.timeout(10000),
        headers: { Accept: "application/json" },
      },
    );
    if (!r.ok) throw Error("Address search is unavailable.");
    const d = await r.json();
    if (!d.length) throw Error("Location not found: " + raw);
    return {
      coord: [+d[0].lon, +d[0].lat],
      label: d[0].display_name,
      source: "address",
    };
  }
  function readHgvOptions() {
    const h = state.project.hgv || fresh().hgv;
    const value = (id, fallback) => $("#" + id)?.value ?? fallback;
    const profile = value("hgvProfile", h.profile);
    const startText = String(value("routeStart", h.startText || "")).trim();
    const endText = String(value("routeEnd", h.endText || "")).trim();
    const o = {profile, startText, endText,
      weight:Number(value("hgvWeight", h.weight)), height:Number(value("hgvHeight", h.height)),
      width:Number(value("hgvWidth", h.width)), length:Number(value("hgvLength", h.length)),
      axles:HGV_PROFILES[profile]?.axles || 3,
      start:startText === h.startText ? h.start : null,
      end:endText === h.endText ? h.end : null};
    if (![o.weight,o.height,o.width,o.length].every(n => Number.isFinite(n) && n > 0))
      throw Error("Enter the vehicle weight, height, width and length.");
    state.project.hgv = {...h,...o};
    return o;
  }

  function decodePolyline(str, precision = 6) {
    let index = 0,
      lat = 0,
      lng = 0,
      out = [],
      factor = 10 ** precision;
    while (index < str.length) {
      let b,
        shift = 0,
        result = 0;
      do {
        if (index >= str.length || shift > 30) throw Error("Invalid route geometry returned by routing service.");
        b = str.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      lat += result & 1 ? ~(result >> 1) : result >> 1;
      shift = 0;
      result = 0;
      do {
        if (index >= str.length || shift > 30) throw Error("Invalid route geometry returned by routing service.");
        b = str.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      lng += result & 1 ? ~(result >> 1) : result >> 1;
      out.push([lng / factor, lat / factor]);
    }
    return out;
  }
  async function planHgvRoute() {
    if (state.routeBusy) return;
    const project = state.project, request = state.routeRequest = (state.routeRequest || 0) + 1;
    let o;
    try {
      o = readHgvOptions();
    } catch (e) {
      toast(e.message);
      return;
    }
    state.routeBusy = true;
    state.lastRouteStatus = "Resolving locations…";
    renderDrawer("routeToSite");
    try {
      let a = o.start
          ? { coord: o.start, label: o.startText || coordLabel(o.start) }
          : await resolveLocationText(o.startText),
        b = o.end
          ? { coord: o.end, label: o.endText || coordLabel(o.end) }
          : await resolveLocationText(o.endText);
      if (state.project !== project || request !== state.routeRequest) return;
      state.project.hgv = {
        ...state.project.hgv,
        start: a.coord,
        end: b.coord,
        startText: a.label,
        endText: b.label,
      };
      if (!G.validCoord(a.coord) || !G.validCoord(b.coord)) throw Error("A route point is invalid. Choose it again.");
      if (G.distance(a.coord,b.coord) < 5) throw Error("Choose a start at least 5 metres from the destination.");
      state.lastRouteStatus = "Finding a truck route…";
      renderDrawer("routeToSite");
      let result,
        provider,
        warning,
        datasetVersion = "",
        status = "preview",
        routeConstraints = [];
      const endpoint = window.SAMI_CONFIG?.hgvRouteEndpoint;
      if (endpoint) {
        const r = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            start: a.coord,
            end: b.coord,
            vehicle: {
              profile: o.profile,
              weight: o.weight,
              height: o.height,
              width: o.width,
              length: o.length,
              axles: o.axles,
            },
            country: "GB",
          }),
          signal: AbortSignal.timeout(25000),
        });
        const d = await boundedJSON(r, 2 * 1024 * 1024);
        if (!Array.isArray(d.geometry) || d.geometry.length < 2 || !d.geometry.every(G.validCoord))
          throw Error(
            "Configured HGV route service returned no usable geometry.",
          );
        result = {
          geometry: d.geometry,
          distanceKm: +d.distanceKm || G.length(d.geometry) / 1000,
          timeSec: +d.timeSec || 0,
        };
        provider = d.provider || "Configured HGV routing service";
        datasetVersion = String(d.datasetVersion || d.dataVersion || "");
        warning =
          d.warning ||
          "Verify the route against current restrictions and site instructions.";
        status = d.authoritative ? "production" : "preview";
        routeConstraints = Array.isArray(d.constraints)
          ? d.constraints
          : Array.isArray(d.restrictions)
            ? d.restrictions
            : Array.isArray(d.hazards)
              ? d.hazards
              : [];
      } else {
        const payload = {
          locations: [
            { lat: a.coord[1], lon: a.coord[0] },
            { lat: b.coord[1], lon: b.coord[0] },
          ],
          costing: "truck",
          costing_options: {
            truck: {
              height: o.height,
              width: o.width,
              length: o.length,
              weight: o.weight,
              axle_load: Math.max(1, o.weight / Math.max(1, o.axles)),
            },
          },
          directions_options: { units: "kilometers" },
        };
        const r = await fetch(
          window.SAMI_CONFIG?.valhallaEndpoint ||
            "https://valhalla1.openstreetmap.de/route",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
            signal: AbortSignal.timeout(30000),
          },
        );
        const d = await boundedJSON(r, 4 * 1024 * 1024);
        if (!d?.trip?.legs?.length) throw Error(d?.error || "No truck route was returned for these points.");
        const geometry = [];
        for (const leg of d.trip.legs) {
          const pts = decodePolyline(leg.shape, 6);
          if (
            geometry.length &&
            pts.length &&
            geometry.at(-1)[0] === pts[0][0] &&
            geometry.at(-1)[1] === pts[0][1]
          )
            pts.shift();
          geometry.push(...pts);
        }
        if (geometry.length < 2 || !geometry.every(G.validCoord)) throw Error("Routing returned invalid coordinates. Your saved routes are unchanged.");
        result = {
          geometry,
          distanceKm: +d.trip.summary?.length || G.length(geometry) / 1000,
          timeSec: +d.trip.summary?.time || 0,
        };
        provider = "Valhalla · OpenStreetMap truck preview";
        datasetVersion = "Public demo routing graph · version not exposed";
        warning =
          "Preview respects mapped HGV/height/weight/width restrictions where present. It is not a guarantee of legal or physical suitability. Production SAMI should use licensed authoritative GB routing data plus current notices.";
      }
      state.lastRouteStatus = "";
      const rec = {
        id: uid(),
        label: "Route to site · " + a.label + " → " + b.label,
        createdAt: new Date().toISOString(),
        profile: o.profile,
        profileName: hgvIssueName(o.profile, o.weight),
        vehicle: {
          weight: o.weight,
          height: o.height,
          width: o.width,
          length: o.length,
          axles: o.axles,
        },
        start: a.coord,
        end: b.coord,
        startLabel: a.label,
        endLabel: b.label,
        geometry: result.geometry,
        distanceKm: result.distanceKm,
        timeSec: result.timeSec,
        provider,
        datasetVersion,
        warning,
        status,
        constraints: routeConstraints,
      };
      if (state.project !== project || request !== state.routeRequest) return;
      state.project.hgv.stale = false;
      state.project.routes.push(rec);
      if (state.project.routes.length > 30) state.project.routes.shift();
      commit();
      closeDrawer();
      if (state.mode === "plan") setMode("map");
      state.map.fitBounds(L.latLngBounds(result.geometry.map(latlng)), {
        padding: [60, 60],
      });
      openDrawer("routeToSite");
      toast("HGV route planned and saved as a dated route record.");
    } catch (e) {
      if (state.project !== project || request !== state.routeRequest) return;
      state.lastRouteStatus = e.message;
      renderDrawer("routeToSite");
      toast("Route: " + e.message);
    } finally {
      if (state.project === project && request === state.routeRequest) {
        state.routeBusy = false;
        if (state.drawer === "routeToSite") renderDrawer("routeToSite");
      }
    }
  }
  function pickRoutePoint(which) {
    if (!["start", "end"].includes(which)) return;
    try { readHgvOptions(); } catch {}
    cancelDraw();
    if (state.mode !== "route") setMode("route");
    state.routePick = which;
    state.suppressMapClick = 0;
    closeDrawer(true);
    updateLock();
    toast("Tap the map to set the route " + (which === "start" ? "start" : "destination") + ".");
  }

  function openRouteHandoff() {
    const r = state.project.routes.at(-1);
    if (!r) return;
    const [a, b] = [r.start, r.end],
      apple =
        "https://maps.apple.com/?saddr=" +
        a[1] +
        "," +
        a[0] +
        "&daddr=" +
        b[1] +
        "," +
        b[0] +
        "&dirflg=d",
      google =
        "https://www.google.com/maps/dir/?api=1&origin=" +
        a[1] +
        "," +
        a[0] +
        "&destination=" +
        b[1] +
        "," +
        b[0] +
        "&travelmode=driving",
      waze =
        "https://www.waze.com/ul?ll=" + b[1] + "%2C" + b[0] + "&navigate=yes";
    showModal(
      "Navigation hand-off",
      '<p class="route-warning">Apple Maps, Google Maps and Waze may calculate a <strong>car route</strong> and can ignore HGV restrictions. Use them only as a location/navigation hand-off, not as evidence that the HGV route is compliant.</p><div class="modal-grid"><a class="wide-btn primary" target="_blank" rel="noopener" href="' +
        apple +
        '">Open Apple Maps</a><a class="wide-btn" target="_blank" rel="noopener" href="' +
        google +
        '">Open Google Maps</a><a class="wide-btn" target="_blank" rel="noopener" href="' +
        waze +
        '">Open Waze destination</a><a class="wide-btn" target="_blank" rel="noopener" href="https://www.lorryroute.com/route-planning">Open Lorry Route</a></div><p class="subtle">The SAMI route record remains saved with its vehicle dimensions and creation date.</p>',
    );
  }
  function deleteLatestRoute() {
    if (!state.project.routes.length) return;
    state.project.routes.pop();
    commit();
    renderDrawer("routeToSite");
    toast("Latest route removed. Undo is available.");
  }
  function openRouteHistory() {
    const routes = (state.project.routes || []).slice().reverse();
    showModal(
      "Route-to-site history",
      routes.length
        ? '<p class="subtle">Each re-check creates a new dated route record. Older records are retained rather than overwritten.</p>' +
            routes
              .map(
                (r, i) =>
                  '<div class="item-row"><div><strong>' +
                  esc(HGV_PROFILES[r.profile]?.name || "HGV route") +
                  "</strong><small>" +
                  esc(new Date(r.createdAt).toLocaleString()) +
                  " · " +
                  Number(r.distanceKm || 0).toFixed(1) +
                  " km · " +
                  esc(r.provider || "route source") +
                  '</small></div><button class="mini-btn" data-route-history="' +
                  esc(r.id) +
                  '">Restore</button></div>',
              )
              .join("")
        : '<p class="subtle">No saved route records yet.</p>',
    );
    $("#modalBody").onclick = (e) => {
      const id = e.target.closest("[data-route-history]")?.dataset.routeHistory;
      if (!id) return;
      const idx = state.project.routes.findIndex((r) => r.id === id);
      if (idx < 0) return;
      const rec = state.project.routes.splice(idx, 1)[0];
      state.project.hgv.stale = false;
      state.project.routes.push(rec);
      state.project.hgv = {
        ...state.project.hgv,
        profile: rec.profile,
        ...rec.vehicle,
        start: rec.start,
        end: rec.end,
        startText: rec.startLabel,
        endText: rec.endLabel,
      };
      commit();
      closeModal();
      if (rec.geometry?.length)
        state.map.fitBounds(L.latLngBounds(rec.geometry.map(latlng)), {
          padding: [60, 60],
        });
      openDrawer("routeToSite");
      toast("Earlier route record restored as the active overview.");
    };
  }
  function planBaseClass(tags) {
    if (tags.building) return "building";
    if (tags.highway)
      return [
        "footway",
        "path",
        "cycleway",
        "bridleway",
        "steps",
        "track",
      ].includes(tags.highway)
        ? "path"
        : "road";
    if (tags.railway) return "rail";
    if (tags.waterway || tags.natural === "water" || tags.water) return "water";
    if (tags.barrier) return "barrier";
    if (tags.power === "line" || tags.power === "minor_line") return "power";
    if (
      tags.landuse ||
      tags.leisure ||
      tags.amenity ||
      ["wood", "scrub", "grassland"].includes(tags.natural)
    )
      return "land";
    return null;
  }
  function roadWeight(tags) {
    return (
      {
        motorway: 7,
        trunk: 6,
        primary: 5,
        secondary: 4,
        tertiary: 3.5,
        residential: 3,
        unclassified: 2.5,
        service: 2,
      }[tags.highway] || 2
    );
  }
  function roadWidthMeters(tags) {
    const raw = String(tags.width || "").match(/[0-9]+(?:\.[0-9]+)?/);
    if (raw && +raw[0] > 0.5 && +raw[0] < 40) return +raw[0];
    const laneCount = +tags.lanes || 0;
    if (laneCount > 0) return Math.max(1, Math.min(8, laneCount)) * 3.2;
    return (
      {
        motorway: 12,
        trunk: 9.5,
        primary: 8,
        secondary: 7,
        tertiary: 6.5,
        residential: 5.5,
        unclassified: 5,
        service: 4,
        track: 3.5,
      }[tags.highway] || 3
    );
  }
  function overpassFeatures(data, opts = {}) {
    const powerAsService = !!opts.powerAsService,
      nodes = new Map(
        (data.elements || [])
          .filter((x) => x.type === "node")
          .map((n) => [n.id, [n.lon, n.lat, n.tags || {}]]),
      ),
      out = [];
    for (const w of (data.elements || []).filter(
      (x) => x.type === "way" && (Array.isArray(x.nodes) || Array.isArray(x.geometry)),
    ).flatMap(w => Array.isArray(w.geometry)
      ? window.SAMIPlanning.waySegments(w.geometry).map((geometry,i)=>({...w,id:w.id+"-"+i,geometry})) : [w])) {
      const tags = w.tags || {},
        cls = planBaseClass(tags),
        coords = Array.isArray(w.geometry)
          ? w.geometry.filter(n => n && Number.isFinite(n.lon) && Number.isFinite(n.lat)).map(n => [n.lon,n.lat])
          : (w.nodes || []).map(id => nodes.get(id)).filter(Boolean).map(n => [n[0],n[1]]);
      if (!cls || coords.length < 2) continue;
      if (powerAsService && cls === "power") {
        const supports = {},
          supportPoints = [];
        for (const id of w.nodes || []) {
          const n = nodes.get(id);
          if (n?.[2]?.power === "pole") {
            supports[supportKey(n)] = "pole";
            supportPoints.push([n[0], n[1]]);
          }
          if (n?.[2]?.power === "tower") {
            supports[supportKey(n)] = "pylon";
            supportPoints.push([n[0], n[1]]);
          }
        }
        out.push(
          feature(
            "service",
            { type: "LineString", coordinates: coords },
            {
              serviceType: "ohl",
              label: tags.name || tags.ref || "Overhead power line",
              source: "Stored OpenStreetMap power-asset snapshot",
              sourceId: "builtin:ohl-osm",
              verification:
                "Representative only · verify with network operator / survey",
              provenance: "Snapshot captured " + new Date().toISOString(),
              supportTypesJSON: JSON.stringify(supports),
              supportPointsJSON: JSON.stringify(supportPoints),
              voltage: tags.voltage || "",
              includeLegend: true,
            },
          ),
        );
        continue;
      }
      const closed = coords.length > 3 && coords[0][0] === coords.at(-1)[0] && coords[0][1] === coords.at(-1)[1],
        poly = closed && ["building", "water", "land"].includes(cls),
        props = {
          baseClass: cls,
          name: tags.name || tags["addr:street"] || tags.ref || "",
          labelPointJSON: JSON.stringify(coords[Math.floor(coords.length / 2)]),
          ref: tags.ref || "",
          highway: tags.highway || "",
          building: tags.building || "",
          surface: tags.surface || "",
          source: "Stored OpenStreetMap vector snapshot",
        };
      let geometry;
      if (cls === "road") {
        const width = roadWidthMeters(tags);
        props.roadWeight = roadWeight(tags);
        props.roadWidthM = width;
        try {
          geometry = G.lineBuffer(coords, width);
        } catch {
          geometry = { type: "LineString", coordinates: coords };
        }
      } else if (cls === "path") {
        const mt = String(tags.width || "").match(/[0-9.]+/),
          width = Math.max(1, Math.min(5, mt ? +mt[0] : 1.8));
        props.roadWidthM = width;
        try {
          geometry = G.lineBuffer(coords, width);
        } catch {
          geometry = { type: "LineString", coordinates: coords };
        }
      } else
        geometry = poly
          ? { type: "Polygon", coordinates: [coords] }
          : { type: "LineString", coordinates: coords };
      out.push({
        type: "Feature",
        id: "base-" + w.id,
        properties: props,
        geometry,
      });
    }
    for (const n of (data.elements || []).filter(
      (n) => n.type === "node" && n.tags?.natural === "tree",
    ))
      out.push({
        type: "Feature",
        id: "base-node-" + n.id,
        properties: {
          baseClass: "tree",
          name: n.tags.name || "",
          radius: Math.max(
            0.5,
            Math.min(15, (parseFloat(n.tags["diameter_crown"]) || 6) / 2),
          ),
          source: "Stored OpenStreetMap tree point",
        },
        geometry: { type: "Point", coordinates: [n.lon, n.lat] },
      });
    return out;
  }
  function overpassEndpoints() {
    const configured = String(
        window.SAMI_CONFIG?.overpassEndpoint || "",
      ).trim(),
      configuredFallbacks = Array.isArray(
        window.SAMI_CONFIG?.overpassFallbackEndpoints,
      )
        ? window.SAMI_CONFIG.overpassFallbackEndpoints
        : [],
      fallbacks = [
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
      ];
    return [
      ...new Set(
        [configured, ...configuredFallbacks, ...fallbacks]
          .map((x) => String(x || "").trim())
          .filter(Boolean),
      ),
    ];
  }
  async function overpassQuery(query, max = 8 * 1024 * 1024, opts = {}) {
    const errors = [];
    let empty = null;
    for (const endpoint of overpassEndpoints()) {
      const ctl = new AbortController(),
        timer = setTimeout(() => ctl.abort(), 38000);
      try {
        const r = await fetch(endpoint, {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
              Accept: "application/json",
            },
            body: "data=" + encodeURIComponent(query),
            signal: ctl.signal,
            cache: "no-store",
            credentials: "omit",
          }),
          data = await boundedJSON(r, max);
        if (data?.remark && /runtime error|timed out|out of memory/i.test(data.remark)) throw Error(data.remark);
        if (!data || !Array.isArray(data.elements))
          throw Error("Invalid Overpass response");
        if (opts.preferNonEmpty && !data.elements.length) {
          empty ??= data;
          errors.push(
            endpoint.replace(/^https?:\/\//, "").split("/")[0] +
              ": empty result",
          );
          continue;
        }
        return data;
      } catch (e) {
        errors.push(
          endpoint.replace(/^https?:\/\//, "").split("/")[0] +
            ": " +
            (e?.name === "AbortError" ? "timeout" : e?.message || "failed"),
        );
      } finally {
        clearTimeout(timer);
      }
    }
    if (empty) return empty;
    throw Error(
      "Public map source unavailable after " +
        overpassEndpoints().length +
        " mirrors · " +
        errors.join(" · "),
    );
  }
  const PLAN_DETAIL_TAGS = {
    low: ['way["highway"]', 'way["building"]'],
    medium: [
      'way["highway"]',
      'way["building"]',
      'way["railway"]',
      'way["waterway"]',
      'way["natural"]',
      'way["landuse"]',
      'way["power"~"^(line|minor_line)$"]',
    ],
    high: [
      'way["highway"]',
      'way["building"]',
      'way["railway"]',
      'way["waterway"]',
      'way["natural"]',
      'node["natural"="tree"]',
      'way["landuse"]',
      'way["barrier"]',
      'way["amenity"]',
      'way["leisure"]',
      'way["man_made"]',
      'way["power"~"^(line|minor_line)$"]',
    ],
  };
  const PLAN_DETAIL_RANK = { low: 1, medium: 2, high: 3 };
  function planDetailLevel() {
    return ["low", "medium", "high"].includes(state.project.planDetail)
      ? state.project.planDetail
      : "low";
  }
  function updateCadProcessingUI(active) {
    $$('[data-base="drawing"], [data-action="capturePlanBase"]').forEach(
      (b) => b.classList.toggle("cad-processing", active),
    );
    window.dispatchEvent(new Event("sami:cadstatus"));
  }
  function planBaseNeedsCapture(requiredDetail) {
    return window.SAMIPlanning.needsCapture(state.project, requiredDetail || planDetailLevel());
  }

  async function ensureExportCadDetail(requiredDetail = planDetailLevel()) {
    if (!state.project.area) return;
    if (requiredDetail === "simple") requiredDetail = "low";
    if (state.planCapturePromise) await state.planCapturePromise;
    if (planBaseNeedsCapture(requiredDetail)) await capturePlanBase(true, requiredDetail);
    if (planBaseNeedsCapture(requiredDetail))
      toast("CAD background is incomplete or out of date. Your drawn objects are retained; check before issue.");
  }
  function capturePlanBase(silent = false, detailOverride = null) {
    const owner = state.project, generation = state.areaGeneration;
    if (state.planCapturePromise && state.planCaptureOwner === owner && state.planCaptureGeneration === generation)
      return state.planCapturePromise;
    state.planCaptureOwner = owner;
    state.planCaptureGeneration = generation;
    const task = capturePlanBaseWork(silent, detailOverride);
    state.planCapturePromise = task;
    return task.finally(() => { if (state.planCapturePromise === task) state.planCapturePromise = null; });
  }
  async function capturePlanBaseWork(silent = false, detailOverride = null) {
    if (!state.project.area) {
      if (!silent) openDrawer("area");
      return;
    }
    let b;
    try { b = window.SAMIPlanning.captureBounds(state.project); }
    catch (e) { state.planCaptureError = e.message; toast(e.message); updateCadProcessingUI(false); return; }
    const a = G.area(b),
      captureGeneration = state.areaGeneration,
      captureProject = state.project,
      detail = detailOverride || planDetailLevel();
    if (a > 6000000) {
      if (!silent)
        toast(
          "Detailed plan capture is limited to about 6 km². Reduce the site area or bleed.",
        );
      return;
    }
    state.planCaptureError = null;
    state.planCapturing = true;
    updateCadProcessingUI(true);
    window.dispatchEvent(new Event("sami:cadstatus"));
    if (!silent)
      toast(
        "Capturing " +
          detail +
          "-detail vector geometry for the defined site area + bleed…",
      );
    try {
      const bbox = [b[1], b[0], b[3], b[2]].join(","),
        tags = PLAN_DETAIL_TAGS[detail] || PLAN_DETAIL_TAGS.low,
        q =
          "[out:json][timeout:30];(" +
          tags.map((t) => t + "(" + bbox + ");").join("") +
          ");out body geom(" + bbox + ");";
      const data = await overpassQuery(q);
      if (
        captureProject !== state.project ||
        captureGeneration !== state.areaGeneration
      )
        return;
      const features = overpassFeatures(data)
        .map((f) => {
          let g;
          try {
            g = G.clipGeometry(f.geometry, b);
          } catch {
            return null;
          }
          return g ? { ...f, geometry: g } : null;
        })
        .filter(Boolean)
        .slice(0, 9000);
      const previous = state.project.planBase?.length
        ? {
            capturedAt: state.project.planBaseMeta?.capturedAt || "",
            source: state.project.planBaseMeta?.source || "",
            featureCount: state.project.planBase.length,
          }
        : null;
      if (!features.length && state.project.planBase?.length) {
        state.planCaptureError = "No replacement detail returned. Existing background kept; choose Refresh to retry.";
        toast(state.planCaptureError);
        return;
      }
      state.project.planBase = features;
      state.project.planBaseMeta = {
        capturedAt: new Date().toISOString(),
        source: "Stored OpenStreetMap vector snapshot · bounded site capture",
        bleed: Number(state.project.planBleed ?? PLAN_BLEED_DEFAULT),
        detail,
        bbox: boundsText(b),
        featureCount: features.length,
        stale: false,
        captureKey: window.SAMIPlanning.captureKey(captureProject, detail),
        previous,
      };
      commit();
      if (state.mode === "plan") state.map.invalidateSize({ pan: false });
      if (!silent)
        toast(
          features.length +
            " " +
            detail +
            "-detail map features stored. Roads use metre-width geometry where available / inferred.",
        );
    } catch (e) {
      if (captureProject === state.project && captureGeneration === state.areaGeneration) {
        state.planCaptureError = e.message;
        toast("CAD detail unavailable. Existing drawing retained. " + e.message);
      }
    } finally {
      if (captureProject === state.project && captureGeneration === state.areaGeneration) {
        state.planCapturing = false;
        updateCadProcessingUI(false);
        window.dispatchEvent(new Event("sami:cadstatus"));
      }
    }
  }
  const serviceRefreshes = new Map();
  async function runServiceRefresh(key, work) {
    const project = state.project, generation = state.areaGeneration;
    if (!project.area) { openDrawer("area", true); return {status:"error",message:"Define the site area first."}; }
    const requestKey = project.id + ":" + generation + ":" + key;
    if (serviceRefreshes.has(requestKey)) return serviceRefreshes.get(requestKey);
    const task = (async () => {
      project.serviceStatus ??= {};
      project.serviceStatus[key] = {status:"loading", message:"Checking source…"};
      if (state.drawer === "services") renderDrawer("services");
      let result;
      try { result = await work(); }
      catch(e) { result = {status:"error", message:e.message || "Source unavailable"}; }
      if (state.project !== project || state.areaGeneration !== generation) return {status:"cancelled"};
      result ??= {status:"retained", message:"Existing records retained."};
      project.serviceStatus[key] = {...result, checkedAt:new Date().toISOString()};
      saveSoon();
      if (state.drawer === "services") renderDrawer("services");
      return result;
    })();
    serviceRefreshes.set(requestKey, task);
    try { return await task; } finally { serviceRefreshes.delete(requestKey); }
  }
  async function showSelectedServiceMapping() {
    if (!state.project.area) { openDrawer("area", true); return; }
    const project = state.project, generation = state.areaGeneration;
    const on = Object.keys(SERVICES).filter(k => project.serviceVisibility[k] === true);
    if (!on.length) { toast("Select at least one service or constraint."); return; }
    project.hiddenTypes = project.hiddenTypes.filter(t => t !== "service");
    commit();
    const results = [];
    if (on.includes("ohl")) results.push(await refreshOhlSnapshot());
    if (state.project !== project || generation !== state.areaGeneration) return;
    if (on.some(k => ["electric","gas","water","drainage","telecom"].includes(k))) results.push(await refreshPublicUtilities());
    if (state.project !== project || generation !== state.areaGeneration) return;
    if (on.some(k => ["ecology","sssi","tpo","heritage","archaeology","flood","conservation"].includes(k))) results.push(await refreshPlanningConstraints());
    if (state.project !== project || generation !== state.areaGeneration) return;
    const failed = results.filter(r => r?.status === "error" || r?.status === "retained").length;
    toast(failed ? "Some sources could not be updated. See source status; saved records are retained." : "Source checks complete. See the record counts and coverage in Services.");
    if (state.drawer === "services") renderDrawer("services");
  }
  async function refreshOhlSnapshot() {
    if (!state.project.area) {
      openDrawer("area");
      return;
    }
    const b = ohlSearchBounds(),
      bbox = [b[1], b[0], b[3], b[2]].join(",");
    toast("Updating mapped overhead-line intelligence…");
    try {
      const q =
        '[out:json][timeout:35];(way["power"~"^(line|minor_line)$"](' +
        bbox +
        ');way["power"="cable"]["location"="overhead"](' +
        bbox +
        ');node["power"~"^(pole|tower|portal|terminal)$"](' +
        bbox +
        "););(._;>;);out body;";
      const data = await overpassQuery(q, 16 * 1024 * 1024),
        features = overpassFeatures(data, { powerAsService: true });
      await replaceSourceFeatures(
        "builtin:ohl-osm",
        features,
        "OHL intelligence snapshot",
      );
      state.project.hiddenTypes = state.project.hiddenTypes.filter(
        (t) => t !== "service",
      );
      state.project.serviceVisibility.ohl = true;
      toast(
        features.length +
          " mapped overhead-line records saved for the site + 0.5 mile buffer.",
      );
      if (state.drawer === "services") renderDrawer("services");
    } catch (e) {
      toast("Overhead lines: " + e.message);
    }
  }
  function publicUtilityType(tags = {}) {
    const substance = String(
        tags.substance || tags.content || tags.product || tags.sewer || "",
      ).toLowerCase(),
      utility = String(tags.utility || "").toLowerCase(),
      manMade = String(tags.man_made || "").toLowerCase(),
      pipeline = String(tags.pipeline || "").toLowerCase(),
      pumping = String(tags.pumping_station || "").toLowerCase(),
      manhole = String(tags.manhole || "").toLowerCase(),
      gasType = String(tags.gas || "").toLowerCase();
    if (
      (tags.power &&
        [
          "cable",
          "underground_cable",
          "substation",
          "transformer",
          "switch",
          "minor_line",
        ].includes(tags.power)) ||
      ["power", "electricity", "electric"].includes(utility) ||
      (manMade === "street_cabinet" && !tags.pipeline && !tags.telecom)
    )
      return "electric";
    if (
      manhole === "gas" ||
      gasType ||
      substance.includes("gas") ||
      utility === "gas" ||
      pumping === "gas" ||
      (pipeline === "valve" && substance.includes("gas"))
    )
      return "gas";
    if (
      ["sewage", "sewer", "wastewater", "stormwater", "storm"].some(
        (x) => substance.includes(x) || manhole.includes(x),
      ) ||
      ["sewer", "drainage"].includes(utility) ||
      ["sewage", "wastewater"].includes(pumping) ||
      manMade === "wastewater_plant" ||
      manMade === "storm_drain" ||
      manMade === "culvert" ||
      ["drain", "ditch"].includes(String(tags.waterway || "")) ||
      manhole === "drain" ||
      manhole === "unknown" ||
      manhole === "yes" ||
      tags.drain
    )
      return "drainage";
    if (
      substance.includes("water") ||
      utility === "water" ||
      pumping === "water" ||
      [
        "water_works",
        "water_tower",
        "reservoir_covered",
        "water_well",
        "water_tap",
      ].includes(manMade) ||
      manhole === "water" ||
      tags.emergency === "fire_hydrant" ||
      tags["fire_hydrant:type"]
    )
      return "water";
    if (
      tags.communication === "line" ||
      utility === "telecom" ||
      tags.telecom ||
      manhole === "telecom"
    )
      return "telecom";
    if (pipeline === "marker" && substance.includes("gas")) return "gas";
    return null;
  }
  function publicUtilityFeatures(data) {
    const elements = data?.elements || [],
      nodes = new Map(
        elements.filter((x) => x.type === "node").map((n) => [n.id, n]),
      ),
      out = [],
      stamp = new Date().toISOString(),
      sourceId = "builtin:osm-public-utilities";
    for (const w of elements.filter(
      (x) => x.type === "way" && (Array.isArray(x.nodes) || Array.isArray(x.geometry)),
    )) {
      const tags = w.tags || {},
        type = publicUtilityType(tags),
        coords = w.nodes
          .map((id) => nodes.get(id))
          .filter(Boolean)
          .map((n) => [n.lon, n.lat]);
      if (!type || coords.length < 2) continue;
      const location = tags.location ? String(tags.location) : "",
        name =
          tags.name ||
          tags.ref ||
          "Mapped " + SERVICES[type].name.toLowerCase();
      out.push(
        feature(
          "service",
          { type: "LineString", coordinates: coords },
          {
            serviceType: type,
            label: name + (location ? " · " + location : ""),
            source: "OpenStreetMap public mapped infrastructure",
            sourceId,
            sourceRecord: "OSM way " + w.id,
            verification:
              "Public map reference only · NOT FOR EXCAVATION / SERVICE AVOIDANCE",
            provenance: "Bounded snapshot " + stamp,
            operator: tags.operator || "",
            owner: tags.owner || "",
            network: tags.network || "",
            material: tags.material || tags.pipe_material || "",
            location,
            voltage: tags.voltage || "",
            diameter: tags.diameter || "",
            includeLegend: true,
          },
        ),
      );
    }
    for (const n of elements.filter((x) => x.type === "node" && x.tags)) {
      const tags = n.tags || {},
        type = publicUtilityType(tags);
      if (!type || !Number.isFinite(n.lon) || !Number.isFinite(n.lat)) continue;
      if (
        !tags.utility &&
        !tags.pipeline &&
        !tags.telecom &&
        !tags.manhole &&
        !tags.drain &&
        tags.emergency !== "fire_hydrant" &&
        !tags["fire_hydrant:type"] &&
        !["substation", "transformer", "switch"].includes(tags.power) &&
        ![
          "street_cabinet",
          "pumping_station",
          "water_works",
          "wastewater_plant",
          "water_tower",
          "reservoir_covered",
          "water_well",
          "water_tap",
          "storm_drain",
        ].includes(tags.man_made)
      )
        continue;
      out.push(
        feature(
          "service",
          { type: "Point", coordinates: [n.lon, n.lat] },
          {
            serviceType: type,
            label:
              tags.name ||
              tags.ref ||
              (tags.emergency === "fire_hydrant"
                ? "Fire hydrant"
                : tags.manhole
                  ? "Manhole · " +
                    (tags.manhole === "yes" ? "unspecified" : tags.manhole)
                  : ["substation", "transformer", "switch"].includes(tags.power)
                    ? "Electricity " + tags.power
                    : "Mapped " + SERVICES[type].name + " feature"),
            source: "OpenStreetMap public mapped infrastructure",
            sourceId,
            sourceRecord: "OSM node " + n.id,
            verification:
              "Public map reference only · NOT FOR EXCAVATION / SERVICE AVOIDANCE",
            provenance: "Bounded snapshot " + stamp,
            operator: tags.operator || "",
            owner: tags.owner || "",
            network: tags.network || "",
            diameter: tags.diameter || "",
            includeLegend: true,
          },
        ),
      );
    }
    return out;
  }
  function refreshPublicUtilities() {
    return runServiceRefresh("utilities", refreshPublicUtilitiesWork);
  }
  async function refreshPublicUtilitiesWork() {
    const project = state.project, generation = state.areaGeneration;
    if (!state.project.area) {
      openDrawer("area");
      return;
    }
    const b = serviceBounds(),
      bbox = [b[1], b[0], b[3], b[2]].join(",");
    toast("Refreshing public mapped utilities for the bounded site area…");
    try {
      const q =
        '[out:json][timeout:35];(way["power"~"^(cable|underground_cable)$"](' +
        bbox +
        ');way["utility"~"^(power|electricity|electric|gas|water|telecom|sewer|drainage)$"](' +
        bbox +
        ');way["substance"~"^(gas|water|sewage|wastewater)$"](' +
        bbox +
        ');way["man_made"="pipeline"](' +
        bbox +
        ');way["pipeline"](' +
        bbox +
        ');way["sewer"](' +
        bbox +
        ');way["water"="wastewater"](' +
        bbox +
        ');way["waterway"~"^(drain|ditch)$"](' +
        bbox +
        ');way["man_made"="culvert"](' +
        bbox +
        ');way["communication"="line"](' +
        bbox +
        ');way["telecom"="cable"](' +
        bbox +
        ');way["power"="minor_line"]["location"="underground"](' +
        bbox +
        ');node["utility"~"^(power|electricity|electric|gas|water|telecom|sewer|drainage)$"](' +
        bbox +
        ');node["man_made"="street_cabinet"](' +
        bbox +
        ');node["pipeline"~"^(marker|valve|substation)$"](' +
        bbox +
        ');node["power"~"^(substation|transformer|switch)$"](' +
        bbox +
        ');node["man_made"="pumping_station"](' +
        bbox +
        ');node["man_made"~"^(water_works|wastewater_plant|water_tower|reservoir_covered|water_well|water_tap|storm_drain)$"](' +
        bbox +
        ');node["manhole"](' +
        bbox +
        ');node["emergency"="fire_hydrant"](' +
        bbox +
        ');node["fire_hydrant:type"](' +
        bbox +
        "););(._;>;);out body;";
      const data = await overpassQuery(q, 12 * 1024 * 1024),
        features = publicUtilityFeatures(data)
          .map((f) => {
            const g = G.clipGeometry(f.geometry, b);
            return g ? { ...f, geometry: g } : null;
          })
          .filter(Boolean)
          .slice(0, 5000);
      if (project !== state.project || generation !== state.areaGeneration) return {status:"cancelled"};
      const previousCount = state.project.features.filter(
        (feature) =>
          feature.properties.sourceId === "builtin:osm-public-utilities",
      ).length;
      if (!features.length && previousCount) {
        toast(
          "No new public utility records were returned. The last stored snapshot has been kept.",
        );
        return {status:"retained",count:previousCount,message:"No replacement records; previous snapshot kept."};
      }
      await replaceSourceFeatures(
        "builtin:osm-public-utilities",
        features,
        "Public mapped utilities · OpenStreetMap", project, generation,
      );
      if (project !== state.project || generation !== state.areaGeneration) return;
      state.project.serviceVisibilityConfigured = true;
      toast(
        features.length
          ? features.length +
              " public mapped utility records stored as a dated reference snapshot."
          : "No mapped public utility records were returned for this bounded area. SAMI has not invented any.",
      );
      if (state.drawer === "services") renderDrawer("services");
      return {status:features.length ? "ready" : "empty",count:features.length,message:features.length ? "Public mapped references loaded." : "No public mapped records returned. Coverage is incomplete."};
    } catch (e) {
      if (project !== state.project || generation !== state.areaGeneration) return {status:"cancelled"};
      const kept = state.project.features.some(
        (feature) =>
          feature.properties.sourceId === "builtin:osm-public-utilities",
      );
      toast(
        "Public utilities: " +
          e.message +
          (kept ? " The last stored snapshot is still available." : ""),
      );
      return {status:"error",message:e.message + (kept ? " Previous snapshot kept." : "")};
    }
  }
  const PLANNING_DATASETS = {
    "tree-preservation-zone": "tpo",
    tree: "tpo",
    "listed-building-outline": "heritage",
    "listed-building": "heritage",
    "conservation-area": "conservation",
    "scheduled-monument": "archaeology",
    "site-of-special-scientific-interest": "sssi",
    "ancient-woodland": "ecology",
    "local-nature-reserve": "ecology",
    "flood-risk-zone": "flood",
  };
  const PLANNING_LABELS = {
    "tree-preservation-zone": "Tree Preservation Order zone",
    tree: "Protected tree",
    "listed-building-outline": "Listed building outline",
    "listed-building": "Listed building",
    "conservation-area": "Conservation area",
    "scheduled-monument": "Scheduled monument",
    "site-of-special-scientific-interest": "SSSI",
    "ancient-woodland": "Ancient woodland",
    "local-nature-reserve": "Local nature reserve",
    "flood-risk-zone": "Flood risk zone",
  };
  function serviceAreaWKT(b) {
    return `POLYGON((${b[0]} ${b[1]},${b[2]} ${b[1]},${b[2]} ${b[3]},${b[0]} ${b[3]},${b[0]} ${b[1]}))`;
  }
  async function planningDataGeoJSON(b) {
    const base = "https://www.planning.data.gov.uk/entity.geojson",
      datasets = Object.keys(PLANNING_DATASETS),
      all = [];
    for (let offset = 0; offset < 1500; offset += 500) {
      const u = new URL(base);
      for (const d of datasets) u.searchParams.append("dataset", d);
      u.searchParams.set("geometry", serviceAreaWKT(b));
      u.searchParams.set("geometry_relation", "intersects");
      u.searchParams.set("limit", "500");
      u.searchParams.set("offset", String(offset));
      const r = await fetch(u, {
          headers: { Accept: "application/geo+json,application/json" },
          signal: AbortSignal.timeout(25000),
        }),
        d = await boundedJSON(r, 12 * 1024 * 1024),
        fs = Array.isArray(d.features) ? d.features : [];
      all.push(...fs);
      if (fs.length < 500) break;
    }
    return all;
  }
  function planningConstraintFeatures(rows, b) {
    const sourceId = "builtin:planning-data-constraints",
      stamp = new Date().toISOString(),
      out = [];
    for (const row of rows) {
      const props = row.properties || {},
        dataset = props.dataset || props.prefix || "",
        serviceType = PLANNING_DATASETS[dataset];
      if (!serviceType || !row.geometry) continue;
      let geometry;
      try {
        geometry = G.clipGeometry(row.geometry, b);
      } catch {
        continue;
      }
      if (!geometry) continue;
      const ref = props.reference || props.entity || "",
        name = props.name || PLANNING_LABELS[dataset] || dataset,
        label = name + (ref && String(name) !== String(ref) ? " · " + ref : "");
      out.push(
        feature("service", geometry, {
          serviceType,
          label,
          source: "Planning Data API · " + dataset,
          sourceId,
          sourceRecord: String(props.entity || ref || ""),
          verification:
            "Public planning reference · coverage varies; confirm with the relevant authority/source",
          provenance: "Bounded API snapshot " + stamp,
          dataset,
          quality: props.quality || "",
          grade:
            props["listed-building-grade"] || props.listed_building_grade || "",
          includeLegend: true,
        }),
      );
    }
    return out;
  }
  function refreshPlanningConstraints() {
    return runServiceRefresh("constraints", refreshPlanningConstraintsWork);
  }
  async function refreshPlanningConstraintsWork() {
    const project = state.project, generation = state.areaGeneration;
    if (!state.project.area) {
      openDrawer("area");
      return;
    }
    const b = serviceBounds();
    toast("Refreshing public planning constraints for the bounded site area…");
    try {
      const rows = await planningDataGeoJSON(b),
        features = planningConstraintFeatures(rows, b).slice(0, 5000);
      if (project !== state.project || generation !== state.areaGeneration) return {status:"cancelled"};
      const previousCount = project.features.filter(f => f.properties.sourceId === "builtin:planning-data-constraints").length;
      if (!features.length && previousCount)
        return {status:"retained",count:previousCount,message:"No replacement records; previous planning snapshot kept."};
      await replaceSourceFeatures(
        "builtin:planning-data-constraints",
        features,
        "Planning Data constraints · bounded snapshot", project, generation,
      );
      if (project !== state.project || generation !== state.areaGeneration) return;
      state.project.serviceVisibilityConfigured = true;
      toast(
        features.length
          ? features.length +
              " planning constraint records stored for the site + 0.1 mile buffer."
          : "No Planning Data constraint records were returned for this area. Coverage varies, so this is not proof that no constraint exists.",
      );
      if (state.drawer === "services") renderDrawer("services");
      return {status:features.length ? "ready" : "empty",count:features.length,message:features.length ? "Planning records loaded." : "No records returned. England coverage varies."};
    } catch (e) {
      if (project !== state.project || generation !== state.areaGeneration) return {status:"cancelled"};
      toast("Planning constraints: " + e.message);
      return {status:"error",message:e.message + " Existing records kept."};
    }
  }
  let archiveDbPromise;
  function archiveDB() {
    if (archiveDbPromise) return archiveDbPromise;
    archiveDbPromise = new Promise((resolve, reject) => {
      const r = indexedDB.open("SAMI_DATA_ARCHIVE", 1);
      r.onupgradeneeded = () => {
        const db = r.result;
        if (!db.objectStoreNames.contains("snapshots")) {
          const s = db.createObjectStore("snapshots", { keyPath: "id" });
          s.createIndex("sourceId", "sourceId");
          s.createIndex("project", "project");
        }
      };
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
    return archiveDbPromise;
  }
  async function archiveActiveSource(sourceId, label, project = state.project) {
    const fs = project.features.filter(
      (f) => f.properties.sourceId === sourceId,
    );
    if (!fs.length || !("indexedDB" in window)) return;
    try {
      const db = await archiveDB(),
        rec = {
          id: uid(),
          sourceId,
          project: project.name,
          projectId: project.id,
          label: label || sourceId,
          createdAt: new Date().toISOString(),
          area: serviceBounds(),
          features: copy(fs),
        };
      await new Promise((resolve, reject) => {
        const tx = db.transaction("snapshots", "readwrite");
        tx.objectStore("snapshots").put(rec);
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
      });
    } catch {}
  }
  async function replaceSourceFeatures(sourceId, features, label, project = state.project, generation = state.areaGeneration) {
    if (project !== state.project || generation !== state.areaGeneration) return false;
    const checked = features.filter(G.validateFeature);
    if (checked.length !== features.length) throw Error("Source contains invalid geometry; existing records have been kept.");
    let result = window.SAMIProjectData.mergeSource(project.features, checked, sourceId);
    if (result.retained) {
      toast("No replacement records returned. The last stored source snapshot has been kept.");
      return false;
    }
    await archiveActiveSource(sourceId, label, project);
    if (project !== state.project || generation !== state.areaGeneration) return false;
    result = window.SAMIProjectData.mergeSource(project.features, checked, sourceId);
    project.features = result.features;
    commit();
    return true;
  }
  async function listArchives() {
    if (!("indexedDB" in window)) return [];
    try {
      const db = await archiveDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction("snapshots", "readonly"),
          r = tx.objectStore("snapshots").getAll();
        r.onsuccess = () =>
          resolve(
            r.result
              .filter((x) => x.projectId ? x.projectId === state.project.id : x.project === state.project.name)
              .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
              .slice(0, 30),
          );
        r.onerror = () => reject(r.error);
      });
    } catch {
      return [];
    }
  }
  async function openArchiveManager() {
    const rows = await listArchives();
    showModal(
      "Archived data snapshots",
      rows.length
        ? '<p class="subtle">Refreshing a data source archives the previous active snapshot instead of deleting it. Restore only when you intentionally want to roll back.</p>' +
            rows
              .map(
                (x) =>
                  '<div class="item-row"><div><strong>' +
                  esc(x.label) +
                  "</strong><small>" +
                  esc(new Date(x.createdAt).toLocaleString()) +
                  " · " +
                  x.features.length +
                  ' records</small></div><button class="mini-btn" data-archive="' +
                  esc(x.id) +
                  '">Restore</button></div>',
              )
              .join("")
        : "<p>No archived snapshots on this device yet.</p>",
    );
    $("#modalBody").onclick = async (e) => {
      const id = e.target.closest("[data-archive]")?.dataset.archive;
      if (!id) return;
      const db = await archiveDB(),
        rec = await new Promise((resolve, reject) => {
          const tx = db.transaction("snapshots", "readonly"),
            r = tx.objectStore("snapshots").get(id);
          r.onsuccess = () => resolve(r.result);
          r.onerror = () => reject(r.error);
        });
      if (!rec) return;
      await archiveActiveSource(rec.sourceId, "Snapshot before restore");
      state.project.features = state.project.features
        .filter((f) => f.properties.sourceId !== rec.sourceId)
        .concat(copy(rec.features));
      commit();
      closeModal();
      toast("Archived snapshot restored.");
    };
  }
  function dataCatalogHTML() {
    return DATA_CATALOG.map(
      (x) =>
        '<div class="source-status"><div><strong>' +
        esc(x.name) +
        "</strong><small>" +
        esc(x.source) +
        " · " +
        esc(x.coverage) +
        "<br>" +
        esc(x.note) +
        '</small></div><span class="status-pill">' +
        esc(x.status) +
        "</span></div>",
    ).join("");
  }
  function startContribution() {
    if (!state.project.area) {
      openDrawer("area");
      return;
    }
    const k = $("#serviceType")?.value || state.project.serviceType,
      v = SERVICES[k],
      source = $("#serviceSource")?.value.trim(),
      label = $("#serviceLabel")?.value.trim() || v.name;
    if (!source) {
      toast(
        "Add a credible source / drawing reference before submitting an observation.",
      );
      return;
    }
    startTool("contribution", {
      serviceType: k,
      area: !!v.area,
      label,
      source,
      verification: "Pending SAMI approval",
      provenance: "User contribution",
    });
  }
  function finishContribution(ps, opt) {
    const polygon = !!opt.area;
    if (ps.length < (polygon ? 3 : 2)) return false;
    let geom = polygon
      ? { type: "Polygon", coordinates: [[...ps, ps[0].slice()]] }
      : { type: "LineString", coordinates: ps };
    geom = G.clipGeometry(geom, serviceBounds());
    if (!geom) throw Error("Contribution is outside the site service buffer.");
    state.project.contributions.push({
      id: uid(),
      createdAt: new Date().toISOString(),
      status: "pending",
      serviceType: opt.serviceType,
      label: opt.label,
      source: opt.source,
      geometry: geom,
    });
    cancelDraw();
    commit();
    toast(
      "Observation saved separately as pending. It has not been merged into the authoritative/project service layer.",
    );
    return true;
  }
  function exportContributions() {
    const fc = {
      type: "FeatureCollection",
      name: state.project.name + " pending SAMI contributions",
      features: state.project.contributions.map((c) => ({
        type: "Feature",
        id: c.id,
        properties: {
          status: c.status,
          serviceType: c.serviceType,
          label: c.label,
          source: c.source,
          createdAt: c.createdAt,
        },
        geometry: c.geometry,
      })),
    };
    download(
      safeName() + "_pending_contributions.geojson",
      JSON.stringify(fc, null, 2),
      "application/geo+json",
    );
  }
  function startTextBox() {
    showModal(
      "Add text box",
      field("newTextBox", "Text", "") +
        button("Choose its position", "placeTextBox", true),
    );
    $("#modalBody").onclick = (e) => {
      if (e.target.closest('[data-action="placeTextBox"]')) {
        const text = $("#newTextBox").value.trim();
        if (!text) return;
        closeModal();
        startTool("textBox", { text, label: text, includeLegend: false });
      }
    };
    $("#newTextBox").focus();
  }
  function startStoneRoad(freehand = false) {
    showModal(
      "Stone road",
      field(
        "stoneRoadWidth",
        "Road width (m)",
        "4",
        "number",
        'min="1" max="30" step="0.5"',
      ) +
        button(
          freehand ? "Draw freehand road" : "Draw point-line road",
          "placeStoneRoad",
          true,
        ),
    );
    $("#modalBody").onclick = (e) => {
      if (e.target.closest('[data-action="placeStoneRoad"]')) {
        const width = +$("#stoneRoadWidth").value;
        if (!(width >= 1 && width <= 30)) return;
        closeModal();
        startTool(freehand ? "stoneRoadFreehand" : "stoneRoad", {
          width,
          label: "Stone road",
          stoneKind: "road",
          styleColor: "#7b786e",
          styleFill: "#c8c4b6",
          styleFillOpacity: 0.78,
          includeLegend: true,
        });
      }
    };
  }
  function startStoneArea(freehand = false) {
    startTool(freehand ? "stoneAreaFreehand" : "stoneArea", {
      label: "Stone area",
      stoneKind: "area",
      styleColor: "#7b786e",
      styleFill: "#c8c4b6",
      styleFillOpacity: 0.78,
      includeLegend: true,
    });
  }
  function assetCategories() {
    const cats = {};
    for (const [k, v] of Object.entries(ASSETS))
      (cats[v.category] ??= []).push([k, v]);
    return cats;
  }
  function commonScales() {
    return [100, 200, 250, 500, 1000, 1250, 2500, 5000, 10000];
  }
  function suggestedScale() {
    const b = planBounds() || state.project.area;
    if (!b) return "";
    const w = G.distance([b[0], b[1]], [b[2], b[1]]),
      h = G.distance([b[0], b[1]], [b[0], b[3]]),
      raw = Math.max((w * 1000) / 404, (h * 1000) / 229);
    return commonScales().find((x) => x >= raw) || Math.ceil(raw / 5000) * 5000;
  }
  function applyPrintScale() {
    const b = planBounds() || state.project.area;
    if (!b) return;
    const scale = +suggestedScale();
    if (!(scale > 0)) return;
    const lat = (b[1] + b[3]) / 2,
      lng = (b[0] + b[2]) / 2,
      mpp = scale / 3779.527559,
      zoom = Math.log2(
        (156543.03392804097 * Math.cos((lat * Math.PI) / 180)) / mpp,
      );
    state.map.options.zoomSnap = 0.01;
    state.map.invalidateSize({ pan: false });
    state.map.setView([lat, lng], Math.max(3, Math.min(23, zoom)), {
      animate: false,
    });
  }
  function buildPrintTemplate(meta) {
    const s = suggestedScale(),
      b = planBounds() || state.project.area,
      legend = new Map(),
      assets = new Map();
    for (const f of state.project.features) {
      const m = f.properties;
      if (m.includeLegend === false) continue;
      const name = m.label || TYPES[m.type] || m.type;
      legend.set(name, (legend.get(name) || 0) + 1);
      if (["asset", "panel", "logo"].includes(m.type))
        assets.set(name, (assets.get(name) || 0) + 1);
    }
    $("#printProjectMeta").innerHTML =
      "<table>" +
      [
        ["Project", state.project.name],
        ["Site", meta.siteAddress || ""],
        ["Client", meta.clientName || ""],
        ["Site ref", meta.siteRef || ""],
        ["Drawing", meta.drawingNo || ""],
        ["Revision", meta.revision || ""],
        ["Creator", meta.creator || ""],
        ["Date", new Date().toLocaleDateString("en-GB")],
        ["Scale", "1:" + s + " @ A3"],
        ["CRS", "WGS84 · geographic site geometry"],
        [
          "Base snapshot",
          state.project.planBaseMeta?.capturedAt
            ? new Date(
                state.project.planBaseMeta.capturedAt,
              ).toLocaleDateString("en-GB")
            : "Not captured",
        ],
      ]
        .map(
          (r) =>
            "<tr><td>" +
            esc(r[0]) +
            "</td><td><strong>" +
            esc(r[1]) +
            "</strong></td></tr>",
        )
        .join("") +
      "</table>";
    $("#printLegend").innerHTML =
      "<h4>Legend / key</h4><ul>" +
      [...legend.entries()]
        .slice(0, 30)
        .map(([n, c]) => "<li>" + esc(n) + (c > 1 ? " × " + c : "") + "</li>")
        .join("") +
      "</ul>";
    $("#printAssets").innerHTML =
      "<h4>Assets / materials</h4><ul>" +
      ([...assets.entries()]
        .slice(0, 28)
        .map(([n, c]) => "<li>" + esc(n) + " × " + c + "</li>")
        .join("") || "<li>None listed</li>") +
      "</ul>";
    if (b) {
      const xs = [0, 0.25, 0.5, 0.75, 1].map((t) =>
          (b[0] + (b[2] - b[0]) * t).toFixed(5),
        ),
        ys = [1, 0.75, 0.5, 0.25, 0].map((t) =>
          (b[1] + (b[3] - b[1]) * t).toFixed(5),
        );
      $("#printCoordTop").innerHTML = xs
        .map((x) => "<span>" + x + "°</span>")
        .join("");
      $("#printCoordBottom").innerHTML = xs
        .map((x) => "<span>" + x + "°</span>")
        .join("");
      $("#printCoordLeft").innerHTML = ys
        .map((y) => "<span>" + y + "°</span>")
        .join("");
      $("#printCoordRight").innerHTML = ys
        .map((y) => "<span>" + y + "°</span>")
        .join("");
    }
  }

  function samiAiEndpoint() {
    return String(
      readPref("sami.ai.url") || window.SAMI_CONFIG?.aiEndpoint || "",
    ).trim();
  }
  function samiAiProfile() {
    const cfg = window.SAMI_CONFIG?.aiProfile || {};
    return {
      ...cfg,
      jurisdiction: cfg.jurisdiction || "United Kingdom",
      requireSourcesForGuidance: cfg.requireSourcesForGuidance !== false,
    };
  }
  function appContextForAI() {
    const counts = {};
    for (const f of state.project.features || []) {
      const type = f?.properties?.type || "other";
      counts[type] = (counts[type] || 0) + 1;
    }
    return {
      name: state.project.name,
      meta: {
        siteRef: state.project.meta?.siteRef || "",
        clientName: state.project.meta?.clientName || "",
        siteName: state.project.meta?.siteName || "",
        siteAddress: state.project.meta?.siteAddress || "",
        what3words: state.project.meta?.what3words || "",
      },
      area: state.project.area,
      mapCenter: state.map ? coord(state.map.getCenter()) : null,
      mode: state.mode,
      base: state.base,
      itemCount: state.project.features?.length || 0,
      itemCounts: counts,
      currentPanelProduct: state.project.route?.product || "lion",
      hgv: state.project.hgv
        ? {
            profile: state.project.hgv.profile,
            weight: state.project.hgv.weight,
            height: state.project.hgv.height,
            width: state.project.hgv.width,
            length: state.project.hgv.length,
          }
        : null,
    };
  }
  const trustedSources = [
    {
      keys: ["railway", "rail line", "network rail", "rail boundary", "rail"],
      org: "Network Rail",
      title: "Asset Protection & Optimisation — working on or near the railway",
      url: "https://www.networkrail.co.uk/our-work/looking-after-the-railway/asset-protection-and-optimisation/",
      desc: "Official Network Rail route for third-party work on or near railway infrastructure.",
    },
    {
      keys: [
        "underground",
        "buried service",
        "services",
        "excavat",
        "digging",
        "cable",
        "utility",
      ],
      org: "HSE",
      title: "HSG47 — Avoiding danger from underground services",
      url: "https://www.hse.gov.uk/pubns/books/hsg47.htm",
      desc: "HSE guidance for planning work, locating buried services and safe excavation.",
    },
    {
      keys: ["overhead line", "power line", "ohl", "electric line"],
      org: "HSE",
      title: "GS6 — Avoiding danger from overhead power lines",
      url: "https://www.hse.gov.uk/pubns/gs6.htm",
      desc: "Official HSE guidance for planning and controlling work near overhead power lines.",
    },
    {
      keys: [
        "cdm",
        "construction design management",
        "principal designer",
        "principal contractor",
      ],
      org: "HSE",
      title: "Construction (Design and Management) Regulations 2015",
      url: "https://www.hse.gov.uk/construction/cdm/2015/index.htm",
      desc: "Official HSE CDM 2015 guidance and dutyholder information.",
    },
    {
      keys: ["lifting", "loler", "crane", "lift plan"],
      org: "HSE",
      title: "LOLER — Lifting Operations and Lifting Equipment Regulations",
      url: "https://www.hse.gov.uk/work-equipment-machinery/loler.htm",
      desc: "Official HSE information on LOLER and lifting operations.",
    },
    {
      keys: [
        "vehicle",
        "traffic",
        "workplace transport",
        "reversing",
        "site access",
      ],
      org: "HSE",
      title: "Workplace transport safety",
      url: "https://www.hse.gov.uk/workplacetransport/index.htm",
      desc: "Official HSE workplace transport guidance.",
    },
    {
      keys: ["flood", "flood zone", "surface water"],
      org: "GOV.UK / Environment Agency",
      title: "Flood map for planning",
      url: "https://flood-map-for-planning.service.gov.uk/",
      desc: "Official flood risk information for planning in England.",
    },
  ];
  function updateVoiceButton() {
    $("#muteSami").textContent =
      readPref("sami.voice.output") === "off" ? "Voice off" : "Voice on";
    $("#muteSami").setAttribute(
      "aria-label",
      readPref("sami.voice.output") === "off"
        ? "Enable SAMI talk-back"
        : "Mute SAMI talk-back",
    );
  }
  function initVoice() {
    if (readPref("sami.voice.output") === null)
      setPref("sami.voice.output", "on");
    if ("speechSynthesis" in window) {
      const load = () => {
        state.voices = speechSynthesis.getVoices();
        populateVoiceSelect();
      };
      load();
      speechSynthesis.addEventListener("voiceschanged", load);
    }
  }
  function primeSpeech() {
    try {
      window.speechSynthesis?.resume();
    } catch {}
  }

  function populateVoiceSelect() {
    const sel = $("#samiVoiceSelect");
    if (!sel) return;
    const vs = window.speechSynthesis?.getVoices() || state.voices;
    sel.innerHTML =
      '<option value="">Best available British English voice</option>' +
      vs
        .filter((v) => /^en/i.test(v.lang))
        .map(
          (v) =>
            '<option value="' +
            esc(v.name) +
            '">' +
            esc(v.name) +
            " · " +
            esc(v.lang) +
            "</option>",
        )
        .join("");
    sel.value = readPref("sami.voice.name") || "";
  }
  function speakOptional(text, force = false) {
    /* Studio replaces this with the recorded/HTTPS SAMI Voice pipeline before init. Device TTS is intentionally disabled. */ if (
      force
    )
      toast("SAMI natural voice is loading.");
  }
  function updateAskLabel() {
    const active = state.listening || state.voiceStarting;
    const label = state.voiceStarting
      ? "Starting…"
      : state.listening
        ? "Listening…"
        : $("#askInput").value.trim()
          ? "Send request"
          : "Ask SAMI";
    const aiConfigured = !!samiAiEndpoint(),
      capability = $("#assistantCapability");
    if (capability)
      capability.textContent = aiConfigured
        ? "AI endpoint configured · availability not verified"
        : "Local commands · AI not connected";
    const ariaLabel = active
      ? "Stop listening"
      : $("#askInput").value.trim()
        ? "Send typed request"
        : "Ask SAMI by voice";

    $("#sendBtn").classList.toggle("listening", active);
    $("#sendBtn").setAttribute("aria-pressed", String(active));
    $("#sendBtn").setAttribute("aria-label", ariaLabel);
    if ($("#headerAskBtn")) {
      $("#headerAskBtn").classList.toggle("listening", active);
      $("#headerAskBtn").setAttribute("aria-pressed", String(active));
      $("#headerAskBtn").setAttribute("aria-label", ariaLabel);
    }

    $("#askButtonLabel").textContent = label;
    if ($("#headerAskLabel")) $("#headerAskLabel").textContent = label;

    $("#voiceHint").textContent = active
      ? "Speak naturally · tap the same button to stop"
      : aiConfigured
        ? "Ask naturally · voice and typed requests use the configured AI endpoint"
        : "Local commands work now · connect an HTTPS AI backend for open questions";
  }
  function handleAskButton() {
    primeSpeech();
    if (state.listening || state.voiceStarting) {
      stopVoiceCapture();
      return;
    }
    if ($("#askInput").value.trim()) sendAsk();
    else startVoiceCapture();
  }
  function stopVoiceCapture() {
    const r = state.recognition;
    if (state.voiceStarting) {
      state.recognition = null;
      try {
        r?.abort();
      } catch {}
      state.voiceStarting = false;
      state.listening = false;
      updateAskLabel();
      return;
    }
    try {
      r?.stop();
    } catch {}
    state.listening = false;
    updateAskLabel();
  }
  function startVoiceCapture() {
    window.speechSynthesis?.cancel();
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      showModal(
        "Ask SAMI voice",
        '<p>This browser does not provide speech capture. Type your request, or use the microphone on your device keyboard.</p><p class="subtle">Open the hosted app in Safari or another browser that supports speech recognition. Talk-back can work independently of capture.</p>',
      );
      return;
    }
    const r = new SR();
    state.recognition = r;
    state.voiceStarting = true;
    state.voiceResultHandled = false;
    state.voiceError = false;
    let transcript = "";
    r.lang = "en-GB";
    r.interimResults = true;
    r.continuous = false;
    r.maxAlternatives = 1;
    updateAskLabel();
    const current = () => state.recognition === r;
    r.onstart = () => {
      if (!current()) {
        r.abort();
        return;
      }
      state.voiceStarting = false;
      state.listening = true;
      updateAskLabel();
    };
    r.onresult = (e) => {
      if (!current()) return;
      transcript = Array.from(e.results)
        .map((x) => x[0].transcript)
        .join(" ")
        .trim();
      $("#askInput").value = transcript;
      if (
        e.results[e.results.length - 1]?.isFinal &&
        !state.voiceResultHandled
      ) {
        state.voiceResultHandled = true;
        try {
          r.stop();
        } catch {}
        sendAsk(transcript);
      }
    };
    r.onerror = (e) => {
      if (!current()) return;
      state.voiceError = true;
      const messages = {
        "not-allowed":
          "Allow microphone and speech recognition permission for this site.",
        "service-not-allowed": "Speech capture is not enabled by this browser.",
        "audio-capture": "No microphone input is available.",
        "no-speech": "No speech was heard. Tap Ask SAMI and try again.",
        network:
          "The speech service could not connect. Typed requests still work.",
      };
      if (e.error !== "aborted")
        toast(
          messages[e.error] ||
            "Speech capture stopped. You can type your request.",
        );
    };
    r.onend = () => {
      if (!current()) return;
      state.listening = false;
      state.voiceStarting = false;
      state.recognition = null;
      if (!state.voiceResultHandled && !state.voiceError && transcript) {
        state.voiceResultHandled = true;
        sendAsk(transcript);
      }
      updateAskLabel();
    };
    try {
      r.start();
    } catch {
      state.recognition = null;
      state.listening = false;
      state.voiceStarting = false;
      updateAskLabel();
      toast("Microphone could not start. Check permission or type a request.");
    }
  }
  function sendAsk(forced) {
    const q = String(forced || $("#askInput").value).trim();
    if (!q) return;
    $("#askInput").value = "";
    updateAskLabel();
    addMessage("user", q);
    $("#samiPanel").classList.add("open");
    void handleCommand(q).catch((error) => {
      console.error("SAMI request failed", error);
      samiSay(
        "I couldn't complete that request. " +
          String(error?.message || "Try a different command.").slice(0, 180),
      );
    });
  }
  function addMessage(who, text, source) {
    const d = document.createElement("div");
    d.className = "msg " + who;
    d.innerHTML = "<p>" + esc(text) + "</p>";
    if (source) {
      let url;
      try {
        url = new URL(source.url);
      } catch {}
      if (url && url.protocol === "https:")
        d.innerHTML +=
          '<a class="source-card" href="' +
          esc(url.href) +
          '" target="_blank" rel="noopener"><span>' +
          esc(source.org || "Source") +
          "</span><strong>" +
          esc(source.title || "Read source") +
          "</strong><small>" +
          esc(source.desc || "") +
          "</small></a>";
    }
    $("#samiMessages").appendChild(d);
    $("#samiMessages").scrollTop = $("#samiMessages").scrollHeight;
  }
  function samiSay(text) {
    addMessage("sami", text);
    speakOptional(text);
  }
  function generationCenter() {
    const mc = state.map ? coord(state.map.getCenter()) : null;
    if (state.project.area) {
      if (mc && G.inside(mc, state.project.area)) return mc;
      const b = state.project.area;
      return [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
    }
    return mc || [-2.1288, 52.5862];
  }
  function generatedPanelPadLabel(product, solution) {
    const mode =
      solution.mode === "atLeast"
        ? "minimum-size"
        : solution.mode === "inside"
          ? "fit-inside"
          : "closest-fit";
    return `${product.name} pad · ${solution.panelCount} panels · ${solution.actualWidth.toFixed(2)} × ${solution.actualHeight.toFixed(2)} m · ${mode}`;
  }
  function createPanelPadObject(request) {
    const I = window.SamiIntelligentObject;
    if (!I) throw Error("SAMI object generator is unavailable.");
    const productKey =
        request.product && PRODUCTS[request.product]
          ? request.product
          : state.project.route?.product &&
              PRODUCTS[state.project.route.product]
            ? state.project.route.product
            : "lion",
      product = { ...PRODUCTS[productKey], product: productKey },
      solution = I.solvePanelGrid(
        request.widthM,
        request.heightM,
        product,
        request.fitMode || "closest",
      ),
      center = generationCenter(),
      pr = G.projection(center),
      groupId = uid(),
      routeId = groupId,
      fullX = solution.longOnX ? product.length : product.width,
      fullY = solution.longOnX ? product.width : product.length,
      overlapX = solution.longOnX
        ? product.overlap || 0
        : product.lateralOverlap || 0,
      overlapY = solution.longOnX
        ? product.lateralOverlap || 0
        : product.overlap || 0,
      stepX = Math.max(0.001, fullX - overlapX),
      stepY = Math.max(0.001, fullY - overlapY),
      x0 = -solution.actualWidth / 2 + fullX / 2,
      y0 = -solution.actualHeight / 2 + fullY / 2,
      angle = solution.longOnX ? 90 : 0,
      label = generatedPanelPadLabel(product, solution),
      guide = feature(
        "area",
        G.rectangle(center, solution.actualHeight, solution.actualWidth, 0),
        {
          label,
          routeId,
          groupId,
          generated: true,
          guideHidden: true,
          includeLegend: false,
          generatedBy: "SAMI Intelligent Object Generator",
          requestedWidth: request.widthM,
          requestedHeight: request.heightM,
          fitMode: solution.mode,
          actualWidth: +solution.actualWidth.toFixed(4),
          actualHeight: +solution.actualHeight.toFixed(4),
          panelCount: solution.panelCount,
          product: productKey,
        },
      );
    state.project.features.push(guide);
    let first = null;
    for (let ix = 0; ix < solution.nx; ix++)
      for (let iy = 0; iy < solution.ny; iy++) {
        const c = pr.ll([x0 + ix * stepX, y0 + iy * stepY]),
          f = feature(
            "panel",
            G.rectangle(c, product.length, product.width, angle),
            {
              label: product.name,
              product: productKey,
              length: product.length,
              width: product.width,
              angle,
              routeId,
              groupId,
              derived: true,
              dimensionLocked: true,
              includeLegend: true,
              generatedBy: "SAMI Intelligent Object Generator",
              padLabel: label,
              padPanelIndex: iy * solution.nx + ix + 1,
            },
          );
        state.project.features.push(f);
        if (!first) first = f;
      }
    state.project.route = {
      ...state.project.route,
      ...product,
      product: productKey,
    };
    state.selected = first?.id || null;
    commit();
    if (state.mode !== "plan") setMode("plan");
    const deltaW = solution.actualWidth - request.widthM,
      deltaH = solution.actualHeight - request.heightM,
      fitText =
        solution.mode === "atLeast"
          ? "I kept the finished pad at or above the requested size."
          : solution.mode === "inside"
            ? "I kept the finished pad inside the requested size."
            : "I used the closest whole-panel layout without stretching any panels.",
      difference =
        Math.abs(deltaW) < 0.005 && Math.abs(deltaH) < 0.005
          ? "It matches the requested dimensions exactly."
          : `Finished size is ${solution.actualWidth.toFixed(2)} × ${solution.actualHeight.toFixed(2)} metres (${deltaW >= 0 ? "+" : ""}${deltaW.toFixed(2)} m × ${deltaH >= 0 ? "+" : ""}${deltaH.toFixed(2)} m from target).`;
    samiSay(
      `Created ${solution.panelCount} ${product.name} panels as one movable group. ${fitText} ${difference}`,
    );
    toast(label + " · grouped and ready to move.");
    return { productKey, product, solution, label };
  }
  function assetKindFromNaturalRequest(text) {
    const I = window.SamiIntelligentObject,
      k = I?.detectBuiltinAsset(text);
    if (k && ASSETS[k]) return k;
    const n = String(text || "").toLowerCase();
    let best = null;
    for (const [key, a] of Object.entries(ASSETS)) {
      const words = String(a.name || "")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, " ")
          .trim()
          .split(/\s+/)
          .filter(
            (w) =>
              w.length > 2 &&
              !["site", "point", "footprint", "area"].includes(w),
          ),
        score = words.filter((w) => n.includes(w)).length;
      if (score && (best === null || score > best.score)) best = { key, score };
    }
    return best && best.score >= 2 ? best.key : null;
  }
  function createCatalogAssetObject(kind, override = {}) {
    const base = ASSETS[kind];
    if (!base) throw Error("That asset is not in the verified SAMI catalogue.");
    const length = Number(override.length || base.length),
      width = Number(override.width || base.width);
    if (!(length > 0.1 && length <= 100 && width > 0.05 && width <= 30))
      throw Error("SAMI refused an unrealistic generated asset footprint.");
    const center = generationCenter(),
      a = {
        kind,
        name: override.name || base.name,
        length,
        width,
        angle: Number(override.angle) || 0,
        symbol: base.symbol || "•",
        category: base.category || "Other",
        includeLegend: true,
        dimensionLocked:
          override.dimensionLocked !== false &&
          (base.dimensionLocked === true ||
            override.generated === true ||
            base.verifiedDimensions === true),
        verifiedDimensions:
          base.verifiedDimensions === true ||
          override.verifiedDimensions === true,
        source:
          override.source || base.source || "SAMI verified asset catalogue",
        sourceUrl: override.sourceUrl || base.sourceUrl || "",
        sourceRetrievedAt:
          override.sourceRetrievedAt || base.sourceRetrievedAt || "",
        sourceNote: override.sourceNote || base.sourceNote || "",
        generatedBy: "SAMI Intelligent Object Generator",
      },
      f = feature("asset", G.rectangle(center, length, width, a.angle), {
        ...a,
        label: a.name,
        centerLng: center[0],
        centerLat: center[1],
      });
    state.project.features.push(f);
    state.project.asset = copy(a);
    state.selected = f.id;
    commit();
    if (state.mode !== "plan") setMode("plan");
    const sourceText = a.source ? ` Source: ${a.source}.` : "";
    samiSay(
      `Created ${a.name} at ${length.toFixed(2)} × ${width.toFixed(2)} metres and placed it on the drawing ready to move or rotate.${a.dimensionLocked ? " Its verified dimensions are locked." : ""}${sourceText}`,
    );
    toast(a.name + " placed to scale.");
    return f;
  }
  function createExternallySpecifiedAssetObject(spec) {
    const url = String(spec?.sourceUrl || "");
    let safeUrl = "";
    try {
      const u = new URL(url);
      if (u.protocol === "https:") safeUrl = u.href;
    } catch {}
    const length = +spec?.length,
      width = +spec?.width;
    if (!(
      length > 0.1 &&
      length <= 100 &&
      width > 0.05 &&
      width <= 30 &&
      safeUrl &&
      spec?.source
    ))
      throw Error(
        "A researched asset needs realistic dimensions and an HTTPS source before SAMI will create it.",
      );
    const center = generationCenter(),
      kind = "generatedCustom",
      a = {
        kind,
        name: String(spec.name || "Researched site asset").slice(0, 120),
        length,
        width,
        angle: Number(spec.angle) || 0,
        symbol: String(spec.symbol || "OBJ").slice(0, 8),
        category: String(spec.category || "Other").slice(0, 40),
        includeLegend: true,
        dimensionLocked: true,
        verifiedDimensions: true,
        source: String(spec.source).slice(0, 200),
        sourceUrl: safeUrl,
        sourceNote: String(
          spec.sourceNote ||
            "Dimensions supplied by connected research service. Verify against the actual item before issue.",
        ).slice(0, 500),
        generatedBy: "SAMI Intelligent Object Generator",
      },
      f = feature("asset", G.rectangle(center, length, width, a.angle), {
        ...a,
        label: a.name,
        centerLng: center[0],
        centerLat: center[1],
      });
    state.project.features.push(f);
    state.project.asset = copy(a);
    state.selected = f.id;
    commit();
    if (state.mode !== "plan") setMode("plan");
    samiSay(
      `Created ${a.name} at ${length.toFixed(2)} × ${width.toFixed(2)} metres from the cited specification and locked the dimensions. It is selected and ready to move.`,
    );
    toast(a.name + " created from sourced dimensions.");
    return f;
  }
  function tryHandleIntelligentObject(q) {
    const I = window.SamiIntelligentObject;
    if (!I) return false;
    const req = I.parsePanelPadRequest(q);
    if (req) {
      createPanelPadObject(req);
      return true;
    }
    const kind = assetKindFromNaturalRequest(q);
    if (
      kind &&
      /\b(create|add|place|put|need|give me|i need|draw)\b/i.test(q)
    ) {
      createCatalogAssetObject(kind, { generated: true });
      return true;
    }
    return false;
  }
  function localProjectSummary() {
    const project = state.project;
    if (!project) return "No project is open.";
    const features = (project.features || []).filter(
        (f) => !f.properties?.guideHidden,
      ),
      counts = {};
    for (const f of features) {
      const type = f.properties?.type || "other";
      counts[type] = (counts[type] || 0) + 1;
    }
    const lines = [
      `${project.name || "Untitled site"}.`,
      `Site area: ${project.area ? areaText() : "not defined"}.`,
      `${features.length} project items total.`,
    ];
    if (counts.panel) lines.push(`${counts.panel} Trakway panels.`);
    if (counts.asset) lines.push(`${counts.asset} site assets.`);
    if (counts.service) lines.push(`${counts.service} service or constraint records.`);
    if (project.routes?.length)
      lines.push(`${project.routes.length} saved route${project.routes.length === 1 ? "" : "s"}.`);
    return lines.join(" ");
  }
  function localAssistantHelp() {
    const aiNote = samiAiEndpoint()
      ? "An AI endpoint is configured, but SAMI cannot confirm it is reachable until it successfully answers a request."
      : "Open-ended questions need a connected HTTPS AI backend; no OpenAI key belongs in this app.";
    samiSay(
      "I can run local workspace commands and report this project's contents. Try: open the site plan; open the route; show services; switch to satellite; define the site area; measure a line; add a note; create a 15 by 15 metre Lion pad; summarize this project; undo. " +
        aiNote,
    );
  }
  async function handleCommand(q) {
    const n = q.toLowerCase().trim();
    if (/^(help|commands|what can you do|what can sami do)[.!?]?$/.test(n)) {
      localAssistantHelp();
      return;
    }
    if (
      /\b(summarize|summary|project status|what(?:'s| is) in (?:the )?(?:project|site)|how many (?:items|objects|assets))\b/.test(n)
    ) {
      samiSay(localProjectSummary());
      return;
    }
    if (/\b(open|show|switch to|use)\s+(?:the\s+)?cad\b/.test(n)) {
      if (!state.project.area) {
        openDrawer("area");
        samiSay("Define a site area first. CAD will then show only that site area and its configured bleed.");
        return;
      }
      setMode("plan");
      switchBase("drawing");
      samiSay("CAD site drawing opened for the selected site area only.");
      return;
    }
    if (/^(undo|undo that|undo last (?:step|change)|go back one)[.!?]?$/.test(n)) {
      undo();
      samiSay("Undo requested.");
      return;
    }
    if (/^redo/.test(n)) {
      redo();
      samiSay("Redo requested.");
      return;
    }
    if (/unlock.*(map|plan|view)/.test(n)) {
      setLock(false);
      samiSay("View unlocked.");
      return;
    }
    if (/lock.*(map|plan|view)/.test(n)) {
      setLock(true);
      samiSay("View locked. Drawing tools remain available.");
      return;
    }
    if (/satellite/.test(n)) {
      switchBase("satellite");
      samiSay(
        "Satellite background opened. Your site drawing remains editable.",
      );
      return;
    }
    if (/site drawing|site plan|plan drawing|drawing view|open (the )?plan|switch to (the )?plan/.test(n)) {
      setMode("plan");
      samiSay(
        "Site Drawing is open. Draw over Map, Satellite or switch separately to the CAD background.",
      );
      return;
    }
    if (/define|set|create/.test(n) && /(?:plan|site) area/.test(n)) {
      openDrawer("area");
      samiSay(
        "Draw the site area freehand, choose two opposite corners, or use the visible map area.",
      );
      return;
    }
    if (tryHandleIntelligentObject(q)) return;
    if (/map view|street view|open (the )?map|show (the )?map/.test(n)) {
      setMode("map");
      switchBase("street");
      samiSay("Map background opened.");
      return;
    }
    if (/open|show|add|build/.test(n) && /panel|trakway/.test(n)) {
      openDrawer("panels");
      samiSay(
        "Trakway is an on-site plan asset. Choose the product and run width, then draw the Trakway run on the site plan.",
      );
      return;
    }
    if (/route to site|hgv route|lorry route|truck route|open (the )?route/.test(n)) {
      setMode("route");
      samiSay(
        "Route to site is open. Choose the vehicle profile and enter or pick the two route endpoints.",
      );
      return;
    }
    if (/open|show|add/.test(n) && /assets?|welfare|cabin/.test(n)) {
      openDrawer("assets");
      samiSay("Choose a site asset, adjust its dimensions and place it.");
      return;
    }
    if (
      /open|show|load/.test(n) &&
      /services?|constraints?|utilities/.test(n)
    ) {
      openDrawer("services");
      samiSay(
        "Choose the types to display. Public service data is limited to the site plus about 500 feet, may be incomplete, and must be checked against authoritative records before safety-critical use.",
      );
      return;
    }
    if (/library/.test(n)) {
      setMode("library");
      samiSay("The materials and item library is open.");
      return;
    }
    if (/zoom in|zoom out/.test(n)) {
      n.includes("in") ? state.map.zoomIn() : state.map.zoomOut();
      samiSay("Zoom changed.");
      return;
    }
    if (/my location|current location|where am i/.test(n)) {
      locate();
      samiSay("Requesting your current location.");
      return;
    }
    if (/fit.*(site|plan|project)/.test(n)) {
      fitProject();
      samiSay("Fit plan requested.");
      return;
    }
    if (/draw|start|create/.test(n) && /stone road/.test(n)) {
      startStoneRoad();
      samiSay("Set the stone-road width, then draw its centre line.");
      return;
    }
    if (/draw|start|create/.test(n) && /excavat/.test(n)) {
      startTool("excavation", { label: "Excavation", includeLegend: true });
      samiSay("Tap the excavation footprint, then press Finish.");
      return;
    }
    if (/add|create/.test(n) && /text box|textbox/.test(n)) {
      startTextBox();
      samiSay("Enter the drawing annotation, then choose its position.");
      return;
    }
    if (
      /draw|start|create/.test(n) &&
      /access|egress|measure|area|on[- ]?site route/.test(n)
    ) {
      const t = n.includes("access")
        ? "access"
        : n.includes("egress")
          ? "egress"
          : n.includes("measure")
            ? "measure"
            : n.includes("area")
              ? "area"
              : "route";
      startTool(t, { snap: t === "measure", includeLegend: t !== "measure" });
      samiSay("Tap your points, then press Finish.");
      return;
    }
    if (/add|create|place/.test(n) && /note/.test(n)) {
      const text = q.replace(/^.*?note\s*/i, "").trim();
      if (text) startTool("note", { text, label: text });
      else startNote();
      samiSay("Tap where you want the note placed.");
      return;
    }
    if (/export/.test(n)) {
      if (/dxf|cad/.test(n)) exportDXF();
      else if (/geojson/.test(n)) exportGeoJSON();
      else if (/kml/.test(n)) exportKML();
      else if (/csv|schedule/.test(n)) exportCSV();
      else openExport();
      samiSay("Your export is ready to choose or download.");
      return;
    }
    const ai = samiAiEndpoint();
    if (ai) {
      await askConnectedAI(q);
      return;
    }
    const source = trustedSources
      .map((s) => ({ s, score: s.keys.filter((k) => n.includes(k)).length }))
      .sort((a, b) => b.score - a.score)[0];
    if (source?.score) {
      addMessage(
        "sami",
        "SAMI AI is not connected yet. I can still take you to the most relevant official UK source for this topic.",
        source.s,
      );
      speakOptional("I have linked the official source on screen.");
      return;
    }
    samiSay(
      "I can control SAMI locally, but broad questions need the SAMI AI service to be connected. App commands still work now; construction and regulatory answers will become source-grounded once the AI endpoint is enabled.",
    );
  }
  async function askConnectedAI(query) {
    try {
      const endpoint = samiAiEndpoint();
      if (!endpoint) throw Error("SAMI AI is not connected.");
      const r = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query,
          assistant: samiAiProfile(),
          project: appContextForAI(),
          catalog: {
            panels: Object.fromEntries(
              Object.entries(PRODUCTS).map(([k, v]) => [
                k,
                {
                  name: v.name,
                  length: v.length,
                  width: v.width,
                  overlap: v.overlap,
                  lateralOverlap: v.lateralOverlap,
                },
              ]),
            ),
            assetKinds: Object.keys(ASSETS),
            serviceTypes: Object.keys(SERVICES),
          },
          policy: {
            jurisdiction: "UK",
            officialSourcesFirst: true,
            sourceDomains: [
              "hse.gov.uk",
              "legislation.gov.uk",
              "gov.uk",
              "planning.data.gov.uk",
              "networkrail.co.uk",
            ],
            distinguishLawGuidanceAndProjectRules: true,
            neverInventPhysicalDimensions: true,
            neverInventServiceLocations: true,
            requireSourceForRegulatoryClaims: true,
            siteSpecificSafety:
              "Identify when competent-person/site-specific verification is required.",
          },
          capabilities: {
            allowMapActions: true,
            allowObjectGeneration: true,
            allowProjectRead: true,
            allowProjectMutationThroughStructuredActionsOnly: true,
          },
        }),
        signal: AbortSignal.timeout(30000),
      });
      const data = await boundedJSON(r, 300000);
      if (!r.ok) throw Error(data?.error || "SAMI AI returned " + r.status);
      if (typeof data.answer !== "string")
        throw Error("SAMI AI returned no answer.");
      samiSay(data.answer.slice(0, 16000));
      for (const source of (
        Array.isArray(data.sources) ? data.sources : []
      ).slice(
        0,
        10,
      ))
        addMessage("sami", "Source", source);
      const actions = Array.isArray(data.actions)
        ? data.actions
        : data.action
          ? [data.action]
          : [];
      for (const action of actions.slice(0, 4)) {
        if (
          action?.type === "activateTool" &&
          ["access", "egress", "route", "area", "measure", "hazard"].includes(
            action.tool,
          )
        )
          startTool(action.tool);
        else if (
          action?.type === "setView" &&
          G.validCoord([action.lng, action.lat])
        ) {
          if (state.mode === "plan") setMode("map");
          state.map.setView(
            [action.lat, action.lng],
            Math.max(3, Math.min(23, Number(action.zoom) || 18)),
          );
        } else if (action?.type === "createPanelPad") {
          const product = PRODUCTS[action.product]
            ? action.product
            : state.project.route?.product || "lion";
          createPanelPadObject({
            type: "panelPad",
            product,
            widthM: +action.widthM,
            heightM: +action.heightM,
            fitMode: ["closest", "atLeast", "inside"].includes(action.fitMode)
              ? action.fitMode
              : "closest",
          });
        } else if (
          action?.type === "createCatalogAsset" &&
          ASSETS[action.kind]
        )
          createCatalogAssetObject(action.kind, { generated: true });
        else if (action?.type === "createResearchedAsset")
          createExternallySpecifiedAssetObject(action);
      }
    } catch (error) {
      console.warn(error);
      samiSay(
        error?.message && error.message !== "Failed to fetch"
          ? error.message
          : "The SAMI AI service did not respond. Local drawing and map commands still work.",
      );
    }
  }
  let deferredInstallPrompt = null;
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    updateLaunchGate();
  });
  window.addEventListener("appinstalled", () => {
    deferredInstallPrompt = null;
    updateLaunchGate(true);
  });
  function isStandaloneApp() {
    return (
      window.navigator.standalone === true ||
      window.matchMedia?.("(display-mode: standalone)")?.matches ||
      window.matchMedia?.("(display-mode: window-controls-overlay)")?.matches ||
      window.matchMedia?.("(display-mode: minimal-ui)")?.matches ||
      window.navigator.windowControlsOverlay?.visible === true
    );
  }
  function setupLaunchGate() {
    updateLaunchGate();
  }
  function closeInstallFallback() {
    const el = $("#installFallback");
    if (el) el.classList.remove("open");
  }
  function showInstallFallback() {
    const box = $("#installFallback"),
      text = $("#installFallbackText");
    if (!box || !text) return;
    const ios =
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    text.innerHTML = ios
      ? "Safari does not expose a one-tap install prompt. Tap <b>Share</b> then <b>Add to Home Screen</b>. This is an iOS browser limitation."
      : "Open your browser menu and choose <b>Install app</b> or <b>Add to Home Screen</b>.";
    box.classList.add("open");
    clearTimeout(showInstallFallback.t);
    showInstallFallback.t = setTimeout(closeInstallFallback, 7000);
  }
  function leaveLaunch() {
    const splash = $("#splash");
    if (!splash) return;
    splash.classList.add("launching");
    setTimeout(() => splash.remove(), 470);
  }
  function updateLaunchGate(justInstalled = false) {
    const splash = $("#splash");
    if (!splash) return;
    const start = $("#launchStartBtn"),
      install = $("#installPwaBtn"),
      guide = $("#installGuide"),
      status = $("#splashStatus"),
      fallbackClose = $("#installFallbackClose");
    const standalone = isStandaloneApp();
    start.hidden = !standalone;
    install.hidden = standalone;
    guide.hidden = true;
    document.documentElement.classList.toggle("browser-gated", !standalone);
    if (fallbackClose) fallbackClose.onclick = closeInstallFallback;
    if (standalone) {
      status.textContent = justInstalled
        ? "SAMI is installed and ready."
        : "Your site intelligence workspace is ready.";
      start.textContent = "Open SAMI";
      start.onclick = leaveLaunch;
    } else {
      status.textContent = deferredInstallPrompt
        ? "Install SAMI for the full-screen site-planning experience."
        : "Add SAMI to your Home Screen for the full-screen site-planning experience.";
      install.textContent = "Add SAMI to Home Screen";
      install.onclick = async () => {
        if (deferredInstallPrompt) {
          const p = deferredInstallPrompt;
          deferredInstallPrompt = null;
          try {
            p.prompt();
            await p.userChoice;
          } catch {}
          updateLaunchGate();
        } else showInstallFallback();
      };
    }
  }
  function isFreehandTool(t) {
    return [
      "panelFreehand",
      "panelAreaFreehand",
      "planAreaFreehand",
      "serviceFreehand",
      "accessFreehand",
      "egressFreehand",
      "routeFreehand",
      "areaFreehand",
      "hazardFreehand",
      "excavationFreehand",
      "arrowFreehand",
      "stoneRoadFreehand",
      "stoneAreaFreehand",
    ].includes(t);
  }
  function screenToCoord(e) {
    const pt = state.map.mouseEventToContainerPoint
      ? state.map.mouseEventToContainerPoint(e)
      : L.point(
          e.clientX - $("#map").getBoundingClientRect().left,
          e.clientY - $("#map").getBoundingClientRect().top,
        );
    return coord(state.map.containerPointToLatLng(pt));
  }
  function freehandPointAllowed(c) {
    if (
      state.tool === "serviceFreehand" &&
      state.project.area &&
      !G.inside(c, serviceBounds())
    )
      return false;
    if (
      state.mode === "plan" &&
      state.project.area &&
      !["planAreaFreehand", "serviceFreehand"].includes(state.tool) &&
      !insidePlanFrame(c)
    )
      return false;
    return true;
  }
  function initFreehandInput() {
    const el = $("#map");
    let pointer = null,
      lastPx = null;
    el.addEventListener(
      "pointerdown",
      (e) => {
        if (!isFreehandTool(state.tool) || pointer !== null || e.button > 0)
          return;
        const c = screenToCoord(e);
        if (!freehandPointAllowed(c)) {
          toast("Start inside the active drawing area.");
          return;
        }
        pointer = e.pointerId;
        state.freehandActive = true;
        state.points = [c];
        lastPx = { x: e.clientX, y: e.clientY };
        state.map.dragging.disable();
        el.setPointerCapture?.(e.pointerId);
        e.preventDefault();
        e.stopPropagation();
        renderDraft();
      },
      { capture: true },
    );
    el.addEventListener(
      "pointermove",
      (e) => {
        if (pointer !== e.pointerId || !state.freehandActive) return;
        const d = Math.hypot(e.clientX - lastPx.x, e.clientY - lastPx.y);
        if (d < 5) return;
        let c = screenToCoord(e);
        if (!freehandPointAllowed(c)) return;
        const prev = state.points.at(-1);
        state.snapPoint = null;
        if (prev && state.points.length > 1) {
          const snapped = snapToCorner(c, state.points[state.points.length - 2]);
          if (snapped !== c) {
            state.snapPoint = snapped;
            c = snapped;
          }
        }
        if (!prev || G.distance(prev, c) > 0.18) {
          state.points.push(c);
          lastPx = { x: e.clientX, y: e.clientY };
          state.snapPoint = null;
          renderDraft();
        }
        e.preventDefault();
        e.stopPropagation();
      },
      { capture: true },
    );
    const finish = (e) => {
      if (pointer !== e.pointerId) return;
      el.releasePointerCapture?.(e.pointerId);
      pointer = null;
      state.freehandActive = false;
      const t = state.tool;
      updateLock();
      const lines = [
        "panelFreehand",
        "accessFreehand",
        "egressFreehand",
        "routeFreehand",
        "arrowFreehand",
        "stoneRoadFreehand",
      ];
      const min =
        (t === "serviceFreehand" && !state.options.area) || lines.includes(t)
          ? 2
          : 3;
      if (t && state.points.length >= min) finishDraw();
      else if (t) {
        toast("Draw a little further to create the item.");
        renderDraft();
      }
      e.preventDefault();
      e.stopPropagation();
    };
    el.addEventListener("pointerup", finish, { capture: true });
    el.addEventListener(
      "pointercancel",
      (e) => {
        if (pointer === e.pointerId) {
          pointer = null;
          state.freehandActive = false;
          updateLock();
        }
      },
      { capture: true },
    );
  }
  function addPanelRun(ps, opt) {
    const clean = simplifyLine(ps, 0.35),
      result = G.panels(clean, opt),
      id = uid(),
      guide = feature(
        "route",
        { type: "LineString", coordinates: clean },
        {
          label: opt.name + " Trakway run",
          routeId: id,
          groupId: id,
          distance: result.distance,
          product: opt.product,
          generated: true,
          guideHidden: true,
          includeLegend: false,
        },
      );
    state.project.features.push(guide);
    state.project.features.push(
      feature(
        "measure",
        { type: "LineString", coordinates: clean },
        {
          label: opt.name + " run length",
          distance: result.distance,
          routeId: id,
          groupId: id,
          generated: true,
          autoAnnotation: true,
          includeLegend: false,
        },
      ),
    );
    const added = [];
    for (const p of result.panels) {
      const f = feature("panel", p.geometry, {
        label: opt.name,
        product: opt.product,
        length: opt.length,
        width: opt.width,
        routeId: id,
        groupId: id,
        corner: p.corner,
        junctionRow: p.junctionRow || 0,
        cornerRule: p.cornerRule || "",
        sabreUnverified: p.sabreUnverified || false,
        jointOffsetMm: p.jointOffsetMm || 0,
        dimensionLocked: true,
        styleFill: opt.styleFill,
        styleColor: opt.styleColor,
        derived: true,
        includeLegend: true,
      });
      state.project.features.push(f);
      added.push(f);
    }
    cancelDraw();
    state.selected = null;
    commit();
    toast(
      `${result.panels.length} panels added as one grouped Trakway run · Select mode.`,
    );
    if (opt.product === "sabre" && result.warnings.length)
      showModal(
        "Review Sabre-X joints",
        "<p>" + result.warnings.map(esc).join("</p><p>") + "</p>",
      );
  }
  function simplifyLine(ps, minM = 0.35) {
    if (
      state.tool &&
      isFreehandTool(state.tool) &&
      state.options.smoothing === false
    )
      return copy(ps);
    const out = [];
    for (const p of ps) {
      if (!out.length || G.distance(out.at(-1), p) >= minM) out.push(p);
    }
    if (out.length === 1 && ps.length > 1) out.push(ps.at(-1));
    return out;
  }
  function pointInRingXY(p, ring) {
    let inside = false;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const a = ring[i],
        b = ring[j],
        hit =
          a[1] > p[1] !== b[1] > p[1] &&
          p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1] + 1e-12) + a[0];
      if (hit) inside = !inside;
    }
    return inside;
  }
  function addPanelFill(ps, opt) {
    const clean = simplifyLine(ps, 0.25);
    if (clean.length < 3) throw Error("Sketch a larger panel area.");
    const origin = clean[0],
      pr = G.projection(origin),
      ring = clean.map(pr.xy),
      stepL = Math.max(0.1, +opt.length - (+opt.overlap || 0)),
      stepW = Math.max(0.1, +opt.width - (+opt.lateralOverlap || 0));
    let ang = 0;
    if (ring.length > 1) {
      const dx = ring[1][0] - ring[0][0],
        dy = ring[1][1] - ring[0][1];
      ang = (Math.atan2(dx, dy) * 180) / Math.PI;
    }
    if (typeof opt.padBearing === "number" && Number.isFinite(opt.padBearing)) ang = opt.padBearing;
    const a = (ang * Math.PI) / 180,
      u = [Math.sin(a), Math.cos(a)],
      v = [Math.cos(a), -Math.sin(a)],
      corners = ring.map(([x, y]) => [
        x * u[0] + y * u[1],
        x * v[0] + y * v[1],
      ]),
      cx = corners.map((p) => p[0]),
      cy = corners.map((p) => p[1]),
      minX = Math.min(...cx) - stepL,
      maxX = Math.max(...cx) + stepL,
      minY = Math.min(...cy) - stepW,
      maxY = Math.max(...cy) + stepW,
      panels = [];
    for (let x = minX; x <= maxX; x += stepL) {
      for (let y = minY; y <= maxY; y += stepW) {
        const world = [u[0] * x + v[0] * y, u[1] * x + v[1] * y];
        if (!pointInRingXY(world, ring)) continue;
        const c = pr.ll(world);
        panels.push(G.rectangle(c, +opt.length, +opt.width, ang));
        if (panels.length > 5000)
          throw Error(
            "This area would exceed 5,000 panels. Draw a smaller area.",
          );
      }
    }
    const id = uid(),
      areaGeom = {
        type: "Polygon",
        coordinates: [[...clean, clean[0].slice()]],
      };
    state.project.features.push(
      feature("area", areaGeom, {
        label: opt.name + " panelised area",
        routeId: id,
        groupId: id,
        generated: true,
        guideHidden: true,
        includeLegend: false,
      }),
    );
    const perimeter = [...clean, clean[0].slice()];
    state.project.features.push(
      feature(
        "measure",
        { type: "LineString", coordinates: perimeter },
        {
          label: opt.name + " pad perimeter",
          distance: G.length(perimeter),
          routeId: id,
          groupId: id,
          generated: true,
          autoAnnotation: true,
          includeLegend: false,
        },
      ),
    );
    const added = [];
    for (const g of panels) {
      const f = feature("panel", g, {
        label: opt.name,
        product: opt.product,
        length: opt.length,
        width: opt.width,
        angle: ang,
        routeId: id,
        groupId: id,
        dimensionLocked: true,
        styleFill: opt.styleFill,
        styleColor: opt.styleColor,
        derived: true,
        includeLegend: true,
      });
      state.project.features.push(f);
      added.push(f);
    }
    cancelDraw();
    state.selected = null;
    commit();
    toast(`${panels.length} panels filled as one group · Select mode.`);
  }
  function assetIconSVG(kind, v = {}) {
    const cat = v.category || ASSETS[kind]?.category || "Other";
    const svg = (x) =>
      '<svg viewBox="0 0 64 64" aria-hidden="true">' + x + "</svg>";
    if (kind === "fire")
      return svg(
        '<rect x="5" y="5" width="54" height="54" rx="6" fill="#d92f2f"/><path d="M34 12c5 11-5 13 2 22 4-5 7-9 6-14 11 10 13 24 4 32-8 8-23 7-30-2-8-12 1-25 10-31-1 8 3 11 8 14-2-8 2-13 0-21z" fill="white"/>',
      );
    if (kind === "firstaid")
      return svg(
        '<rect x="5" y="5" width="54" height="54" rx="6" fill="#168451"/><path d="M26 14h12v12h12v12H38v12H26V38H14V26h12z" fill="white"/>',
      );
    if (kind === "muster")
      return svg(
        '<rect x="5" y="5" width="54" height="54" rx="6" fill="#168451"/><path d="M15 14l10 7M15 14l5 11M49 14l-10 7M49 14l-5 11M15 50l10-7M15 50l5-11M49 50l-10-7M49 50l-5-11" stroke="white" stroke-width="3"/><circle cx="27" cy="31" r="5" fill="white"/><circle cx="39" cy="31" r="4" fill="white"/><path d="M19 47c1-8 6-12 12-12s11 4 12 12" fill="none" stroke="white" stroke-width="4"/>',
      );
    if (kind === "toilet")
      return svg(
        '<path d="M16 6h32a6 6 0 016 6v46H10V12a6 6 0 016-6z" fill="#347fcf"/><circle cx="32" cy="21" r="6" fill="white"/><path d="M22 50l5-20h10l5 20M25 38h14" fill="none" stroke="white" stroke-width="5"/>',
      );
    if (/^cabin/.test(kind) || kind === "storage")
      return svg(
        '<rect x="5" y="14" width="54" height="36" rx="3" fill="#e7eceb" stroke="#33464b" stroke-width="3"/><rect x="12" y="22" width="14" height="12" fill="#7fb6cc"/><rect x="37" y="20" width="14" height="30" fill="#bcc8c9"/><path d="M5 41h54M10 14V9M54 14V9" stroke="#66777b" stroke-width="2"/>',
      );
    if (kind === "concreteMixer8")
      return svg(
        '<path d="M5 31h22v17H5z" fill="#dfe7e9" stroke="#283a42" stroke-width="3"/><path d="M27 27h10l8 7v14H27z" fill="#e8eef0" stroke="#283a42" stroke-width="3"/><path d="M30 29h6l6 6h-12z" fill="#82b9cf"/><ellipse cx="18" cy="24" rx="12" ry="9" transform="rotate(-18 18 24)" fill="#d7dcdd" stroke="#536064" stroke-width="3"/><path d="M7 19l21 10M8 28l17-13" stroke="#8a9799" stroke-width="2"/><path d="M5 34h-2v11h4" fill="none" stroke="#566467" stroke-width="3"/><circle cx="13" cy="50" r="5"/><circle cx="34" cy="50" r="5"/><path d="M5 31L1 26" stroke="#566467" stroke-width="3"/>',
      );
    if (kind === "rigid")
      return svg(
        '<path d="M7 23h34v26H7zM41 29h10l7 9v11H41z" fill="#e3eaed" stroke="#283a42" stroke-width="3"/><path d="M44 32h6l5 6H44z" fill="#82b9cf"/><circle cx="18" cy="50" r="6"/><circle cx="48" cy="50" r="6"/>',
      );
    if (kind === "artic")
      return svg(
        '<rect x="4" y="18" width="36" height="28" rx="2" fill="#edf1f2" stroke="#283a42" stroke-width="3"/><path d="M40 26h10l9 10v10H40z" fill="#dce7ea" stroke="#283a42" stroke-width="3"/><path d="M44 29h5l6 7H44z" fill="#82b9cf"/><circle cx="14" cy="49" r="5"/><circle cx="34" cy="49" r="5"/><circle cx="51" cy="49" r="5"/>',
      );
    if (kind === "van" || kind === "pickup")
      return svg(
        kind === "van"
          ? '<path d="M8 24h34l11 9v16H8z" fill="#e6edef" stroke="#283a42" stroke-width="3"/><path d="M38 27h6l7 7H38z" fill="#82b9cf"/><circle cx="19" cy="50" r="5"/><circle cx="45" cy="50" r="5"/>'
          : '<path d="M7 30h23l5-10h13l8 12v16H7z" fill="#e6edef" stroke="#283a42" stroke-width="3"/><path d="M37 23h8l7 9H35z" fill="#82b9cf"/><circle cx="18" cy="49" r="5"/><circle cx="46" cy="49" r="5"/>',
      );
    if (kind === "forklift")
      return svg(
        '<circle cx="18" cy="49" r="6"/><circle cx="38" cy="49" r="6"/><path d="M12 42h29V24H25l-6 18" fill="#e3bd35" stroke="#5b4c18" stroke-width="3"/><path d="M43 15v35M43 44h15M43 48h15" stroke="#3d4748" stroke-width="4"/>',
      );
    if (kind === "telehandler")
      return svg(
        '<circle cx="16" cy="49" r="6"/><circle cx="43" cy="49" r="6"/><path d="M10 42h38l-5-17H25l-8 17" fill="#e3bd35" stroke="#5b4c18" stroke-width="3"/><path d="M30 28L55 12" stroke="#e3bd35" stroke-width="6"/><path d="M52 10h8v6h-8" fill="#4e5a5a"/>',
      );
    if (kind === "excavator8" || kind === "excavator20")
      return svg(
        '<path d="M9 47h36l7 7H6z" fill="#323a3c"/><rect x="17" y="27" width="24" height="18" rx="4" fill="#e3bd35"/><rect x="22" y="21" width="13" height="12" fill="#83b8cb"/><path d="M38 30l13-13 5 4-10 15M55 20l4 16" fill="none" stroke="#e3bd35" stroke-width="5"/>',
      );
    if (kind === "roller")
      return svg(
        '<circle cx="18" cy="45" r="12" fill="#545d5e"/><circle cx="48" cy="47" r="7"/><path d="M24 41h26l-5-18H28z" fill="#e3bd35" stroke="#5b4c18" stroke-width="3"/><rect x="31" y="17" width="12" height="10" fill="#83b8cb"/>',
      );
    if (kind === "dumper")
      return svg(
        '<circle cx="18" cy="49" r="6"/><circle cx="45" cy="49" r="6"/><path d="M8 37h22l7 8H12z" fill="#e3bd35"/><path d="M29 18l27 8-10 16-22-7z" fill="#e3bd35" stroke="#5b4c18" stroke-width="3"/>',
      );
    if (kind === "mewp")
      return svg(
        '<circle cx="15" cy="51" r="5"/><circle cx="38" cy="51" r="5"/><path d="M8 43h35v8H8z" fill="#e3bd35"/><path d="M27 43l10-22 13-8" fill="none" stroke="#e3bd35" stroke-width="5"/><rect x="47" y="8" width="13" height="9" fill="none" stroke="#394849" stroke-width="3"/>',
      );
    if (kind === "heras" || kind === "storm" || kind === "barrier")
      return svg(
        '<path d="M8 12v44M56 12v44M8 18h48M8 50h48" stroke="#748487" stroke-width="3"/><path d="M8 18l48 32M56 18L8 50M20 18v32M32 18v32M44 18v32" stroke="#a7b2b3" stroke-width="2"/>',
      );
    if (kind === "pedGate" || kind === "vehicleGate")
      return svg(
        '<path d="M7 10v48M57 10v48M9 18h46v34H9z" fill="none" stroke="#748487" stroke-width="3"/><path d="M10 19l44 32M54 19L10 51" stroke="#a7b2b3" stroke-width="2"/><circle cx="32" cy="36" r="4" fill="#70ead0"/>',
      );
    if (kind === "parking")
      return svg(
        '<rect x="7" y="8" width="50" height="48" rx="5" fill="#dfeaf2" stroke="#356f9c" stroke-width="3"/><path d="M18 42h28l4-12-7-7H24l-7 7z" fill="#6c8796"/><circle cx="23" cy="44" r="4"/><circle cx="43" cy="44" r="4"/><path d="M12 14h40" stroke="#356f9c" stroke-width="3"/>',
      );
    if (kind === "generator")
      return svg(
        '<rect x="8" y="15" width="48" height="36" rx="5" fill="#d7dadd" stroke="#39464b" stroke-width="3"/><circle cx="18" cy="52" r="4"/><circle cx="46" cy="52" r="4"/><path d="M34 20l-11 16h9l-4 11 14-18h-9z" fill="#e0b52c"/>',
      );
    if (kind === "fuel")
      return svg(
        '<ellipse cx="30" cy="33" rx="22" ry="15" fill="#d9d6c8" stroke="#5d5745" stroke-width="3"/><path d="M49 26h7v17h-7M18 48v8M42 48v8" stroke="#5d5745" stroke-width="3"/><path d="M30 20c7 8 8 13 0 19-8-6-7-11 0-19z" fill="#c77f2e"/>',
      );
    if (kind === "skip")
      return svg(
        '<path d="M8 22h48l-6 30H14z" fill="#d0d4ce" stroke="#465250" stroke-width="3"/><path d="M15 28h34M18 36h28M20 44h24" stroke="#7a8581" stroke-width="2"/>',
      );
    if (kind === "wheelwash")
      return svg(
        '<rect x="6" y="16" width="52" height="34" rx="3" fill="#ccd8dc" stroke="#465a61" stroke-width="3"/><path d="M12 22v22M20 22v22M28 22v22M36 22v22M44 22v22M52 22v22" stroke="#657d86" stroke-width="2"/><path d="M10 53c8-7 16 7 24 0s16 7 22 0" fill="none" stroke="#3c99ca" stroke-width="3"/>',
      );
    if (kind === "stage")
      return svg(
        '<path d="M8 47h48V24H8z" fill="#3d4650"/><path d="M8 24l8-12h32l8 12M16 12v35M48 12v35" fill="none" stroke="#c9d2d4" stroke-width="3"/><circle cx="23" cy="34" r="4" fill="#70ead0"/><circle cx="41" cy="34" r="4" fill="#70ead0"/>',
      );
    if (cat === "Event")
      return svg(
        '<rect x="8" y="14" width="48" height="38" rx="5" fill="#dfe4ea" stroke="#39464b" stroke-width="3"/><path d="M14 42l10-17 8 11 7-9 11 15" fill="none" stroke="#6f7f8f" stroke-width="3"/>',
      );
    return svg(
      '<path d="M8 48h48V18H8z" fill="#dbe5e5" stroke="#334a50" stroke-width="3"/><path d="M14 24h36M14 32h36M14 40h26" stroke="#6e8589" stroke-width="3"/>',
    );
  }
  function assetCenter(f) {
    const b = G.boundsOf(f.geometry);
    return b ? [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2] : null;
  }
  function assetFootprintPx(f, c) {
    const m = f.properties,
      l = Math.max(0.2, +m.length || 1),
      w = Math.max(0.1, +m.width || 1),
      angle = Number.isFinite(Number(m.angle))
        ? Number(m.angle)
        : derivedRectAngle(f),
      a = (angle * Math.PI) / 180,
      u = [Math.sin(a), Math.cos(a)],
      v = [Math.cos(a), -Math.sin(a)];
    try {
      const centerPt = state.map.latLngToContainerPoint(latlng(c)),
        lenPt = state.map.latLngToContainerPoint(
          latlng(pointFromLocal(c, (u[0] * l) / 2, (u[1] * l) / 2)),
        ),
        widPt = state.map.latLngToContainerPoint(
          latlng(pointFromLocal(c, (v[0] * w) / 2, (v[1] * w) / 2)),
        ),
        lengthPx = Math.hypot(lenPt.x - centerPt.x, lenPt.y - centerPt.y) * 2,
        widthPx = Math.hypot(widPt.x - centerPt.x, widPt.y - centerPt.y) * 2;
      return {
        lengthPx: Math.max(12, Math.min(320, lengthPx || 0)),
        widthPx: Math.max(12, Math.min(320, widthPx || 0)),
        angle,
      };
    } catch {
      return { lengthPx: 34, widthPx: 34, angle };
    }
  }
  function renderAssetIllustrations() {
    if (!state.assetIconGroup) return;
    state.assetIconGroup.clearLayers();
    for (const f of state.project.features) {
      if (
        f.properties.type !== "asset" ||
        state.project.hiddenTypes.includes("asset")
      )
        continue;
      const c = assetCenter(f);
      if (!c) continue;
      const isVehicle =
        f.properties.category === "Vehicles" ||
        /truck|lorry|car|van|excavator|crane|cement|artic/i.test(
          String(f.properties.kind || ""),
        );
      const { lengthPx, widthPx, angle } = assetFootprintPx(f, c),
        opacity = Number.isFinite(+f.properties.styleFillOpacity)
          ? Math.max(0, Math.min(1, +f.properties.styleFillOpacity))
          : 1,
        html =
          '<div class="asset-map-icon ' +
          (isVehicle ? "vehicle" : "") +
          '" style="width:100%;height:100%;opacity:' +
          opacity +
          ";transform:rotate(" +
          angle +
          'deg)">' +
          assetIconSVG(f.properties.kind, f.properties) +
          "</div>";
      L.marker(latlng(c), {
        interactive: false,
        zIndexOffset: 250,
        icon: L.divIcon({
          className: "",
          html,
          iconSize: [widthPx, lengthPx],
          iconAnchor: [widthPx / 2, lengthPx / 2],
        }),
      }).addTo(state.assetIconGroup);
    }
  }
  function controlIcon(cls, txt) {
    return L.divIcon({
      className: "",
      html: '<div class="transform-handle ' + cls + '">' + txt + "</div>",
      iconSize: [34, 34],
      iconAnchor: [17, 17],
    });
  }
  function pointFromLocal(center, x, y) {
    const pr = G.projection(center);
    return pr.ll([x, y]);
  }
  function derivedRectAngle(f) {
    try {
      const c = assetCenter(f),
        pr = G.projection(c),
        r = f.geometry.coordinates[0],
        a = pr.xy(r[0]),
        b = pr.xy(r[1]);
      return (
        ((Math.atan2(b[0] - a[0], b[1] - a[1]) * 180) / Math.PI + 360) % 360
      );
    } catch {
      return 0;
    }
  }
  function localCornerPositions(f) {
    const m = f.properties,
      c = assetCenter(f);
    if (!c) return null;
    const l = Math.max(0.2, +m.length || 1),
      w = Math.max(0.1, +m.width || 1),
      angle = Number.isFinite(Number(m.angle))
        ? Number(m.angle)
        : derivedRectAngle(f),
      a = (angle * Math.PI) / 180,
      u = [Math.sin(a), Math.cos(a)],
      v = [Math.cos(a), -Math.sin(a)],
      xy = (along, cross) =>
        pointFromLocal(
          c,
          u[0] * along + v[0] * cross,
          u[1] * along + v[1] * cross,
        );
    return {
      center: c,
      resize: xy(l / 2, w / 2),
      rotate: xy(l / 2 + Math.max(1.2, l * 0.18), 0),
      delete: xy(-l / 2, -w / 2),
      angle,
    };
  }
  function renderTransformHandles() {
    const f = selectedFeature();
    if (!f || state.vertexEditId) return;
    const members = groupMembers(f),
      grouped = members.length > 1;
    if (grouped) {
      const b = groupBounds(members);
      if (!b) return;
      const center = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2],
        move = L.marker(latlng(center), {
          draggable: true,
          zIndexOffset: 1000,
          icon: controlIcon("move", "✥"),
        }).addTo(state.editGroup);
      move.bindTooltip("Move group", { direction: "top" });
      move.on("dragend", () => {
        const next = coord(move.getLatLng()),
          delta = [next[0] - center[0], next[1] - center[1]];
        translateMembers(members, delta);
        commit();
        toast("Group moved.");
      });
      const pr = G.projection(center),
        corners = [
          [b[0], b[1]],
          [b[2], b[3]],
          [b[0], b[3]],
          [b[2], b[1]],
        ].map(pr.xy),
        radius = Math.max(3, ...corners.map((q) => Math.hypot(q[0], q[1]))) + 3,
        rotPos = pr.ll([0, radius]),
        rot = L.marker(latlng(rotPos), {
          draggable: true,
          zIndexOffset: 1000,
          icon: controlIcon("rotate", "↻"),
        }).addTo(state.editGroup);
      rot.bindTooltip("Rotate group", { direction: "top" });
      rot.on("dragend", () => {
        const q = pr.xy(coord(rot.getLatLng())),
          degrees = (Math.atan2(q[0], q[1]) * 180) / Math.PI;
        rotateMembers(members, center, degrees);
        commit();
        toast("Group rotated.");
      });
      return;
    }
    if (!["asset", "panel", "logo"].includes(f.properties.type)) return;
    const p = localCornerPositions(f);
    if (!p) return;
    const move = L.marker(latlng(p.center), {
      draggable: true,
      zIndexOffset: 1000,
      icon: controlIcon("move", "✥"),
    }).addTo(state.editGroup);
    move.bindTooltip("Move", { direction: "top" });
    move.on("dragend", () => {
      const next = coord(move.getLatLng()),
        delta = [next[0] - p.center[0], next[1] - p.center[1]];
      translateMembers([f], delta);
      commit();
    });
    const rot = L.marker(latlng(p.rotate), {
      draggable: true,
      zIndexOffset: 1000,
      icon: controlIcon("rotate", "↻"),
    }).addTo(state.editGroup);
    rot.bindTooltip("Rotate", { direction: "top" });
    rot.on("dragend", () => {
      const next = coord(rot.getLatLng()),
        pr = G.projection(p.center),
        q = pr.xy(next),
        angle = ((Math.atan2(q[0], q[1]) * 180) / Math.PI + 360) % 360;
      f.properties.angle = angle;
      f.geometry = G.rectangle(
        p.center,
        +f.properties.length || 1,
        +f.properties.width || 1,
        angle,
      );
      commit();
    });
    if (!f.properties.dimensionLocked) {
      const resize = L.marker(latlng(p.resize), {
        draggable: true,
        zIndexOffset: 1000,
        icon: controlIcon("resize", "↘"),
      }).addTo(state.editGroup);
      resize.bindTooltip("Resize", { direction: "top" });
      resize.on("dragend", () => {
        const next = coord(resize.getLatLng()),
          pr = G.projection(p.center),
          q = pr.xy(next),
          currentAngle = Number.isFinite(Number(f.properties.angle))
            ? Number(f.properties.angle)
            : derivedRectAngle(f),
          a = (currentAngle * Math.PI) / 180,
          u = [Math.sin(a), Math.cos(a)],
          v = [Math.cos(a), -Math.sin(a)],
          along = q[0] * u[0] + q[1] * u[1],
          cross = q[0] * v[0] + q[1] * v[1],
          l = Math.max(0.2, Math.abs(along) * 2),
          w = Math.max(0.1, Math.abs(cross) * 2);
        f.properties.length = +l.toFixed(2);
        f.properties.width = +w.toFixed(2);
        f.properties.angle = currentAngle;
        f.geometry = G.rectangle(p.center, l, w, currentAngle);
        commit();
      });
    }
  }
  function readPaletteAsset(k) {
    const base = ASSETS[k] || ASSETS.custom;
    if (state.project.asset.kind === k && $("#assetLength"))
      return {
        ...base,
        kind: k,
        name: $("#assetLabel").value.trim() || base.name,
        length: base.dimensionLocked
          ? base.length
          : +$("#assetLength").value || base.length,
        width: base.dimensionLocked
          ? base.width
          : +$("#assetWidth").value || base.width,
        angle: +$("#assetAngle").value || 0,
        symbol: base.symbol || "•",
        category: base.category || "Other",
        includeLegend: $("#assetLegend")?.checked !== false,
      };
    return { kind: k, ...base, angle: 0, includeLegend: true };
  }
  function placeAssetAtScreen(k, x, y) {
    const r = $("#map").getBoundingClientRect();
    if (x < r.left || x > r.right || y < r.top || y > r.bottom) return false;
    const c = coord(state.map.containerPointToLatLng([x - r.left, y - r.top]));
    if (state.mode === "plan" && state.project.area && !insidePlanFrame(c)) {
      toast("Drop the asset inside the site drawing area.");
      return false;
    }
    const a = readPaletteAsset(k);
    state.project.asset = copy(a);
    if (Array.isArray(a.panelLayout) && a.panelLayout.length) {
      const ids = placePanelLayout(c, a, false);
      if (!ids.length) return false;
      state.selected = null;
      commit();
      toast(a.name + " placed · " + ids.length + " panels.");
      return true;
    }
    const f = feature(
      "asset",
      G.rectangle(c, +a.length, +a.width, +a.angle || 0),
      { ...a, label: a.name, centerLng: c[0], centerLat: c[1] },
    );
    state.project.features.push(f);
    state.selected = null;
    commit();
    toast(a.name + " placed.");
    return true;
  }
  function bindAssetPaletteDrag() {
    const box = $("#drawerContent");
    if (!box) return;
    box.querySelectorAll("[data-asset-drag]").forEach((btn) => {
      btn.ondragstart = (e) => {
        e.dataTransfer.effectAllowed = "copy";
        e.dataTransfer.setData("text/sami-asset", btn.dataset.assetDrag);
      };
      let touch = null,
        ghost = null,
        moved = false;
      btn.onpointerdown = (e) => {
        if (e.pointerType === "mouse") return;
        touch = {
          id: e.pointerId,
          x: e.clientX,
          y: e.clientY,
          k: btn.dataset.assetDrag,
        };
        btn.setPointerCapture?.(e.pointerId);
        moved = false;
      };
      btn.onpointermove = (e) => {
        if (!touch || e.pointerId !== touch.id) return;
        if (
          !moved &&
          Math.hypot(e.clientX - touch.x, e.clientY - touch.y) > 8
        ) {
          moved = true;
          ghost = document.createElement("div");
          ghost.className = "asset-drag-ghost";
          ghost.innerHTML =
            "<span>" + assetIconSVG(touch.k, ASSETS[touch.k]) + "</span>";
          document.body.appendChild(ghost);
        }
        if (moved && ghost) {
          ghost.style.left = e.clientX + "px";
          ghost.style.top = e.clientY + "px";
          e.preventDefault();
        }
      };
      const end = (e) => {
        if (!touch || e.pointerId !== touch.id) return;
        if (moved) {
          e.preventDefault();
          e.stopPropagation();
          placeAssetAtScreen(touch.k, e.clientX, e.clientY);
        }
        btn.releasePointerCapture?.(e.pointerId);
        ghost?.remove();
        ghost = null;
        touch = null;
        moved = false;
      };
      btn.onpointerup = end;
      btn.onpointercancel = (e) => {
        ghost?.remove();
        ghost = null;
        touch = null;
        moved = false;
      };
    });
  }
  function initAssetDropZone() {
    const map = $("#map");
    map.addEventListener("dragover", (e) => {
      if (e.dataTransfer.types.includes("text/sami-asset")) {
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
      }
    });
    map.addEventListener("drop", (e) => {
      const k = e.dataTransfer.getData("text/sami-asset");
      if (!k) return;
      e.preventDefault();
      placeAssetAtScreen(k, e.clientX, e.clientY);
    });
  }
  function updateCadOverlay() {
    const o = $("#cadOverlay");
    if (!o) return;
    const on = state.base === "drawing";
    o.setAttribute("aria-hidden", String(!on));
    if (!on) return;
    $("#cadProjectName").textContent = state.project.name;
    $("#cadSiteRef").textContent =
      state.project.meta.siteAddress ||
      state.project.meta.siteRef ||
      "Defined site area";
    $("#cadDrawingNo").textContent =
      state.project.meta.drawingNo || "SITE PLAN";
    $("#cadRevision").textContent =
      "Rev " + (state.project.meta.revision || "—");
    $("#cadScale").textContent = "1:" + suggestedScale();
  }
  const studio = window.SAMIWorkspaceController(
    {
      state,
      G,
      PRODUCTS,
      ASSETS,
      TYPES,
      SERVICES,
      HGV_PROFILES,
      rotateMembers: (...a) => rotateMembers(...a),
      exportProjectJSON: (...a) => exportProjectJSON(...a),
      fresh: (...args) => fresh(...args),
      normaliseProject: (...args) => normaliseProject(...args),
      planBounds: (...args) => planBounds(...args),
      insidePlanFrame: (...args) => insidePlanFrame(...args),
      featureStyle: (...args) => featureStyle(...args),
      visibleFeature: (...args) => visibleFeature(...args),
      assetIconSVG: (...args) => assetIconSVG(...args),
      renderAssetIllustrations: (...args) => renderAssetIllustrations(...args),
      supportIcon: (...args) => supportIcon(...args),
      chooseOhlSupport: (...args) => chooseOhlSupport(...args),
      render: (...args) => render(...args),
      updateLock: (...args) => updateLock(...args),
      setMode: (...args) => setMode(...args),
      setModeUI: (...args) => setModeUI(...args),
      fitArea: (...args) => fitArea(...args),
      openDrawer: (...args) => openDrawer(...args),
      closeDrawer: (...args) => closeDrawer(...args),
      assetsHTML: (...args) => assetsHTML(...args),
      drawHTML: (...args) => drawHTML(...args),
      startTool: (...args) => startTool(...args),
      isFreehandTool: (...args) => isFreehandTool(...args),
      onMapClick: (...args) => onMapClick(...args),
      renderDraft: (...args) => renderDraft(...args),
      finishDraw: (...args) => finishDraw(...args),
      placeItem: (...args) => placeItem(...args),
      placeAssetAtScreen: (...args) => placeAssetAtScreen(...args),
      bindAssetPaletteDrag: (...args) => bindAssetPaletteDrag(...args),
      layersHTML: (...args) => layersHTML(...args),
      renderTransformHandles: (...args) => renderTransformHandles(...args),
      selectionHTML: (...args) => selectionHTML(...args),
      editAction: (...args) => editAction(...args),
      routeToSiteHTML: (...args) => routeToSiteHTML(...args),
      planHgvRoute: (...args) => planHgvRoute(...args),
      projectHTML: (...args) => projectHTML(...args),
      initVoice: (...args) => initVoice(...args),
      speakOptional: (...args) => speakOptional(...args),
      helpHTML: (...args) => helpHTML(...args),
      renderDrawer: (...args) => renderDrawer(...args),
      bindDrawer: (...args) => bindDrawer(...args),
      runAction: (...args) => runAction(...args),
      handleCommand: (...args) => handleCommand(...args),
      overpassFeatures: (...args) => overpassFeatures(...args),
      refreshOhlSnapshot: (...args) => refreshOhlSnapshot(...args),
      updateLaunchGate: (...args) => updateLaunchGate(...args),
      initToolRail: (...args) => initToolRail(...args),
      clampRail: (...args) => clampRail(...args),
      initFreehandInput: (...args) => initFreehandInput(...args),
      addPanelFill: (...args) => addPanelFill(...args),
      esc: (...args) => esc(...args),
      copy: (...args) => copy(...args),
      uid: (...args) => uid(...args),
      button: (...args) => button(...args),
      field: (...args) => field(...args),
      choice: (...args) => choice(...args),
      checkedRow: (...args) => checkedRow(...args),
      section: (...args) => section(...args),
      latlng: (...args) => latlng(...args),
      coord: (...args) => coord(...args),
      isLocked: (...args) => isLocked(...args),
      serviceBounds: (...args) => serviceBounds(...args),
      selectedFeature: (...args) => selectedFeature(...args),
      groupMembers: (...args) => groupMembers(...args),
      groupBounds: (...args) => groupBounds(...args),
      featureCenter: (...args) => featureCenter(...args),
      translateMembers: (...args) => translateMembers(...args),
      duplicateSelected: (...args) => duplicateSelected(...args),
      startGroupPick: (...args) => startGroupPick(...args),
      ungroupSelected: (...args) => ungroupSelected(...args),
      pointInRingXY: (...args) => pointInRingXY(...args),
      feature: (...args) => feature(...args),
      lineMidpointAndBearing: (...args) => lineMidpointAndBearing(...args),
      readSupportTypes: (...args) => readSupportTypes(...args),
      supportKey: (...args) => supportKey(...args),
      ohlCoords: (...args) => ohlCoords(...args),
      coordLabel: (...args) => coordLabel(...args),
      boundedJSON: (...args) => boundedJSON(...args),
      overpassQuery: (...args) => overpassQuery(...args),
      replaceSourceFeatures: (...args) => replaceSourceFeatures(...args),
      freehandPointAllowed: (...args) => freehandPointAllowed(...args),
      screenToCoord: (...args) => screenToCoord(...args),
      samiSay: (...args) => samiSay(...args),
      toast: (...args) => toast(...args),
      showModal: (...args) => showModal(...args),
      closeModal: (...args) => closeModal(...args),
      saveSoon: (...args) => saveSoon(...args),
      saveNow: (...args) => saveNow(...args),
      readPref: (...args) => readPref(...args),
      setPref: (...args) => setPref(...args),
      updateVoiceButton: (...args) => updateVoiceButton(...args),
      commit: (...args) => commit(...args),
      cancelDraw: (...args) => cancelDraw(...args),
      addPanelRun: (...args) => addPanelRun(...args),
      openExport: (...args) => openExport(...args),
      switchBase: (...args) => switchBase(...args),
      setArea: (...args) => setArea(...args),
      snapshot: (...args) => snapshot(...args),
      resolveLocationText: (...args) => resolveLocationText(...args),
      readHgvOptions: (...args) => readHgvOptions(...args),
      runServiceRefresh: (...args) => runServiceRefresh(...args),
    },
    {
      fresh,
      normaliseProject,
      planBounds,
      featureStyle,
      visibleFeature,
      assetIconSVG,
      renderAssetIllustrations,
      supportIcon,
      chooseOhlSupport,
      render,
      updateLock,
      setMode,
      setModeUI,
      fitArea,
      openDrawer,
      closeDrawer,
      assetsHTML,
      drawHTML,
      startTool,
      isFreehandTool,
      onMapClick,
      renderDraft,
      finishDraw,
      placeItem,
      placeAssetAtScreen,
      bindAssetPaletteDrag,
      layersHTML,
      renderTransformHandles,
      selectionHTML,
      editAction,
      routeToSiteHTML,
      planHgvRoute,
      projectHTML,
      initVoice,
      speakOptional,
      helpHTML,
      renderDrawer,
      bindDrawer,
      runAction,
      handleCommand,
      overpassFeatures,
      refreshOhlSnapshot,
      updateLaunchGate,
      initToolRail,
      clampRail,
      initFreehandInput,
      addPanelFill,
      libraryHTML,
    },
  );
  ({
    fresh,
    normaliseProject,
    planBounds,
    featureStyle,
    visibleFeature,
    assetIconSVG,
    renderAssetIllustrations,
    supportIcon,
    chooseOhlSupport,
    render,
    updateLock,
    setMode,
    setModeUI,
    fitArea,
    openDrawer,
    closeDrawer,
    assetsHTML,
    drawHTML,
    startTool,
    isFreehandTool,
    onMapClick,
    renderDraft,
    finishDraw,
    placeItem,
    placeAssetAtScreen,
    bindAssetPaletteDrag,
    layersHTML,
    renderTransformHandles,
    selectionHTML,
    editAction,
    routeToSiteHTML,
    planHgvRoute,
    projectHTML,
    initVoice,
    speakOptional,
    helpHTML,
    renderDrawer,
    bindDrawer,
    runAction,
    handleCommand,
    overpassFeatures,
    refreshOhlSnapshot,
    updateLaunchGate,
    initToolRail,
    clampRail,
    initFreehandInput,
    addPanelFill,
  } = studio);
  init();
  studio.mount();
})();
