/* SAMI workspace: one controller owns navigation, panels, project lifecycle and context. */
window.SAMIWorkspaceController = function (C, O) {
  "use strict";
  const base = window.SAMIStudioEngine(C, O),
    S = C.state,
    G = C.G,
    Store = window.SAMIProjectStore;
  const $ = (s) => document.querySelector(s),
    $$ = (s) => [...document.querySelectorAll(s)],
    esc = C.esc,
    copy = C.copy;
  const projectId = () =>
    crypto?.randomUUID?.() ||
    "sami-" +
      Date.now().toString(36) +
      "-" +
      Math.random().toString(36).slice(2, 9);
  const ui = {
    drawer: "explore",
    drawAsset: "panel_lion",
    drawMode: "line",
    assetQuery: "",
    favourites: new Set((() => { try { const v=JSON.parse(C.readPref("sami.favourites") || "[]"); return Array.isArray(v) ? v : []; } catch { return []; } })()),
    assetFamily: "Trakway",
    category: new Set(["Trakway"]),
    serviceMode: "show",
    serviceEditType: "ohl",
    drafts: {},
    ready: false,
    reference: null,
    tooltips: true,
    exportApproved: false,
    precision: {
      active: false,
      mode: "line",
      points: [],
      target: "measure",
      cursorX: 0.5,
      cursorY: 0.5,
      drag: null,
      multi: false,
      showMeasurements: true,
    },
    boxSelect: false,
  };
  let referenceOverlay = null,
    bearing,
    saveSeq = 0,
    snapRing = null;
  const B = (label, action, primary = false) =>
    `<button data-action="${action}" class="${primary ? "primary" : ""}">${label}</button>`;
  const tip = (symbol, label, action) =>
    `<button class="icon-btn" data-action="${action}" title="${esc(label)}" aria-label="${esc(label)}">${symbol}</button>`;
  const ICONS = {
    edit: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>',
    move: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v18M3 12h18"/><path d="M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/></svg>',
    rotate:
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 12a8.5 8.5 0 1 0 2.8-6.3"/><path d="M3.5 3.8v5h5"/></svg>',
    points:
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 19L12 6l7 13"/><circle cx="5" cy="19" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="6" r="1.6" fill="currentColor" stroke="none"/><circle cx="19" cy="19" r="1.6" fill="currentColor" stroke="none"/></svg>',
    duplicate:
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
    group:
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.2"/><rect x="14" y="14" width="7" height="7" rx="1.2"/><path d="M10 6.5h5A2.5 2.5 0 0 1 17.5 9v5"/></svg>',
    ungroup:
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.2"/><rect x="14" y="14" width="7" height="7" rx="1.2"/></svg>',
    bin: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/><path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/><path d="M10 11v6M14 11v6"/></svg>',
    close:
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  };
  const details = (title, body, key = title) =>
    `<details class="compact-section" data-section="${esc(key)}" ${ui.category.has(key) ? "open" : ""}><summary>${esc(title)}</summary>${body}</details>`;
  const STAGES = {
    project: "Project",
    map: "Map",
    plan: "Site Plan",
    route: "Route",
    review: "Export",
    create: "Create",
  };
  const TABS = {
    project: [
      ["details", "Details"],
      ["designer", "Designer"],
    ],
    map: [
      ["explore", "Find site"],
      ["area", "Site area"],
      ["background", "View"],
    ],
    route: [
      ["routeToSite", "Route"],
      ["access", "Entrances"],
      ["background", "View"],
    ],
    plan: [
      ["draw", "Items"],
      ["services", "Services"],
      ["layers", "Objects"],
      ["background", "View"],
      ["selection", "Properties"],
    ],
    review: [["review", "Review & export"]],
    create: [
      ["builder", "Builder"],
      ["assets", "My assets"],
    ],
  };
  const SURFACES = {
    surface_access: { name: "Access route", mode: "line" },
    surface_egress: { name: "Egress route", mode: "line" },
    surface_route: { name: "On-site route", mode: "line" },
    surface_stoneRoad: { name: "Stone road", mode: "line" },
    surface_stoneArea: { name: "Stone hardstanding", mode: "area" },
    surface_area: { name: "Compound / area", mode: "area" },
    surface_hazard: { name: "Exclusion area", mode: "area" },
    surface_excavation: { name: "Excavation", mode: "area" },
  };
  const ANNOTATIONS = {
    rectangle: ["Rectangle", "area"],
    circle: ["Circle / radius", "area"],
    arrow: ["Arrow", "line"],
    measure: ["Dimension", "line"],
    textBox: ["Text", "place"],
    note: ["Note", "place"],
    photo: ["Photo", "place"],
  };
  const METHODS = {
    place: ["▣", "Place"],
    line: ["⎁", "Line"],
    area: ["⬡", "Area"],
    freeLine: ["〰", "Draw line"],
    freeArea: ["◌", "Draw area"],
  };
  const CAVEAT =
    "Service information is provided for planning/reference only. Locations must be verified using the appropriate utility records, surveys and safe-dig procedures before work.";
  const aliases = {
    mapExplore: "explore",
    mapImage: "image",
    mapArea: "area",
    planArea: "area",
    planDraw: "draw",
    planPlace: "draw",
    place: "draw",
    planSelect: "layers",
    planServices: "services",
    planAccess: "access",
    planStyle: "background",
    project: "details",
    panels: "draw",
    library: "layers",
    search: "explore",
    shapeLibrary: "assets",
  };
  function canonical(k) {
    return aliases[k] || k;
  }
  function currentAsset() {
    if (ui.drawAsset.startsWith("panel_"))
      return {
        ...C.PRODUCTS[ui.drawAsset.slice(6)],
        kind: ui.drawAsset,
        type: "panel",
        allowed: ["place", "line", "area", "freeLine", "freeArea"],
      };
    if (SURFACES[ui.drawAsset]) {
      const x = SURFACES[ui.drawAsset];
      return {
        ...x,
        allowed:
          x.mode === "area" ? ["area", "freeArea"] : ["line", "freeLine"],
      };
    }
    if (ui.drawAsset.startsWith("annotation_")) {
      const x = ANNOTATIONS[ui.drawAsset.slice(11)];
      return { name: x?.[0], allowed: [x?.[1] || "place"] };
    }
    return {
      ...C.ASSETS[ui.drawAsset],
      allowed: ["place", "line", "area", "freeLine", "freeArea"],
    };
  }
  function methodsHTML() {
    const a = currentAsset(), panel = a.type === "panel";
    const names = panel ? {line:"Run",area:"Pad",place:"Single panel",freeLine:"Freehand run",freeArea:"Freehand pad"}
      : {place:"Place",line:"Repeat along line",area:"Fill area",freeLine:"Freehand line",freeArea:"Freehand area"};
    const button = k => `<button data-action="method:${k}" aria-pressed="${k === ui.drawMode}" class="${k === ui.drawMode ? "active" : ""}">${names[k]}</button>`;
    const allowed = a.allowed || ["place"];
    return `<div class="placement-modes" aria-label="Placement method">${allowed.filter(k => !k.startsWith("free")).map(button).join("")}</div>${allowed.some(k => k.startsWith("free")) ? details("Freehand tools",`<div class="placement-modes">${allowed.filter(k => k.startsWith("free")).map(button).join("")}</div>`,"freehand") : ""}`;
  }

  function sabreOptions() {
    return `<div class="inline-note">Sabre-X: 1.80 m progression × 3.80 m usable width. Joining flanges remain separate from the usable footprint.</div>${C.field("sabreJoint", "Verified joint spacing (mm)", S.project.route.jointSpacingMm || "", "number", 'min="1" max="300" step="1" placeholder="Enter from product joint drawing"')}<label class="switch-row"><span>Joint spacing checked against product drawing</span><input id="sabreVerified" type="checkbox" ${S.project.route.jointVerified ? "checked" : ""}></label>`;
  }
  function assetGroups() {
    base.syncCatalogue();
    const groups = {
      Trakway: Object.entries(C.PRODUCTS).map(([k, p]) => ["panel_" + k, p]),
      "Routes & areas": Object.entries(SURFACES),
      Annotation: Object.entries(ANNOTATIONS).map(([k, [name]]) => [
        "annotation_" + k,
        { name },
      ]),
    };
    for (const [k, a] of Object.entries(C.ASSETS)) {
      const category = /vehicle/i.test(a.category || "") ? "Vehicles" : /plant/i.test(a.category || "") ? "Plant & equipment" : a.category || "Site assets";
      (groups[category] ??= []).push([k, a]);
    }
    groups.Favourites = Object.values(groups).flat().filter(([k]) => ui.favourites.has(k));
    return groups;
  }
  function assetTile(k, a, family = null, hidden = false) {
    const selected = ui.drawAsset === k,
      kind = k.startsWith("panel_")
        ? "panel"
        : k.startsWith("surface_")
          ? "surface"
          : k.startsWith("annotation_")
            ? "annotation"
            : "asset",
      canDrag = kind === "panel" || kind === "asset",
      detail =
        k === "panel_sabre"
          ? "4.00 × 2.00 m panel · special stagger"
          : a.needsScale ? "Set real dimensions" : a.length
            ? `${Number(Number(a.length).toFixed(2))} × ${Number(Number(a.width).toFixed(2))} m`
            : kind === "surface"
              ? `Draw ${a.mode}`
              : kind === "annotation"
                ? "Drawing tool"
                : a.category || "Site asset",
      thumb =
        kind === "surface"
          ? '<svg viewBox="0 0 100 60" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 48L30 12l55 10-5 26z"/><path d="M22 39l17-17 33 8" stroke-dasharray="4 4"/></svg>'
          : kind === "annotation"
            ? k.endsWith("textBox")
              ? '<svg viewBox="0 0 100 60" fill="none" stroke="currentColor" stroke-width="3"><path d="M28 18v-5h44v5M50 13v36M39 49h22"/></svg>'
              : '<svg viewBox="0 0 100 60" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M15 50V10M85 50V10M15 22h70M11 26l8-8M81 26l8-8"/><path d="M25 40h50" stroke-dasharray="3 3"/></svg>'
            : C.assetIconSVG(k, a);
    return `<button class="asset-tile ${selected ? "active" : ""}" ${hidden ? "hidden" : ""} ${family ? `data-family="${esc(family)}"` : ""} data-search="${esc((a.name + " " + detail + " " + (family || "")).toLowerCase())}" data-action="choose:${k}" aria-pressed="${selected}" title="${esc(a.name)}" draggable="${canDrag}" ${canDrag ? `data-asset-drag="${esc(k)}"` : ""}><span class="asset-thumb">${thumb}</span><span class="asset-tile-copy"><strong>${esc(a.name)}</strong><small>${esc(detail)}</small></span>${selected ? "<b>✓</b>" : ""}</button>`;
  }
  function drawSetupHTML() {
    const a = currentAsset();
    if (!a) return "";
    let html = "";
    if (a.type === "panel" && !["area", "freeArea"].includes(ui.drawMode))
      html += `<div class="draw-setup"><div><small>RUN WIDTH</small>${C.choice("workspaceLanes", "", { 1: `${a.width} m · single`, 2: `${2 * a.width} m · double` }, String(S.project.route.lanes || 1))}</div><p>Panel colour and appearance are edited after placement from <b>Properties</b>. Product dimensions remain locked.</p></div>`;
    if (a.type === "panel" && ["area", "freeArea"].includes(ui.drawMode))
      html += `<div class="pad-orientation">${C.choice("padOrientation", "Panel orientation", { auto: "Follow first edge", north: "North–south · 0°", east: "East–west · 90°", custom: "Custom bearing" }, S.project.padBearing == null ? "auto" : S.project.padBearing === 0 ? "north" : S.project.padBearing === 90 ? "east" : "custom")}${C.field("padBearing", "Panel length direction (° clockwise from north)", S.project.padBearing ?? 0, "number", 'min="0" max="359.9" step="0.1"')}<p class="subtle">Applies to this pad. Set the direction before drawing; Follow first edge keeps the existing automatic alignment.</p></div>`;
    if (ui.drawAsset === "panel_sabre") html += sabreOptions();
    if (a.dimensionLocked === false) html += `${a.needsScale ? '<p class="scale-warning">Set the real footprint before placing this imported item.</p>' : ""}<div class="property-grid">${C.field("customAssetLength","Length (m)",a.length,"number",'min="0.1" max="500" step="0.1"')}${C.field("customAssetWidth","Width (m)",a.width,"number",'min="0.1" max="500" step="0.1"')}</div>${a.needsScale ? B("Confirm dimensions","confirmAssetScale",true) : ""}`;
    if (a.type !== "panel" && !ui.drawAsset.startsWith("annotation_") && ["line","area","freeLine","freeArea"].includes(ui.drawMode))
      html += C.field("repeatGap","Space between items (m)",S.project.assetGap || 0,"number",'min="0" max="100" step="0.1"');
    return html;
  }
  function libraryHTML() {
    const groups = assetGroups(), families = Object.keys(groups);
    if (!groups[ui.assetFamily]) ui.assetFamily = "Trakway";
    const rows = groups[ui.assetFamily] || [], a = currentAsset();
    const query = ui.assetQuery.trim().toLowerCase();
    const all = Object.entries(groups).filter(([family]) => family !== "Favourites");
    const matches = query ? all.flatMap(([family,items]) => items.filter(([k,x]) => (x.name+" "+family).toLowerCase().includes(query)).map(([k,x])=>[k,x,family])) : rows.map(([k,x])=>[k,x,ui.assetFamily]);
    const preview = a?.name ? `<section class="item-setup"><div class="item-setup-heading"><div><small>SELECTED ITEM</small><strong>${esc(a.name)}</strong></div><button data-action="favourite:${ui.drawAsset}" aria-label="${ui.favourites.has(ui.drawAsset) ? "Remove favourite" : "Save favourite"}" aria-pressed="${ui.favourites.has(ui.drawAsset)}">${ui.favourites.has(ui.drawAsset) ? "★" : "☆"}</button></div>${methodsHTML()}${drawSetupHTML()}${B(ui.drawAsset === "annotation_measure" ? "Add dimension" : a.type === "panel" ? (["area","freeArea"].includes(ui.drawMode) ? "Draw pad" : ui.drawMode === "place" ? "Place panel" : "Draw run") : ui.drawMode === "place" ? "Place on plan" : "Start drawing","startDrawing",true)}</section>` : "";
    return `<div class="library-intro"><p>Choose an item, then place or draw it.</p><button data-action="importShapePack" title="Import SVG, DXF or Visio">Import</button></div><label class="asset-search"><span aria-hidden="true">⌕</span><input id="assetSearch" type="search" value="${esc(ui.assetQuery)}" autocomplete="off" placeholder="Search items…" aria-label="Search all items"></label><label class="asset-family-picker"><span>Library</span><select id="assetFamily">${families.map(name => `<option value="${esc(name)}" ${name === ui.assetFamily ? "selected" : ""}>${esc(name)} (${groups[name].length})</option>`).join("")}</select></label><div class="asset-family-heading"><strong>${query ? "Search results" : esc(ui.assetFamily)}</strong><small id="assetVisibleCount" role="status">${matches.length} items</small></div><div class="asset-grid">${all.flatMap(([family,items]) => items.map(([k,x]) => assetTile(k,x,family,!matches.some(([id])=>id === k)))).join("")}</div><p class="library-empty" ${matches.length ? "hidden" : ""}>No items here yet. Try another search or add a favourite.</p>${preview}${details("Manage library", B("Create a shape", "stage:create") + B("My imported assets", "myAssets") + B("My logos", "open:branding") + B("Export asset pack", "exportShapePack"), "library-tools")}`;
  }

  function exploreHTML() {
    return `<label class="search-field"><span>⌕</span><input id="mapExploreQuery" aria-label="Find site" placeholder="Address, postcode or coordinates"><button data-action="mapSearch" aria-label="Search">↵</button></label><div class="button-pair">${B("◎ My location", "mapLocate")}${B("▧ Image locate", "open:image")}</div><div class="section-title">Drawing space</div>${B(S.project.area ? "Adjust site area" : "Define site area", "open:area", true)}<div class="section-title">Field evidence</div><div class="button-pair">${B("＋ Note", "fieldNote")}${B("＋ Photo", "fieldPhoto")}</div><p class="subtle">Saved with your project. Included on the issued drawing only when you choose.</p><div class="section-title">Site intelligence</div>${B("Services & constraints", "open:services")}${details("Coordinates & what3words", C.field("exploreLat", "Latitude", S.map?.getCenter().lat.toFixed(6) || "", "number", 'step="any"') + C.field("exploreLng", "Longitude", S.map?.getCenter().lng.toFixed(6) || "", "number", 'step="any"') + B("Go to coordinates", "goCoordinates") + C.field("exploreW3w", "what3words", S.project.meta.what3words || "") + B("Locate what3words", "locateW3w"))}`;
  }
  function areaHTML() {
    return `<div class="stage-intro"><small>SITE AREA</small><h2>Use what you can see.</h2></div><p class="subtle">Define the Site Plan in one press. SAMI centres an A3/A4 landscape-ratio frame inside the current view and retains the current bearing.</p>${B(S.project.area ? "Redefine area from current view" : "Define area from current view", "visibleArea", true)}${S.project.area ? `<div class="inline-note">${Math.round(G.area(S.project.area)).toLocaleString()} m² · landscape paper ratio · stored bearing</div>${B("Open Site Plan", "stage:plan", true)}<div class="button-pair">${B("Fit area", "fitArea")}${B("Clear area", "clearArea")}</div>` : ""}${details("Manual / irregular area tools", `<div class="area-methods">${B("Two corners", "defineArea")}${B("Point boundary", "defineAreaPoints")}${B("Freehand extent", "defineAreaFreehand")}</div>`, "Manual area tools")}`;
  }
  const PROJECT_FIELDS = [
    ["siteRef", "Project reference"],
    ["clientName", "Client"],
    ["siteName", "Site name"],
    ["siteAddress", "Site address"],
    ["what3words", "what3words"],
    ["issueDate", "Date", "date"],
    ["revision", "Revision"],
    ["drawingNo", "Drawing number"],
    ["siteContact", "Site contact"],
    ["sitePhone", "Site telephone"],
  ];
  const DESIGNER_FIELDS = [
    ["creator", "Prepared by"],
    ["designerCompany", "Company"],
    ["jobTitle", "Job title"],
    ["designerEmail", "Email"],
    ["designerPhone", "Telephone"],
  ];
  function projectHTML() {
    const m=S.project.meta, essential=["clientName","siteAddress"];
    const fields=rows => rows.map(([k,label,type]) => C.field("meta_"+k,label,m[k] || (k === "issueDate" ? new Date().toISOString().slice(0,10) : ""),type || "text")).join("");
    return `<div class="stage-intro"><small>PROJECT</small><h2>Start with the essentials.</h2></div>${C.field("detailsName","Project name",S.project.name)}${fields(PROJECT_FIELDS.filter(([k]) => essential.includes(k)))}${B(S.project.area ? "Continue to Site Plan →" : "Find the site →",S.project.area ? "stage:plan" : "stage:map",true)}${details("Drawing details",fields(PROJECT_FIELDS.filter(([k]) => !essential.includes(k))) + '<label class="field-label" for="projectNotes">Drawing notes</label><textarea id="projectNotes" class="field" rows="3">' + esc(m.siteNotes || "") + '</textarea>')}${details("Designer & logos",B("Designer details","open:designer") + B("Company / client logos","open:branding"))}${details("Project files",B("Export backup","backup")+B("Import backup","openProject"))}`;
  }
  function designerHTML() {
    const m = S.project.meta;
    return `<div class="stage-intro"><small>PROJECT / DESIGNER</small><h2>Designer information.</h2></div><div class="metadata-grid">${DESIGNER_FIELDS.map(([k, label, type]) => C.field("meta_" + k, label, m[k] || "", type || "text")).join("")}</div><div class="button-pair">${B("Logos", "open:branding")}${B("Saved profiles", "open:profiles")}</div>${B("Save these designer details as a profile", "saveProfile", true)}<p class="subtle">Designer information is kept separate from project/site details and is reused only when you choose a saved profile.</p>`;
  }
  function selectionHTML() {
    if (S.multiSelection && S.multiSelection.size > 1) {
      const count = S.multiSelection.size;
      return `<div class="selection-heading"><small>Multi-selection</small><strong>${count} objects selected</strong></div><p class="subtle">Ctrl+Click to add or remove items from the selection.</p><div class="properties-actions">${B("Group selected items", "groupMultiSelection")}${B("Clear selection", "clearMultiSelection")}</div>`;
    }
    const f = C.selectedFeature();
    if (!f)
      return '<p class="subtle">Select an object to see its properties.</p>';
    const m = f.properties;
    if (m.dimension) return `<div class="selection-heading"><small>DIMENSION</small><strong>${esc(window.SAMIPlanning.dimensionLabel(G.length(f.geometry.coordinates),m))}</strong></div>${C.field("editLabel","Name",m.label || "Dimension")}${C.field("dimensionOffset","Distance from edge (m)",+(m.dimensionOffset || 0).toFixed(2),"number",'step="0.1"')}${C.choice("dimensionUnits","Units",{m:"Metres",mm:"Millimetres",ft:"Feet"},m.dimensionUnits || "m")}${C.choice("dimensionPrecision","Decimal places",{0:"0",1:"1",2:"2",3:"3"},String(m.dimensionPrecision ?? 2))}<p class="subtle">Snapped endpoints follow their objects when moved or rotated. A negative distance places the label on the other side.</p>${B("Add another dimension","dimensionTool",true)}${B("Delete dimension","editDelete")}`;
    if (m.type === "service") {
      const svc = C.SERVICES[m.serviceType] || {
          name: m.serviceType || "Service / constraint",
          color: "#71808a",
        },
        facts = [
          ["Source", m.source],
          ["Verification", m.verification],
          ["Operator", m.operator],
          ["Voltage", m.voltage],
          ["Reference", m.lineRef || m.ref],
          [
            "Captured",
            m.capturedAt ? new Date(m.capturedAt).toLocaleString() : null,
          ],
        ].filter(([, v]) => v !== undefined && v !== null && String(v).trim());
      return `<div class="selection-heading service-selection-heading"><small>SERVICE / CONSTRAINT</small><strong>${esc(m.label || svc.name)}</strong></div><div class="service-info-badge"><i style="background:${esc(S.project.serviceStyles?.[m.serviceType]?.color || svc.color)}"></i><div><small>${esc(svc.name)}</small><strong>Information</strong></div></div><dl class="service-info-list">${facts.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(String(v))}</dd></div>`).join("")}</dl><p class="service-guidance">${CAVEAT}</p>${B("Edit all " + svc.name + " appearance", "serviceStyle:" + m.serviceType, true)}${!m.planCommitted ? B("Keep on issued plan", "commitServiceToPlan") : ""}`;
    }
    const group = C.groupMembers(f),
      locked = group.some((x) => x.properties.locked),
      fixed = group.some(
        (x) => x.properties.dimensionLocked || x.properties.type === "panel",
      ),
      st = C.featureStyle({
        ...f,
        id: "__preview",
        properties: { ...m, groupId: null },
      });
    let h = `<div class="selection-heading"><small>${esc(m.type)}${group.length > 1 ? " · " + group.length + " objects" : ""}</small><strong>${esc(m.label || "Selected object")}</strong></div>${C.field("editLabel", "Name / label", m.label || "")}`;
    if (["note", "photo"].includes(m.type))
      h += `<label class="switch-row"><span>Show on issued drawing</span><input id="issuedDrawing" type="checkbox" ${m.includeOnDrawing ? "checked" : ""}></label>`;
    const editButton = (icon, label, action, disabled = false) =>
      `<button data-action="${action}" ${disabled ? 'disabled' : ''}>${icon}<span>${label}</span></button>`;
    h += `<div class="properties-actions labelled-actions">${editButton(ICONS.move, "Move", "editMove", locked)}${editButton(ICONS.rotate, "Rotate", "rotateProperties", locked)}${editButton(ICONS.duplicate, "Copy", "editDuplicate")}${editButton(group.length > 1 ? ICONS.ungroup : ICONS.group, group.length > 1 ? "Ungroup" : "Group", group.length > 1 ? "editUngroup" : "editGroup", locked)}${editButton(ICONS.points, "Edit points", "editVertices", locked || fixed || f.geometry.type === "Point" || !!m.sourceId)}${editButton(ICONS.bin, "Delete", "editDelete", locked)}</div>`;
    if (locked)
      h += `<div class="inline-note">This object is locked.</div>${B("Unlock", "toggleSelectedLock")}`;
    else
      h += `<section class="properties-section"><div class="section-title">Appearance</div><div class="property-grid"><label>Fill<input id="editStyleFill" type="color" value="${m.styleFill || st.fillColor || "#89919a"}"></label><label>Outline<input id="editStyleColor" type="color" value="${m.styleColor || st.color || "#56616a"}"></label></div>${C.choice("editStylePattern", "Fill pattern", { solid: "Solid", hatch: "Hatch", dots: "Dots", none: "None" }, m.stylePattern || "solid")}${C.field("editStyleWeight", "Outline width", m.styleWeight ?? st.weight ?? 1, "number", 'min="0" max="12" step="0.1"')}<label class="field-label" for="editStyleFillOpacity">Opacity</label><input id="editStyleFillOpacity" type="range" min="0" max="100" value="${Math.round((m.styleFillOpacity ?? st.fillOpacity ?? 0.7) * 100)}">${C.choice("editStyleDash", "Line style", { solid: "Solid", dash: "Dashed", dot: "Dotted" }, m.styleDash || "solid")}</section>`;
    if (
      !locked &&
      !fixed &&
      group.length === 1 &&
      f.geometry.type === "Polygon" &&
      ["shape", "asset", "logo"].includes(m.type)
    ) {
      const mt = base.shapeMetrics(f);
      h += details(
        "Dimensions",
        `<div class="property-grid">${C.field("shapeLength", "Length (m)", +mt.length.toFixed(3), "number", 'min="0.1" max="500" step="0.01"')}${C.field("shapeWidth", "Width (m)", +mt.width.toFixed(3), "number", 'min="0.1" max="500" step="0.01"')}</div>${C.field("shapeAngle", "Rotation (°)", +mt.angle.toFixed(2), "number", 'step="1"')}${B("Apply dimensions", "shapeDimensions")}`,
        "dimensions",
      );
    }
    if (fixed)
      h +=
        '<div class="inline-note">Fixed product dimensions. Move and rotate freely; stretching is locked.</div>';
    if (!locked && m.type === "asset")
      h += details(
        "Replace asset",
        C.choice(
          "replaceAsset",
          "Replace with",
          Object.fromEntries(
            Object.entries(C.ASSETS).map(([k, v]) => [k, v.name]),
          ),
          m.kind,
        ) + B("Replace selected asset", "replaceAsset"),
      );
    h += details(
      "Order & control",
      `<div class="button-pair">${B("To front", "frontSelected")}${B("To back", "backSelected")}</div>${B(locked ? "Unlock object" : "Lock object", "toggleSelectedLock")}${B("Object manager", "open:layers")}`,
    );
    if (
      (!locked &&
        ["Polygon", "MultiPolygon", "LineString", "MultiLineString"].includes(
          f.geometry.type,
        )) ||
      (!locked && ["panel", "asset", "logo"].includes(m.type))
    ) {
      const areaLike =
        ["Polygon", "MultiPolygon"].includes(f.geometry.type) ||
        ["panel", "asset", "logo"].includes(m.type);
      h += details(
        "Add to selected item",
        areaLike
          ? `<div class="button-pair">${B("Area", "extend:area")}${B("Draw area", "extend:freeArea")}</div><p class="subtle">Start and finish on the selected item. The addition is joined into the existing asset.</p>`
          : `<div class="button-pair">${B("Line", "extend:line")}${B("Draw line", "extend:freeLine")}</div><p class="subtle">Start on the selected line and draw the continuation.</p>`,
        "extend-selected",
      );
    }
    if (m.type === "accessPoint") h += B("Edit entrance details", "editAccess");
    if (m.type === "service" && !m.planCommitted)
      h += B("Keep on issued plan", "commitServiceToPlan", true);
    if (m.routeId && ["lion", "hybrid", "tuff"].includes(m.product))
      h += B(
        "Rebuild " + (C.PRODUCTS[m.product]?.name || "Trakway") + " width",
        "rebuildLion",
      );
    if (m.type === "panel" || (m.type === "asset" && ["lion", "hybrid", "tuff"].includes(m.product)))
      h += B("Add measurement annotation", "addAssetMeasurement", true);
    return h;
  }
  function panelLayersHTML(fs) {
    const products = {};
    for (const f of fs)
      (products[f.properties.product || "unknown"] ??= []).push(f);
    return Object.entries(products)
      .map(([product, panels]) => {
        const runs = {};
        for (const f of panels) {
          const k = f.properties.groupId || f.properties.routeId || f.id;
          (runs[k] ??= []).push(f);
        }
        const productName =
            C.PRODUCTS[product]?.name ||
            panels[0]?.properties.label ||
            "Trakway",
          panelCount = (n) => n + " panel" + (n === 1 ? "" : "s"),
          runRows = Object.values(runs)
            .reverse()
            .map((members, i) => {
              const f = members[0],
                gid = f.properties.groupId || f.id,
                guide = S.project.features.find(
                  (x) =>
                    x.properties.guideHidden && x.properties.groupId === gid,
                ),
                kind = guide?.properties?.type === "area" ? "Area" : "Run",
                active =
                  members.some((x) => x.id === S.selected) ||
                  C.selectedFeature()?.properties?.groupId === gid,
                hidden = members.every((x) => x.properties.hidden),
                locked = members.some((x) => x.properties.locked);
              return `<div class="object-row ${active ? "active" : ""}"><button data-action="select:${f.id}"><span>${kind} ${i + 1}</span><small>${panelCount(members.length)}</small></button>${tip(hidden ? "◯" : "◉", hidden ? "Show" : "Hide", "hideItem:" + f.id)}${tip(locked ? "▣" : "□", locked ? "Unlock" : "Lock", "lockItem:" + f.id)}</div>`;
            })
            .join("");
        return details(
          productName + " · " + panelCount(panels.length),
          runRows,
          "Trakway:" + product,
        );
      })
      .join("");
  }
  function layersHTML() {
    const groups = {},
      panels = [];
    for (const f of S.project.features.filter(
      (f) => !f.properties.guideHidden,
    )) {
      const m = f.properties;
      if (m.type === "panel") {
        panels.push(f);
        continue;
      }
      const key =
        m.type === "service"
          ? m.serviceType === "ohl"
            ? "OHL references"
            : "Utilities & constraints"
          : m.type === "ohlCable"
            ? "OHL committed"
            : ["note", "photo"].includes(m.type)
              ? "Field evidence"
              : m.type === "measure"
                ? "Dimensions"
                : m.type === "asset" || m.type === "logo"
                  ? "Structures & assets"
                  : "Shapes & annotations";
      (groups[key] ??= []).push(f);
    }
    const panelBlock = panels.length
      ? details(
          "Trakway · " + panels.length + " panels",
          panelLayersHTML(panels),
          "Trakway",
        )
      : "";
    const other = Object.entries(groups)
      .map(([name, fs]) =>
        details(
          name + " · " + fs.length,
          fs
            .slice()
            .reverse()
            .map(
              (f) =>
                `<div class="object-row ${S.selected === f.id ? "active" : ""}"><button data-action="select:${f.id}">${esc(f.properties.label || f.properties.type)}</button>${tip(f.properties.hidden ? "◯" : "◉", f.properties.hidden ? "Show" : "Hide", "hideItem:" + f.id)}${tip(f.properties.locked ? "▣" : "□", f.properties.locked ? "Unlock" : "Lock", "lockItem:" + f.id)}</div>`,
            )
            .join(""),
          name,
        ),
      )
      .join("");
    return (
      `<p class="subtle">Trakway is totalled by product. Expand a product only when you need a specific run or area.</p>${panelBlock}${other}` ||
      '<p class="subtle">No objects yet.</p>'
    );
  }
  function serviceStyleHTML(k, v, count = 0) {
    const q = S.project.serviceStyles?.[k] || {},
      baseColor = q.color || v.color || "#6f7b85",
      baseFill = q.fillColor || v.color || "#6f7b85",
      weight = q.weight ?? 1,
      dash = q.dash || (k === "ohl" ? "solid" : "dashed"),
      opacity = Math.round((q.opacity ?? 1) * 100),
      fillOpacity = Math.round((q.fillOpacity ?? 0.15) * 100);
    return `<div class="service-style-card"><div class="service-style-head"><i style="background:${baseColor}"></i><div><small>EDIT SERVICE APPEARANCE</small><strong>${esc(v.name)}</strong><span>${count} project ${count === 1 ? "record" : "records"} · changes apply to every ${esc(v.name)} item</span></div></div><div class="property-grid"><label>Line colour<input id="serviceStyleColor" type="color" value="${baseColor}"></label><label>Line width<input id="serviceStyleWeight" type="number" min="0.5" max="12" step="0.5" value="${weight}"></label></div>${C.choice("serviceStyleDash", "Line style", { solid: "Solid", dashed: "Dashed", dotted: "Dotted" }, dash)}<label class="field-label" for="serviceStyleOpacity">Line opacity <o>${opacity}%</o></label><input id="serviceStyleOpacity" type="range" min="5" max="100" value="${opacity}">${v.area ? `<div class="property-grid"><label>Fill colour<input id="serviceStyleFill" type="color" value="${baseFill}"></label><label>Fill opacity<input id="serviceStyleFillOpacity" type="range" min="0" max="80" value="${fillOpacity}"></label></div>` : ""}<div class="button-pair">${B("Reset", "resetServiceStyle:" + k)}${B("Apply to all", "applyServiceStyle:" + k, true)}</div></div>`;
  }
  function servicesHTML() {
    const counts = {};
    for (const f of S.project.features)
      if (f.properties.type === "service")
        counts[f.properties.serviceType] =
          (counts[f.properties.serviceType] || 0) + 1;
    const reference = new Set([
      "ohl",
      "electric",
      "gas",
      "water",
      "drainage",
      "telecom",
    ]);
    const ordered = Object.entries(C.SERVICES).sort(([a], [b]) =>
      a === "ohl" ? -1 : b === "ohl" ? 1 : (counts[b] || 0) - (counts[a] || 0),
    );
    if (!C.SERVICES[ui.serviceEditType]) ui.serviceEditType = "ohl";
    const statuses = Object.entries(S.project.serviceStatus || {}).map(([key,st]) => `<div class="source-status" data-state="${esc(st.status)}"><strong>${{ohl:"Overhead electricity",utilities:"Public utilities",constraints:"Planning constraints"}[key] || esc(key)}</strong><span>${esc(st.message || st.status)}</span>${st.checkedAt ? `<small>${new Date(st.checkedAt).toLocaleString("en-GB")}</small>` : ""}</div>`).join("");
    const tabs = `${statuses}<div class="segmented">${B("Show", "serviceMode:show", ui.serviceMode === "show")}${B("Add", "serviceMode:add", ui.serviceMode === "add")}${B("Edit", "serviceMode:edit", ui.serviceMode === "edit")}</div>`;
    if (ui.serviceMode === "edit") {
      const selected = ui.serviceEditType,
        v = C.SERVICES[selected];
      return `${tabs}<p class="subtle">Choose a service or constraint, then set one appearance for every item in that category. Tapping an item on the map opens its information instead of its styling controls.</p><div class="service-edit-list">${ordered.map(([k, x]) => `<button class="service-row service-edit-row ${selected === k ? "active" : ""}" data-action="serviceStyle:${k}"><i style="background:${S.project.serviceStyles?.[k]?.color || x.color}"></i><span>${esc(x.name)}<small>${counts[k] || 0} project records</small></span><b>›</b></button>`).join("")}</div>${serviceStyleHTML(selected, v, counts[selected] || 0)}<p class="service-guidance">${CAVEAT}</p>`;
    }
    return `${tabs}${ui.serviceMode === "show" ? `${B("↻ Refresh checked sources", "showServiceMapping", true)}<div class="button-pair">${B("Show all", "servicesShowAll")}${B("Hide all", "servicesHideAll")}</div><p class="subtle service-refresh-note">Checking a box shows or hides sources already loaded. Use Refresh to fetch the latest data for everything checked.</p>` : ""}${ordered.map(([k, v]) => (ui.serviceMode === "add" ? `<button class="service-row" data-action="addService:${k}"><i style="background:${v.color}"></i><span>${esc(v.name)}<small>Manual ${v.area ? "area" : "line"}</small></span><b>＋</b></button>` : `<label class="service-row"><input type="checkbox" data-service="${k}" ${S.project.serviceVisibility[k] ? "checked" : ""}><i style="background:${S.project.serviceStyles?.[k]?.color || v.color}"></i><span>${esc(v.name)}<small>${counts[k] ? counts[k] + " project records" : reference.has(k) ? (k === "ohl" ? "Mapped OHL intelligence · site + 0.5 mile" : "Public reference search · coverage varies") : "Constraint source · coverage varies"}</small></span></label>`)).join("")}${details("Data sources & import", B("Source catalogue", "servicesCatalogue") + B("Import survey / utility data", "dataPack"))}<p class="service-guidance">${CAVEAT}</p>`;
  }
  function vehicleSVG(k) {
    const artic = k === "artic40",
      van = k === "van35";
    return `<svg viewBox="0 0 100 46" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M8 33V${van ? 14 : 10}H${artic ? 66 : 60}V33H8 M${artic ? 72 : 60} 33V${van ? 14 : 18}H83L94 28V33Z"/><path d="M${artic ? 78 : 65} 20H82L89 27H${artic ? 78 : 65}Z"/><path d="M8 33H94"/>${[20, artic ? 51 : 53, artic ? 63 : 82, ...(artic ? [85] : [])].map((x) => `<circle cx="${x}" cy="35" r="5" fill="var(--panel)"/>`).join("")}</g></svg>`;
  }
  function routeHTML() {
    let html = base.routeToSiteHTML();
    const template = document.createElement("template");
    template.innerHTML = html;
    const select = template.content.querySelector("#hgvProfile");
    if (select) {
      const label = template.content.querySelector('[for="hgvProfile"]');
      if (label) label.remove();
      const grid = document.createElement("div");
      grid.className = "vehicle-grid";
      grid.innerHTML = Object.entries(C.HGV_PROFILES)
        .map(
          ([k, v]) =>
            `<button data-action="vehicle:${k}" aria-pressed="${S.project.hgv.profile === k}" class="${S.project.hgv.profile === k ? "active" : ""}" title="${esc(v.name)}">${vehicleSVG(k)}<strong>${{ van35: "Van", rigid75: "7.5 t rigid", rigid24: "Large rigid", artic40: "Articulated", custom: "Custom" }[k]}</strong><small>${v.weight} t · ${v.height} m</small></button>`,
        )
        .join("");
      select.hidden = true;
      select.before(grid);
    }
    const warning = template.content.querySelector(".warning-card");
    if (warning)
      warning.innerHTML =
        '<strong>Route suitability</strong><p class="subtle">Uses your actual dimensions and gross weight with the configured truck-routing service. Public routing is labelled as a reference preview. Check route restrictions and site access before travel.</p>';
    const first=template.content.querySelector('.route-endpoint');
    if(first) first.insertAdjacentHTML("beforebegin",`<div class="route-quick">${B("Use my location","routeCurrentLocation")}</div>`);
    const submit=template.content.querySelector('[data-action="planHgv"]');
    if(submit) { submit.disabled=!!S.routeBusy; submit.setAttribute("aria-busy",String(!!S.routeBusy)); }
    return template.innerHTML;
  }
  function backgroundHTML() {
    if (S.mode !== "plan") return '<div class="section-title">Map background</div><div class="button-pair">' + B("Street map","workspaceBase:street") + B("Satellite","workspaceBase:satellite") + '</div><p class="subtle">Find your site, then define an area to create a CAD drawing.</p>' + B("Define site area", "open:area");
    const suggested=window.SAMIProjectData.recommendedDetail(G.area(S.project.area),S.project.features.length);
    return `<div class="button-pair">${B("Map", "workspaceBase:street")}${B("Satellite", "workspaceBase:satellite")}${B("CAD", "workspaceBase:drawing")}</div><p class="subtle">Suggested detail: <strong>${suggested}</strong>, based on this site's size and object count.</p>${C.choice("cadDetail","CAD detail",{low:"Low · overview",medium:"Medium · standard",high:"High · detailed"},S.project.planDetail || "high")}${B("Use suggested detail","suggestCadDetail")}${C.field("cadBleed","Drawing bleed (metres)",S.project.planBleed ?? 10,"number",'min="0" max="200"')}<p class="subtle">${S.project.planBaseMeta?.capturedAt ? "Stored CAD snapshot: " + esc(new Date(S.project.planBaseMeta.capturedAt).toLocaleString("en-GB")) : "Capture a CAD background for this site."}</p>${B("Capture / refresh CAD detail", "capturePlanBase")}${B("Fit plan", "fitArea")}${B("Review & export", "review")}`;
  }
  const APPEARANCES = {
    graphite: {
      name: "Graphite Pro",
      note: "Neutral black and graphite studio.",
      theme: "#0b0d0f",
    },
    obsidian: {
      name: "Obsidian",
      note: "Near-black glass and deep chrome.",
      theme: "#050607",
    },
    carbon: {
      name: "Carbon",
      note: "Technical charcoal and steel.",
      theme: "#101316",
    },
    midnight: {
      name: "Midnight",
      note: "Deep blue-black command workspace.",
      theme: "#07101b",
    },
    titanium: {
      name: "Titanium",
      note: "Lighter gunmetal professional studio.",
      theme: "#181b1e",
    },
    blackout: {
      name: "Blackout",
      note: "True black, minimal chrome and maximum map contrast.",
      theme: "#000000",
    },
    navy: {
      name: "Deep Navy",
      note: "Naval blue surfaces with cool technical contrast.",
      theme: "#06101f",
    },
    slate: {
      name: "Slate",
      note: "Architectural blue-grey with quieter panels.",
      theme: "#17212a",
    },
    sandstone: {
      name: "Sandstone",
      note: "Warm graphite with restrained bronze surfaces.",
      theme: "#17130f",
    },
    arctic: {
      name: "Arctic Dark",
      note: "Cold graphite with pale steel controls.",
      theme: "#11171b",
    },
    studioLight: {
      name: "Studio Light",
      note: "Clean neutral light workspace with dark SAMI chrome.",
      theme: "#f3f5f4",
    },
    paper: {
      name: "Paper",
      note: "Warm drawing-board white with soft graphite controls.",
      theme: "#f5f1e8",
    },
    arcticLight: {
      name: "Arctic Light",
      note: "Cool architectural white with blue-grey structure.",
      theme: "#eef3f5",
    },
  };
  function currentAppearance() {
    return C.readPref("sami.appearance") || "graphite";
  }
  function currentAccent() {
    const x = C.readPref("sami.accent");
    return /^#[0-9a-f]{6}$/i.test(x || "") ? x : "#54d79a";
  }
  function applyAccent(value = currentAccent()) {
    if (!/^#[0-9a-f]{6}$/i.test(value)) value = "#54d79a";
    C.setPref("sami.accent", value);
    document.documentElement.style.setProperty("--accent", value);
    document.documentElement.style.setProperty(
      "--accent2",
      `color-mix(in srgb, ${value} 72%, #06100c)`,
    );
  }
  function applyAppearance(key = currentAppearance()) {
    if (!APPEARANCES[key]) key = "graphite";
    document.documentElement.dataset.theme = key;
    C.setPref("sami.appearance", key);
    applyAccent();
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = APPEARANCES[key].theme;
    const favicon = document.querySelector('link[rel="icon"]');
    if (favicon)
      favicon.href = window.SAMI_VERSION?.asset
        ? window.SAMI_VERSION.asset("sami-app-icon-192.png")
        : "sami-app-icon-192.png";
  }
  function appearanceHTML() {
    const current = currentAppearance(),
      accent = currentAccent(),
      presets = [
        "#54d79a",
        "#39b8ff",
        "#8f7dff",
        "#e6b755",
        "#ff6b61",
        "#d9e3ea",
      ];
    return `<p class="subtle">Themes change the whole workspace treatment. Accent colour is independent, so highlights can be yours.</p><div class="appearance-grid">${Object.entries(
      APPEARANCES,
    )
      .map(
        ([k, a]) =>
          `<button class="appearance-choice ${current === k ? "active" : ""}" data-action="appearance:${k}"><span class="appearance-swatch" data-swatch="${k}"></span><strong>${a.name}</strong><small>${a.note}</small>${current === k ? "<b>✓</b>" : ""}</button>`,
      )
      .join(
        "",
      )}</div><div class="section-title">Highlight colour</div><label class="accent-picker"><span>Selected accent</span><input id="appearanceAccent" type="color" value="${accent}"></label><div class="accent-presets">${presets.map((x) => `<button data-action="accent:${x}" style="--chip:${x}" aria-label="Use ${x}"></button>`).join("")}</div><div class="inline-note">Build v${esc(window.SAMI_VERSION?.version || document.documentElement.dataset.samiVersion || "2.7.14")} · Installed PWA icons can remain cached until the device refreshes the app.</div>`;
  }
  const LAYOUTS = {
    guided: ["Guided", "Clear next steps and a balanced workspace."],
    compact: ["Compact", "Narrow tools panel with more map space."],
    studio: ["Studio", "Wide properties panel for desktop drawing."],
    focus: ["Canvas focus", "Tools fold away when you start drawing."],
    touch: ["Touch", "Large controls and a bottom tools panel."],
    classic: ["Classic Pro", "Familiar left-side tools with the modern command dock."],
  };
  const WORKSPACE_PROFILES = {
    classic: {
      name: "Classic Pro",
      note: "Familiar left inspector, map controls and bottom command dock, with current touch targets and save feedback.",
      layout: "classic",
      appearance: "graphite",
      accent: "#54d79a",
    },
    studio: {
      name: "Studio Pro",
      note: "Right-side properties, persistent map styles and a focused desktop canvas.",
      layout: "studio",
      appearance: "graphite",
      accent: "#54d79a",
    },
    field: {
      name: "Field Tablet",
      note: "Bottom task sheet, high-contrast controls and generous touch targets.",
      layout: "touch",
      appearance: "arcticLight",
      accent: "#267a9b",
    },
    drafting: {
      name: "Paper Drafting",
      note: "Light drawing-board surfaces with a wide properties panel for review.",
      layout: "studio",
      appearance: "paper",
      accent: "#356f86",
    },
    focus: {
      name: "Canvas Focus",
      note: "A broad drawing surface with tools kept compact and close to the canvas.",
      layout: "focus",
      appearance: "carbon",
      accent: "#d1a34a",
    },
  };
  let adminUnlocked = false;
  function applyLayout(name) {
    if (!LAYOUTS[name]) name = "guided";
    document.documentElement.dataset.layout = name;
    C.setPref("sami.layout",name);
    requestAnimationFrame(() => S.map?.invalidateSize());
  }
  function applyWorkspaceProfile(key) {
    const profile = WORKSPACE_PROFILES[key];
    if (!profile) return false;
    applyAppearance(profile.appearance);
    applyAccent(profile.accent);
    applyLayout(profile.layout);
    C.setPref("sami.workspaceProfile", key);
    C.toast(profile.name + " workspace applied.");
    return true;
  }
  function adminHTML() {
    if (!adminUnlocked)
      return '<form id="adminLogin"><label class="field-label" for="adminPin">Admin code</label><input id="adminPin" class="field" type="password" inputmode="numeric" maxlength="4" autocomplete="off"><p id="adminError" role="status"></p><button class="primary" type="submit">Unlock interface options</button></form>';
    const selected = C.readPref("sami.layout") || "guided",
      selectedProfile = C.readPref("sami.workspaceProfile") || "";
    return (
      '<div class="stage-intro"><small>WORKSPACE DESIGN</small><h3>Choose a complete interface</h3><p class="subtle">Profiles apply a layout, appearance and accent together. They update this workspace immediately and never change project data.</p></div><div class="workspace-profile-grid">' +
      Object.entries(WORKSPACE_PROFILES)
        .map(
          ([key, profile]) =>
            `<button class="workspace-profile-choice ${selectedProfile === key ? "active" : ""}" data-action="workspaceProfile:${key}" aria-pressed="${selectedProfile === key}"><span class="workspace-profile-preview" data-profile="${key}" aria-hidden="true"><i></i><b></b><em></em></span><strong>${profile.name}</strong><small>${profile.note}</small><span class="workspace-profile-meta">${LAYOUTS[profile.layout][0]} · ${APPEARANCES[profile.appearance].name}</span></button>`,
        )
        .join("") +
      '</div><div class="section-title">Fine-tune layout</div><p class="subtle">Change the panel arrangement without changing your chosen theme.</p><div class="layout-choices">' +
      Object.entries(LAYOUTS)
        .map(
          ([key, [name, note]]) =>
            `<button class="layout-choice ${selected === key ? "active" : ""}" data-action="layout:${key}" aria-pressed="${selected === key}"><span class="layout-preview" data-preview="${key}"><i></i><b></b></span><strong>${name}</strong><small>${note}</small></button>`,
        )
        .join("") +
      '</div><p class="subtle">Change colours, contrast and highlight colour in Appearance.</p>' +
      B("Done", "adminDone")
    );
  }
  function chrome() {
    if (!ui.ready) return;
    const selected = S.mode;
    $$("[data-mode]").forEach((b) => {
      const on = b.dataset.mode === selected;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", String(on));
      if (on) b.setAttribute("aria-current", "step");
      else b.removeAttribute("aria-current");
      if (b.dataset.mode === "plan") {
        b.setAttribute("aria-disabled", String(!S.project.area));
        b.classList.toggle("unavailable", !S.project.area);
      }
    });
    document.body.dataset.stage = selected;
    $("#modeCaption").textContent = "";
    $("#editorSummary") && ($("#editorSummary").textContent = S.tool ? "Drawing · " + (S.options?.name || S.tool) : `${S.project.features.filter(f=>!f.properties.guideHidden && f.properties.type!=="service").length} objects · ${base.ui.snap ? "Snap on" : "Snap off"}`);
    $("#inspectorTabs").innerHTML =
      (TABS[selected] || TABS.map)
        .map(
          ([k, n]) =>
            `<button data-inspector="${k}" class="${ui.drawer === k ? "active" : ""}">${n}</button>`,
        )
        .join("") +
      `<button id="inspectorCollapse" aria-label="Collapse tools" title="Collapse tools"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg></button>`;
    $("#inspectorTabs").onclick = (e) => {
      const b = e.target.closest("[data-inspector]");
      if (b) openDrawer(b.dataset.inspector, true);
      if (e.target.closest("#inspectorCollapse")) closeDrawer(true);
    };
    $("#areaChip").textContent = S.project.area
      ? "⌗ Site area · " +
        Math.round(G.area(S.project.area)).toLocaleString() +
        " m²"
      : "＋ Define site area";
    $("#projectName").value = S.project.name;
    const commandBar = $("#primaryCommandBar");
    if (commandBar) commandBar.dataset.stage = selected;
    updateMapModeControls();
  }
  function openDrawer(k, reveal = false) {
    k = canonical(k);
    if (k === "assets" && C.ASSETS[base.ui.asset]) {
      ui.drawAsset = base.ui.asset;
      ui.assetFamily = C.ASSETS[base.ui.asset].category || "Site assets";
      ui.assetQuery = "";
      ui.drawMode = "place";
      k = "draw";
      reveal = true;
    }
    if (k === "create") {
      setMode("create");
      return;
    }
    ui.drawer = k;
    S.drawer = k;
    if (reveal) document.body.classList.remove("inspector-collapsed");
    const visible = !document.body.classList.contains("inspector-collapsed"),
      restore = $("#restoreInspector");
    if (restore) restore.hidden = visible;
    $("#drawer").classList.add("open");
    $("#drawer").inert = !visible;
    $("#drawer").setAttribute("aria-hidden", String(!visible));
    renderDrawer(k);
    chrome();
  }
  function closeDrawer(userCommand = false) {
    if (!userCommand) return;
    document.body.classList.add("inspector-collapsed");
    const restore = $("#restoreInspector");
    if (restore) restore.hidden = false;
    $("#drawer").inert = true;
    $("#drawer").setAttribute("aria-hidden", "true");
  }
  function hideDashboard() {
    const dash = $("#projectDashboard");
    if (dash) {
      dash.hidden = true;
      dash.style.display = "none";
    }
  }
  function referenceImageHTML() {
    const r = ui.reference;
    return `<p class="subtle">Use a satellite screenshot, map image or old plan. SAMI checks image location metadata first, then a configured visual matcher, then uses your nearest-place hint for assisted alignment.</p>
    <button data-action="chooseReferenceImage" class="primary">${r ? "Choose another image" : "Choose map / satellite image"}</button>
    ${
      r
        ? `<img class="reference-preview" src="${esc(r.dataUrl)}" alt="Reference map image"><label class="field-label">Is the site in the UK?<select class="field" id="referenceCountry"><option value="GB" ${r.country === "GB" ? "selected" : ""}>Yes · United Kingdom</option><option value="" ${!r.country ? "selected" : ""}>No / unknown</option></select></label><label class="field-label">Nearest known place (optional)<input class="field" id="referenceHint" value="${esc(r.hint || "")}" placeholder="Town, road, postcode, landmark"></label>
      <div class="reference-status">${r.gps ? `Embedded location found: ${r.gps[1].toFixed(6)}, ${r.gps[0].toFixed(6)}` : "No embedded GPS location found."}</div>
      <button data-action="matchReferenceImage" class="primary">Find this site</button>
      <div class="reference-controls"><label>Image rotation <output id="referenceRotationOut">${r.rotation || 0}°</o><input id="referenceRotation" type="range" min="0" max="359" value="${r.rotation || 0}"></label><label>Overlay opacity <output id="referenceOpacityOut">${Math.round((r.opacity ?? 0.55) * 100)}%</o><input id="referenceOpacity" type="range" min="10" max="100" value="${Math.round((r.opacity ?? 0.55) * 100)}"></label><label>Overlay scale <output id="referenceScaleOut">${Math.round((r.scale ?? 1) * 100)}%</o><input id="referenceScale" type="range" min="50" max="180" value="${Math.round((r.scale ?? 1) * 100)}"></label></div>
      <div class="row equal"><button data-action="overlayCurrentView">Fit overlay to current view</button><button data-action="removeReferenceOverlay">Hide overlay</button></div>
      <p class="subtle">Pan/zoom the live map, adjust rotation and opacity, then use “Fit overlay to current view” to re-register the reference image.</p>`
        : ""
    }`;
  }

  async function geocode(query, country = "GB") {
    const url =
      "https://nominatim.openstreetmap.org/search?format=json&limit=5" +
      (country
        ? "&countrycodes=" + encodeURIComponent(country.toLowerCase())
        : "") +
      "&q=" +
      encodeURIComponent(query);
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) throw Error("Place search is unavailable.");
    const data = await res.json();
    if (!data.length) throw Error("Place not found.");
    return data;
  }
  async function mapSearch() {
    const q = $("#mapExploreQuery")?.value.trim();
    if (!q) throw Error("Enter a place, address or postcode.");
    const d = await geocode(q, "GB");
    const x = d[0];
    S.map.setView([+x.lat, +x.lon], Math.max(17, S.map.getZoom()), {
      animate: false,
    });
    S.project.meta.siteAddress = x.display_name || q;
    C.saveSoon();
    C.toast("Site area found. Define the drawing space when ready.");
  }
  function useCurrentLocation() {
    navigator.geolocation?.getCurrentPosition(
      (p) => {
        S.map.setView([p.coords.latitude, p.coords.longitude], 18, {
          animate: false,
        });
        C.toast("Map centred on your location.");
      },
      () => C.toast("Current location is unavailable."),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    );
  }
  function imageDataUrl(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(r.error || Error("Image could not be read."));
      r.readAsDataURL(file);
    });
  }
  function getExifGps(buffer) {
    try {
      const v = new DataView(buffer);
      if (v.getUint16(0, false) !== 0xffd8) return null;
      let o = 2;
      while (o + 4 < v.byteLength) {
        if (v.getUint8(o) !== 0xff) {
          o++;
          continue;
        }
        const marker = v.getUint8(o + 1),
          len = v.getUint16(o + 2, false);
        if (marker === 0xe1 && len > 8) {
          const start = o + 4;
          if (
            String.fromCharCode(...new Uint8Array(buffer, start, 4)) === "Exif"
          ) {
            const t = start + 6,
              le = v.getUint16(t, false) === 0x4949,
              u16 = (p) => v.getUint16(p, le),
              u32 = (p) => v.getUint32(p, le),
              ifd0 = t + u32(t + 4),
              count = u16(ifd0);
            let gpsPtr = 0;
            for (let i = 0; i < count; i++) {
              const p = ifd0 + 2 + i * 12;
              if (u16(p) === 0x8825) {
                gpsPtr = u32(p + 8);
                break;
              }
            }
            if (!gpsPtr) return null;
            const gi = t + gpsPtr,
              gc = u16(gi),
              tags = {};
            for (let i = 0; i < gc; i++) {
              const p = gi + 2 + i * 12,
                tg = u16(p),
                type = u16(p + 2),
                n = u32(p + 4),
                valuePos =
                  n * (type === 5 ? 8 : type === 2 ? 1 : 4) > 4
                    ? t + u32(p + 8)
                    : p + 8;
              tags[tg] = { type, n, p: valuePos };
            }
            const ascii = (x) =>
              x ? String.fromCharCode(v.getUint8(x.p)) : "";
            const rationals = (x) => {
              if (!x) return null;
              const a = [];
              for (let i = 0; i < x.n; i++) {
                const p = x.p + i * 8,
                  a0 = u32(p),
                  b0 = u32(p + 4);
                a.push(b0 ? a0 / b0 : 0);
              }
              return a;
            };
            const lat = rationals(tags[2]),
              lon = rationals(tags[4]);
            if (!lat || !lon) return null;
            let la = lat[0] + lat[1] / 60 + lat[2] / 3600,
              lo = lon[0] + lon[1] / 60 + lon[2] / 3600;
            if (ascii(tags[1]).toUpperCase() === "S") la = -la;
            if (ascii(tags[3]).toUpperCase() === "W") lo = -lo;
            if (
              Number.isFinite(la) &&
              Number.isFinite(lo) &&
              Math.abs(la) <= 90 &&
              Math.abs(lo) <= 180
            )
              return [lo, la];
          }
        }
        if (!len || len < 2) break;
        o += 2 + len;
      }
    } catch {}
    return null;
  }
  async function chooseReferenceFile(file) {
    if (!file) return;
    if (!/^image\//.test(file.type)) throw Error("Choose an image file.");
    if (file.size > 20 * 1024 * 1024)
      throw Error("Use an image smaller than 20 MB.");
    const [dataUrl, buf] = await Promise.all([
      imageDataUrl(file),
      file.arrayBuffer(),
    ]);
    ui.reference = {
      file,
      dataUrl,
      gps: getExifGps(buf),
      country: "GB",
      hint: "",
      rotation: 0,
      opacity: 0.55,
      scale: 1,
    };
    openDrawer("image");
    if (ui.reference.gps) {
      const [lng, lat] = ui.reference.gps;
      S.map.setView([lat, lng], 18, { animate: false });
      setTimeout(() => showReferenceOverlay(), 100);
      C.toast("Embedded image location found. Check the overlay alignment.");
    }
  }
  function showReferenceOverlay(bounds) {
    const r = ui.reference;
    if (!r) return;
    referenceOverlay?.remove();
    referenceOverlay = L.imageOverlay(r.dataUrl, bounds || S.map.getBounds(), {
      opacity: r.opacity ?? 0.55,
      interactive: false,
      className: "sami-reference-image",
    }).addTo(S.map);
    updateReferenceOverlay();
  }
  function updateReferenceOverlay() {
    const r = ui.reference,
      el = referenceOverlay?.getElement?.();
    if (!r || !el) return;
    referenceOverlay.setOpacity(r.opacity ?? 0.55);
    el.style.rotate = (r.rotation || 0) + "deg";
    el.style.scale = String(r.scale || 1);
    el.style.transformOrigin = "50% 50%";
  }
  async function matchReferenceImage() {
    const r = ui.reference;
    if (!r) throw Error("Choose a reference image first.");
    r.country = $("#referenceCountry")?.value ?? r.country;
    r.hint = $("#referenceHint")?.value.trim() ?? r.hint;
    if (r.gps) {
      const [lng, lat] = r.gps;
      S.map.setView([lat, lng], 18, { animate: false });
      setTimeout(() => showReferenceOverlay(), 80);
      saveImageMatch([lng, lat], "Embedded image GPS", 1);
      return;
    }
    const endpoint =
      C.readPref("sami.imageMatch.url") ||
      window.SAMI_CONFIG?.siteImageMatchEndpoint;
    if (endpoint) {
      C.toast("Matching the reference image to map data…");
      const fd = new FormData();
      fd.append("image", r.file, r.file.name);
      fd.append("country", r.country || "");
      fd.append("hint", r.hint || "");
      const res = await fetch(endpoint, {
          method: "POST",
          body: fd,
          signal: AbortSignal.timeout(45000),
        }),
        data = await C.boundedJSON(res, 750000),
        best = data.best || data.candidates?.[0];
      if (!best || !Number.isFinite(+best.lat) || !Number.isFinite(+best.lng))
        throw Error("The image matcher did not return a usable location.");
      const coord = [+best.lng, +best.lat];
      r.rotation = Number.isFinite(+best.rotation)
        ? (+best.rotation + 360) % 360
        : r.rotation;
      S.map.setView([coord[1], coord[0]], Math.max(17, +best.zoom || 18), {
        animate: false,
      });
      setTimeout(() => showReferenceOverlay(), 100);
      saveImageMatch(
        coord,
        best.label || "Visual image match",
        +best.confidence || 0,
      );
      openDrawer("image");
      return;
    }
    if (r.hint) {
      const d = await geocode(r.hint, r.country),
        x = d[0],
        coord = [+x.lon, +x.lat];
      S.map.setView([coord[1], coord[0]], 18, { animate: false });
      setTimeout(() => showReferenceOverlay(), 100);
      saveImageMatch(coord, x.display_name || r.hint, 0);
      C.toast(
        "Nearest place found. Align the reference overlay to confirm the exact site.",
      );
      return;
    }
    showReferenceOverlay(S.map.getBounds());
    const c = C.coord(S.map.getCenter());
    saveImageMatch(c, "Manual alignment from current map view", 0);
    openDrawer("image");
    C.toast(
      "Automatic location was unavailable. The image is now registered over the current map so you can pan, rotate, scale and align it.",
    );
  }
  function saveImageMatch(coord, label, confidence) {
    S.project.meta.referenceImageMatch = {
      coord,
      label,
      confidence,
      matchedAt: new Date().toISOString(),
      rotation: ui.reference?.rotation || 0,
    };
    C.saveSoon();
  }

  function bindImageControls() {
    const r = ui.reference;
    if (!r) return;
    for (const [key, scale] of [
      ["Rotation", 1],
      ["Opacity", 0.01],
      ["Scale", 0.01],
    ])
      $("#reference" + key)?.addEventListener("input", (e) => {
        r[key.toLowerCase()] = +e.target.value * scale;
        $("#reference" + key + "Out").textContent =
          e.target.value + (key === "Rotation" ? "°" : "%");
        updateReferenceOverlay();
        S.project.reference = { ...r, file: undefined };
        C.saveSoon();
      });
  }
  function profilesHTML() {
    return (
      '<div class="card"><strong>Designer profiles</strong><p class="subtle">Reuse company, role, contact details and logos when preparing drawings. These are not sign-in accounts and do not share projects between devices.</p></div><div id="savedProfiles">Loading profiles…</div>' +
      B("Save current designer details", "saveProfile", true)
    );
  }
  async function loadProfiles() {
    try {
      const ps = await Store.profiles();
      if (!$("#savedProfiles")) return;
      $("#savedProfiles").innerHTML =
        ps
          .map(
            (p) =>
              `<button class="profile-row" data-action="profile:${p.id}"><strong>${esc(p.name)}</strong><small>${esc(p.meta.creator || "")} · ${esc(p.meta.jobTitle || "")}</small></button>`,
          )
          .join("") ||
        '<p class="subtle">No saved profiles yet. Complete your designer/company information in Designer first.</p>';
    } catch {
      C.toast("Profiles could not be opened on this device.");
    }
  }
  function settingsHTML() {
    return `<div class="section-title">Drawing assistance</div><label class="switch-row">Snap to geometry<input id="settingSnap" type="checkbox" ${base.ui.snap ? "checked" : ""}></label><label class="switch-row">Measurement grid snap<input id="settingGridSnap" type="checkbox" ${S.project.gridSnap !== false ? "checked" : ""}></label>${C.choice("settingGridStep", "Measurement grid", { 0.1: "0.10 m", 0.25: "0.25 m", 0.5: "0.50 m", 1: "1.00 m", 2: "2.00 m", 5: "5.00 m" }, String(S.project.gridStep || 0.5))}<p class="subtle">Measurements snap to object corners and edges first, then to the selected grid interval.</p><div class="section-title">Presentation</div><label class="switch-row">Prestige mode <small class="subtle">— shine &amp; motion on buttons and the intro</small><input id="settingPrestige" type="checkbox" ${C.readPref("sami.reducedMotion") === "on" ? "" : "checked"}></label><p class="subtle">Off = Simple mode: flat, instant, minimal motion — best for glare, older devices or battery life. Your device's own reduced-motion setting is always respected either way.</p><label class="switch-row">Function name bubbles<input id="settingTips" type="checkbox" ${ui.tooltips ? "checked" : ""}></label><div class="section-title">Location integration</div>${C.field("settingW3wKey", "what3words API key", C.readPref("sami.w3w.key") || "", "password", 'placeholder="Add your own key — leave blank to use the demo key"')}<p class="subtle">${C.readPref("sami.w3w.key") ? "Using your own what3words account." : window.SAMI_CONFIG?.what3wordsApiKey ? "Currently using the built-in demo what3words key. Add your own key above to use your account and quota instead." : "No what3words key configured yet. Coordinates and normal addresses still work without one."} <a href="https://what3words.com/select-plan" target="_blank" rel="noopener">Get your own what3words API key ↗</a></p><div class="section-title">Image recognition</div>${C.field("settingImageMatcher", "Visual image matcher HTTPS endpoint", C.readPref("sami.imageMatch.url") || window.SAMI_CONFIG?.siteImageMatchEndpoint || "", "url", 'placeholder="https://…/match-site-image"')}<p class="subtle">GPS metadata is used first. A connected matcher can identify image-only screenshots; without one, SAMI opens the image on the current map for manual registration instead of failing.</p><div class="section-title">Connected tools</div>${B("Voice & connected services", "open:voice")}${B("Save project file", "backup")}${B("Previous saved versions", "history")}`;
  }
  function helpHTML() {
    return `<h2>From site to drawing</h2><ol class="help-steps"><li>Complete <b>Project</b> details.</li><li>In <b>Map</b>, find the site and define the area.</li><li>Open <b>Site Plan</b>. Tap <b>Items</b> to choose an item, then choose <b>Run</b>, <b>Pad</b> or <b>Place</b> and press the drawing button.</li><li>Use <b>Finish</b> to commit a line or area. Tap an item to edit it. For dimensions, tap <b>Dimension</b>, pick two corners, then tap where the label should sit.</li><li>Open <b>Route</b>, then <b>Export</b> for the finished drawing pack.</li></ol>${details("Touch & drawing", "<p>Use two fingers to pan or zoom while drawing. Rotation starts locked; tap the N compass to unlock it, reset North or set a bearing. Drag a selected object or its centre handle to move; use ↻ to rotate. Adjustable assets have resize handles. Fixed Trakway panels retain their dimensions.</p><p>Freehand commits automatically when you lift your finger; freehand areas close back to their starting point. Point mode remains editable until you choose Finish, and Undo point removes the last point.</p>", "help-touch")}${details("Keyboard", "<p>V Select · M Dimension · P Place · L Line · A Area · F Freehand · S Snap · Ctrl/⌘ Z Undo · Ctrl/⌘ S Save · Escape Cancel</p>")}${details("Field evidence & services", "<p>Explore notes and photos are project evidence. Enable “Show on issued drawing” only for items you want in the PDF.</p><p>" + CAVEAT + "</p>")}${B("Guided first project", "tutorial")}${B("Why ask SAMI?", "sales")}`;
  }
  function validate() {
    const issues = [],
      m = S.project.meta;
    const add = (severity, text, action) =>
      issues.push({ severity, text, action });
    if (!S.project.name.trim() || /^Untitled/.test(S.project.name))
      add("warning", "Add a project title", "stage:project");
    if (!m.clientName) add("warning", "Add the client", "stage:project");
    if (!m.siteName && !m.siteAddress)
      add("warning", "Add the site name or address", "stage:project");
    if (!m.revision) add("warning", "Add a revision", "stage:project");
    if (!S.project.area) add("error", "Define the drawing area", "open:area");
    if (
      (S.tool && S.points.length) ||
      Object.values(ui.drafts).some((x) => x.points?.length)
    )
      add(
        "error",
        "Finish or cancel the active draft before issuing",
        "resumeDraft",
      );
    if (S.groupPick) add("error", "Finish the group selection", "finishGroup");
    if (S.project.features.some((f) => !G.validateFeature(f)))
      add(
        "error",
        "An object contains invalid geometry. Review the object manager.",
        "open:layers",
      );
    const sabre = S.project.features.filter(
      (f) => f.properties.product === "sabre" && f.properties.type === "panel",
    );
    if (sabre.some((f) => f.properties.sabreUnverified))
      add(
        "warning",
        "Sabre-X joint arrangement needs product-drawing verification",
        "open:layers",
      );
    if (S.project.hgv?.stale)
      add(
        "warning",
        "Vehicle details changed. Recalculate the route.",
        "stage:route",
      );
    if (S.project.hgv?.start && !S.project.routes?.length)
      add(
        "warning",
        "Complete the route, or issue the site page alone",
        "stage:route",
      );
    if (
      S.project.features.some(
        (f) =>
          f.properties.type === "service" || f.properties.type === "ohlCable",
      )
    )
      add("info", CAVEAT, "open:services");
    return issues;
  }
  function reviewHTML() {
    const issues = validate(),
      hard = issues.some((x) => x.severity === "error");
    return `<div class="stage-intro"><small>REVIEW / ISSUE</small><h2>Ready to share.</h2></div><p class="subtle">A brief check before the drawing leaves your device.</p>${issues.map((i) => `<div class="check-item ${i.severity}"><span>${i.severity === "error" ? "!" : i.severity === "warning" ? "△" : "ⓘ"}</span><div>${esc(i.text)}${i.severity !== "info" ? B("Review", i.action) : ""}</div></div>`).join("") || '<div class="check-item success">✓ Project checks passed.</div>'}<button class="primary" data-action="issue" ${hard ? "disabled" : ""}>${hard ? "Resolve required items" : "Continue to PDF options →"}</button><p class="subtle">${S.project.features.filter((f) => !f.properties.guideHidden).length} objects · ${S.project.routes?.length || 0} routes · saved metadata flows into your title block.</p>`;
  }
  function requestExport() {
    openDrawer("review", true);
  }
  function session() {
    return {
      mode: S.mode,
      selected: S.selected,
      tool: S.tool,
      points: copy(S.points || []),
      options: copy(S.options || {}),
      drafts: copy(ui.drafts),
      drawer: ui.drawer,
      collapsed: document.body.classList.contains("inspector-collapsed"),
      asset: ui.drawAsset,
      method: ui.drawMode,
      assetFamily: ui.assetFamily,
      categories: [...ui.category],
      measurement: {mode:ui.precision.mode, points:copy(ui.precision.points), showMeasurements:ui.precision.showMeasurements},
    };
  }
  async function save(checkpoint = false, label = "Autosave") {
    if (!ui.ready) return false;
    const sequence = ++saveSeq, badge = $("#saveState");
    S.project.session = session();
    if (S.mode === "plan") S.project.planView = captureView();
    else S.project.map = captureView();
    S.project.savedAt = new Date().toISOString();
    S.project.storageRevision = 1;
    badge.dataset.state = "saving";
    badge.textContent = "Saving…";
    try {
      await Store.save(S.project, { checkpoint, label });
      if (sequence === saveSeq) {
        badge.dataset.state = "saved";
        badge.textContent = "✓ Saved on this device";
      }
      return true;
    } catch (e) {
      badge.dataset.state = "failed";
      badge.textContent = "Save failed · download a backup";
      if (badge.isConnected) C.toast(
        "Device storage could not save this project. Use menu → Download project file.",
      );
      return false;
    }
  }
  async function loadProject(p) {
    ui.ready = false;
    S.areaGeneration++;
    S.routeRequest = (S.routeRequest || 0) + 1;
    S.routeBusy = false;
    S.planCaptureError = null;
    S.planCapturePromise = null;
    S.planCapturing = false;
    S.request?.abort?.();
    clearTimeout(S._ohlAutoRefresh);
    S.cache?.clear();
    if (ui.precision.active) setPrecision(false);
    S.routePick = null;
    S.multiSelection?.clear();
    C.cancelDraw();
    S.selected = null;
    S.vertexEditId = null;
    S.groupPick = null;
    S.project = normaliseProject(p);
    base.syncCatalogue();
    S.history = [];
    S.future = [];
    const saved = S.project.session || {};
    ui.drafts = saved.drafts || {};
    ui.precision.points = (saved.measurement?.points || []).filter(G.validCoord);
    ui.precision.mode = saved.measurement?.mode === "area" ? "area" : "line";
    ui.precision.showMeasurements = saved.measurement?.showMeasurements !== false;
    ui.drawAsset = saved.asset || "panel_lion";
    if (!currentAsset().name) ui.drawAsset = "panel_lion";
    ui.drawMode = saved.method || "line";
    ui.assetFamily = saved.assetFamily || "Trakway";
    ui.category = new Set(saved.categories || ["Trakway"]);
    S.mode = STAGES[saved.mode] ? saved.mode : "project";
    if (S.mode === "plan" && !S.project.area) S.mode = "map";
    S.project.meta.issueDate ||= new Date().toISOString().slice(0, 10);
    const savedMap = copy(
      S.mode === "plan" && S.project.planView
        ? S.project.planView
        : S.project.map,
    );
    S.map.setView(savedMap.center, savedMap.zoom, { animate: false });
    bearing.set(savedMap.bearing || 0, false);
    C.switchBase(S.mode === "plan" ? S.project.planBaseStyle : S.project.exploreBase, false);
    if (saved.tool) {
      S.tool = saved.tool;
      S.points = saved.points || [];
      S.options = saved.options || {};
      $("#drawStatus").hidden = false;
    }
    S.selected = S.project.features.some((f) => f.id === saved.selected)
      ? saved.selected
      : null;
    ui.reference = S.project.reference || null;
    referenceOverlay?.remove();
    referenceOverlay = null;
    if (ui.reference?.dataUrl && ui.reference?.bounds)
      showReferenceOverlay(ui.reference.bounds);
    ui.ready = true;
    window.dispatchEvent(new Event("sami:cadstatus"));
    document.body.classList.toggle("asset-creation-mode", S.mode === "create");
    $("#creatorWorkspace").hidden = S.mode !== "create";
    if (S.mode === "create") base.openCreator();
    C.snapshot(true);
    openDrawer(saved.drawer || TABS[S.mode][0][0], !saved.collapsed);
    if (saved.collapsed) closeDrawer(true);
    C.updateLock();
    C.render();
    if (S.tool) renderDraft();
    await save();
  }
  function normaliseProject(p) {
    const n = base.normaliseProject(p);
    n.padBearing = typeof p.padBearing === "number" && Number.isFinite(p.padBearing)
      ? ((p.padBearing % 360) + 360) % 360 : null;
    n.showAutoMeasurements = p.showAutoMeasurements === true;
    n.serviceStatus = {};
    for (const key of ["ohl", "utilities", "constraints"]) {
      const status = p.serviceStatus?.[key];
      if (status && ["ready", "empty", "retained", "error"].includes(status.status))
        n.serviceStatus[key] = {status:status.status, message:String(status.message || "").slice(0,1000), count:Math.max(0,+status.count || 0), checkedAt:String(status.checkedAt || "")};
    }
    n.snapEnabled = p.snapEnabled !== false;
    n.gridSnap = p.gridSnap !== false;
    n.gridStep = [0.1, 0.25, 0.5, 1, 2, 5].includes(+p.gridStep)
      ? +p.gridStep
      : 0.5;
    n.serviceStyles =
      n.serviceStyles && typeof n.serviceStyles === "object"
        ? n.serviceStyles
        : {};
    n.session =
      p.session && typeof p.session === "object" ? copy(p.session) : {};
    if (p.reference?.dataUrl && p.reference.dataUrl.length < 8000000)
      n.reference = copy(p.reference);
    return n;
  }
  function preview(p) {
    const fs = (p.features || [])
      .filter((f) => !f.properties.guideHidden)
      .slice(0, 400);
    let bounds = p.area;
    if (!bounds && fs.length) {
      const bs = fs.map((f) => G.boundsOf(f.geometry)).filter(Boolean);
      if (bs.length)
        bounds = [
          Math.min(...bs.map((b) => b[0])),
          Math.min(...bs.map((b) => b[1])),
          Math.max(...bs.map((b) => b[2])),
          Math.max(...bs.map((b) => b[3])),
        ];
    }
    if (!bounds)
      return '<svg viewBox="0 0 240 130"><path d="M20 85L65 85V45H120V70H180V30H225M65 45V15M120 70V110" fill="none" stroke="#3b6051"/></svg>';
    const w = bounds[2] - bounds[0] || 1,
      h = bounds[3] - bounds[1] || 1,
      xy = (q) =>
        [
          ((q[0] - bounds[0]) / w) * 200 + 20,
          115 - ((q[1] - bounds[1]) / h) * 100,
        ].join(",");
    return `<svg viewBox="0 0 240 130">${fs
      .filter((f) => ["LineString", "Polygon"].includes(f.geometry.type))
      .map(
        (f) =>
          `<${f.geometry.type === "Polygon" ? "polygon" : "polyline"} points="${(f.geometry.type === "Polygon" ? f.geometry.coordinates[0] : f.geometry.coordinates).map(xy).join(" ")}" fill="${f.geometry.type === "Polygon" ? "#345849" : "none"}" stroke="#64b58b" stroke-width=".7"/>`,
      )
      .join("")}</svg>`;
  }
  async function dashboard() {
    await save();
    let el = $("#projectDashboard");
    if (!el) {
      el = document.createElement("section");
      el.id = "projectDashboard";
      el.className = "project-dashboard";
      $("#app").append(el);
    }
    el.hidden = false;
    el.style.display = "";
    let rows = [];
    try {
      rows = await Store.list();
    } catch {
      C.toast(
        "Recent projects could not be loaded. You can open a saved .sami file.",
      );
    }
    const draw = (q) => {
      const list = rows.filter((p) =>
        (
          p.name +
          " " +
          (p.meta?.clientName || "") +
          " " +
          (p.meta?.siteRef || "")
        )
          .toLowerCase()
          .includes(q.toLowerCase()),
      );
      $("#recentProjects").innerHTML =
        list
          .map(
            (p) =>
              `<button class="project-card" data-open-project="${esc(p.id)}"><span class="project-miniature">${preview(p)}</span><strong>${esc(p.name)}</strong><span>${esc(p.meta?.clientName || "Local project")} · ${esc(p.meta?.siteRef || "")}</span><small>${new Date(p.savedAt).toLocaleString()} · ${p.features?.length || 0} objects</small></button>`,
          )
          .join("") ||
        '<p class="subtle">Your saved projects will appear here.</p>';
    };
    el.innerHTML = `<header><img src="sami-wordmark.png" alt="SAMI"><button data-action="resumeProject">Back to workspace →</button></header><div class="dashboard-intro"><small>YOUR FIELD WORKSPACE</small><h1>Clarity starts here.</h1><p>One project. From the first site visit to the issued plan.</p><div class="button-pair">${B("＋ New project", "newProject", true)}${B("Open project file", "openProject")}</div></div><div class="recent-heading"><h2>Recent projects</h2><input id="projectSearch" placeholder="Search projects" aria-label="Search projects"></div><div id="recentProjects" class="recent-grid"></div><footer>Private local workspace · projects stay on this device unless you deliberately export them. Cloud accounts and sharing require the connected SAMI workspace service.</footer>`;
    draw("");
    $("#projectSearch").oninput = (e) => draw(e.target.value);
    el.onclick = async (e) => {
      const id = e.target.closest("[data-open-project]")?.dataset.openProject;
      if (id) {
        const p = await Store.get(id);
        if (p) {
          await save();
          await loadProject(p);
          el.hidden = true;
        }
        return;
      }
      const a = e.target.closest("[data-action]")?.dataset.action;
      if (a) runAction(a);
    };
  }
  async function newProject() {
    if (!(await save(true, "Before new project"))) {
      C.toast("The current project was not replaced because it could not be saved.");
      return false;
    }
    const p = base.fresh();
    p.id = projectId();
    p.name = "Untitled project";
    p.session = { mode: "project" };
    await loadProject(p);
    hideDashboard();
    setMode("project");
    document.activeElement?.blur?.();
    return true;
  }
  async function history() {
    const rows = await Store.history(S.project.id);
    C.showModal(
      "Previous saved states",
      `<p class="subtle">Restoring a state keeps a checkpoint of your current project.</p>${rows.map((v) => `<button class="history-row" data-version="${esc(v.key)}"><strong>${esc(v.label)}</strong><span>${new Date(v.savedAt).toLocaleString()}</span><small>${v.project.features?.length || 0} objects</small></button>`).join("") || "<p>No checkpoints yet.</p>"}`,
    );
    $("#modalBody").onclick = async (e) => {
      const key = e.target.closest("[data-version]")?.dataset.version;
      if (!key) return;
      await save(true, "Before restore");
      const p = await Store.restore(key);
      C.closeModal();
      await loadProject(p);
      C.toast("Previous saved state restored.");
    };
  }
  function menu() {
    const el = $("#globalMenu"),
      open = el.hidden;
    el.hidden = !open;
    document.body.classList.toggle("global-menu-open", open);
    $("#menuButton").setAttribute("aria-expanded", String(open));
    if (open) el.querySelector("button")?.focus();
  }
  function tutorial() {
    C.showModal(
      "Your first SAMI project",
      `<div class="tutorial"><span class="tutorial-number">01 → 05</span>${helpHTML()}${B("Find my site", "tutorialStart", true)}</div>`,
    );
    $("#modalBody").onclick = (e) => {
      const a = e.target.closest("[data-action]")?.dataset.action;
      if (a === "tutorialStart") {
        C.closeModal();
        setMode("map");
        openDrawer("explore");
        $("#mapExploreQuery")?.focus();
      } else if (a) runAction(a);
    };
    C.setPref("sami.tutorial.seen", "yes");
  }
  function setSnap(on) {
    base.ui.snap = on;
    S.options.snap = on;
    S.project.snapEnabled = on;
    $("#snapToggle").setAttribute("aria-pressed", String(on));
    $("#snapToggle").classList.toggle("active", on);
    C.saveSoon();
  }
  function rotateProperties() {
    const f = C.selectedFeature();
    if (!f || C.groupMembers(f).some((x) => x.properties.locked)) return;
    C.showModal(
      "Rotate selection",
      C.field("rotationValue", "Rotate by degrees", 0, "number", 'step="1"') +
        B("Rotate", "applyRotation", true),
    );
    $("#modalBody").onclick = (e) => {
      if (!e.target.closest('[data-action="applyRotation"]')) return;
      const a = +$("#rotationValue").value;
      if (!Number.isFinite(a)) return;
      C.rotateMembers(C.groupMembers(f), C.featureCenter(f), a);
      C.closeModal();
      C.commit();
    };
  }
  function renderDrawer(k) {
    k = canonical(k);
    ui.drawer = k;
    S.drawer = k;
    const box = $("#drawerContent");
    const functions = {
      draw: () => libraryHTML(false),
      place: () => libraryHTML(true),
      assets: () => libraryHTML(true),
      explore: exploreHTML,
      area: areaHTML,
      details: projectHTML,
      designer: designerHTML,
      appearance: appearanceHTML,
      admin: adminHTML,
      selection: selectionHTML,
      layers: layersHTML,
      services: servicesHTML,
      routeToSite: routeHTML,
      background: backgroundHTML,
      image: referenceImageHTML,
      profiles: profilesHTML,
      settings: settingsHTML,
      help: helpHTML,
      review: reviewHTML,
      builder: () =>
        '<p class="subtle">Use the shape builder controls beside the canvas.</p>',
    };
    if (functions[k]) {
      box.innerHTML = functions[k]();
      const next = {explore:["Continue to Site Plan →","stage:plan"],routeToSite:["Review & export →","stage:review"]}[k];
      if (next && (k !== "explore" || S.project.area)) box.innerHTML += '<div class="workflow-next">' + B(next[0], next[1], true) + '</div>';
      $("#drawerTitle").textContent =
        {
          draw: "Item library",
          place: "Place",
          details: "Project details",
          designer: "Designer details",
          appearance: "Appearance",
          admin: "Admin",
          explore: "Find site",
          area: "Site area",
          selection: "Properties",
          layers: "Objects",
          services: "Services",
          routeToSite: "Route to site",
          image: "Image locate",
          profiles: "Designer profiles",
          review: "Review & export",
          settings: "Settings",
          help: "Help",
          background: "Style",
        }[k] || k;
    } else base.renderDrawer(k);
    box.onclick = (e) => {
      const b = e.target.closest("[data-action]");
      if (b) {
        e.stopPropagation();
        runAction(b.dataset.action, b);
      }
    };
    bindDrawer(k);
    chrome();
  }
  function bindDrawer(k) {
    if (k === "admin" && $("#adminLogin")) $("#adminLogin").onsubmit = e => {
      e.preventDefault();
      if ($("#adminPin").value === "8241") { adminUnlocked = true; renderDrawer("admin"); }
      else $("#adminError").textContent = "Incorrect code. Try again.";
    };
    if (k === "background" && $("#cadDetail")) {
      $("#cadDetail").onchange = e => { S.project.planDetail=e.target.value; C.commit(); renderDrawer("background"); };
      $("#cadBleed").onchange = e => { S.project.planBleed=Math.max(0,Math.min(200,+e.target.value || 0)); S.project.planBaseMeta={...S.project.planBaseMeta,stale:true}; C.commit(); };
    }
    $$("#drawerContent [data-section]").forEach(
      (el) =>
        (el.ontoggle = () =>
          el.open
            ? ui.category.add(el.dataset.section)
            : ui.category.delete(el.dataset.section)),
    );
    if (k === "details") {
      const name = $("#detailsName");
      name.oninput = () => {
        S.project.name = name.value.trim() || "Untitled site";
        $("#projectName").value = S.project.name;
        C.saveSoon();
      };
      for (const [key] of PROJECT_FIELDS)
        $("#meta_" + key).oninput = (e) => {
          S.project.meta[key] = e.target.value;
          C.saveSoon();
        };
      $("#projectNotes").oninput = (e) => {
        S.project.meta.siteNotes = e.target.value;
        C.saveSoon();
      };
    }
    if (k === "designer")
      for (const [key] of DESIGNER_FIELDS)
        $("#meta_" + key).oninput = (e) => {
          S.project.meta[key] = e.target.value;
          C.saveSoon();
        };
    if (["draw", "place", "assets"].includes(k)) {
      $("#assetFamily")?.addEventListener("change", (e) => {
        ui.assetFamily = e.target.value;
        ui.assetQuery = "";
        renderDrawer(k);
      });
      $("#assetSearch")?.addEventListener("input", (e) => {
        ui.assetQuery = e.target.value;
        const q = e.target.value.trim().toLowerCase();
        let count = 0;
        $$(".asset-grid .asset-tile").forEach((tile) => {
          const show = q ? (tile.dataset.search || "").includes(q) : (ui.assetFamily === "Favourites" ? ui.favourites.has(tile.dataset.action.slice(7)) : tile.dataset.family === ui.assetFamily);
          tile.hidden = !show;
          if (show) count++;
        });
        const label = $("#assetVisibleCount");
        if (label) label.textContent = count + (count === 1 ? " item" : " items");
        const heading=$(".asset-family-heading strong"),empty=$(".library-empty");
        if(heading)heading.textContent=q ? "Search results" : ui.assetFamily;
        if(empty)empty.hidden=count>0;
      });
      for (const id of ["customAssetLength","customAssetWidth"]) $("#"+id)?.addEventListener("change",()=>{
        const asset=C.ASSETS[ui.drawAsset];if(!asset || asset.dimensionLocked!==false)return;
        const length=Number($("#customAssetLength").value),width=Number($("#customAssetWidth").value);
        if(!(length>=.1 && length<=500 && width>=.1 && width<=500)){C.toast("Enter dimensions between 0.1 and 500 metres.");return;}
        Object.assign(asset,{length,width});C.saveSoon();
      });
      $("#repeatGap")?.addEventListener("change",e=>{S.project.assetGap=Math.max(0,Math.min(100,+e.target.value||0));C.saveSoon();});
      const setPadBearing = (bearing) => {
        S.project.padBearing = bearing;
        if (["panelAreaPoints", "panelAreaFreehand"].includes(S.tool))
          S.options.padBearing = bearing;
        C.saveSoon();
      };
      const bearingInput = $("#padBearing"), bearingChoice = $("#padOrientation");
      if (bearingInput) bearingInput.disabled = S.project.padBearing == null;
      bearingChoice?.addEventListener("change", (e) => {
        const value = e.target.value;
        const bearing = value === "auto" ? null : value === "north" ? 0 : value === "east" ? 90 : S.project.padBearing ?? 0;
        setPadBearing(bearing);
        bearingInput.disabled = bearing == null;
        bearingInput.value = bearing ?? 0;
      });
      bearingInput?.addEventListener("change", () => {
        const raw = Number(bearingInput.value);
        if (!bearingInput.value.trim() || !Number.isFinite(raw)) { bearingInput.value = S.project.padBearing ?? 0; return; }
        const bearing = ((raw % 360) + 360) % 360;
        bearingInput.value = bearing;
        bearingChoice.value = bearing === 0 ? "north" : bearing === 90 ? "east" : "custom";
        setPadBearing(bearing);
      });
      $("#workspaceLanes")?.addEventListener("change", (e) => {
        S.project.route.lanes = +e.target.value;
        if (S.tool) activateAsset();
        C.saveSoon();
      });
      $("#sabreJoint")?.addEventListener("change", (e) => {
        S.project.route.jointSpacingMm = +e.target.value;
        S.project.route.jointVerified = false;
        renderDrawer(k);
        C.saveSoon();
      });
      $("#sabreVerified")?.addEventListener("change", (e) => {
        S.project.route.jointVerified = e.target.checked;
        C.saveSoon();
        if (S.tool) activateAsset();
      });
      base.bindAssetPaletteDrag?.();
    }
    if (k === "selection") {
      for (const key of ["dimensionOffset","dimensionUnits","dimensionPrecision"])
        $("#"+key)?.addEventListener("change",e=>{
          const f=C.selectedFeature(); if(!f) return;
          f.properties[key]=key === "dimensionUnits" ? e.target.value : Number(e.target.value);
          C.commit();
        });
      const f = C.selectedFeature();
      if (!f) return;
      $("#editLabel").onchange = (e) => {
        f.properties.label = e.target.value;
        if (["note", "textBox"].includes(f.properties.type))
          f.properties.text = e.target.value;
        C.commit();
      };
      $("#issuedDrawing")?.addEventListener("change", (e) => {
        f.properties.includeOnDrawing = e.target.checked;
        C.commit();
      });
      for (const id of [
        "editStyleFill",
        "editStyleColor",
        "editStylePattern",
        "editStyleWeight",
        "editStyleFillOpacity",
        "editStyleDash",
      ])
        $("#" + id)?.addEventListener("input", applyStyle);
    }
    if (k === "services")
      // Checkboxes only toggle visibility of sources already loaded into
      // the project; fetching fresh data happens only when the user taps
      // "Refresh checked sources" (see servicesHTML), so toggling several
      // boxes quickly never fires overlapping network refresh cycles.
      $$("[data-service]").forEach(
        (el) =>
          (el.onchange = () => {
            S.project.serviceVisibility[el.dataset.service] = el.checked;
            S.project.serviceVisibilityConfigured = true;
            C.commit();
          }),
      );
    if (k === "routeToSite") base.bindDrawer(k);
    if (k === "explore") {
      const search = $("#mapExploreQuery");
      if (search) {
        search.readOnly = true;
        search.inputMode = "none";
        search.autocomplete = "off";
        search.blur();
        search.addEventListener(
          "pointerdown",
          () => {
            search.readOnly = false;
            search.inputMode = "search";
          },
          { once: true },
        );
        search.onkeydown = (e) => {
          if (search.readOnly && (e.key === "Enter" || e.key.length === 1)) {
            search.readOnly = false;
            search.inputMode = "search";
          }
          if (e.key === "Enter") runAction("mapSearch");
        };
      }
    }
    if (k === "image") bindImageControls();
    if (k === "profiles") loadProfiles();
    if (k === "settings") {
      for (const [id, key] of [
        ["settingSnap", "snap"],
        ["settingPrestige", "prestige"],
        ["settingTips", "tips"],
      ])
        $("#" + id).onchange = (e) => {
          if (key === "snap") setSnap(e.target.checked);
          if (key === "prestige") {
            C.setPref("sami.reducedMotion", e.target.checked ? "off" : "on");
            document.documentElement.dataset.reducedMotion = e.target.checked
              ? "off"
              : "on";
          }
          if (key === "tips") ui.tooltips = e.target.checked;
        };
      $("#settingGridSnap")?.addEventListener("change", (e) => {
        S.project.gridSnap = e.target.checked;
        C.saveSoon();
      });
      $("#settingGridStep")?.addEventListener("change", (e) => {
        S.project.gridStep = +e.target.value;
        C.saveSoon();
      });
      $("#settingW3wKey")?.addEventListener("change", (e) =>
        C.setPref("sami.w3w.key", e.target.value.trim()),
      );
      $("#settingImageMatcher")?.addEventListener("change", (e) =>
        C.setPref("sami.imageMatch.url", e.target.value.trim()),
      );
    }
    if (k === "appearance")
      $("#appearanceAccent")?.addEventListener("input", (e) =>
        applyAccent(e.target.value),
      );
    if (
      ![
        "draw",
        "place",
        "assets",
        "details",
        "designer",
        "appearance",
        "selection",
        "services",
        "routeToSite",
        "explore",
        "area",
        "image",
        "profiles",
        "settings",
        "help",
        "review",
        "background",
        "builder",
      ].includes(k)
    )
      base.bindDrawer(k);
  }
  function applyStyle() {
    const f = C.selectedFeature();
    if (!f || C.groupMembers(f).some((x) => x.properties.locked)) return;
    const values = {
      styleFill: $("#editStyleFill").value,
      styleColor: $("#editStyleColor").value,
      stylePattern: $("#editStylePattern").value,
      styleWeight: +$("#editStyleWeight").value,
      styleFillOpacity: +$("#editStyleFillOpacity").value / 100,
      styleDash: $("#editStyleDash").value,
    };
    for (const x of C.groupMembers(f).filter((x) => !x.properties.guideHidden))
      Object.assign(x.properties, values, { recolourParts: true });
    C.commit();
  }
  function featureStyle(f) {
    const st = base.featureStyle(f),
      m = f.properties;
    if (m.styleWeight != null) st.weight = +m.styleWeight;
    if (m.styleFillOpacity != null) st.fillOpacity = +m.styleFillOpacity;
    if (m.stylePattern === "none") st.fillOpacity = 0;
    if (m.type === "service") {
      const q = S.project.serviceStyles?.[m.serviceType];
      if (q) {
        if (q.color) st.color = q.color;
        if (Number.isFinite(+q.weight)) st.weight = +q.weight;
        if (q.dash === "solid") delete st.dashArray;
        else if (q.dash === "dashed") st.dashArray = "10 6";
        else if (q.dash === "dotted") st.dashArray = "2 5";
        if (Number.isFinite(+q.opacity)) st.opacity = +q.opacity;
        if (q.fillColor) st.fillColor = q.fillColor;
        if (Number.isFinite(+q.fillOpacity)) st.fillOpacity = +q.fillOpacity;
      }
    }
    st.smoothFactor = 0;
    st.lineJoin = "miter";
    st.lineCap = "butt";
    return st;
  }
  function paintPatterns() {
    if (!S.map) return;
    const svg = S.map.getPanes().overlayPane.querySelector("svg");
    if (!svg) return;
    let defs = svg.querySelector("defs.sami-patterns");
    if (!defs) {
      defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
      defs.classList.add("sami-patterns");
      svg.prepend(defs);
    }
    defs.replaceChildren();
    for (const f of S.project.features) {
      const m = f.properties;
      if (
        !["hatch", "dots"].includes(m.stylePattern) ||
        m.fillEnabled === false
      )
        continue;
      const id = "pat-" + String(f.id).replace(/[^a-z0-9]/gi, ""),
        color = m.styleFill || m.styleColor || "#88929a",
        p = document.createElementNS("http://www.w3.org/2000/svg", "pattern");
      p.id = id;
      p.setAttribute("width", "10");
      p.setAttribute("height", "10");
      p.setAttribute("patternUnits", "userSpaceOnUse");
      p.innerHTML =
        m.stylePattern === "dots"
          ? `<circle cx="5" cy="5" r="1.1" fill="${color}"/>`
          : `<path d="M-2 2L2-2M0 10L10 0M8 12L12 8" fill="none" stroke="${color}" stroke-width=".8"/>`;
      defs.append(p);
      S.layers.get(f.id)?.eachLayer((l) => {
        const path = l.getElement?.();
        if (path) {
          path.setAttribute("fill", "url(#" + id + ")");
          path.setAttribute("fill-opacity", String(m.styleFillOpacity ?? 0.8));
        }
      });
    }
  }
  function render() {
    base.render();
    paintPatterns();
    chrome();
    if (S.tool && !S.freehandActive) renderDraft();
    if (ui.ready) {
      const f = C.selectedFeature(),
        bar = $("#selectionBar"),
        groupMode = !!S.groupPick;
      // Selecting an object opens the single editing surface. The old floating
      // Properties button is hidden, so selection must not leave controls stranded.
      const inspected = f && !S.tool && !groupMode ? f.id : null;
      if (inspected && inspected !== ui.inspectedId && f.properties.type !== "service")
        openDrawer("selection", true);
      ui.inspectedId = inspected;
      bar.classList.toggle("group-picking", groupMode);
      document.body.classList.toggle("group-picking-active", groupMode);
      bar.hidden = groupMode ? false : !f || !!S.tool;
      if (groupMode) {
        const count = S.project.features.filter(
          (x) =>
            x.properties?.groupId === S.groupPick.groupId &&
            !x.properties?.guideHidden,
        ).length;
        $("#selectionName").textContent = "Group selection";
        $("#selectionCount").textContent =
          count + " selected · tap items to add/remove";
        bar
          .querySelectorAll("[data-group-normal]")
          .forEach((x) => (x.hidden = true));
        bar
          .querySelectorAll("[data-group-pick]")
          .forEach((x) => (x.hidden = false));
      } else {
        bar
          .querySelectorAll("[data-group-normal]")
          .forEach((x) => (x.hidden = false));
        bar
          .querySelectorAll("[data-group-pick]")
          .forEach((x) => (x.hidden = true));
        if (f) {
          const fixed = C.groupMembers(f).some(
            (x) =>
              x.properties.dimensionLocked || x.properties.type === "panel",
          );
          bar.querySelector('[data-action="editVertices"]').disabled =
            fixed || f.geometry.type === "Point" || !!f.properties.sourceId;
          bar.querySelector('[data-action="editGroup"]').hidden =
            C.groupMembers(f).length > 1;
          bar.querySelector('[data-action="editUngroup"]').hidden =
            C.groupMembers(f).length <= 1;
        }
      }
    }
  }
  function captureView() {
    const c = S.map.getCenter();
    return {
      center: { lat: c.lat, lng: c.lng },
      zoom: S.map.getZoom(),
      bearing: bearing?.get?.() || 0,
    };
  }
  function applyView(v) {
    if (!v?.center) return;
    bearing?.set(v.bearing || 0, false);
    S.map.setView(v.center, v.zoom || 16, { animate: false });
    requestAnimationFrame(() => bearing?.resize?.());
  }

  function boundsFromFrame(frame) {
    return frame?.length
      ? [
          Math.min(...frame.map((p) => p[0])),
          Math.min(...frame.map((p) => p[1])),
          Math.max(...frame.map((p) => p[0])),
          Math.max(...frame.map((p) => p[1])),
        ]
      : null;
  }
  function syncPlanFromCurrentView(renderNow = false) {
    if (S.mode !== "plan" || !S.project.area) return;
    S.project.planView = captureView();
    C.saveSoon();
    if (renderNow) C.render();
    chrome();
  }
  function setMode(mode) {
    if (!STAGES[mode]) return false;
    hideDashboard();
    if (mode === "plan" && !S.project.area) {
      C.showModal(
        "Define the site plan area",
        "<p>Define the site plan area before opening Site Plan.</p>" +
          B("Define site area", "goDefine", true),
      );
      $("#modalBody").onclick = (e) => {
        if (e.target.closest('[data-action="goDefine"]')) {
          C.closeModal();
          setMode("map");
          openDrawer("area");
        }
      };
      return false;
    }
    if (ui.precision.active) setPrecision(false);
    S.routePick = null;
    S.routeRequest = (S.routeRequest || 0) + 1;
    S.routeBusy = false;
    if (S.tool)
      ui.drafts[S.mode] = {
        tool: S.tool,
        points: copy(S.points),
        options: copy(S.options),
      };
    else delete ui.drafts[S.mode];
    if (S.mode === "plan" && !S.areaViewPending) S.project.planView = captureView();
    else if (S.mode === "map") S.project.map = captureView();
    C.cancelDraw();
    S.mode = mode;
    C.switchBase(mode === "plan" ? S.project.planBaseStyle : S.project.exploreBase, false);
    document.body.classList.toggle("asset-creation-mode", mode === "create");
    $("#creatorWorkspace").hidden = mode !== "create";
    if (mode === "plan") {
      S.areaViewPending = false;
      if (S.project.planView) applyView(S.project.planView);
      else requestAnimationFrame(fitArea);
    }
    else if (mode === "map") applyView(S.project.map);
    if (mode === "create") base.openCreator();
    else openDrawer(TABS[mode][0][0], true);
    if (ui.drafts[mode]) {
      const d = ui.drafts[mode];
      S.tool = d.tool;
      S.points = copy(d.points);
      S.options = copy(d.options);
      $("#drawStatus").hidden = false;
      renderDraft();
    }
    C.updateLock();
    C.render();
    C.saveSoon();
    chrome();
    return true;
  }
  function setModeUI() {
    chrome();
  }
  function startTool(t, o = {}) {
    const area = /^planArea/.test(t),
      evidence = ["note", "photo"].includes(t) && S.mode === "map",
      entrance = t === "accessPoint" && S.mode === "route";
    if (!area && !evidence && !entrance && S.mode !== "plan") {
      if (!S.project.area) {
        setMode("map");
        openDrawer("area");
        C.toast("Define the site area before drawing.");
        return;
      }
      setMode("plan");
    }
    if (["panelAreaPoints", "panelAreaFreehand"].includes(t))
      o = { ...o, padBearing: S.project.padBearing ?? null };
    const current = ui.drawer;
    if (S.tool && S.points.length)
      ui.drafts[S.mode] = {
        tool: S.tool,
        points: copy(S.points),
        options: copy(S.options),
      };
    base.startTool(t, {
      ...o,
      ...(evidence
        ? { includeOnDrawing: false, fieldCapture: true, includeLegend: false }
        : {}),
    });
    if (["draw", "place", "services"].includes(current)) openDrawer(current);
    if (area || evidence || entrance || innerWidth < 700 || ["focus", "touch"].includes(C.readPref("sami.layout"))) closeDrawer(true);
    renderDraft();
    C.saveSoon();
  }
  function activateAsset() {
    const a = currentAsset();
    if (!a?.name) return;
    if (!a.allowed.includes(ui.drawMode))
      ui.drawMode = a.allowed.includes("place") ? "place" : a.allowed[0];
    base.ui.asset = ui.drawAsset;
    base.ui.method = ui.drawMode;
    if (ui.drawAsset.startsWith("annotation_")) {
      base.runAction("draw:" + ui.drawAsset.slice(11));
      return;
    }
    if (ui.drawAsset === "panel_sabre") {
      const values = {
        jointSpacingMm: S.project.route.jointSpacingMm,
        jointVerified: S.project.route.jointVerified,
      };
      base.activateMaster(ui.drawMode);
      Object.assign(S.options, values);
      Object.assign(S.project.route, values);
    } else base.activateMaster(ui.drawMode);
    if (innerWidth < 900 || ["focus", "touch"].includes(C.readPref("sami.layout"))) closeDrawer(true);
    else openDrawer("draw");
  }
  function renderDraft() {
    base.renderDraft();
    if (S.tool === "measure" && S.options.dimension) {
      S.draftGroup.clearLayers();
      const hover=S.options.dimensionHover, points=S.points.slice(0,2), color="#18a976";
      const line=(ps,dashed=false)=>L.polyline(ps.map(C.latlng),{color,weight:1.5,dashArray:dashed?"5 4":null,interactive:false}).addTo(S.draftGroup);
      if(points.length===1 && hover) line([points[0],hover.coord],true);
      if(points.length===2) {
        const offset=hover ? window.SAMIPlanning.offsetAt(points[0],points[1],hover.coord) : 2;
        const d=window.SAMIPlanning.dimensionGeometry({geometry:{coordinates:points},properties:{dimensionOffset:offset}});
        if(d){d.extensions.forEach(ps=>line(ps));line(d.line);L.marker(C.latlng(d.midpoint),{interactive:false,icon:L.divIcon({className:"dimension-note",html:`<button tabindex="-1" style="transform:translate(-50%,-50%) rotate(var(--counter-bearing,0deg))">${window.SAMIPlanning.dimensionLabel(d.length)}</button>`,iconSize:[0,0]})}).addTo(S.draftGroup);}
      }
      for(const point of points)L.circleMarker(C.latlng(point),{radius:4,color,weight:1.5,fillColor:"#fff",fillOpacity:1,interactive:false}).addTo(S.draftGroup);
      if(hover && points.length<2)L.circleMarker(C.latlng(hover.coord),{radius:hover.anchor?7:4,color,weight:2,fillOpacity:.15,interactive:false}).addTo(S.draftGroup);
      $("#toolName").textContent = "Dimension";
      $("#drawHint").textContent = S.points.length === 0 ? "1 · Tap the first corner" : S.points.length === 1 ? "2 · Tap the second corner" : "3 · Tap where the dimension line should sit";
      $("#finishDrawBtn").hidden = true;
      $("#backPointBtn").hidden = false;
      $("#backPointBtn").disabled = !S.points.length;
      return;
    }
    if (!S.tool) return;
    const repeatPlace = ["asset", "singlePanel"].includes(S.tool),
      pointOnly = [
        "note",
        "photo",
        "textBox",
        "accessPoint",
        "hazard-marker",
      ].includes(S.tool),
      automatic = ["planArea", "rectangle"].includes(S.tool),
      minimum =
        S.tool === "circle"
          ? 2
          : S.options.area || /Area|area|hazard|excavation/.test(S.tool)
            ? 3
            : 2;
    const freehand = C.isFreehandTool(S.tool);
    $("#finishDrawBtn").hidden = pointOnly || repeatPlace || automatic || freehand;
    $("#backPointBtn").hidden = pointOnly || repeatPlace || freehand;
    $("#finishDrawBtn").disabled = repeatPlace
      ? !S.options.placedIds?.length
      : S.points.length < minimum;
    $("#backPointBtn").disabled = !S.points.length;
    $("#finishDrawBtn").textContent = "Finish";
    $("#toolName").textContent =
      pointOnly || repeatPlace
        ? S.options.name || S.options.label || "Place item"
        : S.options.name || S.options.label || "Drawing";
    if (C.isFreehandTool(S.tool))
      $("#drawHint").textContent = S.points.length
        ? "Drawing… lift to finish and close automatically"
        : "Draw one continuous stroke · lift to finish";
    if (
      !S.freehandActive &&
      !pointOnly &&
      !repeatPlace &&
      S.points.length <= 150
    ) {
      S.editGroup.clearLayers();
      S.points.forEach((p, i) => {
        const last = i === S.points.length - 1,
          size = last ? 32 : 24,
          m = L.marker(C.latlng(p), {
            draggable: true,
            zIndexOffset: last ? 1450 : 1400,
            icon: L.divIcon({
              className: "",
              html:
                '<div class="draft-edit-point' +
                (last ? " draft-edit-point-last" : "") +
                '"></div>',
              iconSize: [size, size],
              iconAnchor: [size / 2, size / 2],
            }),
          }).addTo(S.editGroup);
        m.on("dragstart", () => {
          S.suppressMapClick = performance.now() + 1000;
        });
        m.on("drag", () => {
          S.points[i] = C.coord(m.getLatLng());
          S.suppressMapClick = performance.now() + 250;
          base.renderDraft();
        });
        m.on("dragend", () => {
          S.suppressMapClick = performance.now() + 350;
          renderDraft();
          C.saveSoon();
        });
      });
    }
    C.saveSoon();
  }
  function finishDraw() {
    if (S.tool === "measure" && S.options.dimension) { C.toast("Tap the plan to position the dimension line."); return; }
    const wasArea = /^planArea/.test(S.tool || ""),
      ohl = S.options?.serviceType === "ohl";
    base.finishDraw();
    if (ohl) {
      const f = C.selectedFeature();
      if (f) {
        f.properties.supportPointsJSON = JSON.stringify(
          f.geometry.type === "LineString" ? f.geometry.coordinates : [],
        );
        f.properties.planCommitted = true;
        C.commit();
      }
    }
    if (wasArea && S.project.area) setMode("plan");
    if (!S.tool) {
      delete ui.drafts[S.mode];
      C.render();
    }
    C.saveSoon();
  }
  function initFreehandInput() {
    const el = $("#mapViewport") || $("#map"),
      pointers = new Set();
    let stroke = null;
    el.addEventListener(
      "pointerdown",
      (e) => {
        pointers.add(e.pointerId);
        if (pointers.size > 1) {
          if (stroke) {
            S.points = stroke.before;
            stroke = null;
            S.freehandActive = false;
            renderDraft();
            C.updateLock();
          }
          return;
        }
        if (
          ui.precision.active ||
          !C.isFreehandTool(S.tool) ||
          e.button > 0 ||
          e.target.closest?.("button,input,select,textarea,.leaflet-control,.leaflet-marker-icon")
        )
          return;
        const p = C.screenToCoord(e);
        if (!C.freehandPointAllowed(p)) return;
        stroke = {
          id: e.pointerId,
          x: e.clientX,
          y: e.clientY,
          before: copy(S.points),
        };
        S.freehandActive = true;
        S.points.push(p);
        S.map.dragging.disable();
        el.setPointerCapture?.(e.pointerId);
        e.preventDefault();
        e.stopPropagation();
        renderDraft();
      },
      { capture: true },
    );
    el.addEventListener(
      "pointermove",
      (e) => {
        if (!stroke || stroke.id !== e.pointerId) return;
        if (Math.hypot(e.clientX - stroke.x, e.clientY - stroke.y) < 5) return;
        const p = C.screenToCoord(e);
        if (!C.freehandPointAllowed(p)) return;
        S.points.push(p);
        stroke.x = e.clientX;
        stroke.y = e.clientY;
        base.renderDraft();
        e.preventDefault();
      },
      { capture: true },
    );
    const end = (e) => {
      pointers.delete(e.pointerId);
      if (!stroke || stroke.id !== e.pointerId) return;
      const before = stroke.before;
      stroke = null;
      S.freehandActive = false;
      S.suppressMapClick = performance.now() + 250;
      el.releasePointerCapture?.(e.pointerId);
      if (e.type === "pointercancel") {
        S.points = before;
        renderDraft();
        C.saveSoon();
      } else finishDraw();
      C.updateLock();
      e.preventDefault();
      e.stopPropagation();
    };
    el.addEventListener("pointerup", end, { capture: true });
    el.addEventListener("pointercancel", end, { capture: true });
  }
  function onMapClick(e) {
    if (S.suppressMapClick > performance.now() && !S.routePick) return;
    if (S.routePick) { base.onMapClick(e); return; }
    if (S.tool === "measure" && S.options.dimension) { dimensionClick(e); return; }
    if (ui.precision.active && !ui.precision.multi) {
      const r = precisionMapRect();
      if (r) {
        const oe = e.originalEvent;
        if (Number.isFinite(oe?.clientX) && Number.isFinite(oe?.clientY))
          positionPrecisionCursor(
            oe.clientX - r.left,
            oe.clientY - r.top,
            true,
            r,
          );
        else {
          const pt = S.map.latLngToContainerPoint(e.latlng),
            screen = bearing?.toScreen ? bearing.toScreen(pt) : null;
          if (screen)
            positionPrecisionCursor(
              screen.x - r.left,
              screen.y - r.top,
              true,
              r,
            );
          else positionPrecisionCursor(pt.x, pt.y, true, r);
        }
      }
      return;
    }
    base.onMapClick(e);
    if (
      ui.drawer === "selection" &&
      !document.body.classList.contains("inspector-collapsed")
    )
      renderDrawer("selection");
  }
  function beginDimension() {
    if (!S.project.area) { setMode("map"); openDrawer("area",true); C.toast("Define your site area first."); return; }
    const sourceId = S.selected;
    if (S.mode !== "plan") setMode("plan");
    if (ui.precision.active) setPrecision(false);
    startTool("measure", {dimension:true, dimensionOffset:2, dimensionUnits:"m", dimensionPrecision:2, anchors:[], sourceId, includeLegend:false, snap:true});
    closeDrawer(true);
    renderDraft();
  }
  function dimensionClick(e) {
    const raw = C.coord(e.latlng), P = window.SAMIPlanning;
    if (S.points.length < 2) {
      const hit=P.nearestCorner(raw,S.project.features,S.project,c=>S.map.latLngToContainerPoint(C.latlng(c)),matchMedia("(pointer:coarse)").matches ? 24 : 16,S.options.sourceId);
      if (S.points.length && G.distance(S.points[0],hit.coord)<.01) { C.toast("Choose a different second corner."); return; }
      S.options.anchors = (S.options.anchors || []).slice(0,S.points.length);
      S.points.push(hit.coord); S.options.anchors.push(hit.anchor); S.options.dimensionHover=null;
      renderDraft(); if(hit.anchor) C.toast("Snapped to corner"); return;
    }
    const offset=P.offsetAt(S.points[0],S.points[1],raw);
    const f=C.feature("measure",{type:"LineString",coordinates:copy(S.points.slice(0,2))},{label:"Dimension",dimension:true,dimensionOffset:offset,dimensionUnits:"m",dimensionPrecision:2,dimensionAnchors:JSON.stringify(S.options.anchors),includeLegend:false});
    S.project.features.push(f); C.cancelDraw(); delete ui.drafts[S.mode]; S.selected=f.id; C.commit();
    C.toast("Dimension added. Select its label to edit units and spacing.");
  }
  function onMapMouseMove() { /* Hover never repositions the touch cursor. */ }
  function fitArea() {
    if (!S.project.area) return;
    const r = $("#mapViewport").getBoundingClientRect(),
      b = S.project.area,
      c = L.latLng((b[1] + b[3]) / 2, (b[0] + b[2]) / 2),
      pr = G.projection([c.lng, c.lat]),
      a = pr.xy([b[0], b[1]]),
      z = pr.xy([b[2], b[3]]),
      angle = ((S.map.getBearing?.() || 0) * Math.PI) / 180,
      w = Math.abs(z[0] - a[0]),
      h = Math.abs(z[1] - a[1]),
      rw = Math.abs(w * Math.cos(angle)) + Math.abs(h * Math.sin(angle)),
      rh = Math.abs(w * Math.sin(angle)) + Math.abs(h * Math.cos(angle)),
      mpp = Math.max(
        rw / Math.max(100, r.width - 110),
        rh / Math.max(100, r.height - 150),
      ),
      zoom = Math.log2(
        (156543.03392 * Math.cos((c.lat * Math.PI) / 180)) / mpp,
      );
    S.map.setView(c, Math.min(23, zoom), { animate: false });
  }
  function paperFrameFromCurrentView(
    ratio = +S.project.areaPaperRatio || 420 / 297,
  ) {
    if (!bearing) return null;
    const r = $("#mapViewport").getBoundingClientRect();
    let w = r.width,
      h = r.height;
    if (!(w > 0 && h > 0)) return null;
    if (w / h > ratio) w = h * ratio;
    else h = w / ratio;
    const left = r.left + (r.width - w) / 2,
      top = r.top + (r.height - h) / 2;
    return [
      [left, top],
      [left + w, top],
      [left + w, top + h],
      [left, top + h],
    ].map(([x, y]) =>
      C.coord(S.map.containerPointToLatLng(bearing.fromScreen(x, y))),
    );
  }
  function visibleArea() {
    const frame = paperFrameFromCurrentView(),
      b = boundsFromFrame(frame),
      view = captureView();
    if (!b || !frame) return;
    S.project.areaAspectLocked = true;
    S.project.areaPaperRatio = 420 / 297;
    C.setArea(b, frame, view);
    setMode("plan");
  }
  function snap(c) {
    if (!base.ui.snap || !S.map) return c;
    const px = (q) => S.map.latLngToContainerPoint(C.latlng(q)),
      target = px(c);
    let best = null,
      distance = 10;
    const test = (q) => {
      const d = target.distanceTo(px(q));
      if (d < distance) {
        best = q;
        distance = d;
      }
    };
    for (const f of S.project.features) {
      if (f.properties.hidden || f.properties.guideHidden) continue;
      const g = f.geometry,
        rings =
          g.type === "Polygon"
            ? g.coordinates
            : g.type === "LineString"
              ? [g.coordinates]
              : g.type === "Point"
                ? [[g.coordinates]]
                : g.type === "MultiPolygon"
                  ? g.coordinates.flat()
                  : g.type === "MultiLineString"
                    ? g.coordinates
                    : [];
      for (const ring of rings)
        for (let j = 0; j < ring.length; j++) {
          test(ring[j]);
          if (j) {
            const a = px(ring[j - 1]),
              b = px(ring[j]),
              v = b.subtract(a),
              n = v.x * v.x + v.y * v.y;
            if (n) {
              const t = Math.max(
                0,
                Math.min(
                  1,
                  ((target.x - a.x) * v.x + (target.y - a.y) * v.y) / n,
                ),
              );
              test(
                C.coord(S.map.containerPointToLatLng(a.add(v.multiplyBy(t)))),
              );
            }
          }
        }
      if (["panel", "asset", "shape", "logo"].includes(f.properties.type))
        test(C.featureCenter(f));
    }
    if (S.project.area) {
      const b = S.project.area;
      for (const q of [
        [b[0], b[1]],
        [b[0], b[3]],
        [b[2], b[1]],
        [b[2], b[3]],
      ])
        test(q);
    }
    if (S.points.length) {
      const last = px(S.points.at(-1));
      for (const q of [L.point(last.x, target.y), L.point(target.x, last.y)])
        test(C.coord(S.map.containerPointToLatLng(q)));
    }
    if (
      (S.tool === "measure" || S.options?.measurement) &&
      S.project.gridSnap !== false
    ) {
      const origin = S.project.area
          ? [
              (S.project.area[0] + S.project.area[2]) / 2,
              (S.project.area[1] + S.project.area[3]) / 2,
            ]
          : c,
        pr = G.projection(origin),
        q = pr.xy(c),
        step = +S.project.gridStep || 0.5,
        grid = pr.ll([
          Math.round(q[0] / step) * step,
          Math.round(q[1] / step) * step,
        ]);
      test(grid);
    }
    if (best) {
      if (!snapRing)
        snapRing = L.circleMarker(C.latlng(best), {
          radius: 7,
          color: "#078e56",
          weight: 2,
          fillColor: "#9eebbc",
          fillOpacity: 0.2,
          interactive: false,
        }).addTo(S.map);
      else snapRing.setLatLng(C.latlng(best));
      clearTimeout(snapRing._fade);
      snapRing._fade = setTimeout(() => {
        snapRing?.remove();
        snapRing = null;
      }, 650);
    }
    return best ? best.slice() : c;
  }

  let precisionLayer = null,
    precisionLiveLayer = null,
    precisionLive = {},
    precisionPanel = null,
    precisionCursor = null,
    boxMarquee = null,
    boxPointer = null,
    precisionRestoreInspector = false,
    precisionWakeLock = null;
  function updateMapModeControls() {
    const btn = $("#mapMeasureButton");
    if (btn) btn.hidden = !["map", "plan"].includes(S.mode);
  }
  function formatMeasureDistance(m) {
    if (!Number.isFinite(m)) return "0 m";
    return m >= 1000
      ? (m / 1000).toFixed(m >= 10000 ? 1 : 2) + " km"
      : m >= 100
        ? m.toFixed(0) + " m"
        : m.toFixed(1) + " m";
  }
  function polygonAreaMeters(points) {
    if (!points || points.length < 3) return 0;
    const origin = [
        points.reduce((a, p) => a + p[0], 0) / points.length,
        points.reduce((a, p) => a + p[1], 0) / points.length,
      ],
      pr = G.projection(origin),
      xy = points.map(pr.xy);
    let sum = 0;
    for (let i = 0, j = xy.length - 1; i < xy.length; j = i++)
      sum += xy[j][0] * xy[i][1] - xy[i][0] * xy[j][1];
    return Math.abs(sum) / 2;
  }
  function precisionMapEl() {
    return $("#mapViewport") || S.map?.getContainer?.() || $("#map");
  }
  function precisionMapRect() {
    return precisionMapEl()?.getBoundingClientRect?.() || null;
  }
  let precisionRefreshFrame = 0,
    precisionTouchIds = new Set(),
    precisionDragMapWasEnabled = false;
  function schedulePrecisionRefresh() {
    if (precisionRefreshFrame) return;
    precisionRefreshFrame = requestAnimationFrame(() => {
      precisionRefreshFrame = 0;
      if (ui.precision.active) refreshPrecision(false);
    });
  }
  function positionPrecisionCursor(x, y, refresh = true, rect = null) {
    if (!precisionCursor || !S.map) return;
    const r = rect || precisionMapRect();
    if (!r || !(r.width > 0 && r.height > 0)) return;
    const size = 56,
      margin = size / 2 + 4,
      px = Math.max(margin, Math.min(r.width - margin, x)),
      py = Math.max(margin, Math.min(r.height - margin, y));
    ui.precision.cursorX = px / r.width;
    ui.precision.cursorY = py / r.height;
    ui.precision.cursorCoord = null;
    precisionCursor.style.setProperty("--cursor-x", px + "px");
    precisionCursor.style.setProperty("--cursor-y", py + "px");
    if (refresh) schedulePrecisionRefresh();
  }
  function schedulePrecisionCursor(clientX, clientY) {
    const r = precisionMapRect();
    if (!r) return;
    positionPrecisionCursor(clientX - r.left, clientY - r.top, true, r);
  }
  function resetPrecisionCursor() {
    const r = precisionMapRect();
    if (!r || !(r.width > 0 && r.height > 0)) return;
    positionPrecisionCursor(r.width * 0.5, r.height * 0.5, false, r);
  }
  function nudgePrecision(east, north) {
    const c = precisionCenter();
    if (!c) return;
    const step = Math.max(
        0.1,
        Math.min(25, +precisionPanel?.querySelector("#precisionStep")?.value || 1),
      ),
      pr = G.projection(c),
      next = pr.ll([east * step, north * step]),
      pt = S.map.latLngToContainerPoint(C.latlng(next)),
      mapRect = S.map.getContainer()?.getBoundingClientRect?.(),
      viewportRect = precisionMapRect(),
      screen = bearing?.toScreen ? bearing.toScreen(pt) : null;
    if (!mapRect || !viewportRect) return;
    positionPrecisionCursor(
      (screen?.x ?? mapRect.left + pt.x) - viewportRect.left,
      (screen?.y ?? mapRect.top + pt.y) - viewportRect.top,
      false,
      viewportRect,
    );
    // Leaflet rounds projected points to display pixels. Retain the exact
    // geographic nudge so a 1 m/5 m accessible step measures exactly even
    // when one screen pixel represents more than one metre.
    ui.precision.cursorCoord = next;
    schedulePrecisionRefresh();
  }
  async function locatePrecision() {
    if (!navigator.geolocation) {
      C.toast("Current location is not available in this browser.");
      return;
    }
    C.toast("Getting current location…");
    try {
      const pos = await new Promise((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 12000,
          maximumAge: 15000,
        }),
      );
      const c = [pos.coords.longitude, pos.coords.latitude],
        zoom = Math.max(S.map?.getZoom?.() || 0, 18);
      S.map.setView([c[1], c[0]], zoom, { animate: false });
      requestAnimationFrame(() => {
        resetPrecisionCursor();
        ui.precision.cursorCoord = c;
        refreshPrecision(true);
      });
      C.toast("Map centred on your position · tap + Point to add it.");
    } catch (error) {
      C.toast(
        error?.code === 1
          ? "Location permission was not granted. You can still move the map under the cursor."
          : "Current location could not be obtained. Move the map under the cursor instead.",
      );
    }
  }
  async function setPrecisionWake(on) {
    C.setPref("sami.measure.wake", on ? "on" : "off");
    try {
      if (!on) {
        await precisionWakeLock?.release?.();
        precisionWakeLock = null;
      } else if (ui.precision.active && document.visibilityState === "visible") {
        precisionWakeLock = await navigator.wakeLock?.request?.("screen");
        precisionWakeLock?.addEventListener?.("release", () => {
          precisionWakeLock = null;
          updatePrecisionWakeButton();
        });
      }
    } catch {
      precisionWakeLock = null;
      if (on) C.toast("Screen wake lock is not available in this browser.");
    }
    updatePrecisionWakeButton();
  }
  function updatePrecisionWakeButton() {
    const button = precisionPanel?.querySelector('[data-pc="wake"]'),
      on = C.readPref("sami.measure.wake") === "on";
    if (!button) return;
    button.textContent = on ? "On" : "Off";
    button.setAttribute("aria-pressed", String(on));
  }
  function restoreMapDragAfterPrecision() {
    if (
      precisionDragMapWasEnabled &&
      S.map?.dragging &&
      !S.map.dragging.enabled()
    )
      S.map.dragging.enable();
    precisionDragMapWasEnabled = false;
  }
  function cancelPrecisionDrag() {
    const d = ui.precision.drag;
    if (d?.kind === "pointer" && precisionCursor?.hasPointerCapture?.(d.id)) {
      try {
        precisionCursor.releasePointerCapture(d.id);
      } catch {}
    }
    ui.precision.drag = null;
    restoreMapDragAfterPrecision();
  }
  function ensurePrecisionUI() {
    if (!precisionLayer) precisionLayer = L.featureGroup().addTo(S.map);
    if (!precisionLiveLayer) precisionLiveLayer = L.featureGroup().addTo(S.map);
    if (!precisionCursor) {
      precisionCursor = document.createElement("button");
      precisionCursor.type = "button";
      precisionCursor.id = "precisionCursor";
      precisionCursor.className = "precision-cursor";
      precisionCursor.setAttribute(
        "aria-label",
        "Measurement cursor. Drag with one finger to position. Tap it or use Plus Point to add a point.",
      );
      precisionCursor.innerHTML =
        '<i></i><b></b><span class="precision-live" aria-hidden="true"></span>';
      precisionCursor.hidden = true;
      (precisionMapEl() || $("#mapViewport") || $("#workspace")).append(
        precisionCursor,
      );
      precisionCursor.addEventListener("pointerdown", (e) => {
        if (
          !ui.precision.active ||
          e.button > 0 ||
          e.isPrimary === false ||
          ui.precision.multi
        )
          return;
        const r = precisionMapRect();
        if (!r) return;
        precisionDragMapWasEnabled = !!S.map?.dragging?.enabled?.();
        if (precisionDragMapWasEnabled) S.map.dragging.disable();
        ui.precision.drag = {
          kind: "pointer",
          id: e.pointerId,
          startX: e.clientX,
          startY: e.clientY,
          offsetX: e.clientX - r.left - ui.precision.cursorX * r.width,
          offsetY: e.clientY - r.top - ui.precision.cursorY * r.height,
          moved: false,
        };
        try {
          precisionCursor.setPointerCapture?.(e.pointerId);
        } catch {}
        e.preventDefault();
        e.stopPropagation();
      });
      precisionCursor.addEventListener("pointermove", (e) => {
        const d = ui.precision.drag;
        if (
          !d ||
          d.kind !== "pointer" ||
          d.id !== e.pointerId ||
          ui.precision.multi
        )
          return;
        if (Math.hypot(e.clientX - d.startX, e.clientY - d.startY) > 4)
          d.moved = true;
        schedulePrecisionCursor(e.clientX - d.offsetX, e.clientY - d.offsetY);
        e.preventDefault();
        e.stopPropagation();
      });
      const finish = (e) => {
        const d = ui.precision.drag;
        if (!d || d.kind !== "pointer" || d.id !== e.pointerId) return;
        const moved = d.moved, r = precisionMapRect();
        if (r && Number.isFinite(e.clientX) && Number.isFinite(e.clientY))
          positionPrecisionCursor(e.clientX - r.left - d.offsetX, e.clientY - r.top - d.offsetY, true, r);
        cancelPrecisionDrag();
        if (moved) S.suppressMapClick = performance.now() + 450;
        if (!moved && !ui.precision.multi) dropPrecisionPoint();
        e.preventDefault();
        e.stopPropagation();
      };
      precisionCursor.addEventListener("pointerup", finish);
      precisionCursor.addEventListener("lostpointercapture", () => {
        if (ui.precision.drag) cancelPrecisionDrag();
      });
      precisionCursor.addEventListener("pointercancel", (e) => {
        const d = ui.precision.drag;
        if (d?.kind === "pointer" && d.id === e.pointerId)
          cancelPrecisionDrag();
      });
      precisionCursor.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
      });
      precisionCursor.addEventListener("keydown", (e) => {
        if ((e.key === "Enter" || e.key === " ") && ui.precision.active) {
          e.preventDefault();
          dropPrecisionPoint();
        }
        if (ui.precision.active && e.key.startsWith("Arrow")) {
          e.preventDefault();
          const multiplier = e.shiftKey ? 5 : 1,
            direction = {
              ArrowUp: [0, 1],
              ArrowDown: [0, -1],
              ArrowLeft: [-1, 0],
              ArrowRight: [1, 0],
            }[e.key];
          if (direction) {
            const step = precisionPanel?.querySelector("#precisionStep");
            if (step) step.value = String(multiplier);
            nudgePrecision(...direction);
          }
        }
        if (e.key === "Escape" && ui.precision.active) {
          e.preventDefault();
          setPrecision(false);
        }
      });
      const surface = precisionMapEl();
      // Repositioning the precision cursor on tap is handled by Leaflet's
      // own native "click" event (see onMapClick's ui.precision.active
      // branch) so it stays in sync with Leaflet's tap/drag gesture
      // recognizer. A separate low-level pointerdown/pointermove/pointerup
      // interceptor used to run here in parallel and call
      // stopImmediatePropagation() on pointerup to reposition the cursor
      // itself; that left Leaflet's native drag/tap handling stuck mid
      // gesture after the first pan, so tapping to place a point stopped
      // working. Only multi-touch (pinch) tracking remains here, to keep
      // the crosshair from jumping while the user is pinch-zooming the map.
      surface.addEventListener(
        "pointerdown",
        (e) => {
          if (e.pointerType !== "touch") return;
          precisionTouchIds.add(e.pointerId);
          if (precisionTouchIds.size > 1) {
            ui.precision.multi = true;
            cancelPrecisionDrag();
            S.suppressMapClick = performance.now() + 500;
          }
        },
        { capture: true, passive: true },
      );
      const releaseTouch = (e) => {
        precisionTouchIds.delete(e.pointerId);
        if (!precisionTouchIds.size) {
          if (ui.precision.multi) S.suppressMapClick = performance.now() + 350;
          ui.precision.multi = false;
        }
      };
      window.addEventListener("pointerup", releaseTouch, { passive: true });
      window.addEventListener("pointercancel", releaseTouch, { passive: true });
      const restoreCursor = () => {
        if (!ui.precision.active) return;
        requestAnimationFrame(() => {
          const r = precisionMapRect();
          if (r)
            positionPrecisionCursor(
              (ui.precision.cursorX ?? 0.5) * r.width,
              (ui.precision.cursorY ?? 0.5) * r.height,
              true,
              r,
            );
        });
      };
      window.addEventListener("resize", restoreCursor, { passive: true });
      window.addEventListener("orientationchange", restoreCursor, {
        passive: true,
      });
    }
    if (!precisionPanel) {
      precisionPanel = document.createElement("div");
      precisionPanel.id = "precisionPanel";
      precisionPanel.className = "precision-panel precision-panel-compact";
      precisionPanel.hidden = true;
      precisionPanel.innerHTML =
        '<div class="precision-toolbar"><div class="precision-modes" aria-label="Measurement type"><button data-pc="line">Distance</button><button data-pc="area">Area</button></div><div class="precision-readout"><span id="precisionReadout">Move the cursor, then tap + Point.</span><small class="precision-coordinates" id="precisionCoordinates"></small></div><div class="precision-quick"><button data-pc="drop" class="primary" aria-label="Add point at cursor">+ Point</button><button data-pc="locate" aria-label="Centre map on current position" title="Current position">◎ Me</button><button data-pc="undo" aria-label="Undo last point" title="Undo">↶</button><button data-pc="finish">Finish</button><button data-pc="more" aria-label="More measurement actions" title="More">•••</button><button data-pc="close" aria-label="Close measurement" title="Close">×</button></div></div><div class="precision-overflow" id="precisionOverflow" hidden><p class="precision-help">Drag the crosshair with one finger, tap the map to reposition it, or move the map beneath the fixed crosshair. + Point records the crosshair position.</p><div class="precision-nudge" aria-label="Nudge measurement cursor"><button data-pc="north" aria-label="Nudge north">↑</button><button data-pc="west" aria-label="Nudge west">←</button><button data-pc="drop" aria-label="Place point at cursor">＋</button><button data-pc="east" aria-label="Nudge east">→</button><button data-pc="south" aria-label="Nudge south">↓</button></div><label class="precision-step">Nudge step<select id="precisionStep"><option value="1">1 m</option><option value="5">5 m</option></select></label><label class="precision-wake">Keep screen awake<button type="button" data-pc="wake" aria-pressed="false">Off</button></label><label class="precision-measurements">Show measurements<button type="button" data-pc="showMeasurements" aria-pressed="true">On</button></label><button data-pc="site">Use measured area for site plan</button><button data-pc="clear">Clear points</button></div>';
      ($("#mapViewport") || $("#workspace")).append(precisionPanel);
      precisionPanel.onclick = (e) => {
        const a = e.target.closest("[data-pc]")?.dataset.pc;
        if (!a) return;
        const overflow = $("#precisionOverflow");
        if (a === "close") setPrecision(false);
        else if (a === "line" || a === "area") {
          ui.precision.mode = a;
          if (overflow) overflow.hidden = true;
          refreshPrecision(true);
        } else if (a === "undo") {
          ui.precision.points.pop();
          refreshPrecision(true);
        } else if (a === "finish") commitPrecision(false);
        else if (a === "more") {
          if (overflow) overflow.hidden = !overflow.hidden;
        } else if (a === "clear") {
          ui.precision.points = [];
          if (overflow) overflow.hidden = true;
          refreshPrecision(true);
        } else if (a === "site") commitPrecision(true);
        else if (a === "drop") dropPrecisionPoint();
        else if (a === "locate") locatePrecision();
        else if (a === "north") nudgePrecision(0, 1);
        else if (a === "south") nudgePrecision(0, -1);
        else if (a === "west") nudgePrecision(-1, 0);
        else if (a === "east") nudgePrecision(1, 0);
        else if (a === "wake")
          setPrecisionWake(C.readPref("sami.measure.wake") !== "on");
        else if (a === "showMeasurements") {
          ui.precision.showMeasurements = !ui.precision.showMeasurements;
          const btn = e.target.closest('[data-pc="showMeasurements"]');
          if (btn) {
            btn.setAttribute("aria-pressed", String(ui.precision.showMeasurements));
            btn.textContent = ui.precision.showMeasurements ? "On" : "Off";
          }
          refreshPrecision(true);
        }
      };
      updatePrecisionWakeButton();
    }
  }
  function setPrecision(on, target = "measure") {
    ensurePrecisionUI();
    if (on) S.suppressMapClick = 0;
    ui.precision.active = !!on;
    const measureCommand = document.querySelector('#primaryCommandBar [data-command="measure"]');
    if (measureCommand) {
      measureCommand.classList.toggle("active", !!on);
      measureCommand.setAttribute("aria-pressed", String(!!on));
    }
    if (on) ui.precision.target = target;
    ui.precision.multi = false;
    precisionCursor.hidden = !on;
    precisionPanel.hidden = !on;
    document.body.classList.toggle("precision-active", !!on);
    if (on) {
      if (target === "draw" && !S.tool) {
        C.toast("Choose a drawing tool first, then use Precision cursor.");
        setPrecision(false);
        return;
      }
      precisionRestoreInspector = !document.body.classList.contains(
        "inspector-collapsed",
      );
      if (precisionRestoreInspector) closeDrawer(true);
      resetPrecisionCursor();
      requestAnimationFrame(() => {
        resetPrecisionCursor();
        refreshPrecision(true);
      });
      if (C.readPref("sami.measure.wake") === "on") setPrecisionWake(true);
    } else {
      cancelPrecisionDrag();
      precisionWakeLock?.release?.().catch?.(() => {});
      precisionWakeLock = null;
      precisionLayer?.clearLayers();
      precisionLiveLayer?.clearLayers();
      const overflow = $("#precisionOverflow");
      if (overflow) overflow.hidden = true;
      if (
        precisionRestoreInspector &&
        document.body.classList.contains("inspector-collapsed")
      )
        openDrawer(ui.drawer, true);
      precisionRestoreInspector = false;
    }
    refreshPrecision(true);
  }
  function precisionCenter() {
    if (!S.map) return null;
    if (ui.precision.cursorCoord) return ui.precision.cursorCoord.slice();
    const r = precisionMapRect();
    if (!r) return C.coord(S.map.getCenter());
    const x = (ui.precision.cursorX ?? 0.5) * r.width,
      y = (ui.precision.cursorY ?? 0.5) * r.height,
      clientX = r.left + x,
      clientY = r.top + y,
      pt = S.map.mouseEventToContainerPoint
        ? S.map.mouseEventToContainerPoint({ clientX, clientY })
        : L.point(
            clientX -
              (S.map.getContainer()?.getBoundingClientRect?.().left || 0),
            clientY -
              (S.map.getContainer()?.getBoundingClientRect?.().top || 0),
          ),
      raw = C.coord(S.map.containerPointToLatLng(pt));
    return ui.precision.target === "draw" ? snap(raw) : raw;
  }
  function precisionLabel(coord, text, cls = "", layer = precisionLayer) {
    return L.marker(C.latlng(coord), {
      interactive: false,
      keyboard: false,
      icon: L.divIcon({
        className: "precision-measure-label " + cls,
        html: "<span>" + text + "</span>",
        iconSize: null,
        iconAnchor: [0, 0],
      }),
    }).addTo(layer);
  }
  function segmentMid(a, b) {
    const v = C.lineMidpointAndBearing?.([a, b]);
    return v?.mid || [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  }
  function dropPrecisionPoint() {
    if (!ui.precision.active) return;
    const c = precisionCenter();
    if (!c) return;
    if (ui.precision.target === "draw") {
      base.onMapClick({ latlng: C.latlng(c) });
      return;
    }
    if (ui.precision.points.length && G.distance(ui.precision.points.at(-1), c) < 0.01) return;
    ui.precision.points.push(c);
    navigator.vibrate?.(8);
    refreshPrecision(true);
  }
  function refreshPrecision(rebuild = true) {
    if (!precisionLayer || !precisionLiveLayer) return;
    if (rebuild) {
      precisionLayer.clearLayers();
      precisionLiveLayer.clearLayers();
      precisionLive = {};
      if (ui.ready) C.saveSoon();
    }
    if (!ui.precision.active) return;
    const ps = ui.precision.points,
      c = precisionCenter();
    if (!c) return;
    const committed = ps.length > 1 ? G.length(ps) : 0,
      next = ps.length ? G.distance(ps.at(-1), c) : 0,
      total = committed + next + (ui.precision.mode === "area" && ps.length >= 2 ? G.distance(c, ps[0]) : 0),
      live = precisionCursor?.querySelector(".precision-live");
    if (ui.precision.target === "draw") {
      if (live) {
        live.textContent = "";
        live.hidden = true;
      }
    } else if (live) {
      live.textContent = ps.length
        ? formatMeasureDistance(next)
        : "Tap to start";
      live.hidden = false;
    }
    if (rebuild && ps.length > 1) {
      L.polyline(ps.map(C.latlng), {
        color: "#57ee9b",
        weight: 3,
        interactive: false,
      }).addTo(precisionLayer);
      if (ui.precision.showMeasurements !== false) {
        for (let i = 1; i < ps.length; i++) {
          const d = G.distance(ps[i - 1], ps[i]);
          precisionLabel(
            segmentMid(ps[i - 1], ps[i]),
            formatMeasureDistance(d),
            "segment",
            precisionLayer,
          );
        }
      }
    }
    if (rebuild && ui.precision.mode === "area" && ps.length > 2)
      L.polygon(ps.map(C.latlng), {
        color: "#57ee9b",
        weight: 2,
        fillColor: "#43d98b",
        fillOpacity: 0.13,
        interactive: false,
      }).addTo(precisionLayer);
    if (rebuild)
      for (let i = 0; i < ps.length; i++)
        L.circleMarker(C.latlng(ps[i]), {
          radius: i === ps.length - 1 ? 5 : 4,
          color: "#e3ffec",
          weight: 2,
          fillColor: "#41dd8f",
          fillOpacity: 0.95,
          interactive: false,
        }).addTo(precisionLayer);
    if (ps.length) {
      const isArea = ui.precision.mode === "area" && ps.length >= 2;
      const points = (isArea ? [...ps,c] : [ps.at(-1),c]).map(C.latlng);
      if (!precisionLive.path) precisionLive.path = (isArea ? L.polygon : L.polyline)(points, {
        color:"#b8ffd3",weight:2,dashArray:"6 6",fillOpacity:0.1,interactive:false
      }).addTo(precisionLiveLayer);
      else precisionLive.path.setLatLngs(points);
      if (ui.precision.showMeasurements !== false) {
        const label = (key,coord,text,kind) => {
          if (!precisionLive[key]) precisionLive[key] = L.marker(C.latlng(coord), {
            interactive:false, icon:L.divIcon({className:"precision-measure-label " + kind, html:"<span></span>",iconSize:[0,0]})
          }).addTo(precisionLiveLayer);
          precisionLive[key].setLatLng(C.latlng(coord));
          const span=precisionLive[key].getElement()?.querySelector("span");
          if(span) span.textContent=text;
        };
        label("next",segmentMid(ps.at(-1),c),formatMeasureDistance(next),"live");
        label("total",ps.at(-1),(isArea ? "Perimeter " : "Total ") + formatMeasureDistance(total),"total");
      }
    }
    const el = $("#precisionReadout");
    if (el) {
      let measure;
      if (ui.precision.target === "draw")
        measure = "Move cursor or map · tap + Point to place";
      else if (!ps.length) measure = "Move cursor or map · tap + Point for point 1";
      else if (ui.precision.mode === "area") {
        const preview = [...ps, c],
          a = preview.length >= 3 ? polygonAreaMeters(preview) : 0;
        measure =
          "Next " +
          formatMeasureDistance(next) +
          " · " +
          formatMeasureDistance(total) +
          (a
            ? " · " +
              (a >= 10000
                ? (a / 10000).toFixed(2) + " ha"
                : Math.round(a).toLocaleString() + " m²")
            : "");
      } else
        measure =
          "Next " +
          formatMeasureDistance(next) +
          " · Total " +
          formatMeasureDistance(total);
      el.textContent = measure;
    }
    const showButton = precisionPanel?.querySelector('[data-pc="showMeasurements"]');
    if (showButton) {
      showButton.textContent = ui.precision.showMeasurements ? "On" : "Off";
      showButton.setAttribute("aria-pressed", String(ui.precision.showMeasurements));
    }
    const coordinateReadout = $("#precisionCoordinates");
    if (coordinateReadout) {
      const segment = ps.length ? C.lineMidpointAndBearing?.([ps.at(-1), c]) : null;
      coordinateReadout.textContent =
        c[1].toFixed(6) +
        ", " +
        c[0].toFixed(6) +
        (segment?.bearing != null
          ? " · " + Math.round(segment.bearing).toString().padStart(3, "0") + "°"
          : "");
    }
    const modes = precisionPanel?.querySelector(".precision-modes"),
      undo = precisionPanel?.querySelector('[data-pc="undo"]'),
      finish = precisionPanel?.querySelector('[data-pc="finish"]'),
      more = precisionPanel?.querySelector('[data-pc="more"]'),
      overflow = $("#precisionOverflow"),
      site = precisionPanel?.querySelector('[data-pc="site"]');
    if (modes) modes.hidden = ui.precision.target === "draw";
    if (undo) undo.hidden = ui.precision.target === "draw" || !ps.length;
    if (finish) finish.hidden = ui.precision.target === "draw";
    if (more) more.hidden = ui.precision.target === "draw";
    if (overflow && ui.precision.target === "draw") overflow.hidden = true;
    if (site) site.hidden = ui.precision.mode !== "area";
    precisionPanel
      ?.querySelectorAll(".precision-modes button")
      .forEach((b) =>
        b.classList.toggle("active", b.dataset.pc === ui.precision.mode),
      );
  }
  function commitPrecision(asSite) {
    const ps = ui.precision.points;
    if (ui.precision.mode === "line" && ps.length < 2) {
      C.toast("Place at least two points.");
      return;
    }
    if (ui.precision.mode === "area" && ps.length < 3) {
      C.toast("Place at least three points.");
      return;
    }
    if (asSite) {
      const b = [
        Math.min(...ps.map((x) => x[0])),
        Math.min(...ps.map((x) => x[1])),
        Math.max(...ps.map((x) => x[0])),
        Math.max(...ps.map((x) => x[1])),
      ];
      C.setArea(b);
      setPrecision(false);
      return;
    }
    if (ui.precision.mode === "line") {
      S.project.features.push(
        C.feature(
          "measure",
          { type: "LineString", coordinates: copy(ps) },
          {
            label: "Map measurement",
            distance: G.length(ps),
            includeLegend: false,
            measurement: true,
          },
        ),
      );
    } else {
      const ring = [...copy(ps), copy(ps[0])];
      S.project.features.push(
        C.feature(
          "area",
          { type: "Polygon", coordinates: [ring] },
          {
            label: "Measured area",
            includeLegend: false,
            measurement: true,
            measuredArea: polygonAreaMeters(ps),
          },
        ),
      );
    }
    C.commit();
    ui.precision.points = [];
    const overflow = $("#precisionOverflow");
    if (overflow) overflow.hidden = true;
    refreshPrecision(true);
    setPrecision(false);
    C.saveSoon();
    C.toast("Measurement added to plan.");
  }
  function startBoxSelect() {
    C.cancelDraw();
    setPrecision(false);
    ui.boxSelect = true;
    document.body.classList.add("box-select-active");
    C.toast("Drag a box across the map to select multiple objects.");
  }
  function finishBoxSelect(rect) {
    ui.boxSelect = false;
    document.body.classList.remove("box-select-active");
    if (!rect || rect.width < 8 || rect.height < 8) {
      C.toast("Drag a larger selection area.");
      return;
    }
    const mapRect = ($("#mapViewport") || $("#map")).getBoundingClientRect(),
      hits = [];
    for (const f of S.project.features) {
      if (
        f.properties.hidden ||
        f.properties.locked ||
        f.properties.guideHidden
      )
        continue;
      let c;
      try {
        c = C.featureCenter(f);
      } catch {}
      if (!c) continue;
      const pt = S.map.latLngToContainerPoint(C.latlng(c)),
        x = mapRect.left + pt.x,
        y = mapRect.top + pt.y;
      if (
        x >= rect.left &&
        x <= rect.right &&
        y >= rect.top &&
        y <= rect.bottom
      )
        hits.push(f);
    }
    if (!hits.length) {
      C.toast("No selectable objects in that area.");
      return;
    }
    if (hits.length === 1) {
      S.selected = hits[0].id;
      C.render();
      openDrawer("selection", true);
      return;
    }
    const gid = C.uid();
    for (const f of hits) f.properties.groupId = gid;
    S.selected = hits[0].id;
    C.commit();
    openDrawer("selection", true);
    C.toast(hits.length + " objects selected together.");
  }
  async function requestEntryPermissions() {
    const tasks = [];
    if (navigator.geolocation)
      tasks.push(
        new Promise((resolve) =>
          navigator.geolocation.getCurrentPosition(
            (p) => {
              S.map.setView([p.coords.latitude, p.coords.longitude], 18, {
                animate: false,
              });
              S.project.map = {
                center: { lat: p.coords.latitude, lng: p.coords.longitude },
                zoom: 18,
                bearing: S.map.getBearing?.() || 0,
              };
              C.saveSoon();
              resolve(true);
            },
            () => resolve(false),
            { enableHighAccuracy: true, timeout: 12000, maximumAge: 15000 },
          ),
        ),
      );
    if (navigator.mediaDevices?.getUserMedia)
      tasks.push(
        navigator.mediaDevices
          .getUserMedia({ audio: true })
          .then((stream) => {
            stream.getTracks().forEach((t) => t.stop());
            return true;
          })
          .catch(() => false),
      );
    return Promise.allSettled(tasks);
  }
  async function runAction(action, b) {
    try {
      const [cmd, ...parts] = action.split(":"),
        arg = parts.join(":");
      if (action !== "toggleMenu") {
        $("#globalMenu")?.setAttribute("hidden", "");
        document.body.classList.remove("global-menu-open");
        $("#menuButton")?.setAttribute("aria-expanded", "false");
      }
      if (cmd === "stage") {
        setMode(arg);
        return;
      }
      if (cmd === "open") {
        openDrawer(arg, true);
        return;
      }
      if (cmd === "choose") {
        C.cancelDraw();
        ui.drawAsset = arg;
        base.ui.asset = arg;
        const a = currentAsset();
        ui.drawMode = a.type === "panel" ? (["line","area","place"].includes(ui.drawMode) ? ui.drawMode : "line") : a.allowed.includes("place") ? "place" : a.allowed[0];
        renderDrawer("draw");
        $(".item-setup")?.scrollIntoView({block:"nearest",behavior:"smooth"});
        return;
      }
      if (cmd === "favourite") {
        ui.favourites.has(arg) ? ui.favourites.delete(arg) : ui.favourites.add(arg);
        C.setPref("sami.favourites",JSON.stringify([...ui.favourites]));
        renderDrawer("draw"); return;
      }
      if (action === "myAssets") {ui.assetFamily="My shapes";ui.assetQuery="";openDrawer("draw",true);return;}
      if (action === "startDrawing") {
        if (ui.drawAsset === "annotation_measure") beginDimension();
        else activateAsset();
        return;
      }
      if (action === "dimensionTool" || action === "addAssetMeasurement" || action === "measureTool") { beginDimension(); return; }
      if (action === "confirmAssetScale") {
        base.ui.asset = ui.drawAsset;
        await base.runAction(action);
        renderDrawer("draw");
        return;
      }
      if (action === "routeCurrentLocation") {
        if (!navigator.geolocation) { C.toast("Location is unavailable on this device."); return; }
        const project=S.project;
        navigator.geolocation.getCurrentPosition(p => {
          if(S.project!==project)return;
          const coord=[p.coords.longitude,p.coords.latitude];
          S.project.hgv={...S.project.hgv,start:coord,startText:coord[1].toFixed(6)+", "+coord[0].toFixed(6)};
          C.commit(); renderDrawer("routeToSite");
        },()=>C.toast("Location could not be found. Enter an address or pick the map."),{enableHighAccuracy:true,timeout:12000});
        return;
      }
      if (cmd === "method") {
        ui.drawMode = arg;
        renderDrawer("draw");
        return;
      }
      if (cmd === "vehicle") {
        try { C.readHgvOptions(); } catch {}
        Object.assign(S.project.hgv, {
          ...C.HGV_PROFILES[arg],
          profile: arg,
          stale: !!S.project.routes?.length,
        });
        C.commit();
        renderDrawer("routeToSite");
        return;
      }
      if (cmd === "workspaceProfile" && adminUnlocked) {
        if (applyWorkspaceProfile(arg)) renderDrawer("admin");
        return;
      }
      if (cmd === "layout" && adminUnlocked) {
        C.setPref("sami.workspaceProfile", "");
        applyLayout(arg);
        renderDrawer("admin");
        return;
      }
      if (action === "adminDone") { adminUnlocked=false; openDrawer(TABS[S.mode][0][0]); return; }
      if (action === "suggestCadDetail") {
        S.project.planDetail=window.SAMIProjectData.recommendedDetail(G.area(S.project.area),S.project.features.length);
        C.commit(); renderDrawer("background"); return;
      }
      if (cmd === "workspaceBase") {
        if (arg === "drawing" && S.mode !== "plan") { setMode("plan"); if (S.mode !== "plan") return; }
        C.switchBase(arg);
        return;
      }
      if (cmd === "appearance") {
        C.setPref("sami.workspaceProfile", "");
        applyAppearance(arg);
        renderDrawer("appearance");
        return;
      }
      if (cmd === "accent") {
        applyAccent(arg);
        renderDrawer("appearance");
        return;
      }
      if (cmd === "serviceMode") {
        ui.serviceMode = arg;
        renderDrawer("services");
        return;
      }
      if (cmd === "serviceStyle") {
        if (!C.SERVICES[arg]) return;
        ui.serviceMode = "edit";
        ui.serviceEditType = arg;
        openDrawer("services", true);
        return;
      }
      if (cmd === "applyServiceStyle") {
        if (!C.SERVICES[arg]) return;
        S.project.serviceStyles ??= {};
        const v = C.SERVICES[arg],
          q = {
            color: $("#serviceStyleColor")?.value || v.color,
            weight: Math.max(
              0.5,
              Math.min(12, +$("#serviceStyleWeight")?.value || 1),
            ),
            dash: $("#serviceStyleDash")?.value || "solid",
            opacity: Math.max(
              0.05,
              Math.min(1, (+$("#serviceStyleOpacity")?.value || 100) / 100),
            ),
          };
        if (v.area) {
          q.fillColor = $("#serviceStyleFill")?.value || v.color;
          q.fillOpacity = Math.max(
            0,
            Math.min(0.8, (+$("#serviceStyleFillOpacity")?.value || 0) / 100),
          );
        }
        S.project.serviceStyles[arg] = q;
        C.commit();
        renderDrawer("services");
        C.toast(v.name + " appearance updated for all items.");
        return;
      }
      if (cmd === "resetServiceStyle") {
        if (!C.SERVICES[arg]) return;
        S.project.serviceStyles ??= {};
        delete S.project.serviceStyles[arg];
        C.commit();
        renderDrawer("services");
        C.toast(C.SERVICES[arg].name + " appearance reset.");
        return;
      }
      if (cmd === "addService") {
        const v = C.SERVICES[arg];
        if (!v) return;
        S.project.serviceVisibility[arg] = true;
        S.project.serviceVisibilityConfigured = true;
        startTool("service", {
          serviceType: arg,
          area: !!v.area,
          label: v.name,
          planCommitted: true,
          source: "Manual project / survey record",
          verification: "Verify before excavation",
          includeLegend: true,
        });
        return;
      }
      if (cmd === "profile") {
        const p = (await Store.profiles()).find((x) => x.id === arg);
        if (p) {
          Object.assign(S.project.meta, p.meta);
          S.project.logos = copy(p.logos || []);
          C.commit();
          openDrawer("details");
        }
        return;
      }
      if (action === "mapSearch") {
        await mapSearch();
        return;
      }
      if (action === "mapLocate") {
        useCurrentLocation();
        return;
      }
      if (action === "goCoordinates") {
        const lat = +$("#exploreLat").value,
          lng = +$("#exploreLng").value;
        if (!G.validCoord([lng, lat]))
          throw Error("Enter valid latitude and longitude.");
        S.map.setView([lat, lng], 18);
        return;
      }
      if (action === "locateW3w") {
        const q = $("#exploreW3w").value.trim(),
          r = await C.resolveLocationText(q);
        S.map.setView(C.latlng(r.coord), 18);
        S.project.meta.what3words = q;
        C.commit();
        return;
      }
      if (action === "visibleArea") {
        visibleArea();
        return;
      }
      if (action === "selectItem") {
        setPrecision(false);
        ui.boxSelect = false;
        document.body.classList.remove("box-select-active");
        C.cancelDraw();
        S.selected = null;
        C.render();
        C.toast("Select mode · tap any item to inspect it.");
        return;
      }
      if (action === "selectArea") {
        startBoxSelect();
        return;
      }
      if (action === "precisionDraw") {
        setPrecision(!ui.precision.active, "draw");
        return;
      }
      if (action === "mapMeasure") {
        setPrecision(!ui.precision.active, "measure");
        return;
      }
      if (action === "measureTool") {
        ui.drawAsset = "annotation_measure";
        ui.drawMode = "line";
        base.runAction("draw:measure");
        openDrawer("draw");
        return;
      }
      if (action === "labelTool") {
        ui.drawAsset = "annotation_textBox";
        ui.drawMode = "place";
        base.runAction("draw:textBox");
        openDrawer("draw");
        return;
      }
      if (action === "fitArea") {
        fitArea();
        return;
      }
      if (action === "servicesShowAll" || action === "servicesHideAll") {
        const visible = action === "servicesShowAll";
        for (const k of Object.keys(C.SERVICES))
          S.project.serviceVisibility[k] = visible;
        S.project.serviceVisibilityConfigured = true;
        C.commit();
        renderDrawer("services");
        return;
      }
      if (action === "fieldNote" || action === "fieldPhoto") {
        if (S.mode !== "map") setMode("map");
        base.runAction(action === "fieldNote" ? "draw:note" : "draw:photo", b);
        return;
      }
      if (action === "chooseReferenceImage") {
        $("#referenceImageInput").click();
        return;
      }
      if (action === "matchReferenceImage") {
        await matchReferenceImage();
        return;
      }
      if (action === "overlayCurrentView") {
        showReferenceOverlay(L.latLngBounds(bearing.visibleCorners()));
        const r = referenceOverlay.getBounds();
        S.project.reference = {
          ...ui.reference,
          file: undefined,
          bounds: [
            [r.getSouth(), r.getWest()],
            [r.getNorth(), r.getEast()],
          ],
        };
        C.saveSoon();
        return;
      }
      if (action === "removeReferenceOverlay") {
        referenceOverlay?.remove();
        referenceOverlay = null;
        delete S.project.reference;
        C.saveSoon();
        return;
      }
      if (action === "review" || action === "export") {
        requestExport();
        return;
      }
      if (action === "issue") {
        if (validate().some((x) => x.severity === "error")) {
          renderDrawer("review");
          return;
        }
        ui.exportApproved = true;
        try {
          C.openExport();
        } finally {
          ui.exportApproved = false;
        }
        return;
      }
      if (action === "resumeDraft") {
        const stage =
          Object.entries(ui.drafts).find(([, x]) => x.points?.length)?.[0] ||
          S.mode;
        setMode(stage);
        return;
      }
      if (action === "finishGroup") {
        await base.runAction("finishGroupPick");
        openDrawer("review");
        return;
      }
      if (action === "projects") {
        await dashboard();
        return;
      }
      if (action === "resumeProject") {
        hideDashboard();
        return;
      }
      if (action === "newProject") {
        await newProject();
        return;
      }
      if (action === "openProject") {
        S.importKind = "project";
        $("#importInput").click();
        $("#projectDashboard")?.setAttribute("hidden", "");
        return;
      }
      if (action === "save") {
        if (await save(true, "Manual save")) C.toast("Project saved.");
        return;
      }
      if (action === "saveAs") {
        C.showModal(
          "Save as a new project",
          C.field("duplicateName", "Project name", S.project.name + " — copy") +
            B("Save copy", "confirmDuplicate", true),
        );
        $("#modalBody").onclick = async (e) => {
          if (!e.target.closest('[data-action="confirmDuplicate"]')) return;
          await save();
          const name = $("#duplicateName").value.trim();
          if (!name) return;
          const p = await Store.duplicate(S.project, name);
          C.closeModal();
          await loadProject(p);
          C.toast("You are working in the new copy.");
        };
        return;
      }
      if (action === "history") {
        await history();
        return;
      }
      if (action === "saveProfile") {
        const keys = [
            "creator",
            "designerCompany",
            "jobTitle",
            "designerEmail",
            "designerPhone",
          ],
          meta = Object.fromEntries(
            keys.map((k) => [k, S.project.meta[k] || ""]),
          ),
          name = meta.designerCompany || meta.creator;
        if (!name) throw Error("Add your company or prepared-by name first.");
        await Store.saveProfile({
          name,
          meta,
          logos: copy(S.project.logos || []),
        });
        loadProfiles();
        C.toast("Company profile saved.");
        return;
      }
      if (action === "tutorial") {
        tutorial();
        return;
      }
      if (action === "replay" || action === "sales") {
        action === "replay"
          ? window.SAMICinema?.play("welcome", { after: "menu" })
          : window.SAMICinema?.play("sales");
        return;
      }
      if (action === "closeApp") {
        await save(true, "Closed SAMI");
        window.SAMICinema?.shutdown();
        return;
      }
      if (action === "about") {
        const version =
          window.SAMI_VERSION?.version ||
          document.documentElement.dataset.samiVersion ||
          "2.7.14";
        C.showModal(
          "SAMI",
          '<img src="sami-wordmark.png" class="about-logo about-wordmark" alt="SAMI"><p>Spatial Analysis Mapping Intelligence</p><p>Version ' +
            esc(version) +
            ' · Project workspace</p><p class="subtle">Map © OpenStreetMap contributors. Imagery © Esri. Public sources are planning references; verify site conditions before work.</p>',
        );
        return;
      }
      if (action === "rotateProperties") {
        rotateProperties();
        return;
      }
      if (action === "editMove") {
        C.cancelDraw();
        C.render();
        C.toast("Drag the object or its centre handle to move.");
        return;
      }
      if (action === "editVertices") {
        const f = C.selectedFeature();
        if (
          !f ||
          f.properties.dimensionLocked ||
          f.properties.type === "panel" ||
          f.properties.locked ||
          f.properties.sourceId
        ) {
          C.toast("This object has fixed or reference geometry.");
          return;
        }
      }
      if (action === "replaceAsset") {
        const f = C.selectedFeature(),
          a = C.ASSETS[$("#replaceAsset").value];
        if (!f || !a || f.properties.locked) return;
        const center = C.featureCenter(f),
          angle = f.properties.angle || 0;
        f.geometry = G.rectangle(center, a.length, a.width, angle);
        Object.assign(f.properties, a, {
          kind: $("#replaceAsset").value,
          label: a.name,
          centerLng: center[0],
          centerLat: center[1],
          angle,
        });
        C.commit();
        renderDrawer("selection");
        return;
      }
      if (cmd === "addOhlToPlan") {
        const f = S.project.features.find((feature) => feature.id === arg);
        if (!f || f.properties.type !== "service" || f.properties.serviceType !== "ohl") return;
        Object.assign(f.properties, { planCommitted: true, includeLegend: true, hidden: false });
        C.closeModal();
        C.commit();
        if (S.project.area) {
          setMode("plan");
          C.switchBase("drawing");
          C.toast("OHL added to CAD · saved with this project.");
        } else C.toast("OHL saved · define the site area to show it on the CAD plan.");
        await save();
        return;
      }
      if (action === "commitServiceToPlan") {
        const f = C.selectedFeature();
        if (f) {
          f.properties.planCommitted = true;
          f.properties.includeLegend = true;
          C.commit();
          renderDrawer("selection");
        }
        return;
      }
      if (action === "servicesCatalogue") {
        C.showModal(
          "Service & constraint sources",
          "<p>Public map features are incomplete reference information. Imported survey and utility records retain their source labels.</p>" +
            B("Public utility references", "refreshPublicUtilities") +
            B("OHL snapshot", "refreshOhl") +
            B("England planning constraints", "refreshPlanningConstraints") +
            B("Scotland protected sites", "refreshScotlandConstraints") +
            B("Wales protected sites (NRW)", "refreshWalesConstraints") +
            B("Northern Ireland ASSI sites", "refreshNIConstraints") +
            B("Source archives", "archives") +
            "<p>" +
            CAVEAT +
            "</p>",
        );
        $("#modalBody").onclick = (e) => {
          const a = e.target.closest("[data-action]")?.dataset.action;
          if (a) {
            C.closeModal();
            runAction(a);
          }
        };
        return;
      }
      if (action === "dataPack") {
        $("#dataPackInput").click();
        return;
      }
      if (action === "groupMultiSelection") {
        await base.runAction("groupMultiSelection");
        renderDrawer("selection");
        return;
      }
      if (action === "clearMultiSelection") {
        S.multiSelection?.clear();
        C.render();
        renderDrawer("selection");
        return;
      }
      return await base.runAction(action, b);
    } catch (e) {
      console.error("SAMI action", action, e);
      C.toast(e.message || "This action could not be completed.");
    }
  }
  function visibleFeature(f) {
    if (f.properties.type === "service" && f.properties.planCommitted) {
      if (f.properties.hidden) return null;
      const mapBounds =
          f.properties.serviceType === "ohl" && S.project.area
            ? G.expandBoundsMeters(S.project.area, 804.672)
            : C.serviceBounds(),
        geometry = S.project.area
          ? G.clipGeometry(
              f.geometry,
              S.mode === "plan" ? base.planBounds() : mapBounds,
            )
          : f.geometry;
      return geometry ? { ...f, geometry } : null;
    }
    return base.visibleFeature(f);
  }
  let tooltipTimer, tooltipEl, lastTip;
  function tooltipStart(e) {
    const b = e.target.closest("button[title]");
    if (!b || !ui.tooltips) return;
    const show = () => {
      tooltipEl?.remove();
      tooltipEl = document.createElement("div");
      tooltipEl.className = "function-tooltip";
      tooltipEl.textContent = b.title;
      document.body.append(tooltipEl);
      const r = b.getBoundingClientRect();
      tooltipEl.style.left =
        Math.max(8, Math.min(innerWidth - 180, r.left + r.width / 2 - 70)) +
        "px";
      tooltipEl.style.top = Math.max(8, r.top - 38) + "px";
      setTimeout(() => tooltipEl?.remove(), 2000);
    };
    if (lastTip?.b === b && performance.now() - lastTip.time < 800) show();
    else tooltipTimer = setTimeout(show, 550);
    lastTip = { b, time: performance.now() };
  }
  function tooltipEnd() {
    clearTimeout(tooltipTimer);
  }

  function mount() {
    applyLayout(C.readPref("sami.layout") || "classic");
    document.body.classList.add("studio-workspace");
    applyAppearance();
    const viewport = document.createElement("div");
    viewport.id = "mapViewport";
    $("#map").before(viewport);
    viewport.append($("#map"));
    $("#inspectorBody").append($("#drawer"));
    $("#drawer").classList.remove("open");
    base.mount();
    const storageWarning = document.createElement("button");
    storageWarning.id = "storageWarning";
    storageWarning.type = "button";
    storageWarning.className = "storage-warning";
    storageWarning.hidden = true;
    storageWarning.setAttribute("aria-live", "assertive");
    storageWarning.onclick = () => runAction("backup");
    $("#app").append(storageWarning);
    window.addEventListener("sami:storage", (event) => {
      if (!event.detail?.message) return;
      storageWarning.textContent = event.detail.message + " Export backup";
      storageWarning.hidden = false;
      C.toast(event.detail.message);
    });
    document.addEventListener(
      "pointerdown",
      () => navigator.storage?.persist?.().catch?.(() => false),
      { once: true, passive: true },
    );
    const armKeyboardField = (el) => {
      if (!el) return;
      el.readOnly = true;
      el.blur?.();
      el.addEventListener(
        "pointerdown",
        () => {
          el.readOnly = false;
          setTimeout(() => el.focus({ preventScroll: true }), 0);
        },
        { once: true },
      );
    };
    armKeyboardField($("#projectName"));
    armKeyboardField($("#askInput"));
    requestAnimationFrame(() => document.activeElement?.blur?.());
    setTimeout(() => document.activeElement?.blur?.(), 120);
    $("#selectionBar").innerHTML =
      `<span><strong id="selectionName"></strong><small id="selectionCount"></small></span><span data-group-normal>${tip(ICONS.edit, "Properties", "open:selection")}</span><span data-group-normal>${tip(ICONS.move, "Move", "editMove")}</span><span data-group-normal>${tip(ICONS.rotate, "Rotate", "rotateProperties")}</span><span data-group-normal>${tip(ICONS.points, "Edit points", "editVertices")}</span><span data-group-normal>${tip(ICONS.duplicate, "Duplicate", "editDuplicate")}</span><span data-group-normal>${tip(ICONS.group, "Group", "editGroup")}</span><span data-group-normal>${tip(ICONS.ungroup, "Ungroup", "editUngroup")}</span><span data-group-normal>${tip(ICONS.bin, "Delete", "editDelete")}</span><span data-group-normal>${tip(ICONS.close, "Close · deselect", "deselectClose")}</span><button class="group-pick-done" data-action="finishGroupPick" data-group-pick hidden>Done</button><button class="group-pick-cancel" data-action="cancelGroupPick" data-group-pick hidden>Cancel</button>`;
    const restore = document.createElement("button");
    restore.id = "restoreInspector";
    restore.title = "Show tools";
    restore.setAttribute("aria-label", "Show tools");
    restore.hidden = !document.body.classList.contains("inspector-collapsed");
    restore.innerHTML =
      'Tools <svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';
    restore.onclick = () => openDrawer(ui.drawer, true);
    $("#workspace").append(restore);
    const menuEl = document.createElement("nav");
    menuEl.id = "globalMenu";
    menuEl.className = "global-menu";
    menuEl.hidden = true;
    menuEl.setAttribute("aria-label", "SAMI commands");
    const menuGroup = (title, rows) => `<section class="menu-group"><h3>${title}</h3>${rows.map(([n,a]) => B(n,a)).join("")}</section>`;
    menuEl.innerHTML =
      menuGroup("Project", [
        ["Projects", "projects"],
        ["New project", "newProject"],
        ["Open project file", "openProject"],
        ["Save a copy", "saveAs"],
        ["Download backup", "backup"],
        ["Previous saved states", "history"],
      ]) +
      menuGroup("Preferences", [
        ["Appearance", "open:appearance"],
        ["Settings", "open:settings"],
        ["Admin layouts", "open:admin"],
      ]) +
      menuGroup("Help", [
        ["Help & tutorial", "open:help"],
        ["Replay intro", "replay"],
        ["About SAMI", "about"],
      ]) +
      `<section class="menu-group menu-close">${B("Close SAMI", "closeApp")}</section>`;
    $("#app").append(menuEl);
    menuEl.onclick = (e) => {
      const a = e.target.closest("[data-action]")?.dataset.action;
      if (!a) return;
      menuEl.hidden = true;
      document.body.classList.remove("global-menu-open");
      $("#menuButton").setAttribute("aria-expanded", "false");
      runAction(a);
    };
    $("#menuButton").onclick = menu;
    $("#homeBtn").onclick = dashboard;
    $("#exportBtn").onclick = requestExport;
    $("#snapToggle").onclick = () => setSnap(!base.ui.snap);
    $("#selectTool").onclick = () => {
      C.cancelDraw();
      S.selected = null;
      C.render();
      openDrawer("layers", true);
    };
    $("#fitBtn").onclick = () =>
      S.project.area
        ? fitArea()
        : C.toast("Define a site area to fit the drawing.");
    $("#locateBtn").onclick = useCurrentLocation;
    const style = document.createElement("button");
    style.id = "mapStyleButton";
    style.title = "Map style";
    style.setAttribute("aria-label", "Map style");
    style.innerHTML =
      '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3.5L4 8l8 4.5 8-4.5z"/><path d="M4 12l8 4.5L20 12"/><path d="M4 16l8 4.5L20 16"/></svg>';
    $(".map-controls").prepend(style);
    style.onclick = () => document.body.classList.toggle("map-style-open");
    $("#baseCollapse")?.remove();
    $$("[data-base]").forEach((b) =>
      b.addEventListener("click", () =>
        document.body.classList.remove("map-style-open"),
      ),
    );
    const mapMeasure = document.createElement("button");
    mapMeasure.id = "mapMeasureButton";
    mapMeasure.type = "button";
    mapMeasure.title = "Measure on map";
    mapMeasure.setAttribute("aria-label", "Measure distance or area on map");
    mapMeasure.innerHTML = "⌖";
    mapMeasure.onclick = () => runAction("mapMeasure");
    $(".map-controls").prepend(mapMeasure);

    const commandBar = document.createElement("nav");
    commandBar.id = "primaryCommandBar";
    commandBar.className = "primary-command-bar";
    commandBar.setAttribute("aria-label", "Site plan commands");
    commandBar.innerHTML =
      '<button type="button" data-command="select" aria-label="Select objects"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 3l12 8-6 2-2 6z"/></svg><span>Select</span></button>' +
      '<button type="button" data-command="add" aria-label="Add item"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14"/></svg><span>Add</span></button>' +
      '<button type="button" data-command="measure" aria-label="Add dimension"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 16L16 4l4 4L8 20z"/><path d="M10 10l2 2M13 7l2 2M7 13l2 2"/></svg><span>Dimension</span></button>';
    const history = document.createElement("div");
    history.className = "command-history";
    history.append($("#undoBtn"), $("#redoBtn"));
    commandBar.append(history);
    $("#workspace").append(commandBar);
    commandBar.querySelector('[data-command="select"]').onclick = () => runAction("selectItem");
    commandBar.querySelector('[data-command="add"]').onclick = () => {
      if (S.mode !== "plan") {
        if (!S.project.area) { C.toast("Define the site area first."); setMode("map"); openDrawer("area", true); return; }
        setMode("plan");
      }
      openDrawer("draw", true);
    };
    commandBar.querySelector('[data-command="measure"]').onclick = () => S.mode === "plan" ? runAction("dimensionTool") : runAction("mapMeasure");
    const extra=document.createElement("div"); extra.className="ribbon-insert";
    extra.innerHTML=`<button data-action="ribbonTrakway"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 3h16v18H4zM4 9h16M4 15h16M12 3v18"/></svg><span>Trakway</span></button><button data-action="ribbonText"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M5 6V4h14v2M12 4v16M8 20h8"/></svg><span>Text</span></button>`;
    commandBar.insertBefore(extra,history);
    extra.onclick=e=>{const a=e.target.closest("[data-action]")?.dataset.action;if(a === "ribbonTrakway"){if(S.mode!=="plan"&&!setMode("plan"))return;ui.assetFamily="Trakway";openDrawer("draw",true);}else if(a === "ribbonText"){ui.drawAsset="annotation_textBox";activateAsset();}};
    commandBar.append($("#snapToggle"));
    const backgrounds=$(".base-switch"); if(backgrounds)commandBar.append(backgrounds);
    const statusbar=document.createElement("footer"); statusbar.id="editorStatus"; statusbar.setAttribute("aria-live","polite");
    statusbar.innerHTML='<span id="editorSummary">Ready</span><button id="cadStatus" type="button">Site view</button>';
    statusbar.querySelector('button').onclick=()=>openDrawer("background",true);
    $("#workspace").append(statusbar);
    const updateStatus=()=>{const x=$("#cadStatus");if(!x)return;x.classList.toggle("is-busy",!!S.planCapturing);x.textContent=S.planCapturing?"Building site CAD…":S.planCaptureError?"CAD needs attention":S.project.planBaseMeta?.capturedAt?"CAD · "+(S.project.planBase?.length||0)+" features":"Site view";x.title=S.planCaptureError||"Map background and CAD detail";};
    window.addEventListener("sami:cadstatus",updateStatus); updateStatus();
    let dimensionFrame;
    S.map.on("mousemove",e=>{
      if(S.tool!=="measure" || !S.options.dimension) return;
      cancelAnimationFrame(dimensionFrame);
      dimensionFrame=requestAnimationFrame(()=>{
        if(S.tool!=="measure" || !S.options.dimension) return;
        const coord=C.coord(e.latlng);
        S.options.dimensionHover=S.points.length<2 ? window.SAMIPlanning.nearestCorner(coord,S.project.features,S.project,c=>S.map.latLngToContainerPoint(C.latlng(c)),16,S.options.sourceId) : {coord};
        renderDraft();
      });
    });

    // Ask SAMI has one entry point in the header. The conversation and input
    // live together in one panel rather than floating over the map.
    const askBar = $(".ask-bar-wrap"), samiPanel = $("#samiPanel");
    if (askBar && samiPanel) samiPanel.append(askBar);
    $("#askCollapse")?.setAttribute("hidden", "");
    if ($("#headerAskBtn")) $("#headerAskBtn").onclick = () => {
      samiPanel?.classList.add("open");
      const input = $("#askInput");
      if (input) { input.readOnly = false; input.inputMode = "text"; setTimeout(() => input.focus({preventScroll:true}), 0); }
    };
    updateMapModeControls();
    const areaChip = $("#areaChip");
    areaChip.title = "Define or update site area";

    const selectSurface = $("#mapViewport") || $("#map");
    selectSurface.addEventListener(
      "pointerdown",
      (e) => {
        if (!ui.boxSelect || e.button > 0) return;
        const r = selectSurface.getBoundingClientRect();
        boxPointer = { id: e.pointerId, x: e.clientX, y: e.clientY };
        boxMarquee = document.createElement("div");
        boxMarquee.className = "selection-marquee";
        boxMarquee.style.left = e.clientX - r.left + "px";
        boxMarquee.style.top = e.clientY - r.top + "px";
        selectSurface.append(boxMarquee);
        S.map.dragging.disable();
        selectSurface.setPointerCapture?.(e.pointerId);
        e.preventDefault();
        e.stopPropagation();
      },
      { capture: true },
    );
    selectSurface.addEventListener(
      "pointermove",
      (e) => {
        if (!boxPointer || e.pointerId !== boxPointer.id || !boxMarquee) return;
        const r = selectSurface.getBoundingClientRect(),
          x1 = Math.min(boxPointer.x, e.clientX) - r.left,
          y1 = Math.min(boxPointer.y, e.clientY) - r.top,
          x2 = Math.max(boxPointer.x, e.clientX) - r.left,
          y2 = Math.max(boxPointer.y, e.clientY) - r.top;
        Object.assign(boxMarquee.style, {
          left: x1 + "px",
          top: y1 + "px",
          width: x2 - x1 + "px",
          height: y2 - y1 + "px",
        });
        e.preventDefault();
        e.stopPropagation();
      },
      { capture: true },
    );
    const endBox = (e) => {
      if (!boxPointer || e.pointerId !== boxPointer.id) return;
      const x1 = Math.min(boxPointer.x, e.clientX),
        y1 = Math.min(boxPointer.y, e.clientY),
        x2 = Math.max(boxPointer.x, e.clientX),
        y2 = Math.max(boxPointer.y, e.clientY),
        rect = {
          left: x1,
          top: y1,
          right: x2,
          bottom: y2,
          width: x2 - x1,
          height: y2 - y1,
        };
      boxMarquee?.remove();
      boxMarquee = null;
      boxPointer = null;
      selectSurface.releasePointerCapture?.(e.pointerId);
      C.updateLock();
      finishBoxSelect(rect);
      e.preventDefault();
      e.stopPropagation();
    };
    selectSurface.addEventListener("pointerup", endBox, { capture: true });
    selectSurface.addEventListener("pointercancel", endBox, { capture: true });
    S.map.on("move", () => {
      if (ui.precision.active) {
        ui.precision.cursorCoord = null;
        schedulePrecisionRefresh();
      }
    });
    let file = $("#referenceImageInput");
    if (!file) {
      file = document.createElement("input");
      file.type = "file";
      file.accept = "image/*";
      file.hidden = true;
      file.id = "referenceImageInput";
      document.body.append(file);
    }
    file.onchange = async () => {
      try {
        await chooseReferenceFile(file.files?.[0]);
      } catch (e) {
        C.toast(e.message);
      }
      file.value = "";
    };
    let rotationHintTimer;
    const showRotationHint = () => {
      let hint = $("#rotationLockHint");
      if (!hint) {
        hint = document.createElement("div");
        hint.id = "rotationLockHint";
        hint.className = "rotation-lock-hint";
        hint.textContent = "Unlock rotation to spin the map";
        $("#workspace").append(hint);
      }
      const button = $("#compassButton"),
        wr = $("#workspace").getBoundingClientRect(),
        br = button.getBoundingClientRect();
      hint.style.left =
        Math.max(10, Math.min(wr.width - 230, br.left - wr.left - 176)) + "px";
      hint.style.top =
        Math.max(10, br.top - wr.top + (br.height - hint.offsetHeight) / 2) +
        "px";
      hint.classList.add("show");
      clearTimeout(rotationHintTimer);
      rotationHintTimer = setTimeout(() => hint.classList.remove("show"), 2200);
    };
    bearing = SAMIBearing(
      S.map,
      viewport,
      (value) => {
        if (S.mode === "plan") {
          S.project.planView = {
            ...(S.project.planView || captureView()),
            bearing: value,
          };
          syncPlanFromCurrentView(false);
        } else
          S.project.map = {
            ...(S.project.map || captureView()),
            bearing: value,
          };
        updateCompass();
        C.saveSoon();
      },
      showRotationHint,
    );
    const updateCompass = () => {
      const n = $("#compassButton");
      n.hidden = false;
      n.style.setProperty("--bearing", bearing.get() + "deg");
      n.title =
        "North & rotation · " +
        Math.round(bearing.get()) +
        "°" +
        (bearing.getLocked() ? " · locked" : "");
      n.setAttribute("aria-label", "North and map rotation controls");
    };
    const northControls = () => {
      const locked = bearing.getLocked();
      C.showModal(
        "North & map rotation",
        `<div class="north-panel"><div class="north-readout"><b>N</b><span>${Math.round(bearing.get())}°</span></div>${C.field("bearingValue", "Map bearing (degrees)", Math.round(bearing.get()), "number", 'min="0" max="359"')}<div class="button-pair">${B("Reset North", "northReset", true)}${B(locked ? "Unlock rotation" : "Lock rotation", "northToggleLock")}</div>${B("Apply bearing", "northApply")}<p class="subtle">Rotation is locked by default. The separate padlock controls panning only; zoom remains available.</p></div>`,
      );
      $("#modalBody").onclick = (e) => {
        const a = e.target.closest("[data-action]")?.dataset.action;
        if (a === "northReset") {
          bearing.set(0);
          C.closeModal();
        }
        if (a === "northApply") {
          bearing.set(+$("#bearingValue").value);
          C.closeModal();
        }
        if (a === "northToggleLock") {
          bearing.setLocked(!bearing.getLocked());
          updateCompass();
          C.closeModal();
          setTimeout(northControls, 0);
        }
      };
    };
    S.map.on("bearingchange", updateCompass);
    $("#compassButton").onclick = northControls;
    $("#bearingButton").hidden = true;
    let planViewSyncTimer;
    S.map.on("moveend zoomend", () => {
      if (S.mode === "plan") {
        clearTimeout(planViewSyncTimer);
        planViewSyncTimer = setTimeout(() => syncPlanFromCurrentView(true), 80);
      }
    });
    document.addEventListener("click", (e) => {
      if (!e.target.closest("#globalMenu,#menuButton")) {
        menuEl.hidden = true;
        document.body.classList.remove("global-menu-open");
        $("#menuButton").setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        save(true, "Manual save");
      }
      if (e.key === "Escape") {
        menuEl.hidden = true;
        document.body.classList.remove("global-menu-open");
      }
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && ui.ready) {
        save();
        Store.journal({
          ...S.project,
          session: session(),
          savedAt: new Date().toISOString(),
        });
        precisionWakeLock?.release?.().catch?.(() => {});
        precisionWakeLock = null;
      } else if (
        ui.precision.active &&
        C.readPref("sami.measure.wake") === "on"
      ) {
        setPrecisionWake(true);
      }
    });
    window.addEventListener("pagehide", () =>
      ui.ready && Store.journal({
        ...S.project,
        session: session(),
        savedAt: new Date().toISOString(),
      }),
    );
    document.addEventListener("pointerdown", tooltipStart, { passive: true });
    document.addEventListener("pointerup", tooltipEnd, { passive: true });
    document.addEventListener("pointercancel", tooltipEnd, { passive: true });
    $("#backPointBtn").onclick = () => {
      if (S.points.length) {
        S.points.pop();
        renderDraft();
      }
    };
    $("#cancelDrawBtn").onclick = () => {
      C.cancelDraw();
      delete ui.drafts[S.mode];
      C.saveSoon();
      C.render();
    };
    document.body.classList.add("ask-collapsed");
    ui.ready = true;
    openDrawer("explore", true);
    window.SAMIWorkspace.ready = (async () => {
      ui.ready = false;
      let recovered;
      try {
        recovered = await Store.recover();
      } catch {}
      await loadProject(recovered || S.project);
      setSnap(S.project.snapEnabled !== false);
      updateCompass();
      await dashboard();
      const installed =
          navigator.standalone === true ||
          window.matchMedia?.("(display-mode: standalone)")?.matches ||
          window.matchMedia?.("(display-mode: window-controls-overlay)")?.matches ||
          window.matchMedia?.("(display-mode: minimal-ui)")?.matches ||
          navigator.windowControlsOverlay?.visible === true,
        launchAction = installed
          ? new URLSearchParams(location.search).get("action")
          : null;
      if (launchAction) {
        window.history.replaceState(
          null,
          "",
          location.pathname + location.hash,
        );
        if (launchAction === "new") await newProject();
        else if (launchAction === "last") hideDashboard();
        else if (launchAction === "route") {
          hideDashboard();
          setMode("route");
        }
      }
    })();
  }
  const api = {
    save,
    dashboard,
    requestExport,
    validate,
    requestEntryPermissions,
    get exportApproved() {
      return !!ui.exportApproved;
    },
    get state() {
      return S;
    },
    isViewLocked: () => bearing?.getLocked?.() || false,
    loadProject,
    runAction,
    snap,
  };
  window.SAMIWorkspace = api;
  return {
    ...base,
    normaliseProject,
    visibleFeature,
    featureStyle,
    render,
    setMode,
    setModeUI,
    fitArea,
    openDrawer,
    closeDrawer,
    assetsHTML: () => libraryHTML(true),
    drawHTML: () => libraryHTML(false),
    startTool,
    onMapClick,
    onMapMouseMove,
    renderDraft,
    finishDraw,
    layersHTML,
    selectionHTML,
    routeToSiteHTML: routeHTML,
    projectHTML,
    helpHTML,
    renderDrawer,
    bindDrawer,
    runAction,
    initToolRail: () => {},
    clampRail: () => {},
    initFreehandInput,
    mount,
  };
};
