window.SAMIStudioEngine = function (C, O) {
  "use strict";
  const { state: S, G, PRODUCTS, ASSETS, TYPES, SERVICES } = C,
    D = window.SAMISymbols;
  const $ = (q) => document.querySelector(q),
    $$ = (q) => [...document.querySelectorAll(q)],
    esc = C.esc,
    copy = C.copy;
  const B = (label, action, primary = false) =>
      C.button(label, action, primary),
    F = C.field;
  const colour = (v) => (/^#[a-f\d]{6}$/i.test(v || "") ? v : "#a2c4b8");
  const EXTRA = {
    accessibleToilet: ["Accessible toilet", 2.4, 2.4, "Welfare"],
    shower: ["Shower unit", 2.4, 2.4, "Welfare"],
    kitchen: ["Catering cabin", 6.1, 2.44, "Welfare"],
    ambulance: ["Ambulance", 6, 2.4, "Vehicles"],
    fireEngine: ["Fire appliance", 8.5, 2.55, "Vehicles"],
    crane: ["Mobile crane footprint", 12, 3, "Plant"],
    crowdBarrier: ["Crowd control barrier", 2.3, 0.5, "Perimeter"],
    waterTank: ["Water tank", 3, 1.8, "Logistics"],
    distribution: ["Electrical distribution", 1.2, 0.8, "Logistics"],
    marquee: ["Marquee", 12, 6, "Event"],
    tent: ["Event tent", 6, 6, "Event"],
    gazebo: ["Gazebo", 3, 3, "Event"],
    foodTruck: ["Catering vehicle", 7, 2.5, "Event"],
    ticketBooth: ["Ticket booth", 3, 2.4, "Event"],
    bar: ["Event bar", 4, 2, "Event"],
    grandstand: ["Grandstand footprint", 12, 5, "Event"],
    chair: ["Chair", 0.55, 0.55, "Event"],
    roundTable: ["Round table & chairs", 2.4, 2.4, "Event"],
    tree: ["Tree canopy", 5, 5, "Landscape"],
    planter: ["Planter", 1.5, 1.5, "Landscape"],
    accessible: ["Accessible meeting point", 1.5, 1.5, "Safety"],
    noEntry: ["No entry sign", 1.5, 1.5, "Safety"],
    pole: ["Utility pole symbol", 0.55, 0.55, "Power"],
    tower: ["Lattice tower footprint", 7, 7, "Power"],
  };
  for (const [k, [name, length, width, category]] of Object.entries(EXTRA))
    ASSETS[k] = {
      name,
      length,
      width,
      category,
      symbol: k,
      dimensionNote: "Editable indicative footprint",
    };
  Object.assign(ASSETS, window.SAMIBuiltinAssets || {});
  TYPES.accessPoint = "Access point";
  TYPES.logo = "Company logo";
  const SURFACES = {
    access: {
      name: "Access direction",
      category: "Lines & areas",
      method: "line",
    },
    egress: {
      name: "Exit direction",
      category: "Lines & areas",
      method: "line",
    },
    route: { name: "Site route", category: "Lines & areas", method: "line" },
    stoneRoad: {
      name: "Stone road",
      category: "Lines & areas",
      method: "line",
    },
    stoneArea: {
      name: "Stone hardstanding",
      category: "Lines & areas",
      method: "area",
    },
    area: {
      name: "Compound / area",
      category: "Lines & areas",
      method: "area",
    },
    hazard: {
      name: "Exclusion area",
      category: "Lines & areas",
      method: "area",
    },
    excavation: {
      name: "Excavation",
      category: "Lines & areas",
      method: "area",
    },
  };
  const ui = {
    asset: "panel_lion",
    method: "place",
    category: "Trakway",
    snap: true,
    search: "",
    collapsed: new Set(),
    creator: null,
    dragging: false,
    panning: false,
    penOnly: false,
    lastVoice: 0,
  };
  let symbolLayer = null,
    selectionBox = null,
    voiceAudio = null,
    voiceController = null,
    voiceSeq = 0,
    creatorHistory = [],
    customKinds = new Set();
  const supportKey = C.supportKey;
  function panelsInfo(k) {
    const key = k.replace("panel_", ""),
      p = PRODUCTS[key];
    return p
      ? {
          ...p,
          kind: k,
          product: key,
          category: "Trakway",
          type: "panel",
          dimensionLocked: key !== "custom",
        }
      : null;
  }
  function getAsset(k = ui.asset) {
    return k?.startsWith("panel_")
      ? panelsInfo(k)
      : k?.startsWith("surface_")
        ? { ...SURFACES[k.slice(8)], kind: k, surface: k.slice(8) }
        : ASSETS[k];
  }
  function ensureProject(p) {
    p.customAssets ??= [];
    p.logos ??= [];
    p.schemaVersion = 5;
    p.features ??= [];
    return p;
  }
  function syncCatalogue() {
    for (const k of customKinds) delete ASSETS[k];
    customKinds.clear();
    for (const a of S.project?.customAssets || []) {
      ASSETS[a.kind] = a;
      customKinds.add(a.kind);
    }
    for (const a of S.project?.logos || []) {
      const k = "logo_" + a.id;
      ASSETS[k] = {
        kind: k,
        name: a.name,
        length: a.length || 4,
        width: a.width || (a.length || 4) / a.ratio,
        category: "My logos",
        imageData: a.data,
        logoId: a.id,
        dimensionLocked: false,
      };
      customKinds.add(k);
    }
  }
  function fresh() {
    const p = ensureProject(O.fresh());
    p.planBleed = 10;
    try {
      const profile = JSON.parse(C.readPref("sami.designer") || "{}");
      for (const k of [
        "creator",
        "designerCompany",
        "designerEmail",
        "designerPhone",
      ])
        if (typeof profile[k] === "string") p.meta[k] = profile[k];
    } catch {}
    return p;
  }
  function normaliseProject(p) {
    const n = ensureProject(O.normaliseProject(p));
    n.customAssets = (p.customAssets || [])
      .filter(
        (a) =>
          a &&
          /^my_[a-z\d_-]+$/i.test(a.kind) &&
          +a.length > 0 &&
          +a.width > 0 &&
          +a.length <= 500 &&
          +a.width <= 500 &&
          (() => {
            try {
              return D.validParts(JSON.parse(a.symbolPartsJSON || "[]"));
            } catch {
              return false;
            }
          })(),
      )
      .slice(0, 250)
      .map(copy);
    n.logos = (p.logos || [])
      .filter(
        (a) =>
          a &&
          typeof a.id === "string" &&
          typeof a.data === "string" &&
          /^data:image\/(png|jpeg);base64,/.test(a.data) &&
          a.data.length < 1200000 &&
          Number.isFinite(a.ratio) &&
          a.ratio > 0,
      )
      .slice(0, 8)
      .map(copy);
    if (n.route.product !== "custom")
      n.route = { ...n.route, ...PRODUCTS[n.route.product] };
    n.assetGap = Math.max(0, Math.min(100, +p.assetGap || 0));
    if (p.assetColour) n.assetColour = colour(p.assetColour);
    n.schemaVersion = 5;
    return n;
  }
  function planBounds() {
    return S.project.area
      ? G.expandBoundsMeters(
          S.project.area,
          Math.max(0, Math.min(200, Number(S.project.planBleed ?? 10))),
        )
      : null;
  }
  function featureStyle(f) {
    const m = f.properties || {},
      selected = S.selected;
    S.selected = null;
    let st = O.featureStyle(f);
    S.selected = selected;
    if (m.type === "panel") {
      st = {
        ...st,
        color: m.styleColor || "#67756b",
        weight: m.styleWeight != null ? Math.min(1.2, +m.styleWeight) : 0.35,
        fillColor: m.styleFill || PRODUCTS[m.product]?.color || "#b1aa6d",
        fillOpacity: 0.85,
      };
    }
    if (m.type === "asset" || m.type === "logo")
      st = {
        ...st,
        weight: 0.5,
        fillOpacity: 0,
        color: m.styleColor || "#52786b",
      };
    if (m.type === "service" && m.serviceType === "ohl") {
      st.weight = 1;
      st.dashArray = null;
    }
    return st;
  }
  function visibleFeature(f) {
    if (f.properties.hidden) return null;
    if (
      f.properties.serviceType === "ohl" &&
      S.project.area &&
      !S.project.hiddenTypes.includes("service") &&
      S.project.serviceVisibility.ohl
    ) {
      const geometry = G.clipGeometry(f.geometry, ohlBounds());
      return geometry ? { ...f, geometry } : null;
    }
    const x = O.visibleFeature(f);
    return x;
  }
  function assetIconSVG(k, m = {}) {
    if (m.imageData) return '<img src="' + esc(m.imageData) + '" alt="">';
    return D.svg(k, m);
  }
  function mountSymbols() {
    if (symbolLayer) return;
    const Layer = L.Layer.extend({
      onAdd(map) {
        this._map = map;
        this._el = L.DomUtil.create(
          "div",
          "sami-symbol-layer",
          map.getPane("overlayPane"),
        );
        this._el.setAttribute("aria-hidden", "true");
        map.on("zoom viewreset move resize", this.draw, this);
        this.draw();
      },
      onRemove(map) {
        map.off("zoom viewreset move resize", this.draw, this);
        this._el.remove();
      },
      draw() {
        const map = this._map;
        if (!map) return;
        const sz = map.getSize(),
          top = map.containerPointToLayerPoint([0, 0]);
        L.DomUtil.setPosition(this._el, top);
        let s = "";
        for (const f of S.project.features) {
          const m = f.properties;
          if (
            !["asset", "logo"].includes(m.type) ||
            !C.visibleFeature(f) ||
            f.geometry.type !== "Polygon"
          )
            continue;
          const ring = f.geometry.coordinates[0];
          if (ring.length < 4) continue;
          const p = ring
              .slice(0, 4)
              .map((c) => map.latLngToContainerPoint(C.latlng(c))),
            a = p[1].subtract(p[0]).divideBy(100),
            b = p[3].subtract(p[0]).divideBy(100);
          const transform = `matrix(${a.x} ${a.y} ${b.x} ${b.y} ${p[0].x} ${p[0].y})`;
          const data =
            m.imageData ||
            (S.project.logos || []).find((l) => l.id === m.logoId)?.data;
          s += `<g transform="${transform}">${data ? '<image href="' + esc(data) + '" x="0" y="0" width="100" height="100" preserveAspectRatio="none"/>' : D.svgParts(D.parts(m.kind, m), m)}</g>`;
        }
        this._el.innerHTML = `<svg width="${sz.x}" height="${sz.y}" viewBox="0 0 ${sz.x} ${sz.y}" xmlns="http://www.w3.org/2000/svg">${s}</svg>`;
      },
    });
    symbolLayer = new Layer().addTo(S.map);
  }
  function renderAssetIllustrations() {
    syncCatalogue();
    mountSymbols();
    symbolLayer.draw();
  }
  function readSupportMeta(f) {
    try {
      return JSON.parse(f.properties.supportMetaJSON || "{}");
    } catch {
      return {};
    }
  }
  const OHL_BUFFER_M = 804.672;
  function ohlBounds() {
    return S.project.area
      ? G.expandBoundsMeters(S.project.area, OHL_BUFFER_M)
      : C.serviceBounds();
  }
  function ohlSnapshotKey(bounds) {
    return (bounds || []).map((v) => Number(v).toFixed(4)).join(",");
  }
  function saveOhlFallback(bounds, features) {
    try {
      if (!features?.length) return;
      const payload = JSON.stringify({
        key: ohlSnapshotKey(bounds),
        savedAt: new Date().toISOString(),
        features,
      });
      if (payload.length < 1500000)
        localStorage.setItem("sami.ohl.last-good.v2", payload);
    } catch {}
  }
  function loadOhlFallback(bounds) {
    try {
      const x = JSON.parse(
        localStorage.getItem("sami.ohl.last-good.v2") || "null",
      );
      return x?.key === ohlSnapshotKey(bounds) &&
        Array.isArray(x.features) &&
        x.features.length
        ? x
        : null;
    } catch {
      return null;
    }
  }
  function supports(f) {
    try {
      const x = JSON.parse(f.properties.supportPointsJSON || "[]");
      if (x.length) return x;
    } catch {}
    return f.geometry.type === "Point" && f.properties.supportNode
      ? [f.geometry.coordinates]
      : f.properties.sourceId
        ? []
        : C.ohlCoords(f.geometry, f);
  }
  function voltageLabel(v) {
    return String(v || "")
      .split(";")
      .filter(Boolean)
      .map((v) =>
        /^\d+(\.\d+)?$/.test(v)
          ? +v >= 1000
            ? +v / 1000 + " kV"
            : v + " V"
          : v,
      )
      .join(" / ");
  }
  function supportIcon(kind, mapped = false, requestedColor = "#923374") {
    const p =
        kind === "pylon" || kind === "tower" || kind === "portal"
          ? "tower"
          : kind === "pole"
            ? "pole"
            : null,
      terminal = kind === "terminal",
      color = /^#[0-9a-f]{3,8}$/i.test(requestedColor)
        ? requestedColor
        : "#923374";
    return L.divIcon({
      className: "",
      html:
        '<div class="ohl-support studio-support ' +
        (mapped ? "mapped-reference" : "") +
        '">' +
        (p
          ? D.svg(p, { styleFill: "none", styleColor: color })
          : terminal
            ? '<span class="terminal-mark">◇</span>'
            : "<span>+</span>") +
        "</div>",
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    });
  }
  function renderOhl() {
    S.ohlSupportGroup.clearLayers();
    // Each feature decides visibility; committed OHL survives reference-layer toggles.
    const seen = new Set(),
      view = S.map.getBounds();
    let count = 0;
    for (const f of S.project.features) {
      if (
        f.properties.type !== "service" ||
        f.properties.serviceType !== "ohl" ||
        !C.visibleFeature(f)
      )
        continue;
      const m = f.properties,
        types = C.readSupportTypes(f),
        meta = readSupportMeta(f);
      if (
        m.voltage &&
        ["LineString", "MultiLineString"].includes(f.geometry.type)
      ) {
        const coords =
            f.geometry.type === "LineString"
              ? f.geometry.coordinates
              : f.geometry.coordinates[0],
          mid = coords?.length ? C.lineMidpointAndBearing(coords) : null;
        if (mid) {
          const lineLayer = S.layers.get(f.id);
          lineLayer?.bindTooltip(esc(voltageLabel(m.voltage)), {
            permanent: S.map.getZoom() >= 17,
            direction: "center",
            className: "map-label ohl-label",
          });
        }
      }
      for (const c of supports(f)) {
        const key = supportKey(c);
        if (
          seen.has(key) ||
          !view.contains(C.latlng(c)) ||
          (S.project.area && !G.inside(c, ohlBounds()))
        )
          continue;
        seen.add(key);
        if (count++ >= 1800) break;
        const info = meta[key] || {},
          confirmed = types[key],
          kind = confirmed || info.mappedKind || "unknown",
          styleColor =
            S.project.serviceStyles?.ohl?.color ||
            SERVICES?.ohl?.color ||
            "#923374",
          marker = L.marker(C.latlng(c), {
            icon: supportIcon(
              kind,
              !confirmed && !!info.mappedKind,
              styleColor,
            ),
            zIndexOffset: 400,
          }).addTo(S.ohlSupportGroup);
        const typeLabel =
            kind === "pylon" || kind === "tower"
              ? "Tower / pylon"
              : kind === "portal"
                ? "Portal"
                : kind === "terminal"
                  ? "OHL terminal"
                  : kind === "pole"
                    ? "Pole"
                    : "Unidentified support",
          label = [typeLabel, info.ref, voltageLabel(info.voltage || m.voltage)]
            .filter(Boolean)
            .join(" · ");
        marker.bindTooltip(
          esc(label + (confirmed ? "" : " · mapped reference")),
          {
            permanent: S.map.getZoom() >= 18 && kind !== "unknown",
            direction: "right",
            className: "map-label ohl-label",
            offset: [10, 0],
          },
        );
        const details = [
          ["Reference", info.ref],
          ["Voltage", voltageLabel(info.voltage || m.voltage)],
          ["Line", info.lineName || m.label || m.lineRef],
          ["Owner", info.owner || m.owner || info.operator || m.operator],
          ["Description", info.note || info.design || info.material],
        ].filter(([, value]) => value),
          supportAlreadyAdded = S.project.features.some(
            (x) => x.properties.ohlNodeKey === key,
          );
        marker.bindPopup(
          '<section class="ohl-compact-info"><strong>' +
            esc(typeLabel) +
            "</strong>" +
            details
              .map(
                ([name, value]) =>
                  "<p><span>" +
                  esc(name) +
                  "</span>" +
                  esc(value) +
                  "</p>",
              )
              .join("") +
            '<div class="ohl-popup-actions"><button type="button" class="mini-btn primary" data-add-ohl>' +
            (supportAlreadyAdded ? "Update support" : "+ Add support") +
            '</button><button type="button" class="mini-btn" data-edit-ohl>Edit</button></div></section>',
          { className: "ohl-info-popup", minWidth: 190, maxWidth: 280 },
        );
        marker.on("popupopen", () => {
          const popup = marker.getPopup()?.getElement(),
            edit = popup?.querySelector("[data-edit-ohl]"),
            add = popup?.querySelector("[data-add-ohl]");
          if (add)
            add.onclick = () => {
              const supportKind =
                type !== "unknown"
                  ? type
                  : info.mappedKind && info.mappedKind !== "unknown"
                    ? info.mappedKind
                    : kind === "pylon" || kind === "tower"
                      ? "pylon"
                      : kind === "pole"
                        ? "pole"
                        : "unknown";
              if (supportKind === "unknown") {
                marker.closePopup();
                C.chooseOhlSupport(f.id, key);
                return;
              }
              commitSupport(
                f.id,
                key,
                supportKind,
                info.ref || "",
                info.voltage || m.voltage || "",
              );
              C.commit();
              C.render();
              marker.closePopup();
              C.toast(
                supportAlreadyAdded
                  ? "OHL support updated on the plan."
                  : "OHL support added to the plan.",
              );
            };
          if (edit)
            edit.onclick = () => {
              marker.closePopup();
              C.chooseOhlSupport(f.id, key);
            };
        });
      }
    }
  }
  function chooseOhlSupport(id, key) {
    const f = S.project.features.find((x) => x.id === id);
    if (!f) return;
    const info = readSupportMeta(f)[key] || {},
      type = C.readSupportTypes(f)[key] || info.mappedKind || "unknown";
    C.showModal(
      "OHL support",
      `<p class="subtle">${esc(f.properties.source || "Project record")}</p>` +
        C.choice(
          "supportKind",
          "Support",
          {
            unknown: "Unidentified (+)",
            pole: "Pole",
            pylon: "Lattice tower / pylon",
            portal: "Portal / gantry",
            terminal: "OHL terminal",
          },
          type,
        ) +
        F("supportRef", "Pole / tower asset number", info.ref || "") +
        F(
          "supportVoltage",
          "Voltage (volts; e.g. 11000)",
          info.voltage || f.properties.voltage || "",
        ) +
        F("supportNote", "Survey / source reference", info.note || "") +
        B("Save support", "saveSupport", true),
    );
    $("#modalBody").onclick = (e) => {
      if (!e.target.closest('[data-action="saveSupport"]')) return;
      const kind = $("#supportKind").value,
        data = {
          ...info,
          ref: $("#supportRef").value.trim(),
          voltage: $("#supportVoltage").value.trim(),
          note: $("#supportNote").value.trim(),
          userEdited: true,
        };
      for (const line of S.project.features.filter(
        (x) =>
          x.properties.serviceType === "ohl" &&
          supports(x).some((c) => supportKey(c) === key),
      )) {
        const ts = C.readSupportTypes(line),
          ms = readSupportMeta(line);
        ts[key] = kind;
        ms[key] = data;
        line.properties.supportTypesJSON = JSON.stringify(ts);
        line.properties.supportMetaJSON = JSON.stringify(ms);
      }
      C.closeModal();
      C.commit();
    };
  }
  function render() {
    ensureProject(S.project);
    O.render();
    renderOhl();
    if (selectionBox) selectionBox.remove();
    selectionBox = null;
    const f = C.selectedFeature();
    if (f) {
      const members = C.groupMembers(f).filter(
          (x) => !x.properties.guideHidden && !x.properties.hidden,
        ),
        b = C.groupBounds(members);
      if (b)
        selectionBox = L.rectangle(
          [
            [b[1], b[0]],
            [b[3], b[2]],
          ],
          {
            color: "#067c64",
            weight: 1.2,
            dashArray: "5 4",
            fill: false,
            interactive: false,
          },
        ).addTo(S.editGroup);
    }
    renderSelectionBar();
    updateActiveTools();
  }
  function renderSelectionBar() {
    const el = $("#selectionBar");
    if (!el) return;
    const f = C.selectedFeature();
    el.hidden = !f || !!S.tool;
    if (!f) return;
    $("#selectionName").textContent = f.properties.label || "Selected item";
    $("#selectionCount").textContent =
      C.groupMembers(f).filter((x) => !x.properties.guideHidden).length > 1
        ? C.groupMembers(f).filter((x) => !x.properties.guideHidden).length +
          " objects"
        : "";
  }
  function updateActiveTools() {
    $$("[data-master]").forEach((b) => {
      const on = b.dataset.master === ui.method;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", String(on));
    });
    $("#snapToggle")?.setAttribute("aria-pressed", String(ui.snap));
    $("#snapToggle")?.classList.toggle("active", ui.snap);
    $("#activeAssetName") &&
      ($("#activeAssetName").textContent =
        getAsset()?.name || "Choose an asset");
  }
  function updateLock() {
    const locked = C.isLocked();
    const drawFree = C.isFreehandTool(S.tool) && !ui.panning;
    S.map.dragging[locked || drawFree ? "disable" : "enable"]();
    for (const k of ["boxZoom", "keyboard"])
      S.map[k]?.[locked ? "disable" : "enable"]();
    for (const k of ["touchZoom", "scrollWheelZoom"]) S.map[k]?.enable?.();
    S.map.doubleClickZoom.disable();
    $("#lockBtn").setAttribute("aria-pressed", String(locked));
    $("#lockBtn").innerHTML =
      (locked
        ? '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>'
        : '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2.5"/></svg>') +
      " <span>" +
      (locked ? "Unlock" : "Lock") +
      "</span>";
    $("#lockBtn").title = locked ? "Unlock pan" : "Lock pan";
    $("#lockBtn").classList.toggle("active", locked);
    $("#zoomInBtn").disabled = false;
    $("#zoomOutBtn").disabled = false;
    $("#map").classList.toggle("freehand-active", drawFree);
  }
  function setMode(mode) {
    if (mode === "create") {
      C.cancelDraw();
      C.closeDrawer();
      S.modeBeforeCreator = S.mode;
      S.mode = "create";
      C.setModeUI(mode);
      document.body.classList.add("asset-creation-mode");
      openCreator();
      return true;
    }
    document.body.classList.remove("asset-creation-mode");
    $("#creatorWorkspace").hidden = true;
    if (S.mode === "create") S.mode = S.modeBeforeCreator || "map";
    const x = O.setMode(mode);
    if (mode === "plan") {
      S.planLocked = false;
      C.updateLock();
    }
    return x;
  }
  function setModeUI(mode) {
    O.setModeUI(mode);
    $("#modeCaption").textContent =
      {
        map: "Explore the site",
        plan: "Design to scale",
        route: "Plan the approach",
        create: "Build reusable assets",
        library: "Assets & materials",
      }[mode] || "";
  }
  function fitArea() {
    if (!S.project.area) return;
    const b = S.project.area,
      drawer = $("#drawer").classList.contains("open"),
      sz = S.map.getSize();
    const left = drawer ? Math.min(390, sz.x * 0.42) : 66;
    S.map.fitBounds(
      [
        [b[1], b[0]],
        [b[3], b[2]],
      ],
      {
        paddingTopLeft: [left + 14, 60],
        paddingBottomRight: [62, 92],
        maxZoom: 22,
        animate: false,
      },
    );
  }
  function openDrawer(k, reveal = false) {
    if (k === "panels") {
      ui.category = "Trakway";
      k = "assets";
    }
    if (k === "library") {
      k = "assets";
    }
    if (k === "create") {
      C.setMode("create");
      return;
    }
    O.openDrawer(k, reveal);
    if (reveal) document.body.classList.add("drawer-visible");
  }
  function closeDrawer(userCommand = false) {
    O.closeDrawer(userCommand);
    if (userCommand) document.body.classList.remove("drawer-visible");
  }
  function methodsFor(a) {
    if (!a) return [];
    if (a.surface)
      return a.method === "area" ? ["area", "freeArea"] : ["line", "freeLine"];
    return ["place", "line", "area", "freeLine", "freeArea"];
  }
  function masterHTML() {
    const names = {
      place: "Place one",
      line: "Point line",
      area: "Point area",
      freeLine: "Freehand line",
      freeArea: "Freehand area",
    };
    const allowed = methodsFor(getAsset());
    return (
      '<div class="master-grid">' +
      Object.entries(names)
        .map(
          ([k, v]) =>
            `<button data-action="master:${k}" class="${ui.method === k ? "active" : ""}" ${allowed.includes(k) ? "" : "disabled"}>${v}</button>`,
        )
        .join("") +
      "</div>"
    );
  }
  function customDimensionHTML(a) {
    if (!a || a.type === "panel" || a.surface || a.dimensionLocked !== false)
      return "";
    const warn = a.needsScale
      ? '<p class="scale-warning"><strong>Set the real footprint before placement.</strong> Imported stencil geometry has no trusted site scale.</p>'
      : "";
    return (
      warn +
      '<div class="row equal"><div>' +
      F(
        "customAssetLength",
        "Length (m)",
        a.length,
        "number",
        'min="0.1" max="500" step="0.1"',
      ) +
      "</div><div>" +
      F(
        "customAssetWidth",
        "Width (m)",
        a.width,
        "number",
        'min="0.1" max="500" step="0.1"',
      ) +
      "</div></div>" +
      (a.needsScale
        ? B("Confirm real dimensions", "confirmAssetScale", true)
        : "")
    );
  }
  function assetsHTML() {
    syncCatalogue();
    const a = getAsset(),
      groups = {
        Trakway: Object.keys(PRODUCTS).map((k) => [
          "panel_" + k,
          panelsInfo("panel_" + k),
        ]),
        "Lines & areas": Object.entries(SURFACES).map(([k, v]) => [
          "surface_" + k,
          v,
        ]),
      };
    for (const [k, v] of Object.entries(ASSETS))
      (groups[v.category || "Other"] ??= []).push([k, v]);
    return (
      '<label class="library-search"><span>⌕</span><input id="assetSearch" value="' +
      esc(ui.search) +
      '" placeholder="Search assets…" aria-label="Search assets"></label><div id="assetCategories">' +
      Object.entries(groups)
        .map(
          ([cat, items]) =>
            `<details class="asset-category" data-category="${esc(cat)}" ${cat === ui.category || ui.search ? "open" : ""}><summary>${esc(cat)} <small>${items.length}</small></summary><div class="asset-grid">` +
            items
              .filter(
                ([k, v]) =>
                  !ui.search ||
                  (v.name + " " + cat)
                    .toLowerCase()
                    .includes(ui.search.toLowerCase()),
              )
              .map(
                ([k, v]) =>
                  `<button class="asset-palette ${ui.asset === k ? "active" : ""}" draggable="${!k.startsWith("surface_")}" data-asset-drag="${k}" data-action="pickAsset:${k}" title="${esc(v.name)}"><span class="asset-preview">${v.surface || k.startsWith("surface_") ? '<svg viewBox="0 0 100 60"><path d="M8 50 L35 15 L90 35" fill="none" stroke="#538e79" stroke-width="3"/></svg>' : assetIconSVG(k, v)}</span><span class="asset-copy">${esc(v.name)}<small>${v.needsScale ? "Set real scale" : v.length ? v.length + " × " + v.width + " m" : v.method === "area" ? "Area surface" : "Line surface"}</small></span></button>`,
              )
              .join("") +
            "</div></details>",
        )
        .join("") +
      '</div><div class="library-selection"><strong>' +
      esc(a?.name || "Select an asset") +
      "</strong>" +
      masterHTML() +
      (a?.type === "panel"
        ? '<div class="row equal"><div>' +
          C.choice(
            "studioLanes",
            "Run width",
            {
              1: `${a.width} m · one panel`,
              2: `${+(2 * a.width - (a.lateralOverlap || 0)).toFixed(2)} m · two panels`,
            },
            String(S.project.route.lanes === 2 ? 2 : 1),
          ) +
          '</div></div><p class="subtle">' +
          a.length +
          " m along the run" +
          (a.overlap ? " · " + a.overlap + " m overlap" : " increments") +
          ". Fixed panel sizes.</p>"
        : a?.surface
          ? ""
          : customDimensionHTML(a) +
            F(
              "repeatGap",
              "Spacing between repeated assets (m)",
              S.project.assetGap || 0,
              "number",
              'min="0" max="100" step="0.1"',
            )) +
      '<div class="row equal"><label class="colour-field">Colour <input id="libraryColour" type="color" value="' +
      colour(S.project.assetColour || "#a2c4b8") +
      '"></label>' +
      B("Start drawing", "masterStart", true) +
      '</div></div><div class="row equal">' +
      B("My shapes", "open:create") +
      B("My logos", "open:branding") +
      '</div><div class="row equal">' +
      B("Import stencil / CAD", "importShapePack") +
      B("Export My shapes", "exportShapePack") +
      '</div><p class="subtle">Imports: SVG, ASCII DXF, Visio VSSX/VSDX and SAMI shape packs. DXF declared units are retained. Visio masters retain their native real-world scale when the stencil contains scaled 2D geometry; only genuinely unscaled shapes ask for dimensions.</p>'
    );
  }
  function drawHTML() {
    return (
      '<div class="card"><strong id="activeAssetName">' +
      esc(getAsset()?.name || "Select an asset") +
      '</strong><p class="subtle">Choose an asset from the library, then use the same drawing tools for panels, fencing, parking, cabins and event layouts.</p>' +
      masterHTML() +
      B("Start drawing", "masterStart", true) +
      "</div>" +
      B("Choose asset", "open:assets") +
      C.section("Precision & annotation") +
      '<div class="compact-tools">' +
      B("Measure", "draw:measure") +
      B("Rectangle", "draw:rectangle") +
      B("Circle", "draw:circle") +
      B("Text", "draw:textBox") +
      B("Access point", "accessPoint") +
      B("Photo", "draw:photo") +
      "</div>" +
      C.section("Workspace") +
      B("Site boundary", "open:area") +
      B("Services & OHL", "open:services")
    );
  }
  function readSelected() {
    const a = getAsset();
    if (!a) throw Error("Choose an asset first.");
    if (a.dimensionLocked === false) {
      const l = +($("#customAssetLength")?.value ?? a.length),
        w = +($("#customAssetWidth")?.value ?? a.width);
      if (l > 0 && w > 0) {
        a.length = Math.min(500, l);
        a.width = Math.min(500, w);
      }
    }
    if (a.needsScale)
      throw Error(
        "Confirm the real dimensions for this imported shape before placing it.",
      );
    const color = $("#libraryColour")?.value || S.project.assetColour;
    if (color) S.project.assetColour = color;
    const gap = +($("#repeatGap")?.value ?? S.project.assetGap ?? 0);
    S.project.assetGap = Math.max(0, gap);
    if (a.type === "panel") {
      const lanes = +($("#studioLanes")?.value ?? S.project.route.lanes ?? 1);
      S.project.route = { ...a, lanes, styleFill: color || a.color };
      return {
        ...a,
        lanes,
        label: a.name,
        styleFill: color || a.color,
        snap: ui.snap,
      };
    }
    const outlineOnly = ["pole", "tower"].includes(ui.asset);
    return {
      ...a,
      kind: ui.asset,
      label: a.name,
      angle: 0,
      includeLegend: true,
      styleFill: outlineOnly ? "none" : color || a.color || "#a2c4b8",
      styleColor: outlineOnly ? color || "#923374" : undefined,
      fillEnabled: outlineOnly ? false : undefined,
      gap: S.project.assetGap,
      snap: ui.snap,
    };
  }
  function activateMaster(method = ui.method) {
    ui.method = method;
    let a;
    try {
      a = readSelected();
    } catch (e) {
      C.toast(e.message);
      return;
    }
    if (!methodsFor(a).includes(method)) {
      C.toast("Choose a compatible drawing method.");
      return;
    }
    if (method === "place") {
      C.startTool(a.type === "panel" ? "singlePanel" : "asset", a);
      return;
    }
    if (a.surface) {
      const kind = a.surface,
        free = method.startsWith("free");
      if (kind === "stoneRoad") {
        a.width = 4;
      }
      C.startTool(kind + (free ? "Freehand" : ""), {
        ...a,
        label: a.name,
        showArrow: ["access", "egress", "route"].includes(kind),
      });
      return;
    }
    if (a.type === "panel") {
      const t = {
        line: "panelRoute",
        freeLine: "panelFreehand",
        area: "panelAreaPoints",
        freeArea: "panelAreaFreehand",
      }[method];
      C.startTool(t, a);
      return;
    }
    C.startTool(
      {
        line: "assetLine",
        area: "assetArea",
        freeLine: "assetFreeLine",
        freeArea: "assetFreeArea",
      }[method],
      a,
    );
  }
  function startTool(t, o = {}) {
    if (S.mode === "create") C.setMode(S.modeBeforeCreator || "map");
    // A prior drag/pan can leave the short click-suppression window active.
    // Starting a deliberate placement tool must make the very next tap usable.
    ui.dragging = false;
    ui.panning = false;
    S.suppressMapClick = 0;
    O.startTool(t, { ...o, snap: o.snap ?? ui.snap });
    C.updateLock();
    updateActiveTools();
    if (t === "accessPoint") {
      $("#toolName").textContent = "Place access point";
      $("#drawHint").textContent = "Tap the gate or entrance position.";
    }
    if (/^asset(Line|Area|Free)/.test(t)) {
      $("#toolName").textContent =
        (o.name || "Asset") +
        " · " +
        (/Area/.test(t) ? "fill area" : "repeat along line");
    }
  }
  function isFreehandTool(t) {
    return (
      ["assetFreeLine", "assetFreeArea"].includes(t) || O.isFreehandTool(t)
    );
  }
  function onMapClick(e) {
    // Route-point picking is a deliberate one-tap action and must not be
    // blocked by a stale drag/pan flag from the previous interaction.
    if ((ui.dragging || ui.panning) && !S.routePick) return;
    if (S.tool === "accessPoint") {
      const c = C.coord(e.latlng);
      C.cancelDraw();
      // Overlapping canvas features can deliver the same tap more than once.
      // Keep the entrance dialog from being replaced by a feature-info dialog.
      S.suppressMapClick = performance.now() + 350;
      editAccessPoint(null, c);
      return;
    }
    O.onMapClick(e);
  }
  function renderDraft() {
    O.renderDraft();
    if (["panelAreaPoints", "assetArea", "assetFreeArea"].includes(S.tool)) {
      $("#finishDrawBtn").disabled = S.points.length < 3;
      $("#finishDrawBtn").textContent = "Fill area";
    }
    if (S.tool === "accessPoint") {
      $("#finishDrawBtn").hidden = true;
      $("#backPointBtn").hidden = true;
      $("#drawHint").textContent = "Tap the entrance position on the map.";
    }
  }
  function repeatedAssets(points, a, area) {
    const result = [],
      groupId = C.uid(),
      pr = G.projection(points[0]);
    const ring = points.map(pr.xy),
      angle =
        ring.length > 1
          ? (Math.atan2(ring[1][0] - ring[0][0], ring[1][1] - ring[0][1]) *
              180) /
            Math.PI
          : 0;
    const add = (center, heading) => {
      if (result.length >= 2000)
        throw Error(
          "Use a smaller area or more spacing; the limit is 2,000 objects per placement.",
        );
      result.push(
        C.feature(
          a.imageData ? "logo" : "asset",
          G.rectangle(center, +a.length, +a.width, heading),
          {
            ...a,
            groupId,
            angle: heading,
            centerLng: center[0],
            centerLat: center[1],
          },
        ),
      );
    };
    if (area) {
      const theta = (angle * Math.PI) / 180,
        u = [Math.sin(theta), Math.cos(theta)],
        v = [Math.cos(theta), -Math.sin(theta)],
        local = ring.map((p) => [
          p[0] * u[0] + p[1] * u[1],
          p[0] * v[0] + p[1] * v[1],
        ]),
        xs = local.map((p) => p[0]),
        ys = local.map((p) => p[1]),
        l = +a.length,
        w = +a.width,
        gap = +a.gap || 0;
      for (
        let x = Math.min(...xs) + l / 2;
        x <= Math.max(...xs) - l / 2 + 0.001;
        x += l + gap
      ) {
        for (
          let y = Math.min(...ys) + w / 2;
          y <= Math.max(...ys) - w / 2 + 0.001;
          y += w + gap
        ) {
          if (
            [
              [-l / 2, -w / 2],
              [l / 2, -w / 2],
              [l / 2, w / 2],
              [-l / 2, w / 2],
            ].every(([dx, dy]) => ringContains([x + dx, y + dy], local))
          )
            add(pr.ll([x * u[0] + y * v[0], x * u[1] + y * v[1]]), angle);
        }
      }
    } else {
      const total = G.length(points),
        step = +a.length + (+a.gap || 0);
      for (let d = +a.length / 2; d <= total + 0.001; d += step) {
        let rem = d;
        for (let i = 1; i < points.length; i++) {
          const len = G.distance(points[i - 1], points[i]);
          if (rem <= len) {
            const a0 = pr.xy(points[i - 1]),
              b = pr.xy(points[i]),
              t = rem / len;
            add(
              pr.ll([a0[0] + t * (b[0] - a0[0]), a0[1] + t * (b[1] - a0[1])]),
              (Math.atan2(b[0] - a0[0], b[1] - a0[1]) * 180) / Math.PI,
            );
            break;
          }
          rem -= len;
        }
      }
    }
    if (!result.length)
      throw Error("The drawn space is too small for this asset.");
    return result;
  }
  function finishDraw() {
    const t = S.tool,
      pts = copy(S.points),
      a = copy(S.options);
    if (t === "panelAreaPoints") {
      if (pts.length >= 3) C.addPanelFill(pts, a);
      return;
    }
    if (
      ["assetLine", "assetArea", "assetFreeLine", "assetFreeArea"].includes(t)
    ) {
      if (pts.length < (/Area/.test(t) ? 3 : 2)) return;
      try {
        const fs = repeatedAssets(pts, a, /Area/.test(t));
        S.project.features.push(...fs);
        C.cancelDraw();
        S.selected = fs[0].id;
        C.commit();
        C.toast(fs.length + " objects placed as a group.");
      } catch (e) {
        C.toast(e.message);
      }
      return;
    }
    O.finishDraw();
  }
  function placeItem(c) {
    O.placeItem(c);
    const f = C.selectedFeature();
    if (f) {
      f.properties.dimensionLocked =
        (f.properties.type === "panel" && f.properties.product !== "custom") ||
        f.properties.dimensionLocked;
      if (f.properties.imageData) {
        f.properties.type = "logo";
        C.commit();
      }
    }
  }
  function placeAssetAtScreen(k, x, y) {
    const hit = document.elementFromPoint(x, y);
    if (
      hit?.closest(
        "#studioDock,.floating-panel,#creatorWorkspace,.topbar,.modebar",
      )
    )
      return false;
    const box =
      $("#mapViewport")?.getBoundingClientRect() ||
      $("#map").getBoundingClientRect();
    if (x < box.left || x > box.right || y < box.top || y > box.bottom)
      return false;
    ui.asset = k;
    const a = readSelected();
    if (a.surface) return false;
    const c = C.coord(S.map.mouseEventToLatLng({ clientX: x, clientY: y }));
    if (S.mode === "plan" && S.project.area && !C.insidePlanFrame(c)) {
      C.toast("Drop inside the site drawing.");
      return false;
    }
    const f = C.feature(
      a.type === "panel" ? "panel" : a.imageData ? "logo" : "asset",
      G.rectangle(c, +a.length, +a.width, 0),
      { ...a, centerLng: c[0], centerLat: c[1], angle: 0 },
    );
    S.project.features.push(f);
    S.selected = f.id;
    C.commit();
    C.toast(a.name + " placed.");
    return true;
  }
  function bindAssetPaletteDrag() {}
  function layersHTML() {
    const seen = new Set(),
      fs = S.project.features
        .filter((f) => !f.properties.guideHidden)
        .slice()
        .reverse(),
      rows = [];
    for (const f of fs) {
      const gid = f.properties.groupId || f.id;
      if (seen.has(gid)) continue;
      seen.add(gid);
      const members = C.groupMembers(f);
      rows.push(
        `<div class="layer-object"><button class="layer-name" data-action="select:${esc(f.id)}">${esc(f.properties.label || f.properties.type)}<small>${members.length > 1 ? members.filter((x) => !x.properties.guideHidden).length + " objects · group" : TYPES[f.properties.type] || f.properties.type}</small></button><button data-action="hideItem:${f.id}" title="${f.properties.hidden ? "Show" : "Hide"} object">${f.properties.hidden ? "○" : "◉"}</button><button data-action="lockItem:${f.id}" title="${f.properties.locked ? "Unlock" : "Lock"} object">${f.properties.locked ? "◆" : "◇"}</button><button data-action="raiseItem:${f.id}" title="Bring forward">↑</button><button data-action="lowerItem:${f.id}" title="Send backward">↓</button></div>`,
      );
    }
    return (
      '<p class="subtle">Top items draw above lower items. Group, hide or lock objects without removing them.</p>' +
      rows.join("") +
      '<details class="advanced-settings"><summary>Layer visibility</summary>' +
      O.layersHTML() +
      "</details>" +
      B("Materials schedule", "open:schedule")
    );
  }
  function renderTransformHandles() {
    const f = C.selectedFeature();
    if (
      f?.properties.locked ||
      C.groupMembers(f).some((x) => x.properties.locked)
    )
      return;
    O.renderTransformHandles();
  }
  function selectionHTML() {
    const f = C.selectedFeature();
    let html = O.selectionHTML();
    if (!f) return html;
    html +=
      C.section("Object control") +
      B(
        f.properties.locked ? "Unlock object" : "Lock object",
        "toggleSelectedLock",
      ) +
      B("Bring to front", "frontSelected") +
      B("Send to back", "backSelected");
    if (f.properties.type === "accessPoint")
      html += B("Edit entrance & address", "editAccess");
    if (
      f.properties.routeId &&
      ["lion", "hybrid", "tuff"].includes(f.properties.product)
    ) {
      const p = PRODUCTS[f.properties.product];
      html += B(
        "Rebuild " +
          p.name +
          " run · " +
          p.width +
          " / " +
          p.width * 2 +
          " m wide",
        "rebuildLion",
      );
    }
    return html;
  }
  function editAction(action) {
    const f = C.selectedFeature();
    if (!f) return;
    if (f.properties.locked && action !== "editStyle") {
      C.toast("Unlock this object in its controls first.");
      return;
    }
    if (action === "editApplyStyle")
      for (const x of C.groupMembers(f))
        if (x.properties.symbolPartsJSON) x.properties.recolourParts = true;
    O.editAction(action);
  }
  function brandingHTML() {
    return (
      '<p class="subtle">Your designer details and enabled logos appear on new PDF exports. Empty fields are omitted.</p>' +
      F("designerName", "Designer name", S.project.meta.creator || "") +
      F(
        "designerCompany",
        "Designer company",
        S.project.meta.designerCompany || "",
      ) +
      F("designerEmail", "Designer email", S.project.meta.designerEmail || "") +
      F("designerPhone", "Designer phone", S.project.meta.designerPhone || "") +
      B("Add company logo", "uploadLogo", true) +
      (S.project.logos || [])
        .map(
          (l) =>
            `<div class="logo-row"><img src="${esc(l.data)}" alt="${esc(l.name)}"><div>${esc(l.name)}${C.checkedRow("Use in PDF", 'data-logo-export="' + esc(l.id) + '"', l.export !== false)}</div><button data-action="pickLogo:${esc(l.id)}">Place</button><button title="Remove logo from project" data-action="removeLogo:${esc(l.id)}">×</button></div>`,
        )
        .join("") +
      '<p class="subtle">PNG and JPEG · up to 8 logos. SAMI automatically fits the image to its aspect ratio for plan placement and export; you can still resize a placed logo afterwards.</p>'
    );
  }
  async function uploadLogo(file) {
    if (!file) return;
    try {
      if (S.project.logos.length >= 8)
        throw Error("This project already has 8 logos.");
      if (!/image\/(png|jpeg|webp)/.test(file.type))
        throw Error("Choose a PNG, JPEG or WebP image.");
      if (file.size > 10 * 1024 * 1024) throw Error("Use a logo under 10 MB.");
      const url = URL.createObjectURL(file),
        im = await new Promise((resolve, reject) => {
          const image = new Image();
          image.onload = () => resolve(image);
          image.onerror = reject;
          image.src = url;
        });
      URL.revokeObjectURL(url);
      const scale = Math.min(1, 640 / Math.max(im.width, im.height)),
        canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(im.width * scale));
      canvas.height = Math.max(1, Math.round(im.height * scale));
      canvas.getContext("2d").drawImage(im, 0, 0, canvas.width, canvas.height);
      const data = canvas.toDataURL("image/png");
      if (data.length > 1000000)
        throw Error("Use a simpler or smaller logo image.");
      const ratio = im.width / im.height,
        max = 4,
        length = ratio >= 1 ? max : max * ratio,
        width = ratio >= 1 ? max / ratio : max;
      S.project.logos.push({
        id: C.uid(),
        name: file.name.replace(/\.[^.]+$/, ""),
        data,
        ratio,
        export: true,
        length,
        width,
      });
      C.commit();
      C.openDrawer("branding");
    } catch (e) {
      C.toast(e.message || "This logo could not be read.");
    }
  }
  function accessPoints() {
    return S.project.features.filter(
      (f) => f.properties.type === "accessPoint",
    );
  }
  function accessHTML() {
    return (
      '<p class="subtle">Place entrances at the exact gate location. Give each an address or use its coordinates, then select it as your route destination.</p>' +
      B("Place access point", "accessPoint", true) +
      accessPoints()
        .map(
          (f) =>
            `<div class="item-row"><div><strong>${esc(f.properties.label)}</strong><small>${esc(f.properties.address || C.coordLabel(f.geometry.coordinates))}</small></div><button data-action="accessEdit:${f.id}">Edit</button><button data-action="accessRoute:${f.id}">Route here</button></div>`,
        )
        .join("")
    );
  }
  async function accessLookup(p) {
    const out = { address: "", what3words: "" };
    try {
      const r = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${p[1]}&lon=${p[0]}&zoom=18`,
          { signal: AbortSignal.timeout(10000) },
        ),
        d = await C.boundedJSON(r, 200000);
      out.address = d.display_name || "";
    } catch {}
    const key = String(
      C.readPref("sami.w3w.key") || window.SAMI_CONFIG?.what3wordsApiKey || "",
    ).trim();
    if (key)
      try {
        const r = await fetch(
            `https://api.what3words.com/v3/convert-to-3wa?coordinates=${encodeURIComponent(p[1] + "," + p[0])}&key=${encodeURIComponent(key)}`,
            { signal: AbortSignal.timeout(10000) },
          ),
          d = await C.boundedJSON(r, 200000);
        if (d.words) out.what3words = "///" + d.words;
      } catch {}
    return out;
  }
  function editAccessPoint(f, c) {
    const m = f?.properties || {},
      p = c || f.geometry.coordinates,
      isNew = !f;
    C.showModal(
      "Access point",
      F("gateName", "Entrance name", m.label || "Site entrance") +
        F("gateAddress", "Address / postcode", m.address || "") +
        F("gateW3w", "what3words", m.what3words || "") +
        F("gateNotes", "Arrival instructions", m.arrivalInstructions || "") +
        C.checkedRow(
          "Use this entrance for project address",
          'id="gateProjectAddress"',
          m.projectEntrance !== false,
        ) +
        '<p class="subtle">' +
        esc(C.coordLabel(p)) +
        (String(
          C.readPref("sami.w3w.key") ||
            window.SAMI_CONFIG?.what3wordsApiKey ||
            "",
        ).trim()
          ? " · address and what3words auto-fill from the pin"
          : " · mapped address auto-fills; add a what3words API key in Settings for automatic 3-word addresses") +
        "</p>" +
        B("Refresh location details", "gateGeocode") +
        B("Save access point", "gateSave", true),
    );
    const fill = async (silent = false) => {
      const d = await accessLookup(p);
      if ($("#gateAddress") && d.address) $("#gateAddress").value = d.address;
      if ($("#gateW3w") && d.what3words) $("#gateW3w").value = d.what3words;
      if (!silent && !d.address && !d.what3words)
        C.toast(
          "No automatic location details were available. Coordinates are retained.",
        );
    };
    if (isNew) fill(true);
    $("#modalBody").onclick = async (e) => {
      const action = e.target.closest("[data-action]")?.dataset.action;
      if (action === "gateGeocode") await fill();
      if (action === "gateSave") {
        const props = {
          ...m,
          label: $("#gateName").value.trim() || "Site entrance",
          address: $("#gateAddress").value.trim(),
          what3words: $("#gateW3w").value.trim(),
          arrivalInstructions: $("#gateNotes").value.trim(),
          projectEntrance: $("#gateProjectAddress").checked,
          includeLegend: true,
        };
        if (f) f.properties = { ...f.properties, ...props };
        else {
          f = C.feature(
            "accessPoint",
            { type: "Point", coordinates: p },
            props,
          );
          S.project.features.push(f);
        }
        if (props.projectEntrance) {
          if (props.address) S.project.meta.siteAddress = props.address;
          if (props.what3words) S.project.meta.what3words = props.what3words;
          S.project.meta.siteEntrance = props.label;
          S.project.meta.arrivalInstructions = props.arrivalInstructions;
        }
        C.closeModal();
        S.selected = f.id;
        C.commit();
        if (S.mode === "route") chooseAccessRoute(f.id);
        else C.openDrawer("access");
      }
    };
  }
  function routeToSiteHTML() {
    const pts = accessPoints();
    return (
      '<div class="route-access-priority"><span class="tag">SITE ACCESS</span>' +
      B("＋ Add site access point", "accessPoint", true) +
      (pts.length
        ? C.choice(
            "routeAccessPoint",
            "Route destination access point",
            {
              "": "Choose an entrance…",
              ...Object.fromEntries(pts.map((f) => [f.id, f.properties.label])),
            },
            S.project.hgv.accessPointId || "",
          )
        : '<p class="subtle">Add the first gate/entrance, then plan its route.</p>') +
      B("Manage all access points (" + pts.length + ")", "open:access") +
      "</div>" +
      O.routeToSiteHTML()
    );
  }
  function chooseAccessRoute(id) {
    const f = accessPoints().find((f) => f.id === id);
    if (!f) return;
    S.project.hgv = {
      ...S.project.hgv,
      end: copy(f.geometry.coordinates),
      endText:
        f.properties.what3words ||
        f.properties.address ||
        C.coordLabel(f.geometry.coordinates),
      endAddress: f.properties.address || "",
      endW3w: f.properties.what3words || "",
      accessPointId: id,
    };
    C.commit();
    C.openDrawer("routeToSite");
  }
  async function planHgvRoute() {
    const project = S.project, before = S.project.routes.length,
      id = S.project.hgv.accessPointId;
    await O.planHgvRoute();
    if (S.project === project && S.project.routes.length > before && id) {
      const f = accessPoints().find((f) => f.id === id);
      if (f) {
        Object.assign(S.project.routes.at(-1), {
          accessPointId: id,
          accessPoint: copy(f.properties),
        });
        C.commit();
      }
    }
  }
  function projectHTML() {
    let h = O.projectHTML();
    h =
      h.slice(0, h.indexOf(C.section("Ask SAMI voice"))) +
      C.section("Identity & logos") +
      B("Designer & company logos", "open:branding") +
      B("Access points", "open:access") +
      C.section("Ask SAMI") +
      B("Voice & connected assistance", "open:voice");
    return h;
  }
  function voiceHTML() {
    const profile = window.SAMI_CONFIG?.voiceProfile || {},
      endpoint =
        C.readPref("sami.naturalVoice.url") ||
        window.SAMI_CONFIG?.voiceEndpoint ||
        "",
      pack = window.SAMI_CONFIG?.recordedSpeechPack || {},
      live = C.readPref("sami.voice.liveFallback") === "on",
      ai = C.readPref("sami.ai.url") || window.SAMI_CONFIG?.aiEndpoint || "";
    return (
      C.checkedRow(
        "Spoken responses",
        'id="voiceOutput"',
        C.readPref("sami.voice.output") !== "off",
      ) +
      '<div class="card voice-profile-card"><strong>' +
      esc(profile.displayName || "SAMI Voice") +
      '</strong><p class="subtle">Brand pronunciation: <b>SAMI → Sammy</b>. Detailed answers remain on screen; the voice speaks a concise matching meaning from the recorded speech pack. Robotic device TTS stays disabled.</p><div class="voice-profile-meta"><span>Profile ' +
      esc(profile.id || "sami-voice-v1") +
      "</span><span>" +
      Object.keys(pack).length +
      ' bundled speech clips</span></div></div><div class="row equal">' +
      B("Play recorded voice", "testVoice") +
      B("Test speech pack", "testSpeechPack") +
      "</div>" +
      C.checkedRow(
        "Use HTTPS live fallback for uncovered replies",
        'id="voiceLiveFallback"',
        live,
      ) +
      F(
        "naturalVoiceUrl",
        "Optional HTTPS voice endpoint",
        endpoint,
        "url",
        'placeholder="https://your-project.supabase.co/functions/v1/sami-voice"',
      ) +
      '<p class="subtle">Normal operation uses bundled recordings offline. If an answer is not covered, SAMI uses the generic recorded response unless live fallback is explicitly enabled.</p><div class="section-title">SAMI AI</div><div class="card"><strong>' +
      (ai ? "Connected endpoint configured" : "Local command engine only") +
      '</strong><p class="subtle">Speech recognition turns your voice into a request. Local commands work on-device; open-ended questions need a reachable HTTPS AI backend. This endpoint can connect an OpenAI-compatible service, but its API key must stay on that server. Enter the endpoint URL here, never the provider key.</p></div>' +
      F(
        "connectedAiUrl",
        "SAMI AI HTTPS endpoint",
        ai,
        "url",
        'placeholder="https://your-project.supabase.co/functions/v1/sami-ai"',
      ) +
      B("Save connections", "saveConnections", true)
    );
  }
  function initVoice() {
    C.setPref("sami.voice.output", C.readPref("sami.voice.output") || "on");
    C.setPref(
      "sami.voice.liveFallback",
      C.readPref("sami.voice.liveFallback") || "off",
    );
    try {
      window.speechSynthesis?.cancel();
    } catch {}
    C.updateVoiceButton();
  }
  function stopAudio() {
    voiceSeq++;
    voiceController?.abort();
    voiceController = null;
    if (voiceAudio) {
      voiceAudio.pause();
      if (voiceAudio.src?.startsWith("blob:"))
        URL.revokeObjectURL(voiceAudio.src);
      voiceAudio = null;
    }
  }
  function spokenText(text) {
    return String(text || "")
      .replace(/\bS\s*\.\s*A\s*\.\s*M\s*\.\s*I\.?/gi, "Sammy")
      .replace(/\bS\s+A\s+M\s+I\b/gi, "Sammy")
      .replace(/\bSAMI\b/gi, "Sammy")
      .replace(
        /https?:\/\/\S+/gi,
        (m) => "web link" + (m.match(/[.,!?;:)]+$/) || [""])[0],
      )
      .replace(/\s+/g, " ")
      .trim();
  }
  function semanticVoiceId(text) {
    const t = spokenText(text).toLowerCase();
    if (!t) return "";
    if (
      /(official|government|guidance|source).*(link|screen)|linked.*official source/.test(
        t,
      )
    )
      return "officialSource";
    if (
      /(connected service|service).*(didn't|did not|failed|unavailable|not respond)|local drawing tools still work/.test(
        t,
      )
    )
      return "offline";
    if (
      /(define|set|draw).*(site area|site boundary).*(first|before)|site area.*(first|required|needed)/.test(
        t,
      )
    )
      return "needSiteArea";
    if (
      /(couldn't|could not|can't|cannot|failed|error|unavailable|isn't available|not available)/.test(
        t,
      )
    )
      return "error";
    if (
      /\b(pdf|export)\b.*\b(created|ready|generated|saved|complete|completed)\b|\b(created|generated)\b.*\bpdf\b/.test(
        t,
      )
    )
      return "pdf";
    if (
      /\b(route|route to site|journey)\b.*\b(ready|planned|created|complete|completed|generated)\b|\bplanned\b.*\broute\b/.test(
        t,
      )
    )
      return "route";
    if (/\b(overhead line|overhead power|ohl)\b/.test(t)) return "ohl";
    if (
      /\b(service|services|utilities|utility)\b.*\b(refresh|refreshed|mapped|updated|found|loaded|snapshot)\b/.test(
        t,
      )
    )
      return "services";
    if (
      /\b(map|satellite|cad|base)\b.*\b(view|switched|changed|mode)\b|\bswitched\b.*\b(map|satellite|cad)\b/.test(
        t,
      )
    )
      return "mapView";
    if (
      /\b(access point|entrance|gate)\b/.test(t) &&
      /\b(add|added|create|created|place|placed|save|saved|ready)\b/.test(t)
    )
      return "accessPoint";
    if (
      /\b(site area|site boundary|boundary)\b.*\b(defined|created|set|drawn|ready)\b|\bdefined\b.*\bsite\b/.test(
        t,
      )
    )
      return "siteArea";
    if (/\b(panel run|trakway run|trackway run)\b/.test(t)) return "panelRun";
    if (/\b(saved|save complete|changes are saved)\b/.test(t)) return "saved";
    if (/\bundo|undone|reverted\b/.test(t)) return "undo";
    if (
      /\b(create|created|build|built|make|made|generate|generated|materialise|materialize|produced)\b/.test(
        t,
      )
    )
      return "created";
    if (/\b(add|added|insert|inserted|place|placed)\b/.test(t)) return "added";
    if (
      /\b(update|updated|change|changed|edit|edited|move|moved|position|positioned|group|grouped|ungroup|duplicate|duplicated|delete|deleted|rotate|rotated|resize|resized|colour|color)\b/.test(
        t,
      )
    )
      return "updated";
    return "";
  }
  function recordedVoiceFor(text, mode = "auto") {
    const cfg = window.SAMI_CONFIG || {},
      normal = spokenText(text).toLowerCase();
    if (
      mode === "recorded" ||
      /^(hello[, ]+i['’]?m sammy\b|sammy is ready\.?$)/i.test(normal)
    )
      return cfg.recordedVoiceWelcome || "";
    if (normal === "you can read my response on screen.")
      return cfg.recordedVoiceResponse || "";
    const id = semanticVoiceId(text);
    return id ? cfg.recordedSpeechPack?.[id]?.url || "" : "";
  }
  async function voiceCacheKey(text) {
    if (!window.crypto?.subtle) return null;
    const profile = window.SAMI_CONFIG?.voiceProfile?.id || "sami-voice-v1",
      bytes = new TextEncoder().encode(profile + "|" + text),
      hash = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(hash))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
  async function cachedVoice(text) {
    try {
      if (!("caches" in window)) return null;
      const key = await voiceCacheKey(text);
      if (!key) return null;
      const cache = await caches.open("sami-natural-voice-v1"),
        req = new Request(new URL("./__sami_voice__/" + key, location.href));
      const hit = await cache.match(req);
      return hit ? await hit.blob() : null;
    } catch {
      return null;
    }
  }
  async function cacheVoice(text, blob) {
    try {
      if (!("caches" in window)) return;
      const key = await voiceCacheKey(text);
      if (!key) return;
      const cache = await caches.open("sami-natural-voice-v1"),
        req = new Request(new URL("./__sami_voice__/" + key, location.href));
      await cache.put(
        req,
        new Response(blob, {
          headers: {
            "Content-Type": blob.type || "audio/mpeg",
            "X-SAMI-Voice-Profile":
              window.SAMI_CONFIG?.voiceProfile?.id || "sami-voice-v1",
          },
        }),
      );
    } catch {}
  }
  async function fetchNaturalVoice(text, url) {
    const max = Math.max(
        200,
        Math.min(5000, +window.SAMI_CONFIG?.voiceProfile?.maxChars || 4500),
      ),
      speech = spokenText(text).slice(0, max),
      cached = await cachedVoice(speech);
    if (cached) return cached;
    voiceController = new AbortController();
    const timer = setTimeout(() => voiceController?.abort(), 20000);
    let r;
    try {
      r = await fetch(url, {
        method: "POST",
        mode: "cors",
        credentials: "omit",
        headers: {
          "Content-Type": "application/json",
          Accept: "audio/mpeg,audio/*",
        },
        body: JSON.stringify({
          text: speech,
          voice_profile:
            window.SAMI_CONFIG?.voiceProfile?.id || "sami-voice-v1",
          language: window.SAMI_CONFIG?.voiceProfile?.language || "en-GB",
          pronunciation: { SAMI: "Sammy" },
        }),
        signal: voiceController.signal,
      });
    } finally {
      clearTimeout(timer);
    }
    if (!r.ok) {
      let message = "Voice service returned " + r.status + ".";
      try {
        const data = await r.clone().json();
        if (data?.error) message = String(data.error).slice(0, 180);
      } catch {}
      throw Error(message);
    }
    if (!r.headers.get("content-type")?.startsWith("audio/"))
      throw Error("Speech service must return an audio response.");
    const blob = await r.blob();
    if (!blob.size || blob.size > 12 * 1024 * 1024)
      throw Error("Speech response size is invalid.");
    await cacheVoice(speech, blob);
    return blob;
  }
  async function speakOptional(text, options = false) {
    const opt =
        typeof options === "object" && options
          ? options
          : { mode: options === true ? "recorded" : "auto" },
      force = !!opt.force || options === true;
    if (!force && C.readPref("sami.voice.output") === "off") return;
    stopAudio();
    const seq = voiceSeq,
      url =
        C.readPref("sami.naturalVoice.url") ||
        window.SAMI_CONFIG?.voiceEndpoint ||
        "",
      mode = opt.mode || "auto",
      live = C.readPref("sami.voice.liveFallback") === "on";
    try {
      let src,
        blob,
        clip = mode === "service" ? "" : recordedVoiceFor(text, mode);
      if (clip) {
        src = clip;
      } else if (url && (mode === "service" || live)) {
        blob = await fetchNaturalVoice(text, url);
        src = URL.createObjectURL(blob);
      } else {
        if (mode === "service")
          throw Error("Add an HTTPS voice endpoint first.");
        if (!force && Date.now() - ui.lastVoice < 3000) return;
        src = window.SAMI_CONFIG?.recordedVoiceResponse || "";
        if (!src) return;
      }
      if (seq !== voiceSeq) return;
      voiceAudio = new Audio(src);
      ui.lastVoice = Date.now();
      await voiceAudio.play();
    } catch (e) {
      if (seq === voiceSeq && e.name !== "AbortError")
        C.toast(
          (e.message || "Natural speech unavailable.") +
            " The full answer is on screen.",
        );
    }
  }
  function helpHTML() {
    return (
      '<div class="card"><strong>Designed for iPad, touch and keyboard</strong><p class="subtle">Pinch the canvas to zoom the map. Menus remain the same size. With freehand active, draw with one finger or Pencil; use two fingers to navigate. Long-press an asset tile, then drag it onto the canvas. Tap it for place mode.</p></div><table class="shortcut-table"><tr><th>Shortcut</th><th>Action</th></tr>' +
      [
        ["V", "Select / stop drawing"],
        ["Space (hold)", "Pan canvas"],
        ["L / A", "Point line / point area"],
        ["F / Shift F", "Freehand line / area"],
        ["P", "Place selected asset"],
        ["M", "Measure"],
        ["S", "Toggle snapping"],
        ["Enter", "Finish drawing"],
        ["Escape", "Cancel / close"],
        ["⌘ / Ctrl Z", "Undo"],
        ["⌘ / Ctrl Shift Z", "Redo"],
        ["⌘ / Ctrl D", "Duplicate selection"],
        ["G / Shift G", "Group / ungroup"],
        ["Arrow keys", "Move selected 0.1 m"],
        ["Shift + arrows", "Move selected 1 m"],
        ["Delete", "Delete selection"],
        ["⌘ / Ctrl S", "Save"],
        ["⌘ / Ctrl E", "Export"],
        ["?", "Help"],
      ]
        .map(
          ([a, b]) =>
            "<tr><td><kbd>" + a + "</kbd></td><td>" + b + "</td></tr>",
        )
        .join("") +
      "</table>" +
      C.section("Quick guide") +
      '<p class="subtle">1. Find your site and define its boundary.<br>2. Pick an asset, then draw with the shared tools.<br>3. Select items to move, rotate, colour, group or lock.<br>4. Add entrances, designer details and logos.<br>5. Export the chosen site and route sheets.</p>' +
      B("Voice & AI connections", "open:voice") +
      B("Materials schedule", "open:schedule")
    );
  }
  function renderDrawer(kind) {
    const custom = {
      assets: assetsHTML,
      draw: drawHTML,
      branding: brandingHTML,
      access: accessHTML,
      voice: voiceHTML,
      schedule: O.libraryHTML,
    };
    if (custom[kind]) {
      $("#drawerTitle").textContent = {
        assets: "Asset library",
        draw: "Drawing tools",
        branding: "Designer & logos",
        access: "Access points",
        voice: "SAMI voice & AI",
        schedule: "Materials schedule",
      }[kind];
      const box = $("#drawerContent");
      box.innerHTML = custom[kind]();
      box.onclick = (e) => {
        const b = e.target.closest("[data-action]");
        if (b && !ui.dragging) C.runAction(b.dataset.action, b);
      };
      C.bindDrawer(kind);
      return;
    }
    O.renderDrawer(kind);
  }
  function bindDrawer(kind) {
    if (
      ![
        "project",
        "assets",
        "branding",
        "access",
        "voice",
        "schedule",
      ].includes(kind)
    )
      O.bindDrawer(kind);
    if (kind === "assets") {
      C.bindAssetPaletteDrag();
      $("#assetSearch").oninput = (e) => {
        ui.search = e.target.value;
        const pos = e.target.selectionStart;
        C.renderDrawer("assets");
        $("#assetSearch").focus();
        $("#assetSearch").setSelectionRange(pos, pos);
      };
      $$("[data-category]").forEach(
        (d) =>
          (d.ontoggle = () => {
            if (d.open) ui.category = d.dataset.category;
          }),
      );
      $("#studioLanes")?.addEventListener("change", () => {
        S.project.route.lanes = +$("#studioLanes").value;
        C.saveSoon();
      });
      $("#libraryColour").onchange = () => {
        S.project.assetColour = $("#libraryColour").value;
        C.saveSoon();
      };
      $("#repeatGap")?.addEventListener("change", () => {
        S.project.assetGap = Math.max(0, +$("#repeatGap").value || 0);
        C.saveSoon();
      });
      for (const id of ["customAssetLength", "customAssetWidth"])
        $("#" + id)?.addEventListener("change", () => {
          const a = getAsset();
          if (!a || a.dimensionLocked !== false) return;
          const l = +($("#customAssetLength")?.value || a.length),
            w = +($("#customAssetWidth")?.value || a.width);
          if (l > 0 && w > 0) {
            a.length = Math.min(500, l);
            a.width = Math.min(500, w);
            const saved = S.project.customAssets.find((x) => x.kind === a.kind);
            if (saved) {
              saved.length = a.length;
              saved.width = a.width;
            }
            C.saveSoon();
          }
        });
    }
    if (kind === "project") {
      for (const id of [
        "siteAddress",
        "what3words",
        "siteRef",
        "clientName",
        "creator",
        "drawingNo",
        "revision",
        "siteContact",
        "sitePhone",
        "siteEntrance",
        "arrivalInstructions",
        "driverNotes",
        "siteNotes",
      ]) {
        const el = $("#" + id);
        if (el)
          el.onchange = () => {
            S.project.meta[id] = el.value;
            C.commit();
          };
      }
      $("#projectNameEdit").onchange = () => {
        S.project.name = $("#projectNameEdit").value.trim() || "Untitled site";
        $("#projectName").value = S.project.name;
        C.commit();
      };
      $("#w3wApiKey").onchange = () =>
        C.setPref("sami.w3w.key", $("#w3wApiKey").value.trim());
    }
    if (kind === "branding") {
      for (const [id, key] of Object.entries({
        designerName: "creator",
        designerCompany: "designerCompany",
        designerEmail: "designerEmail",
        designerPhone: "designerPhone",
      }))
        $("#" + id).onchange = () => {
          S.project.meta[key] = $("#" + id).value.trim();
          C.setPref(
            "sami.designer",
            JSON.stringify(
              Object.fromEntries(
                [
                  "creator",
                  "designerCompany",
                  "designerEmail",
                  "designerPhone",
                ].map((k) => [k, S.project.meta[k] || ""]),
              ),
            ),
          );
          C.commit();
        };
      $$("[data-logo-export]").forEach(
        (e) =>
          (e.onchange = () => {
            S.project.logos.find((l) => l.id === e.dataset.logoExport).export =
              e.checked;
            C.commit();
          }),
      );
    }
    if (kind === "routeToSite") {
      $("#routeAccessPoint")?.addEventListener("change", (e) =>
        chooseAccessRoute(e.target.value),
      );
      $("#routeEnd")?.addEventListener("change", () => {
        delete S.project.hgv.accessPointId;
      });
    }
    if (kind === "voice") {
      $("#voiceOutput").onchange = () => {
        C.setPref(
          "sami.voice.output",
          $("#voiceOutput").checked ? "on" : "off",
        );
        C.updateVoiceButton();
        if (!$("#voiceOutput").checked) stopAudio();
      };
      $("#voiceLiveFallback")?.addEventListener("change", () =>
        C.setPref(
          "sami.voice.liveFallback",
          $("#voiceLiveFallback").checked ? "on" : "off",
        ),
      );
    }
  }
  function runAction(action, b) {
    const [cmd, ...args] = action.split(":"),
      arg = args.join(":");
    if (ui.dragging) return;
    try {
      if (action === "importShapePack") {
        $("#shapePackInput").click();
        return;
      }
      if (action === "exportShapePack") {
        exportShapePack();
        return;
      }
      if (action === "confirmAssetScale") {
        confirmAssetScale();
        return;
      }
      if (cmd === "pickAsset") {
        ui.asset = arg;
        ui.category = getAsset()?.category;
        ui.method = methodsFor(getAsset())[0];
        C.renderDrawer("assets");
        updateActiveTools();
        return;
      }
      if (cmd === "master") {
        ui.method = arg;
        activateMaster(arg);
        return;
      }
      if (action === "masterStart") {
        activateMaster();
        return;
      }
      if (action === "accessPoint") {
        C.startTool("accessPoint");
        return;
      }
      if (cmd === "accessEdit") {
        editAccessPoint(accessPoints().find((f) => f.id === arg));
        return;
      }
      if (action === "editAccess") {
        editAccessPoint(C.selectedFeature());
        return;
      }
      if (cmd === "accessRoute") {
        chooseAccessRoute(arg);
        return;
      }
      if (action === "uploadLogo") {
        $("#logoInput").click();
        return;
      }
      if (cmd === "pickLogo") {
        ui.asset = "logo_" + arg;
        ui.method = "place";
        C.closeDrawer();
        activateMaster();
        return;
      }
      if (cmd === "removeLogo") {
        S.project.logos = S.project.logos.filter((l) => l.id !== arg);
        C.commit();
        C.renderDrawer("branding");
        return;
      }
      if (action === "saveConnections") {
        for (const [id, key] of [
          ["naturalVoiceUrl", "sami.naturalVoice.url"],
          ["connectedAiUrl", "sami.ai.url"],
        ]) {
          const value = $("#" + id).value.trim();
          if (value && new URL(value).protocol !== "https:")
            throw Error("Use an HTTPS endpoint.");
          C.setPref(key, value);
        }
        window.dispatchEvent(new Event("sami:assistant-config"));
        C.toast("Connections saved.");
        return;
      }
      if (action === "toggleSelectedLock") {
        const fs = C.groupMembers();
        const locked = !fs[0]?.properties.locked;
        fs.forEach((f) => (f.properties.locked = locked));
        C.commit();
        C.renderDrawer("selection");
        return;
      }
      if (["frontSelected", "backSelected"].includes(action)) {
        const fs = C.groupMembers(),
          ids = new Set(fs.map((f) => f.id)),
          other = S.project.features.filter((f) => !ids.has(f.id));
        S.project.features =
          action === "frontSelected" ? [...other, ...fs] : [...fs, ...other];
        C.commit();
        return;
      }
      if (["hideItem", "lockItem", "raiseItem", "lowerItem"].includes(cmd)) {
        const f = S.project.features.find((f) => f.id === arg),
          members = C.groupMembers(f);
        if (cmd === "hideItem") {
          const value = !f.properties.hidden;
          members.forEach((x) => (x.properties.hidden = value));
        } else if (cmd === "lockItem") {
          const value = !f.properties.locked;
          members.forEach((x) => (x.properties.locked = value));
        } else {
          const ids = new Set(members.map((x) => x.id)),
            other = S.project.features.filter((x) => !ids.has(x.id));
          S.project.features =
            cmd === "raiseItem"
              ? [...other, ...members]
              : [...members, ...other];
        }
        C.commit();
        C.renderDrawer("layers");
        return;
      }
      if (action === "rebuildLion") {
        rebuildLion();
        return;
      }
      if (action === "testVoice") {
        C.speakOptional(
          "Hello, I'm SAMI. Your site planning workspace is ready.",
          { mode: "recorded", force: true },
        );
        return;
      }
      if (action === "testSpeechPack") {
        C.speakOptional("Please build, make or generate a new object.", {
          mode: "auto",
          force: true,
        });
        return;
      }
      if (action === "testNaturalVoice") {
        C.speakOptional(
          "Hello, I'm SAMI. This is the live fallback voice. I should sound like the same speaker, with the same pace and tone.",
          { mode: "service", force: true },
        );
        return;
      }
      return O.runAction(action, b);
    } catch (e) {
      C.toast(e.message);
    }
  }
  function rebuildLion() {
    const f = C.selectedFeature(),
      product = f?.properties?.product || "lion",
      spec = PRODUCTS[product] || PRODUCTS.lion,
      guide = S.project.features.find(
        (x) =>
          x.properties.routeId === f?.properties?.routeId &&
          x.properties.guideHidden &&
          x.geometry.type === "LineString",
      );
    if (!guide) {
      C.toast(
        "Only generated line runs can be rebuilt. Use the shared tools to draw a new area.",
      );
      return;
    }
    C.showModal(
      "Correct " + spec.name + " run width",
      C.choice(
        "rebuildLanes",
        "Finished run width",
        { 1: spec.width + " m · single", 2: spec.width * 2 + " m · double" },
        String(S.project.route.lanes === 2 ? 2 : 1),
      ) + B("Rebuild run", "confirmRebuild", true),
    );
    $("#modalBody").onclick = (e) => {
      if (!e.target.closest('[data-action="confirmRebuild"]')) return;
      const lanes = +$("#rebuildLanes").value,
        pts = copy(guide.geometry.coordinates),
        id = guide.properties.routeId;
      S.project.features = S.project.features.filter(
        (x) => x.properties.routeId !== id,
      );
      C.closeModal();
      C.addPanelRun(pts, { product, ...spec, lanes });
    };
  }
  function creatorState() {
    return (ui.creator ??= {
      name: "My asset",
      length: 6,
      width: 2.5,
      parts: [],
      selected: -1,
    });
  }
  function creatorPush() {
    creatorHistory.push(copy(creatorState()));
    if (creatorHistory.length > 60) creatorHistory.shift();
  }
  function openCreator() {
    const c = creatorState(),
      el = $("#creatorWorkspace");
    el.hidden = false;
    el.innerHTML = `<div class="creator-tools"><div class="eyebrow">CREATE A SHAPE</div><h2>Build a shape</h2><p class="subtle">Combine simple parts, set real dimensions, then save to My shapes.</p><div class="compact-tools"><button data-create="rect">Rectangle</button><button data-create="ellipse">Ellipse</button><button data-create="line">Line</button><button data-create="triangle">Triangle</button><button data-create="duplicate">Duplicate part</button><button data-create="delete">Delete part</button></div><div class="row equal"><button data-create="truck">Truck template</button><button data-create="cabin">Cabin template</button></div><div class="row equal"><button data-create="import">Import stencil / CAD</button><button data-create="export">Export My shapes</button></div>${F("customName", "Asset name", c.name)}<div class="row equal"><div>${F("customLength", "Length (m)", c.length, "number", 'min="0.1" max="500" step="0.1"')}</div><div>${F("customWidth", "Width (m)", c.width, "number", 'min="0.1" max="500" step="0.1"')}</div></div><div class="creator-props" id="creatorProps"></div><div class="row equal"><button data-create="undo">Undo part edit</button><button data-create="save" class="primary">Save to My shapes</button></div><button data-create="ask">Ask SAMI to help design</button><p class="subtle">Drag a part to move it. Use its properties to resize and colour it. A connected AI service can suggest a draft for review.</p></div><div class="creator-artboard"><div class="artboard-top"><strong>Top view</strong><span id="creatorSize"></span></div><svg id="creatorCanvas" viewBox="-10 -10 120 120" aria-label="Asset design canvas"><defs><pattern id="creatorGrid" width="5" height="5" patternUnits="userSpaceOnUse"><path d="M5 0H0V5" fill="none" stroke="#e0e8e4" stroke-width=".2"/></pattern></defs><rect x="-10" y="-10" width="120" height="120" fill="url(#creatorGrid)"/><rect x="0" y="0" width="100" height="100" fill="#fff" stroke="#8eb3a6" stroke-width=".3"/><g id="creatorParts"></g></svg><div class="artboard-bottom">Real dimensions · reusable vector asset</div></div>`;
    el.onclick = (e) => {
      const a = e.target.closest("[data-create]")?.dataset.create;
      if (a) creatorAction(a);
    };
    for (const [id, key] of [
      ["customName", "name"],
      ["customLength", "length"],
      ["customWidth", "width"],
    ])
      $("#" + id).onchange = () => {
        creatorPush();
        c[key] =
          key === "name"
            ? $("#" + id).value
            : Math.max(0.1, Math.min(500, +$("#" + id).value || 1));
        drawCreator();
      };
    bindCreatorDrag();
    drawCreator();
  }
  function drawCreator() {
    const c = creatorState(),
      svg = $("#creatorCanvas");
    if (!svg) return;
    svg.style.aspectRatio = (c.length / c.width).toFixed(3);
    $("#creatorSize").textContent = c.length + " × " + c.width + " m";
    $("#creatorParts").innerHTML = c.parts
      .map(
        (p, i) =>
          `<g data-part="${i}" class="${c.selected === i ? "selected-part" : ""}">${D.svgParts([p], { styleFill: "#93baa9" })}</g>`,
      )
      .join("");
    const p = c.parts[c.selected],
      props = $("#creatorProps");
    props.innerHTML = p
      ? '<div class="section-title">Selected part ' +
        (c.selected + 1) +
        '</div><div class="part-props">' +
        ["x", "y", "w", "h", ...(p.type === "line" ? ["x2", "y2"] : [])]
          .filter((k) => p[k] != null)
          .map((k) =>
            F(
              "part_" + k,
              k.toUpperCase(),
              p[k],
              "number",
              'step="1" min="0" max="100"',
            ),
          )
          .join("") +
        '<label>Colour<input type="color" id="partFill" value="' +
        colour(p.fill) +
        '"></label></div>'
      : '<p class="subtle">Add or select a part.</p>';
    props.onchange = (e) => {
      if (!p) return;
      creatorPush();
      const k = e.target.id.replace("part_", "");
      if (e.target.id === "partFill") p.fill = e.target.value;
      else if (k in p) p[k] = Math.max(0, Math.min(100, +e.target.value || 0));
      drawCreator();
    };
  }
  function creatorAction(a) {
    const c = creatorState(),
      selected = c.parts[c.selected];
    if (a === "import") {
      $("#shapePackInput").click();
      return;
    }
    if (a === "export") {
      exportShapePack();
      return;
    }
    if (a === "undo") {
      if (creatorHistory.length) ui.creator = creatorHistory.pop();
      openCreator();
      return;
    }
    if (a === "save") {
      if (!c.parts.length) {
        C.toast("Add at least one part.");
        return;
      }
      if (!D.validParts(c.parts)) {
        C.toast("The asset contains invalid shapes.");
        return;
      }
      const p = {
        kind: "my_" + C.uid().replaceAll("-", ""),
        name: String(c.name || "My asset").slice(0, 100),
        length: +c.length,
        width: +c.width,
        category: "My shapes",
        symbolPartsJSON: JSON.stringify(c.parts),
        angle: 0,
        dimensionLocked: false,
      };
      S.project.customAssets.push(p);
      syncCatalogue();
      C.commit();
      C.toast("Saved to My shapes.");
      ui.asset = p.kind;
      ui.category = "My shapes";
      C.setMode(S.project.area ? "plan" : "map");
      C.openDrawer("assets");
      return;
    }
    if (a === "ask") {
      document.body.classList.remove("ask-collapsed");
      $("#askInput").focus();
      $("#askInput").placeholder = "Describe your asset, dimensions and parts…";
      return;
    }
    creatorPush();
    if (a === "truck" || a === "cabin") {
      c.parts = copy(D.parts(a === "truck" ? "rigid" : "cabin20"));
      c.name = a === "truck" ? "My truck" : "My cabin";
      c.length = a === "truck" ? 10.5 : 6.1;
      c.width = a === "truck" ? 2.55 : 2.44;
      openCreator();
      return;
    }
    if (a === "delete" && selected) {
      c.parts.splice(c.selected, 1);
      c.selected = -1;
    } else if (a === "duplicate" && selected) {
      const p = copy(selected);
      if (p.x != null) p.x = Math.min(75, p.x + 5);
      if (p.y != null) p.y = Math.min(75, p.y + 5);
      if (p.points)
        p.points = p.points.map(([x, y]) => [
          Math.min(100, x + 5),
          Math.min(100, y + 5),
        ]);
      c.parts.push(p);
      c.selected = c.parts.length - 1;
    } else {
      const p = {
        rect: D.P.rect(20, 20, 40, 40),
        ellipse: D.P.ellipse(25, 25, 30, 30),
        line: D.P.line(10, 50, 90, 50),
        triangle: D.P.poly([
          [25, 75],
          [50, 25],
          [75, 75],
        ]),
      }[a];
      if (p) {
        c.parts.push(p);
        c.selected = c.parts.length - 1;
      }
    }
    drawCreator();
  }
  function bindCreatorDrag() {
    const canvas = $("#creatorCanvas");
    let drag = null;
    const coord = (e) => {
      const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(
        canvas.getScreenCTM().inverse(),
      );
      return [p.x, p.y];
    };
    canvas.onpointerdown = (e) => {
      const g = e.target.closest("[data-part]");
      if (!g) return;
      const c = creatorState();
      c.selected = +g.dataset.part;
      creatorPush();
      drag = {
        id: e.pointerId,
        start: coord(e),
        part: copy(c.parts[c.selected]),
      };
      canvas.setPointerCapture(e.pointerId);
      drawCreator();
      e.preventDefault();
    };
    canvas.onpointermove = (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const pos = coord(e),
        dx = pos[0] - drag.start[0],
        dy = pos[1] - drag.start[1],
        p = copy(drag.part);
      if (p.points)
        p.points = p.points.map(([x, y]) => [
          Math.max(0, Math.min(100, x + dx)),
          Math.max(0, Math.min(100, y + dy)),
        ]);
      else {
        p.x = Math.max(0, Math.min(100 - (p.w || 0), p.x + dx));
        p.y = Math.max(0, Math.min(100 - (p.h || 0), p.y + dy));
        if (p.x2 != null) {
          p.x2 = Math.max(0, Math.min(100, p.x2 + dx));
          p.y2 = Math.max(0, Math.min(100, p.y2 + dy));
        }
      }
      creatorState().parts[creatorState().selected] = p;
      drawCreator();
    };
    const stop = () => {
      drag = null;
    };
    canvas.onpointerup = stop;
    canvas.onpointercancel = stop;
  }
  async function askAssetDesign(query) {
    const endpoint =
      C.readPref("sami.ai.url") || window.SAMI_CONFIG?.aiEndpoint;
    if (!endpoint) {
      const k = /truck|lorry|vehicle/i.test(query)
        ? "rigid"
        : /cabin|office|container/i.test(query)
          ? "cabin20"
          : /tent|marquee/i.test(query)
            ? "marquee"
            : null;
      if (k) {
        creatorPush();
        const a = ASSETS[k];
        ui.creator = {
          name: "My " + a.name,
          length: a.length,
          width: a.width,
          parts: copy(D.parts(k)),
          selected: -1,
        };
        const match = query.match(
          /(\d+(?:\.\d+)?)\s*(?:m|metres?)?\s*(?:x|by|×)\s*(\d+(?:\.\d+)?)/i,
        );
        if (match) {
          ui.creator.length = Math.max(0.1, Math.min(500, +match[1]));
          ui.creator.width = Math.max(0.1, Math.min(500, +match[2]));
        }
        C.setMode("create");
        C.samiSay(
          "I have opened an editable " +
            a.name +
            " template. Set the final dimensions, adjust its parts, then save it to My shapes.",
        );
      } else {
        C.samiSay(
          "The shape builder is ready. Add rectangles, ellipses, lines and triangles, or start from a truck or cabin. For an original AI design, connect your service in Voice & AI connections.",
        );
        C.setMode("create");
      }
      return;
    }
    try {
      const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query,
            mode: "assetDesign",
            units: "metres",
            schema: {
              name: "string",
              length: "number 0.1..500",
              width: "number 0.1..500",
              parts:
                "0..100 normalized rect/ellipse/line/poly primitives, max 120",
            },
            policy:
              "Return a draft JSON object {asset:{name,length,width,parts},answer}. No markup. Do not claim indicative dimensions are verified.",
          }),
          signal: AbortSignal.timeout(30000),
        }),
        data = await C.boundedJSON(res, 150000),
        a = data.asset;
      if (
        !a ||
        !D.validParts(a.parts) ||
        !(a.length > 0.1 && a.length <= 500 && a.width > 0.1 && a.width <= 500)
      )
        throw Error("The AI service returned an invalid asset draft.");
      creatorPush();
      ui.creator = {
        name: String(a.name || "AI asset draft").slice(0, 100),
        length: +a.length,
        width: +a.width,
        parts: a.parts,
        selected: -1,
      };
      C.setMode("create");
      C.samiSay(
        data.answer ||
          "Your draft is ready to review. Check the dimensions and save it to My shapes.",
      );
    } catch (e) {
      C.samiSay(
        e.message ||
          "Asset design is unavailable. The shape builder remains available.",
      );
    }
  }
  async function handleCommand(q) {
    if (
      S.mode === "create" ||
      /\b(design|build)\b.*\b(my shape|custom asset|asset|truck|cabin|vehicle)\b/i.test(
        q,
      ) ||
      /\bcreate\b.*\b(custom asset|my shape)\b/i.test(q)
    ) {
      await askAssetDesign(q);
      return;
    }
    if (
      /\b(access point|entrance|gate)\b/i.test(q) &&
      /\b(add|place|create)\b/i.test(q)
    ) {
      C.startTool("accessPoint");
      C.samiSay("Tap the entrance position, then add its name and address.");
      return;
    }
    window.SAMI_CONFIG.aiEndpoint =
      C.readPref("sami.ai.url") || window.SAMI_CONFIG.aiEndpoint;
    await O.handleCommand(q);
  }
  function overpassFeatures(data, opts = {}) {
    if (!opts.powerAsService) return O.overpassFeatures(data, opts);
    const nodes = new Map(
        (data.elements || [])
          .filter((x) => x.type === "node")
          .map((n) => [n.id, n]),
      ),
      out = [],
      used = new Set(),
      bounds = ohlBounds(),
      capturedAt = new Date().toISOString(),
      supportKinds = new Set(["pole", "tower", "portal", "terminal"]);
    const meta = (n, line = {}) => ({
      ref: n.tags?.ref || n.tags?.["ref:GB:power"] || "",
      voltage: n.tags?.voltage || line.voltage || "",
      lineName: line.name || line.ref || "",
      operator: n.tags?.operator || line.operator || "",
      owner: n.tags?.owner || line.owner || "",
      material: n.tags?.material || "",
      design: n.tags?.design || "",
      height: n.tags?.height || "",
      osmNodeId: n.id,
    });
    const voltageInScope = (value) => {
      const values = String(value || "")
        .split(";")
        .map((item) => Number(item.trim()))
        .filter(Number.isFinite);
      return (
        !values.length ||
        values.some((value) => value >= 400 && value <= 400000)
      );
    };
    const mappedKind = (n) =>
      n.tags?.power === "tower"
        ? "pylon"
        : n.tags?.power === "portal"
          ? "portal"
          : n.tags?.power === "terminal"
            ? "terminal"
            : "pole";
    for (const way of (data.elements || []).filter(
      (x) =>
        x.type === "way" &&
        (["line", "minor_line"].includes(x.tags?.power) ||
          (x.tags?.power === "cable" &&
            ["overhead", "surface"].includes(x.tags?.location))) &&
        voltageInScope(x.tags?.voltage),
    )) {
      const coords = (way.nodes || [])
        .map((id) => nodes.get(id))
        .filter(Boolean)
        .map((n) => [n.lon, n.lat]);
      if (coords.length < 2) continue;
      const points = [],
        types = {},
        metadata = {};
      for (const id of way.nodes) {
        const n = nodes.get(id);
        if (!supportKinds.has(n?.tags?.power)) continue;
        const c = [n.lon, n.lat];
        if (bounds && !G.inside(c, bounds)) continue;
        used.add(id);
        points.push(c);
        const key = supportKey(c);
        metadata[key] = {
          ...meta(n, way.tags || {}),
          mappedKind: mappedKind(n),
        };
      }
      const geom = bounds
        ? G.clipGeometry({ type: "LineString", coordinates: coords }, bounds)
        : { type: "LineString", coordinates: coords };
      if (!geom) continue;
      out.push(
        C.feature("service", geom, {
          serviceType: "ohl",
          label: way.tags.name || way.tags.ref || "Overhead power line",
          voltage: way.tags.voltage || "",
          lineRef: way.tags.ref || "",
          operator: way.tags.operator || "",
          owner: way.tags.owner || "",
          circuits: way.tags.circuits || "",
          cables: way.tags.cables || "",
          osmPower: way.tags.power || "",
          osmLocation: way.tags.location || "overhead",
          osmWayId: way.id,
          source: "OpenStreetMap power network",
          sourceId: "builtin:ohl-osm",
          capturedAt,
          verification: "Mapped reference · not surveyed",
          supportPointsJSON: JSON.stringify(points),
          supportTypesJSON: JSON.stringify(types),
          supportMetaJSON: JSON.stringify(metadata),
          includeLegend: true,
        }),
      );
    }
    for (const n of nodes.values()) {
      if (used.has(n.id) || !supportKinds.has(n.tags?.power)) continue;
      const c = [n.lon, n.lat];
      if (bounds && !G.inside(c, bounds)) continue;
      const key = supportKey(c);
      out.push(
        C.feature(
          "service",
          { type: "Point", coordinates: c },
          {
            serviceType: "ohl",
            label:
              n.tags.ref ||
              {
                pole: "OHL pole",
                tower: "OHL tower",
                portal: "OHL portal",
                terminal: "OHL terminal",
              }[n.tags.power] ||
              "OHL support",
            source: "OpenStreetMap power network",
            sourceId: "builtin:ohl-osm",
            capturedAt,
            verification: "Mapped reference · not surveyed",
            supportNode: true,
            supportPointsJSON: JSON.stringify([c]),
            supportTypesJSON: "{}",
            supportMetaJSON: JSON.stringify({
              [key]: { ...meta(n), mappedKind: mappedKind(n) },
            }),
            includeLegend: true,
          },
        ),
      );
    }
    return out;
  }
  function refreshOhlSnapshot(opts = {}) {
    return C.runServiceRefresh("ohl", () => refreshOhlSnapshotWork(opts));
  }
  async function refreshOhlSnapshotWork(opts = {}) {
    if (!S.project.area) {
      if (!opts.auto) C.openDrawer("area");
      return;
    }
    const bounds = ohlBounds(),
      generation = S.areaGeneration,
      project = S.project,
      key = ohlSnapshotKey(bounds),
      previous = new Map(),
      existingMapped = project.features.filter(
        (f) => f.properties.sourceId === "builtin:ohl-osm",
      ),
      sameSnapshot = project.meta?.ohlSnapshotKey === key;
    for (const f of project.features.filter(
      (f) => f.properties.serviceType === "ohl",
    )) {
      const ms = readSupportMeta(f),
        ts = C.readSupportTypes(f);
      for (const [k, m] of Object.entries(ms))
        if (m.userEdited) previous.set(k, { meta: m, type: ts[k] });
    }
    if (!opts.auto)
      C.toast(
        "Finding mapped OHLs within the site + 0.5 mile intelligence buffer…",
      );
    const applyEdits = (fs) => {
      for (const f of fs) {
        const ms = readSupportMeta(f),
          ts = C.readSupportTypes(f);
        for (const c of supports(f)) {
          const k = supportKey(c),
            saved = previous.get(k);
          if (saved) {
            ms[k] = saved.meta;
            ts[k] = saved.type;
          }
        }
        f.properties.supportMetaJSON = JSON.stringify(ms);
        f.properties.supportTypesJSON = JSON.stringify(ts);
      }
      return fs;
    };
    const adopt = async (fs, { cached = false } = {}) => {
      if (project !== S.project || generation !== S.areaGeneration) return;
      applyEdits(fs);
      const replaced = await C.replaceSourceFeatures(
        "builtin:ohl-osm",
        fs,
        "OHL intelligence snapshot", project, generation,
      );
      if (project !== S.project || generation !== S.areaGeneration)
        return false;
      if (!replaced && !fs.length && existingMapped.length)
        return {status:"retained",count:existingMapped.length,message:"No replacement OHL records; previous snapshot kept."};
      project.hiddenTypes = project.hiddenTypes.filter((t) => t !== "service");
      project.serviceVisibility.ohl = true;
      project.meta = project.meta || {};
      project.meta.ohlRefreshedAt = new Date().toISOString();
      project.meta.ohlCoverage = "OSM mapped reference · site + 0.5 mile";
      project.meta.ohlSnapshotKey = key;
      project.meta.ohlStale = !!cached;
      project.meta.ohlSnapshotSource = cached
        ? "Last-known-good local OHL cache"
        : "Live Overpass mirror";
      const lineCount = fs.filter((f) => !f.properties.supportNode).length,
        supportCount =
          fs.filter((f) => f.properties.supportNode).length +
          fs.reduce((n, f) => n + supports(f).length, 0);
      C.commit();
      if (!cached) saveOhlFallback(bounds, fs);
      if (!opts.auto)
        C.toast(
          `${lineCount} mapped OHL line records and ${supportCount} mapped support references saved${cached ? " from the last-known-good cache" : ""}. Verify before safety-critical use.`,
        );
      return {status:cached ? "retained" : fs.length ? "ready" : "empty", count:fs.length, message:cached ? "Using stored OHL records." : fs.length ? "Mapped OHL records loaded." : "No mapped OHL returned. Verify site conditions."};
    };
    try {
      const bbox = [bounds[1], bounds[0], bounds[3], bounds[2]].join(","),
        query = `[out:json][timeout:28];(way["power"~"^(line|minor_line)$"](${bbox});way["power"="cable"]["location"~"^(overhead|surface)$"](${bbox});node["power"~"^(pole|tower|portal|terminal)$"](${bbox}););(._;>;);out body;`,
        data = await C.overpassQuery(query, 16 * 1024 * 1024, {
          preferNonEmpty: true,
        });
      if (project !== S.project || generation !== S.areaGeneration) return;
      const fs = C.overpassFeatures(data, { powerAsService: true });
      if (!fs.length && sameSnapshot && existingMapped.length) {
        project.meta = project.meta || {};
        project.meta.ohlStale = true;
        project.meta.ohlLastRefreshError =
          "Live refresh returned no replacement records; retained last-known-good snapshot";
        C.commit();
        if (!opts.auto)
          C.toast(
            "No replacement OHL records were returned. SAMI retained the last-known-good mapped OHL snapshot instead of clearing it.",
          );
        return {status:"retained",count:existingMapped.length,message:project.meta.ohlLastRefreshError};
      }
      if (!fs.length) {
        const cached = loadOhlFallback(bounds);
        if (cached?.features?.length) {
          return await adopt(cached.features, { cached: true });
        }
      }
      return await adopt(fs);
    } catch (e) {
      if (project !== S.project || generation !== S.areaGeneration) return;
      if (sameSnapshot && existingMapped.length) {
        project.meta = project.meta || {};
        project.meta.ohlStale = true;
        project.meta.ohlLastRefreshError = e.message || String(e);
        C.commit();
        if (!opts.auto)
          C.toast(
            "OHL live refresh failed. The last-known-good mapped snapshot has been retained.",
          );
        return {status:"retained",count:existingMapped.length,message:project.meta.ohlLastRefreshError};
      }
      const cached = loadOhlFallback(bounds);
      if (cached?.features?.length) {
        const result = await adopt(cached.features, { cached: true });
        if (!opts.auto)
          C.toast(
            "Live OHL source was unavailable, so SAMI restored the last-known-good local snapshot.",
          );
        return result;
      }
      project.meta = project.meta || {};
      project.meta.ohlStale = true;
      project.meta.ohlLastRefreshError = e.message || String(e);
      C.commit();
      if (!opts.auto)
        C.toast(
          "OHL refresh failed: " +
            e.message +
            ". No saved snapshot was removed.",
        );
      return {status:cached?.features?.length ? "retained" : "error",message:e.message || "OHL source unavailable; existing records kept."};
    }
  }
  function updateLaunchGate() {
    const splash = $("#splash");
    if (!splash) return;
    $("#splashStatus").textContent = "Your site planning workspace is ready.";
    const start = $("#launchStartBtn");
    start.hidden = false;
    start.textContent = "Open workspace";
    start.onclick = () => {
      splash.remove();
      document.documentElement.classList.remove("browser-gated");
    };
    const ios =
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    $("#installGuide").hidden = false;
    $("#installGuide").innerHTML = ios
      ? "<span>For a full-screen workspace: Safari → Share → Add to Home Screen.</span>"
      : "<span>Install from your browser for a full-screen workspace, or open it here.</span>";
    document.documentElement.classList.remove("browser-gated");
    $("#installPwaBtn").hidden = true;
  }
  function initToolRail() {
    $("#railMove").hidden = true;
    $("#railCollapse").onclick = () => {
      document.body.classList.toggle("tools-collapsed");
      $("#railCollapse").setAttribute(
        "aria-expanded",
        String(!document.body.classList.contains("tools-collapsed")),
      );
    };
  }
  function clampRail() {}
  function initFreehandInput() {
    const el = $("#map");
    let pointers = new Map(),
      stroke = null,
      pinching = false;
    el.addEventListener(
      "pointerdown",
      (e) => {
        pointers.set(e.pointerId, e);
        if (pointers.size > 1) {
          pinching = true;
          if (stroke) {
            stroke = null;
            S.freehandActive = false;
            S.points = [];
            S.draftGroup.clearLayers();
            C.updateLock();
          }
          return;
        }
        if (
          !C.isFreehandTool(S.tool) ||
          ui.panning ||
          (ui.penOnly && e.pointerType !== "pen") ||
          e.button > 0
        )
          return;
        const p = C.screenToCoord(e);
        if (!C.freehandPointAllowed(p)) return;
        stroke = { id: e.pointerId, x: e.clientX, y: e.clientY };
        S.freehandActive = true;
        S.points = [p];
        S.map.dragging.disable();
        el.setPointerCapture(e.pointerId);
        e.preventDefault();
        e.stopPropagation();
        C.renderDraft();
      },
      { capture: true },
    );
    el.addEventListener(
      "pointermove",
      (e) => {
        if (!stroke || stroke.id !== e.pointerId || pinching) return;
        if (Math.hypot(e.clientX - stroke.x, e.clientY - stroke.y) < 3) return;
        const p = C.screenToCoord(e);
        if (!C.freehandPointAllowed(p)) return;
        S.points.push(p);
        stroke.x = e.clientX;
        stroke.y = e.clientY;
        C.renderDraft();
        e.preventDefault();
        e.stopPropagation();
      },
      { capture: true },
    );
    const end = (e) => {
      pointers.delete(e.pointerId);
      if (pinching) {
        if (!pointers.size) pinching = false;
        return;
      }
      if (stroke?.id !== e.pointerId) return;
      stroke = null;
      S.freehandActive = false;
      el.releasePointerCapture?.(e.pointerId);
      if (e.type === "pointercancel") {
        S.points = [];
        C.renderDraft();
      } else C.finishDraw();
      C.updateLock();
      e.preventDefault();
      e.stopPropagation();
    };
    el.addEventListener("pointerup", end, { capture: true });
    el.addEventListener("pointercancel", end, { capture: true });
  }
  function moveSelection(dx, dy) {
    const f = C.selectedFeature();
    if (
      !f ||
      f.properties.locked ||
      C.groupMembers(f).some((x) => x.properties.locked)
    )
      return;
    const center = C.featureCenter(f),
      pr = G.projection(center),
      next = pr.ll([dx, dy]);
    C.translateMembers(C.groupMembers(f), [
      next[0] - center[0],
      next[1] - center[1],
    ]);
    C.commit();
  }
  function keyboard(e) {
    if (
      /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) ||
      e.target.isContentEditable ||
      !$("#modal").classList.contains("hidden")
    )
      return;
    const mod = e.ctrlKey || e.metaKey,
      k = e.key.toLowerCase();
    if (e.code === "Space") {
      e.preventDefault();
      ui.panning = true;
      C.updateLock();
      return;
    }
    if (mod && k === "s") {
      e.preventDefault();
      window.SAMIWorkspace?.runAction("save");
      return;
    }
    if (mod && k === "e") {
      e.preventDefault();
      C.openExport();
      return;
    }
    if (mod && k === "d") {
      e.preventDefault();
      C.duplicateSelected();
      return;
    }
    if (mod) return;
    if (k === "v") {
      C.cancelDraw();
      C.closeDrawer();
    } else if (k === "l") activateMaster("line");
    else if (k === "a") activateMaster("area");
    else if (k === "f") activateMaster(e.shiftKey ? "freeArea" : "freeLine");
    else if (k === "p") activateMaster("place");
    else if (k === "m") window.SAMIWorkspace?.runAction("dimensionTool");
    else if (k === "s") {
      ui.snap = !ui.snap;
      S.options.snap = ui.snap;
      updateActiveTools();
    } else if (k === "g") {
      e.shiftKey ? C.ungroupSelected() : C.startGroupPick();
    } else if (k === "?" || e.key === "F1") {
      e.preventDefault();
      C.openDrawer("help");
    } else if (k === "delete" && !S.tool) {
      e.preventDefault();
      C.editAction("editDelete");
    } else if (
      ["arrowleft", "arrowright", "arrowup", "arrowdown"].includes(k) &&
      C.selectedFeature()
    ) {
      e.preventDefault();
      e.stopPropagation();
      const n = e.shiftKey ? 1 : 0.1;
      moveSelection(
        k === "arrowright" ? n : k === "arrowleft" ? -n : 0,
        k === "arrowup" ? n : k === "arrowdown" ? -n : 0,
      );
    }
  }
  async function importShapePack(file) {
    if (!file) return;
    try {
      if (!window.SAMIShapeImport)
        throw Error("Shape import engine is unavailable.");
      const parsed = await window.SAMIShapeImport.parse(file),
        remaining = Math.max(0, 250 - S.project.customAssets.length);
      if (!remaining)
        throw Error(
          "My shapes is full. Remove an unused shape before importing another pack.",
        );
      const added = [];
      for (const a of parsed.slice(0, remaining)) {
        if (!D.validParts(a.parts)) continue;
        const item = {
          kind: "my_" + C.uid().replaceAll("-", ""),
          name: String(a.name || "Imported shape").slice(0, 100),
          length: Math.max(0.1, Math.min(500, +a.length || 1)),
          width: Math.max(0.1, Math.min(500, +a.width || 1)),
          category: "My shapes",
          symbolPartsJSON: JSON.stringify(a.parts),
          symbolSpace: a.symbolSpace || "footprint",
          angle: 0,
          dimensionLocked:
            !a.needsScale &&
            ["Visio", "DXF"].includes(String(a.sourceFormat || ""))
              ? true
              : false,
          needsScale: !!a.needsScale,
          importedFrom: String(a.sourceName || file.name).slice(0, 180),
          sourceFormat: String(a.sourceFormat || "Imported").slice(0, 40),
        };
        S.project.customAssets.push(item);
        added.push(item);
      }
      if (!added.length) throw Error("No compatible shapes were found.");
      syncCatalogue();
      ui.asset = added[0].kind;
      ui.category = "My shapes";
      C.commit();
      const scaleCount = added.filter((a) => a.needsScale).length;
      C.toast(
        added.length +
          " shape" +
          (added.length === 1 ? "" : "s") +
          " imported." +
          (scaleCount ? " Confirm real dimensions before placement." : ""),
      );
      if (S.mode === "create") C.setMode(S.project.area ? "plan" : "map");
      C.openDrawer("assets");
    } catch (e) {
      C.toast(e.message || "The shape pack could not be imported.");
    }
  }
  function confirmAssetScale() {
    const a = getAsset();
    if (!a || a.dimensionLocked !== false) return;
    const l = +$("#customAssetLength")?.value,
      w = +$("#customAssetWidth")?.value;
    if (!(l >= 0.1 && l <= 500 && w >= 0.1 && w <= 500)) {
      C.toast("Enter real dimensions between 0.1 m and 500 m.");
      return;
    }
    a.length = l;
    a.width = w;
    a.needsScale = false;
    const saved = S.project.customAssets.find((x) => x.kind === a.kind);
    if (saved) Object.assign(saved, { length: l, width: w, needsScale: false });
    C.commit();
    C.renderDrawer("assets");
    C.toast("Real dimensions confirmed.");
  }
  function exportShapePack() {
    const assets = S.project.customAssets || [];
    if (!assets.length) {
      C.toast("My shapes is empty.");
      return;
    }
    try {
      const text = window.SAMIShapeImport.exportPack(assets),
        blob = new Blob([text], { type: "application/json" }),
        url = URL.createObjectURL(blob),
        a = document.createElement("a");
      a.href = url;
      a.download =
        (S.project.name || "SAMI").replace(/[^a-z0-9_-]+/gi, "_") +
        "_shapes.sami-shapes";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      C.toast(
        assets.length +
          " shape" +
          (assets.length === 1 ? "" : "s") +
          " exported.",
      );
    } catch (e) {
      C.toast(e.message || "Shape pack export failed.");
    }
  }
  function mount() {
    ensureProject(S.project);
    S.planLocked = false;
    syncCatalogue();
    $("#creatorWorkspace").hidden = true;
    $("#logoInput").onchange = (e) => {
      uploadLogo(e.target.files?.[0]);
      e.target.value = "";
    };
    $("#shapePackInput").onchange = (e) => {
      importShapePack(e.target.files?.[0]);
      e.target.value = "";
    };
    ($("#askCollapse") || {}).onclick = () => {
      document.body.classList.toggle("ask-collapsed");
      $("#askCollapse").setAttribute(
        "aria-expanded",
        String(!document.body.classList.contains("ask-collapsed")),
      );
    };
    ($("#baseCollapse") || {}).onclick = () => {
      document.body.classList.toggle("base-collapsed");
      $("#baseCollapse").setAttribute(
        "aria-expanded",
        String(!document.body.classList.contains("base-collapsed")),
      );
    };
    $("#snapToggle").onclick = () => {
      ui.snap = !ui.snap;
      S.options.snap = ui.snap;
      updateActiveTools();
    };
    $("#selectTool").onclick = () => {
      ui.method = "select";
      C.cancelDraw();
      updateActiveTools();
    };
    $$("[data-master]").forEach(
      (b) => (b.onclick = () => activateMaster(b.dataset.master)),
    );
    $("#quickAssets").onclick = () =>
      S.drawer === "assets" &&
      !document.body.classList.contains("inspector-collapsed")
        ? C.closeDrawer(true)
        : C.openDrawer("assets", true);
    $("#quickHelp").onclick = () => C.openDrawer("help", true);
    $("#selectionBar").onclick = (e) => {
      const action = e.target.closest("[data-action]")?.dataset.action;
      if (action === "deselectClose") {
        C.cancelDraw();
        S.selected = null;
        C.render();
        return;
      }
      if (action) C.runAction(action, e.target);
    };
    $("#muteSami").onclick = () => {
      const off = C.readPref("sami.voice.output") !== "off";
      C.setPref("sami.voice.output", off ? "off" : "on");
      if (off) stopAudio();
      C.updateVoiceButton();
    };
    document.addEventListener("keydown", keyboard, { capture: true });
    document.addEventListener("keyup", (e) => {
      if (e.code === "Space") {
        ui.panning = false;
        C.updateLock();
      }
    });
    window.addEventListener("blur", () => {
      ui.panning = false;
      C.updateLock();
    });
    const responsive = () => {
      const w = window.visualViewport?.width || innerWidth,
        h = window.visualViewport?.height || innerHeight;
      document.documentElement.style.setProperty("--app-height", h + "px");
      document.body.dataset.device =
        navigator.maxTouchPoints > 0
          ? w < 650
            ? "phone"
            : "tablet"
          : "desktop";
      S.map.invalidateSize({ pan: false });
    };
    window.visualViewport?.addEventListener("resize", responsive);
    window.addEventListener("resize", responsive);
    responsive();
    directObjectDrag();
    document.addEventListener("gesturestart", (e) => e.preventDefault(), {
      passive: false,
    });
    document.addEventListener("gesturechange", (e) => e.preventDefault(), {
      passive: false,
    });
    document.addEventListener(
      "wheel",
      (e) => {
        if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          if (e.target.closest("#map"))
            S.map.setZoom(S.map.getZoom() + (e.deltaY < 0 ? 0.25 : -0.25), {
              animate: false,
            });
        }
      },
      { passive: false, capture: true },
    );
    S.map.on("zoomend moveend", renderOhl);
    C.render();
    const last = Date.parse(S.project.meta?.ohlRefreshedAt || 0) || 0;
    if (
      S.project.area &&
      S.project.serviceVisibility?.ohl !== false &&
      (S.project.meta?.ohlStale || Date.now() - last > 24 * 60 * 60 * 1000)
    )
      setTimeout(() => refreshOhlSnapshot({ auto: true }), 1400);
  }
  function ringContains(p, ring) {
    if (C.pointInRingXY(p, ring)) return true;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const a = ring[j],
        b = ring[i],
        dx = b[0] - a[0],
        dy = b[1] - a[1],
        d2 = dx * dx + dy * dy,
        t = Math.max(
          0,
          Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (d2 || 1)),
        );
      if (Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy) < 0.002)
        return true;
    }
    return false;
  }
  function addPanelFill(ps, opt) {
    try {
      if (ps.length < 3) return;
      const clean = C.simplifyLine ? C.simplifyLine(ps, 0.25) : ps,
        pr = G.projection(clean[0]),
        ring = clean.map(pr.xy),
        ang = typeof opt.padBearing === "number" && Number.isFinite(opt.padBearing)
          ? opt.padBearing * Math.PI / 180
          : Math.atan2(ring[1][0] - ring[0][0], ring[1][1] - ring[0][1]),
        u = [Math.sin(ang), Math.cos(ang)],
        v = [Math.cos(ang), -Math.sin(ang)],
        local = ring.map((p) => [
          p[0] * u[0] + p[1] * u[1],
          p[0] * v[0] + p[1] * v[1],
        ]),
        xs = local.map((p) => p[0]),
        ys = local.map((p) => p[1]),
        l = +opt.length,
        w = +opt.width,
        stepL = l - (+opt.overlap || 0),
        stepW = w - (+opt.lateralOverlap || 0),
        id = C.uid(),
        fs = [];
      for (
        let x = Math.min(...xs) + l / 2;
        x <= Math.max(...xs) - l / 2 + 0.002;
        x += stepL
      ) {
        for (
          let y = Math.min(...ys) + w / 2;
          y <= Math.max(...ys) - w / 2 + 0.002;
          y += stepW
        ) {
          const corners = [
              [-l / 2, -w / 2],
              [l / 2, -w / 2],
              [l / 2, w / 2],
              [-l / 2, w / 2],
            ],
            points = corners.map(([dx, dy]) => [x + dx, y + dy]);
          if (!points.every((p) => ringContains(p, local))) continue;
          const candidate = [...points, points[0]],
            areaOf = (r) =>
              Math.abs(
                r.reduce((n, p, i) => {
                  const q = r[(i + 1) % r.length];
                  return n + p[0] * q[1] - p[1] * q[0];
                }, 0) / 2,
              ),
            intersection = window.polygonClipping.intersection(
              [candidate],
              [[...local, local[0]]],
            ),
            insideArea = intersection.reduce(
              (n, poly) =>
                n +
                areaOf(poly[0]) -
                poly.slice(1).reduce((s, r) => s + areaOf(r), 0),
              0,
            );
          if (insideArea < l * w - 0.015) continue;
          const c = pr.ll([x * u[0] + y * v[0], x * u[1] + y * v[1]]);
          fs.push(
            C.feature("panel", G.rectangle(c, l, w, (ang * 180) / Math.PI), {
              ...opt,
              label: opt.name,
              product: opt.product,
              length: l,
              width: w,
              angle: (ang * 180) / Math.PI,
              groupId: id,
              routeId: id,
              derived: true,
              dimensionLocked: opt.product !== "custom",
              includeLegend: true,
            }),
          );
          if (fs.length > 5000) throw Error("Fill is limited to 5,000 panels.");
        }
      }
      if (!fs.length)
        throw Error("The area is too small to contain a complete panel.");
      S.project.features.push(
        C.feature(
          "area",
          { type: "Polygon", coordinates: [[...clean, clean[0].slice()]] },
          {
            groupId: id,
            routeId: id,
            label: opt.name + " area",
            guideHidden: true,
            generated: true,
            includeLegend: false,
          },
        ),
        ...fs,
      );
      C.cancelDraw();
      S.selected = fs[0].id;
      C.commit();
      C.toast(fs.length + " complete panels placed in one group.");
    } catch (e) {
      C.toast(e.message);
    }
  }
  bindAssetPaletteDrag = function () {
    const box = $("#drawerContent");
    for (const btn of $$("[data-asset-drag]")) {
      const k = btn.dataset.assetDrag;
      if (k.startsWith("surface_")) continue;
      btn.ondragstart = (e) => {
        ui.asset = k;
        e.dataTransfer.effectAllowed = "copy";
        e.dataTransfer.setData("text/sami-asset", k);
      };
      let touch = null,
        ghost = null,
        timer = null;
      const reset = () => {
        clearTimeout(timer);
        ghost?.remove();
        ghost = null;
        touch = null;
      };
      btn.addEventListener("pointerdown", (e) => {
        if (e.pointerType === "mouse") return;
        touch = {
          id: e.pointerId,
          x: e.clientX,
          y: e.clientY,
          lastY: e.clientY,
          armed: false,
          scrolling: false,
        };
        btn.setPointerCapture?.(e.pointerId);
        timer = setTimeout(() => {
          if (!touch || touch.scrolling) return;
          touch.armed = true;
          ghost = document.createElement("div");
          ghost.className = "asset-drag-ghost";
          ghost.innerHTML = assetIconSVG(k, getAsset(k));
          ghost.style.left = touch.x + "px";
          ghost.style.top = touch.y + "px";
          document.body.appendChild(ghost);
        }, 240);
      });
      btn.addEventListener("pointermove", (e) => {
        if (!touch || e.pointerId !== touch.id) return;
        e.preventDefault();
        if (!touch.armed) {
          if (Math.hypot(e.clientX - touch.x, e.clientY - touch.y) > 8) {
            touch.scrolling = true;
            clearTimeout(timer);
          }
          if (touch.scrolling) box.scrollTop += touch.lastY - e.clientY;
          touch.lastY = e.clientY;
          return;
        }
        if (ghost) {
          ghost.style.left = e.clientX + "px";
          ghost.style.top = e.clientY + "px";
        }
      });
      btn.addEventListener("pointerup", (e) => {
        if (!touch) return;
        if (touch.armed || touch.scrolling) {
          e.preventDefault();
          e.stopPropagation();
          ui.dragging = true;
          if (touch.armed) C.placeAssetAtScreen(k, e.clientX, e.clientY);
          setTimeout(() => (ui.dragging = false), 250);
        }
        reset();
      });
      btn.addEventListener("pointercancel", reset);
    }
  };
  function directObjectDrag() {
    const el = $("#map");
    let drag = null,
      raf = 0;
    const pointerIds = new Set();
    const hit = (f, c) => {
      const g = f.geometry;
      if (g.type === "Polygon") return C.pointInRingXY(c, g.coordinates[0]);
      return false;
    };
    el.addEventListener(
      "pointerdown",
      (e) => {
        pointerIds.add(e.pointerId);
        if (pointerIds.size > 1) {
          if (drag) {
            drag.members.forEach((f, i) => Object.assign(f, drag.original[i]));
            drag = null;
            C.render();
            C.updateLock();
          }
          return;
        }
        if (
          e.target.closest(".leaflet-marker-icon") ||
          S.tool ||
          ui.panning ||
          e.button > 0
        )
          return;
        const f = C.selectedFeature(),
          members = C.groupMembers(f);
        if (!f || members.some((x) => x.properties.locked)) return;
        const c = C.screenToCoord(e);
        if (!members.some((f) => hit(f, c))) return;
        drag = {
          id: e.pointerId,
          start: c,
          members,
          original: members.map(copy),
          moved: false,
        };
        S.map.dragging.disable();
        el.setPointerCapture(e.pointerId);
        e.preventDefault();
        e.stopPropagation();
      },
      { capture: true },
    );
    el.addEventListener(
      "pointermove",
      (e) => {
        if (!drag || drag.id !== e.pointerId) return;
        const c = C.screenToCoord(e);
        if (G.distance(c, drag.start) < 0.02) return;
        drag.moved = true;
        const delta = [c[0] - drag.start[0], c[1] - drag.start[1]];
        drag.members.forEach((f, i) => {
          const source = drag.original[i];
          f.geometry = copy(source.geometry);
          const walk = (a) =>
            typeof a[0] === "number"
              ? [a[0] + delta[0], a[1] + delta[1]]
              : a.map(walk);
          f.geometry.coordinates = walk(f.geometry.coordinates);
          if (source.properties.centerLng != null) {
            f.properties.centerLng = source.properties.centerLng + delta[0];
            f.properties.centerLat = source.properties.centerLat + delta[1];
          }
        });
        if (!raf)
          raf = requestAnimationFrame(() => {
            raf = 0;
            if (!drag) return;
            for (const f of drag.members) {
              const layer = S.layers.get(f.id),
                g = f.geometry;
              if (!layer) continue;
              layer.eachLayer((l) => {
                if (l.setLatLngs)
                  l.setLatLngs(
                    L.GeoJSON.coordsToLatLngs(
                      g.coordinates,
                      g.type === "Polygon"
                        ? 1
                        : g.type === "MultiPolygon"
                          ? 2
                          : 0,
                    ),
                  );
                else if (l.setLatLng && g.type === "Point")
                  l.setLatLng(C.latlng(g.coordinates));
              });
            }
            symbolLayer?.draw();
          });
        e.preventDefault();
        e.stopPropagation();
      },
      { capture: true },
    );
    const stop = (e) => {
      pointerIds.delete(e.pointerId);
      if (!drag || drag.id !== e.pointerId) return;
      const data = drag;
      drag = null;
      if (e.type === "pointercancel")
        data.members.forEach((f, i) => Object.assign(f, data.original[i]));
      if (data.moved) {
        ui.dragging = true;
        C.commit();
        setTimeout(() => (ui.dragging = false), 180);
      }
      C.updateLock();
      el.releasePointerCapture?.(e.pointerId);
    };
    el.addEventListener("pointerup", stop, { capture: true });
    el.addEventListener("pointercancel", stop, { capture: true });
  }
  ui.smoothing = true;
  const primitiveParts = {
    rectangle: [D.P.rect(0, 0, 100, 100)],
    ellipse: [D.P.ellipse(0, 0, 100, 100)],
    triangle: [
      D.P.poly([
        [0, 100],
        [50, 0],
        [100, 100],
      ]),
    ],
    diamond: [
      D.P.poly([
        [50, 0],
        [100, 50],
        [50, 100],
        [0, 50],
      ]),
    ],
  };
  for (const [key, parts] of Object.entries(primitiveParts))
    ASSETS["shape_" + key] = {
      kind: "shape_" + key,
      name: key[0].toUpperCase() + key.slice(1),
      category: "Basic shapes",
      length: 4,
      width: 4,
      dimensionLocked: false,
      symbolPartsJSON: JSON.stringify(parts),
    };
  let dockReady = false;

  const oldOpenDrawer = openDrawer;
  openDrawer = function (k, reveal = false) {
    oldOpenDrawer(k, reveal);
    if (dockReady && k !== "create" && reveal) {
      $("#dockOptions").open = true;
      document.body.classList.remove("dock-collapsed");
      $("#drawer").removeAttribute("inert");
      $("#drawer").setAttribute("aria-hidden", "false");
    }
  };
  closeDrawer = function () {
    if (!dockReady) {
      O.closeDrawer();
      return;
    } /* Keep the selected tool's settings in the dock during drawing. */
  };
  const oldAssetsHTML = assetsHTML;
  assetsHTML = function () {
    const t = document.createElement("template");
    t.innerHTML = oldAssetsHTML();
    const categories = [...t.content.querySelectorAll(".asset-category")];
    const select = document.createElement("select");
    select.id = "itemCategory";
    select.setAttribute("aria-label", "Item category");
    for (const d of categories) {
      const opt = document.createElement("option");
      opt.value = d.dataset.category;
      opt.textContent = d.querySelector("summary").textContent;
      opt.selected = opt.value === ui.category;
      select.append(opt);
      if (!ui.search && d.dataset.category !== ui.category) d.remove();
      else {
        d.open = true;
        d.querySelector("summary").hidden = true;
      }
    }
    t.content.querySelector("#assetCategories").before(select);
    t.content.querySelector(".library-selection .master-grid")?.remove();
    return t.innerHTML;
  };
  const oldBindDrawer = bindDrawer;
  bindDrawer = function (k) {
    oldBindDrawer(k);
    if ($("#itemCategory"))
      $("#itemCategory").onchange = (e) => {
        ui.category = e.target.value;
        ui.search = "";
        C.renderDrawer("assets");
      };
  };
  function paintMembers(members) {
    for (const f of members) {
      const layer = S.layers.get(f.id),
        g = f.geometry;
      if (!layer) continue;
      layer.eachLayer((l) => {
        if (l.setLatLngs)
          l.setLatLngs(
            L.GeoJSON.coordsToLatLngs(
              g.coordinates,
              g.type === "Polygon"
                ? 1
                : g.type === "MultiPolygon"
                  ? 2
                  : g.type === "MultiLineString"
                    ? 1
                    : 0,
            ),
          );
        else if (l.setLatLng && g.type === "Point")
          l.setLatLng(C.latlng(g.coordinates));
      });
    }
    symbolLayer?.draw();
    const b = C.groupBounds(members.filter((x) => !x.properties.guideHidden));
    if (b && selectionBox)
      selectionBox.setBounds([
        [b[1], b[0]],
        [b[3], b[2]],
      ]);
  }
  function resetMembers(members, snapshot) {
    members.forEach((f, i) => {
      f.geometry = copy(snapshot[i].geometry);
      f.properties = copy(snapshot[i].properties);
    });
  }
  function editableDimensions(f) {
    return (
      f &&
      ["asset", "logo", "shape"].includes(f.properties.type) &&
      f.geometry.type === "Polygon" &&
      !f.properties.dimensionLocked
    );
  }
  function shapeMetrics(f) {
    const m = f.properties,
      b = G.boundsOf(f.geometry),
      center =
        m.centerLng != null
          ? [+m.centerLng, +m.centerLat]
          : [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
    return {
      center,
      length: +m.length || G.distance([b[0], b[1]], [b[0], b[3]]),
      width: +m.width || G.distance([b[0], b[1]], [b[2], b[1]]),
      angle: +m.angle || 0,
    };
  }
  function resizeObject(f, l, w, angle, center) {
    const m = f.properties,
      old = shapeMetrics(f),
      pr = G.projection(old.center),
      theta = (old.angle * Math.PI) / 180,
      u = [Math.sin(theta), Math.cos(theta)],
      v = [Math.cos(theta), -Math.sin(theta)],
      dest = G.projection(center),
      a = (angle * Math.PI) / 180,
      nu = [Math.sin(a), Math.cos(a)],
      nv = [Math.cos(a), -Math.sin(a)];
    const walk = (q) =>
      typeof q[0] === "number"
        ? (() => {
            const p = pr.xy(q),
              x = ((p[0] * u[0] + p[1] * u[1]) * l) / old.length,
              y = ((p[0] * v[0] + p[1] * v[1]) * w) / old.width;
            return dest.ll([x * nu[0] + y * nv[0], x * nu[1] + y * nv[1]]);
          })()
        : q.map(walk);
    f.geometry.coordinates = walk(f.geometry.coordinates);
    Object.assign(m, {
      length: l,
      width: w,
      angle,
      centerLng: center[0],
      centerLat: center[1],
    });
  }
  renderTransformHandles = function () {
    const f = C.selectedFeature(),
      members = C.groupMembers(f);
    if (!f || S.vertexEditId || members.some((x) => x.properties.locked))
      return;
    const b = C.groupBounds(members.filter((x) => !x.properties.guideHidden));
    if (!b) return;
    const center = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2],
      pr = G.projection(center),
      radius =
        Math.max(
          3,
          ...[
            [b[0], b[1]],
            [b[2], b[3]],
          ]
            .map(pr.xy)
            .map((p) => Math.hypot(...p)),
        ) +
        Math.max(
          2,
          S.map
            .containerPointToLatLng([30, 0])
            .distanceTo(S.map.containerPointToLatLng([0, 0])),
        );
    const handle = (pos, type, label, update) => {
      const marker = L.marker(C.latlng(pos), {
        draggable: true,
        zIndexOffset: 1500,
        icon: L.divIcon({
          className: "",
          html:
            '<div class="transform-control ' + type + '">' + label + "</div>",
          iconSize: [30, 30],
          iconAnchor: [15, 15],
        }),
      }).addTo(S.editGroup);
      let snapshot;
      marker.on("dragstart", () => {
        snapshot = members.map(copy);
        ui.dragging = true;
      });
      marker.on("drag", () => {
        if (!snapshot) snapshot = members.map(copy);
        resetMembers(members, snapshot);
        update(C.coord(marker.getLatLng()));
        paintMembers(members);
      });
      marker.on("dragend", () => {
        C.commit();
        setTimeout(() => (ui.dragging = false), 180);
      });
      return marker;
    };
    handle(center, "move", "✥", (p) =>
      C.translateMembers(members, [p[0] - center[0], p[1] - center[1]]),
    );
    handle(pr.ll([0, radius]), "rotate", "↻", (p) => {
      const q = pr.xy(p);
      C.rotateMembers(
        members,
        center,
        (Math.atan2(q[0], q[1]) * 180) / Math.PI,
      );
    });
    if (members.length === 1 && editableDimensions(f)) {
      const mt = shapeMetrics(f),
        theta = (mt.angle * Math.PI) / 180,
        u = [Math.sin(theta), Math.cos(theta)],
        v = [Math.cos(theta), -Math.sin(theta)],
        fp = G.projection(mt.center);
      for (const [sx, sy] of [
        [1, 1],
        [1, 0],
        [0, 1],
        [-1, -1],
        [-1, 1],
        [1, -1],
      ]) {
        const pos = fp.ll([
          (u[0] * sx * mt.length) / 2 + (v[0] * sy * mt.width) / 2,
          (u[1] * sx * mt.length) / 2 + (v[1] * sy * mt.width) / 2,
        ]);
        handle(pos, "resize", "□", (p) => {
          const q = fp.xy(p),
            x = q[0] * u[0] + q[1] * u[1],
            y = q[0] * v[0] + q[1] * v[1];
          resizeObject(
            f,
            sx ? Math.min(500, Math.max(0.1, Math.abs(x) * 2)) : mt.length,
            sy ? Math.min(500, Math.max(0.1, Math.abs(y) * 2)) : mt.width,
            mt.angle,
            mt.center,
          );
        });
      }
    }
  };
  const oldSelectionHTML = selectionHTML;
  selectionHTML = function () {
    const f = C.selectedFeature();
    let h = oldSelectionHTML();
    if (!f) return h;
    const m = f.properties,
      members = C.groupMembers(f),
      locked = members.some((x) => x.properties.locked);
    h = h
      .replace(
        '<details class="style-editor"',
        '<details open class="style-editor"',
      )
      .replace(
        'min="0.5" max="12" step="0.5"',
        'min="0.1" max="12" step="0.1"',
      );
    h =
      '<div class="selection-quick">' +
      B("Group", "editGroup") +
      B("Ungroup", "editUngroup") +
      B("Duplicate", "editDuplicate") +
      B("Delete", "editDelete") +
      "</div>" +
      h;
    if (!locked && members.length === 1 && editableDimensions(f)) {
      const p = shapeMetrics(f);
      h +=
        C.section("Dimensions") +
        '<div class="row equal"><div>' +
        F(
          "shapeLength",
          "Length (m)",
          +p.length.toFixed(3),
          "number",
          'min="0.1" max="500" step="0.01"',
        ) +
        "</div><div>" +
        F(
          "shapeWidth",
          "Width (m)",
          +p.width.toFixed(3),
          "number",
          'min="0.1" max="500" step="0.01"',
        ) +
        "</div></div>" +
        F(
          "shapeAngle",
          "Rotation (°)",
          +p.angle.toFixed(2),
          "number",
          'step="1"',
        ) +
        B("Apply dimensions", "shapeDimensions", true);
    }
    h +=
      C.checkedRow(
        "Fill enabled",
        'id="shapeFillEnabled"',
        m.fillEnabled !== false,
      ) +
      C.checkedRow(
        "Outline enabled",
        'id="shapeOutlineEnabled"',
        m.outlineEnabled !== false,
      ) +
      B("Apply fill & outline", "shapeAppearance");
    if (
      (!locked &&
        !m.dimensionLocked &&
        ["Polygon", "MultiPolygon", "LineString", "MultiLineString"].includes(
          f.geometry.type,
        )) ||
      (!locked && m.type === "panel")
    )
      h +=
        C.section("Add to selected item") +
        '<div class="master-grid">' +
        [
          ["line", "Point line"],
          ["area", "Point area"],
          ["freeLine", "Freehand line"],
          ["freeArea", "Freehand area"],
        ]
          .map(([k, n]) => B(n, "extend:" + k))
          .join("") +
        '</div><p class="subtle">Start on this item. Areas join back to it. Panel additions use its existing orientation and grid.</p>';
    return h;
  };
  const oldFeatureStyle = featureStyle;
  featureStyle = function (f) {
    const st = oldFeatureStyle(f),
      m = f.properties;
    if (m.fillEnabled === false) st.fillOpacity = 0;
    if (m.outlineEnabled === false) st.weight = 0;
    if (m.type === "ohlCable")
      return {
        ...st,
        color: m.styleColor || "#8c407a",
        weight: m.outlineEnabled === false ? 0 : +m.styleWeight || 1.2,
        fill: false,
        dashArray: null,
      };
    return st;
  };
  const oldRunAction = runAction;
  runAction = async function (a, el) {
    const f = C.selectedFeature();
    if (a === "shareSami") {
      await shareSami();
      return;
    }
    if (a === "saveSami") {
      C.exportProjectJSON();
      return;
    }
    if (a === "shapeDimensions") {
      if (!f || !editableDimensions(f) || f.properties.locked) return;
      const l = +$("#shapeLength").value,
        w = +$("#shapeWidth").value,
        angle = +$("#shapeAngle").value;
      if (!(
        l >= 0.1 &&
        l <= 500 &&
        w >= 0.1 &&
        w <= 500 &&
        Number.isFinite(angle)
      )) {
        C.toast("Use dimensions from 0.1 to 500 m.");
        return;
      }
      resizeObject(f, l, w, angle, shapeMetrics(f).center);
      C.commit();
      C.renderDrawer("selection");
      return;
    }
    if (a === "shapeAppearance") {
      if (!f || C.groupMembers(f).some((x) => x.properties.locked)) return;
      for (const x of C.groupMembers(f)) {
        x.properties.fillEnabled = $("#shapeFillEnabled").checked;
        x.properties.outlineEnabled = $("#shapeOutlineEnabled").checked;
      }
      C.commit();
      return;
    }
    if (a.startsWith("extend:")) {
      startExtension(a.split(":")[1]);
      return;
    }
    return oldRunAction(a, el);
  };
  async function shareSami() {
    await window.SAMIWorkspace?.save?.(true, "Before sharing");
    const name =
        (S.project.name || "Site").replace(/[^a-z0-9_-]+/gi, "_") + ".sami",
      file = new File([JSON.stringify(S.project)], name, {
        type: "application/json",
      });
    try {
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: S.project.name });
        return;
      }
    } catch (e) {
      if (e.name === "AbortError") return;
    }
    C.exportProjectJSON();
    C.toast(
      "Send the .sami file to another user. They can open it from Project.",
    );
  }
  const oldProjectHTML = projectHTML;
  projectHTML = function () {
    return (
      '<div class="row equal">' +
      B("Save .sami file", "saveSami", true) +
      B("Share project file", "shareSami") +
      '</div><p class="subtle">Includes drawings, custom items, logos and saved map records. Recipients use Project → Import to edit their own copy.</p>' +
      oldProjectHTML()
    );
  };
  const oldHelpHTML = helpHTML;
  helpHTML = function () {
    return (
      '<p class="subtle">Tap an item once for Properties. Drag its body or centre to move; use ↻ to rotate. Editable items have side and corner handles. Trakway dimensions stay fixed.</p><p class="subtle">The canvas-first inspector changes with your stage and selection. Collapse it when you need maximum map space. Smoothing is on for new freehand strokes.</p>' +
      oldHelpHTML()
    );
  };
  const oldMount = mount;
  mount = function () {
    oldMount();
  };
  const oldOpenCreator = openCreator;
  openCreator = function () {
    oldOpenCreator();
    if (dockReady) {
      const tools = $(".creator-tools");
      $("#dockBuilder .dock-body").replaceChildren(tools);
      $("#dockBuilder").hidden = false;
      $("#dockBuilder").open = true;
      $("#dockOptions").open = false;
      tools.onclick = (e) => {
        const a = e.target.closest("[data-create]")?.dataset.create;
        if (a) creatorAction(a);
      };
    }
  };
  const oldSetMode = setMode;
  setMode = function (mode) {
    const result = oldSetMode(mode);
    if (dockReady) {
      $("#dockBuilder").hidden = mode !== "create";
      if (mode === "create") $("#dockAssistant").open = true;
    }
    return result;
  };
  function partBounds(p) {
    const pts =
      p.points ||
      (p.type === "line" && [
        [p.x, p.y],
        [p.x2, p.y2],
      ]);
    return pts
      ? [
          Math.min(...pts.map((x) => x[0])),
          Math.min(...pts.map((x) => x[1])),
          Math.max(...pts.map((x) => x[0])),
          Math.max(...pts.map((x) => x[1])),
        ]
      : [p.x, p.y, p.x + p.w, p.y + p.h];
  }
  function scalePart(p, from, to) {
    const sx = (to[2] - to[0]) / (from[2] - from[0] || 1),
      sy = (to[3] - to[1]) / (from[3] - from[1] || 1),
      pt = (q) => [
        to[0] + (q[0] - from[0]) * sx,
        to[1] + (q[1] - from[1]) * sy,
      ];
    if (p.points) p.points = p.points.map(pt);
    else if (p.type === "line") {
      [p.x, p.y] = pt([p.x, p.y]);
      [p.x2, p.y2] = pt([p.x2, p.y2]);
    } else
      Object.assign(p, {
        x: to[0],
        y: to[1],
        w: to[2] - to[0],
        h: to[3] - to[1],
      });
  }
  drawCreator = function () {
    const c = creatorState(),
      svg = $("#creatorCanvas");
    if (!svg) return;
    svg.setAttribute("preserveAspectRatio", "none");
    const board = $(".creator-artboard"),
      rect = board?.getBoundingClientRect(),
      maxW = Math.max(120, (rect?.width || 700) - 56),
      maxH = Math.max(120, (rect?.height || 540) - 100),
      ratio = c.length / c.width,
      w = Math.min(maxW, maxH * ratio);
    svg.style.width = w + "px";
    svg.style.height = w / ratio + "px";
    svg.style.aspectRatio = String(ratio);
    $("#creatorSize").textContent = c.length + " × " + c.width + " m";
    let html = c.parts
      .map(
        (p, i) =>
          `<g data-part="${i}" class="${c.selected === i ? "selected-part" : ""}">${D.svgParts([p], { styleFill: "#93baa9" })}</g>`,
      )
      .join("");
    const p = c.parts[c.selected];
    if (p) {
      const b = partBounds(p),
        xs = [b[0], (b[0] + b[2]) / 2, b[2]],
        ys = [b[1], (b[1] + b[3]) / 2, b[3]];
      html += `<rect x="${b[0]}" y="${b[1]}" width="${b[2] - b[0]}" height="${b[3] - b[1]}" fill="none" stroke="#087c64" stroke-width="1" vector-effect="non-scaling-stroke"/>`;
      for (let x = 0; x < 3; x++)
        for (let y = 0; y < 3; y++) {
          if (x === 1 && y === 1) continue;
          html += `<rect data-part-handle="${x},${y}" x="${xs[x] - 2}" y="${ys[y] - 2}" width="4" height="4" fill="white" stroke="#087c64" stroke-width="1.2" vector-effect="non-scaling-stroke"/>`;
        }
    }
    $("#creatorParts").innerHTML = html;
    const props = $("#creatorProps");
    if (!p) {
      props.innerHTML =
        '<p class="subtle">Select a part to move, resize or colour it.</p>';
      return;
    }
    const b = partBounds(p);
    props.innerHTML =
      "<strong>Part " +
      (c.selected + 1) +
      '</strong><div class="part-props">' +
      [
        ["x", (b[0] * c.length) / 100],
        ["y", (b[1] * c.width) / 100],
        ["length", ((b[2] - b[0]) * c.length) / 100],
        ["width", ((b[3] - b[1]) * c.width) / 100],
      ]
        .map(([k, v]) =>
          F(
            "part_" + k,
            k + " (m)",
            +v.toFixed(3),
            "number",
            'step="0.01" min="0"',
          ),
        )
        .join("") +
      '<label>Fill<input type="color" id="partFill" value="' +
      colour(p.fill) +
      '"></label><label>Outline<input type="color" id="partStroke" value="' +
      colour(p.stroke) +
      '"></label></div>';
    props.onchange = (e) => {
      creatorPush();
      if (e.target.id === "partFill") p.fill = e.target.value;
      else if (e.target.id === "partStroke") p.stroke = e.target.value;
      else {
        const x = (Math.max(0, +$("#part_x").value) * 100) / c.length,
          y = (Math.max(0, +$("#part_y").value) * 100) / c.width,
          l = (Math.max(0.01, +$("#part_length").value) * 100) / c.length,
          w = (Math.max(0.01, +$("#part_width").value) * 100) / c.width;
        scalePart(p, b, [x, y, Math.min(100, x + l), Math.min(100, y + w)]);
      }
      drawCreator();
    };
  };
  bindCreatorDrag = function () {
    const canvas = $("#creatorCanvas");
    let drag;
    const pos = (e) => {
      const r = canvas.getBoundingClientRect();
      return [
        ((e.clientX - r.left) / r.width) * 120 - 10,
        ((e.clientY - r.top) / r.height) * 120 - 10,
      ];
    };
    canvas.onpointerdown = (e) => {
      const handle = e.target.closest("[data-part-handle]"),
        part = e.target.closest("[data-part]");
      if (!part && !handle) return;
      const c = creatorState();
      if (part) c.selected = +part.dataset.part;
      creatorPush();
      drag = {
        id: e.pointerId,
        start: pos(e),
        part: copy(c.parts[c.selected]),
        handle: handle?.dataset.partHandle?.split(",").map(Number),
      };
      canvas.setPointerCapture(e.pointerId);
      drawCreator();
      e.preventDefault();
    };
    canvas.onpointermove = (e) => {
      if (!drag || drag.id !== e.pointerId) return;
      const c = creatorState(),
        q = pos(e),
        p = copy(drag.part),
        b = partBounds(p),
        to = [...b];
      if (drag.handle) {
        const [x, y] = drag.handle;
        if (x === 0) to[0] = Math.max(0, Math.min(b[2] - 0.1, q[0]));
        if (x === 2) to[2] = Math.min(100, Math.max(b[0] + 0.1, q[0]));
        if (y === 0) to[1] = Math.max(0, Math.min(b[3] - 0.1, q[1]));
        if (y === 2) to[3] = Math.min(100, Math.max(b[1] + 0.1, q[1]));
      } else {
        const dx = Math.max(-b[0], Math.min(100 - b[2], q[0] - drag.start[0])),
          dy = Math.max(-b[1], Math.min(100 - b[3], q[1] - drag.start[1]));
        to.splice(0, 4, b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy);
      }
      scalePart(p, b, to);
      c.parts[c.selected] = p;
      drawCreator();
      e.preventDefault();
    };
    canvas.onpointerup = () => (drag = null);
    canvas.onpointercancel = () => {
      if (drag) creatorState().parts[creatorState().selected] = drag.part;
      drag = null;
      drawCreator();
    };
  };
  const oldAskAssetDesign = askAssetDesign;
  askAssetDesign = async function (q) {
    const t = q.toLowerCase(),
      c = creatorState(),
      selected = c.parts[c.selected],
      dims = q.match(
        /(\d+(?:\.\d+)?)\s*(?:m|metres?)?\s*(?:x|by|×)\s*(\d+(?:\.\d+)?)/i,
      ),
      colors = {
        green: "#63a985",
        red: "#cb5252",
        blue: "#4d8cce",
        yellow: "#e3c45c",
        orange: "#dd9346",
        white: "#ffffff",
        black: "#26302b",
      };
    let done = false;
    if (/\bundo\b/.test(t)) {
      creatorAction("undo");
      done = true;
    } else if (/\b(delete|remove)\b/.test(t) && selected) {
      creatorAction("delete");
      done = true;
    } else if (/\b(duplicate|copy)\b/.test(t) && selected) {
      creatorAction("duplicate");
      done = true;
    } else if (
      /\b(colou?r|make|paint)\b/.test(t) &&
      selected &&
      Object.keys(colors).some((k) => t.includes(k))
    ) {
      creatorPush();
      selected.fill = colors[Object.keys(colors).find((k) => t.includes(k))];
      done = true;
    } else if (/\b(resize|dimensions|footprint)\b/.test(t) && dims) {
      creatorPush();
      c.length = Math.max(0.1, Math.min(500, +dims[1]));
      c.width = Math.max(0.1, Math.min(500, +dims[2]));
      done = true;
    } else if (
      /\b(add|draw|create)\b/.test(t) &&
      /\b(rectangle|square|circle|ellipse|triangle|line)\b/.test(t)
    ) {
      const kind = /rectangle|square/.test(t)
        ? "rect"
        : /circle|ellipse/.test(t)
          ? "ellipse"
          : /triangle/.test(t)
            ? "triangle"
            : "line";
      creatorAction(kind);
      const p = c.parts[c.selected];
      if (dims && p.w != null) {
        p.w = Math.min(100, (+dims[1] * 100) / c.length);
        p.h = Math.min(100, (+dims[2] * 100) / c.width);
        p.x = Math.max(0, Math.min(p.x, 100 - p.w));
        p.y = Math.max(0, Math.min(p.y, 100 - p.h));
      }
      done = true;
    }
    if (done) {
      drawCreator();
      C.samiSay(
        "Updated your asset design. You can adjust the selected part using its handles or dimensions.",
      );
      return;
    }
    await oldAskAssetDesign(q);
  };
  function startExtension(method) {
    const f = C.selectedFeature(),
      members = C.groupMembers(f);
    if (!f || members.some((x) => x.properties.locked)) return;
    const id = f.id;
    C.startTool(
      method === "line"
        ? "route"
        : method === "freeLine"
          ? "routeFreehand"
          : method === "area"
            ? "area"
            : "areaFreehand",
      {
        extendTarget: id,
        extendMethod: method,
        smoothing: ui.smoothing,
        snap: ui.snap,
        label: "Add to " + (f.properties.label || "item"),
      },
    );
    S.selected = id;
    $("#toolName").textContent = "Add to selected item";
    $("#drawHint").textContent = method.toLowerCase().includes("area")
      ? "Start on the item, outline the addition, then return to the item."
      : "Start on the item and draw the continuation.";
    C.render();
  }
  function geometryPolys(g) {
    return g.type === "Polygon"
      ? [g.coordinates]
      : g.type === "MultiPolygon"
        ? g.coordinates
        : [];
  }
  function geometryArea(ps) {
    const ring = (r) =>
      Math.abs(
        r.reduce((n, p, i) => {
          const q = r[(i + 1) % r.length];
          return n + p[0] * q[1] - p[1] * q[0];
        }, 0) / 2,
      );
    return ps.reduce(
      (s, p) => s + ring(p[0]) - p.slice(1).reduce((s, r) => s + ring(r), 0),
      0,
    );
  }
  function extensionFill(target, members, addition) {
    const m = target.properties,
      center = C.featureCenter(target),
      pr = G.projection(center),
      ring = target.geometry.coordinates[0],
      r0 = pr.xy(ring[0]),
      r1 = pr.xy(ring[1]),
      heading = Math.atan2(r1[0] - r0[0], r1[1] - r0[1]),
      u = [Math.sin(heading), Math.cos(heading)],
      v = [Math.cos(heading), -Math.sin(heading)],
      local = (c) => {
        const p = pr.xy(c);
        return [p[0] * u[0] + p[1] * u[1], p[0] * v[0] + p[1] * v[1]];
      },
      world = (p) =>
        pr.ll([p[0] * u[0] + p[1] * v[0], p[0] * u[1] + p[1] * v[1]]),
      polys = geometryPolys(addition).map((p) => p.map((r) => r.map(local))),
      l = +m.length,
      w = +m.width,
      sl = l - (+m.overlap || 0),
      sw = w - (+m.lateralOverlap || 0),
      bounds = G.boundsOf(addition),
      corners = [
        [bounds[0], bounds[1]],
        [bounds[2], bounds[1]],
        [bounds[2], bounds[3]],
        [bounds[0], bounds[3]],
      ].map(local),
      xs = corners.map((p) => p[0]),
      ys = corners.map((p) => p[1]),
      occupied = new Set(
        members
          .filter((x) => x.properties.type === m.type)
          .map((x) => {
            const p = local(C.featureCenter(x));
            return Math.round(p[0] / sl) + "," + Math.round(p[1] / sw);
          }),
      ),
      fs = [],
      gid = m.groupId || C.uid();
    let candidates = 0;
    for (
      let ix = Math.floor(Math.min(...xs) / sl) - 1;
      ix <= Math.ceil(Math.max(...xs) / sl) + 1;
      ix++
    )
      for (
        let iy = Math.floor(Math.min(...ys) / sw) - 1;
        iy <= Math.ceil(Math.max(...ys) / sw) + 1;
        iy++
      ) {
        if (++candidates > 40000) throw Error("Draw a smaller extension.");
        if (occupied.has(ix + "," + iy)) continue;
        const x = ix * sl,
          y = iy * sw,
          p = [
            [x - l / 2, y - w / 2],
            [x + l / 2, y - w / 2],
            [x + l / 2, y + w / 2],
            [x - l / 2, y + w / 2],
            [x - l / 2, y - w / 2],
          ],
          intersection = window.polygonClipping.intersection([p], polys);
        if (geometryArea(intersection) < l * w - 0.02) continue;
        const c = world([x, y]);
        fs.push(
          C.feature(m.type, G.rectangle(c, l, w, (heading * 180) / Math.PI), {
            ...copy(m),
            groupId: gid,
            routeId: m.routeId || gid,
            angle: (heading * 180) / Math.PI,
            centerLng: c[0],
            centerLat: c[1],
            guideHidden: false,
          }),
        );
        if (fs.length > 5000)
          throw Error("Extension is limited to 5,000 items.");
      }
    if (!fs.length)
      throw Error(
        "The extension contains no new complete items on the existing grid.",
      );
    members.forEach((x) => (x.properties.groupId = gid));
    S.project.features.push(...fs);
    return fs.length;
  }
  function finishExtension(ps, opt) {
    const f = S.project.features.find((x) => x.id === opt.extendTarget);
    if (!f) throw Error("Select the item again.");
    const members = C.groupMembers(f),
      area = /area/i.test(opt.extendMethod);
    if (ps.length < (area ? 3 : 2)) return false;
    const pr = G.projection(ps[0]),
      tolerance = 0.7,
      touches = (p) =>
        members.some((x) => {
          const g = x.geometry;
          if (
            ["Polygon", "MultiPolygon"].includes(g.type) &&
            geometryPolys(g).some((poly) => C.pointInRingXY(p, poly[0]))
          )
            return true;
          const lines =
            g.type === "Polygon"
              ? g.coordinates
              : g.type === "MultiPolygon"
                ? g.coordinates.flat()
                : g.type === "LineString"
                  ? [g.coordinates]
                  : g.type === "MultiLineString"
                    ? g.coordinates
                    : [];
          const q = pr.xy(p);
          return lines.some((r) =>
            r.slice(1).some((b, i) => {
              const a = pr.xy(r[i]),
                z = pr.xy(b),
                dx = z[0] - a[0],
                dy = z[1] - a[1],
                t = Math.max(
                  0,
                  Math.min(
                    1,
                    ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) /
                      (dx * dx + dy * dy || 1),
                  ),
                );
              return (
                Math.hypot(q[0] - a[0] - t * dx, q[1] - a[1] - t * dy) <=
                tolerance
              );
            }),
          );
        });
    if (!touches(ps[0]) || (area && !touches(ps.at(-1))))
      throw Error(
        area
          ? "Start and finish on the selected item to join this area."
          : "Start on the selected item to continue it.",
      );
    const tiled =
      ["panel", "asset", "logo"].includes(f.properties.type) &&
      f.properties.length &&
      f.properties.width;
    let addition;
    if (area)
      addition = { type: "Polygon", coordinates: [[...ps, ps[0].slice()]] };
    else if (tiled || ["Polygon", "MultiPolygon"].includes(f.geometry.type))
      addition = G.lineBuffer(ps, +f.properties.width || 4);
    if (tiled) {
      const existing = members.flatMap((x) => geometryPolys(x.geometry));
      const joined = window.polygonClipping.union(
        ...existing,
        ...geometryPolys(addition),
      );
      extensionFill(f, members, { type: "MultiPolygon", coordinates: joined });
    } else if (addition) {
      const merged = window.polygonClipping.union(
        ...geometryPolys(f.geometry),
        ...geometryPolys(addition),
      );
      f.geometry =
        merged.length === 1
          ? { type: "Polygon", coordinates: merged[0] }
          : { type: "MultiPolygon", coordinates: merged };
      delete f.properties.length;
      delete f.properties.width;
      delete f.properties.centerLng;
      delete f.properties.centerLat;
      f.properties.shapeKind = "area";
    } else {
      const lines =
        f.geometry.type === "LineString"
          ? [f.geometry.coordinates]
          : f.geometry.coordinates;
      const first = lines[0],
        last = lines.at(-1);
      if (G.distance(ps[0], last.at(-1)) <= tolerance)
        last.push(...ps.slice(1));
      else if (G.distance(ps[0], first[0]) <= tolerance)
        first.unshift(...ps.slice(1).reverse());
      else lines.push(ps);
      f.geometry =
        lines.length === 1
          ? { type: "LineString", coordinates: lines[0] }
          : { type: "MultiLineString", coordinates: lines };
    }
    C.cancelDraw();
    S.selected = f.id;
    C.commit();
    C.openDrawer("selection");
    C.toast("Added to the selected item.");
    return true;
  }
  const oldStartTool = startTool;
  startTool = function (t, o = {}) {
    oldStartTool(t, { ...o, smoothing: ui.smoothing });
  };
  const oldFinishDraw = finishDraw;
  finishDraw = function () {
    const opt = S.options,
      t = S.tool;
    if (C.isFreehandTool(t) && ui.smoothing)
      S.points = G.smooth(S.points, 0.3, /area|hazard|excavation/i.test(t));
    if (opt.extendTarget) {
      try {
        finishExtension(copy(S.points), opt);
      } catch (e) {
        C.toast(e.message);
      }
      return;
    }
    oldFinishDraw();
  };
  TYPES.ohlCable = "Overhead cable";
  const oldChooseSupport = chooseOhlSupport;
  chooseOhlSupport = function (id, key) {
    oldChooseSupport(id, key);
    const old = $("#modalBody").onclick;
    $("#modalBody").onclick = (e) => {
      if (e.target.closest('[data-action="saveSupport"]')) {
        const kind = $("#supportKind").value,
          ref = $("#supportRef").value.trim(),
          voltage = $("#supportVoltage").value.trim();
        if (kind !== "unknown") commitSupport(id, key, kind, ref, voltage);
      }
      old(e);
    };
  };
  function commitSupport(id, key, kind, ref, voltage) {
    const source = S.project.features.find((x) => x.id === id),
      position = supports(source).find((p) => supportKey(p) === key);
    if (!position) return;
    const existing = S.project.features.find(
        (x) => x.properties.ohlNodeKey === key,
      ),
      size = kind === "pole" || kind === "terminal" ? 0.55 : 7,
      m = {
        kind: kind === "pole" || kind === "terminal" ? "pole" : "tower",
        label: [
          kind === "pole"
            ? "Pole"
            : kind === "portal"
              ? "Portal"
              : kind === "terminal"
                ? "OHL terminal"
                : "Tower",
          ref,
          voltageLabel(voltage),
        ]
          .filter(Boolean)
          .join(" · "),
        length: size,
        width: size,
        dimensionLocked: false,
        centerLng: position[0],
        centerLat: position[1],
        angle: 0,
        fillEnabled: false,
        styleFill: "none",
        styleColor:
          S.project.serviceStyles?.ohl?.color ||
          SERVICES?.ohl?.color ||
          "#923374",
        ohlNodeKey: key,
        assetRef: ref,
        voltage,
        source: source.properties.source,
        verification: "User selected mapped record",
        includeLegend: true,
      };
    if (existing) {
      Object.assign(existing.properties, m);
      existing.geometry = G.rectangle(position, size, size, 0);
    } else
      S.project.features.push(
        C.feature("asset", G.rectangle(position, size, size, 0), m),
      );
    for (const line of S.project.features
      .slice()
      .filter(
        (x) =>
          x.properties.type === "service" &&
          x.properties.serviceType === "ohl" &&
          supports(x).some((p) => supportKey(p) === key),
      )) {
      if (!["LineString", "MultiLineString"].includes(line.geometry.type))
        continue;
      const sourceKey = String(line.properties.osmWayId || line.id);
      if (
        S.project.features.some((x) => x.properties.ohlSourceKey === sourceKey)
      )
        continue;
      const geometry = copy(line.geometry);
      S.project.features.push(
        C.feature("ohlCable", geometry, {
          label: line.properties.label || "Overhead cable",
          voltage: line.properties.voltage || voltage,
          lineRef: line.properties.lineRef || "",
          source: line.properties.source,
          ohlSourceKey: sourceKey,
          committed: true,
          includeLegend: true,
          styleColor: "#8c407a",
          styleWeight: 1.2,
        }),
      );
    }
  }
  const oldVisibleFeature = visibleFeature;
  visibleFeature = function (f) {
    if (f.properties.type === "ohlCable") {
      if (f.properties.hidden || S.project.hiddenTypes.includes("ohlCable"))
        return null;
      const geometry = G.clipGeometry(
        f.geometry,
        S.mode === "plan" ? C.planBounds() : C.serviceBounds(),
      );
      return geometry ? { ...f, geometry } : null;
    }
    return oldVisibleFeature(f);
  };
  const oldRenderOhl = renderOhl;
  renderOhl = function () {
    oldRenderOhl();
    for (const f of S.project.features.filter((x) => x.properties.ohlNodeKey)) {
      for (const marker of S.ohlSupportGroup.getLayers())
        if (
          marker.getLatLng &&
          supportKey(C.coord(marker.getLatLng())) === f.properties.ohlNodeKey
        )
          S.ohlSupportGroup.removeLayer(marker);
    }
  };
  const renderWithCommittedLabels = render;
  render = function () {
    renderWithCommittedLabels();
    for (const f of S.project.features) {
      if (!f.properties.ohlNodeKey && !f.properties.ohlSourceKey) continue;
      const m = f.properties,
        label = [m.assetRef || m.lineRef, voltageLabel(m.voltage)]
          .filter(Boolean)
          .join(" · ");
      if (label)
        S.layers.get(f.id)?.bindTooltip(esc(label), {
          permanent: S.map.getZoom() >= 17,
          direction: "center",
          className: "map-label ohl-label",
        });
    }
  };
  return {
    ui,
    syncCatalogue,
    activateMaster,
    shapeMetrics,
    openCreator,
    fresh,
    normaliseProject,
    planBounds,
    featureStyle,
    visibleFeature,
    assetIconSVG,
    renderAssetIllustrations,
    supportIcon,
    chooseOhlSupport,
    render,
    updateLock,
    setMode,
    setModeUI,
    fitArea,
    openDrawer,
    closeDrawer,
    assetsHTML,
    drawHTML,
    startTool,
    isFreehandTool,
    onMapClick,
    renderDraft,
    finishDraw,
    placeItem,
    placeAssetAtScreen,
    bindAssetPaletteDrag,
    layersHTML,
    renderTransformHandles,
    selectionHTML,
    editAction,
    routeToSiteHTML,
    planHgvRoute,
    projectHTML,
    initVoice,
    speakOptional,
    helpHTML,
    renderDrawer,
    bindDrawer,
    runAction,
    handleCommand,
    overpassFeatures,
    refreshOhlSnapshot,
    updateLaunchGate,
    initToolRail,
    clampRail,
    initFreehandInput,
    addPanelFill,
    mount,
  };
};
